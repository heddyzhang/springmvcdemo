package spt.kessai.kessai.print;

import java.sql.Connection;

import spt.kessai.kessai.Kessai_Sver;
import spt.kessai.kessaiComn.ComnSver;
import spt.kessai.kessaiComn.KessaiUtil;
import spt.sptComn.sptException;
import spt.sptComn.sptList;

/**
 * ���و�������T�[�o�[ DB������vrq����ł͂Ȃ�java������悤�ɂ������ߒǉ�
 * @author shima@NPC 2006/05/11
 * @version 1.00
 */
public class KessaiPrintSver {

    private ComnSver sver;
    private Connection conn;

    /**
     * �C�j�V�����C�Y
     * @param conn Connection
     */
    public void init( Connection conn ){
        this.sver = new ComnSver( conn );
        this.conn = conn;
    }

    /**
     * �������������擾����
     * @param qno Q/#
     * @param rev REVISION
     * @param ysflg �\�Z�����t���O
     * @return �������
     * @throws sptException
     */
    public sptList getPrintLstSeisiki(
      String qno
    , String rev
    , String ysflg
    ) throws sptException {

        StringBuffer sb = new StringBuffer("");
        sb.append("SELECT SPURT_NO \n");
        sb.append("     , REV \n");
        sb.append("     , YS_FLG \n");
        sb.append("     , SAKUSEIBU \n");
        sb.append("     , SAKUSEIKA \n");
        sb.append("     , SYURUI \n");
        sb.append("     , JOBGR_CODE \n");
        sb.append("     , BU_CODE \n");
        sb.append("     , MI_FORM \n");
        sb.append("     , KEIYAKU_CODE \n");
        sb.append("     , MT_KAITO_NITIGEN \n");
        sb.append("     , PLANT_CODE \n");
        sb.append("     , TANTO_NAME \n");
        sb.append("     , KEY_QNO \n");
        sb.append("     , QNO \n");
        sb.append("     , KYAKU_TAN_KA_NAME \n");
        sb.append("     , KYAKU_TAN_NAME \n");
        sb.append("     , JISSI_JIKI \n");
        sb.append("     , KYAKU_KEIYAKU_NO \n");
        sb.append("     , YOKYU_NOKI \n");
        sb.append("     , CHUMONBI \n");
        sb.append("     , TEIKEN_KAISU \n");
        sb.append("     , ONO \n");
        sb.append("     , KOKI_FROM \n");
        sb.append("     , KOKI_TO \n");
        sb.append("     , KYAKU_NAME \n");
        sb.append("     , KENMEI \n");
        sb.append("     , STATUSCODE \n");
        sb.append("     , MSTATUS \n");
        sb.append("     , MTORIATUKAIN \n");
        sb.append("     , MSHONIN_DATE \n");
        sb.append("     , SP \n");
        sb.append("     , KEIYAKU_YOSO_SP \n");
        sb.append("     , MIKOMI_NET_SP \n");
        sb.append("     , MRITU_SP \n");
        sb.append("     , JISSI_YOSAN \n");
        sb.append("     , TAIYOSAN_HI \n");
        sb.append("     , M_SYOUNIN_NAME \n");
        sb.append("     , M_CHOSA_NAME \n");
        sb.append("     , M_CHOSA2_NAME \n");
        sb.append("     , M_TANTO_NAME \n");
        sb.append("     , M_SHOMUJIKO \n");
        sb.append("     , M_HUTAI_JYOKEN_FLG \n");
        sb.append("     , M_HUTAI_JYOKEN \n");
        sb.append("     , M_HUTAI_TEMP \n");
        sb.append("     , SHUKAN_JOBGR_CODE \n");
        sb.append("     , SORT1 \n");
        sb.append("     , SORT2 \n");
        sb.append("     , SORT3 \n");
        sb.append("     , N_JOBGR_CODE \n");
        sb.append("     , N_SHOSHO_KBN \n");
        sb.append("     , N_SHOSHO_CODE \n");
        sb.append("     , KAIKEI_JOBGR_CODE \n");
        sb.append("     , SHOSHO_NAME \n");
        sb.append("     , SHU_NET \n");
        sb.append("     , MIKO_NET \n");
        sb.append("     , MOKUHYO_NET \n");
        sb.append("     , SEKKEISATEI_NET \n");
        sb.append("     , BIKO \n");
        sb.append("     , TSS_NET \n");
        sb.append("     , TSM_NET \n");
        sb.append("     , TSMOKU_NET \n");
        sb.append("     , TSSATEI_NET \n");
        sb.append("     , JSS_NET \n");
        sb.append("     , JSM_NET \n");
        sb.append("     , JSMOKU_NET \n");
        sb.append("     , JSSATEI_NET \n");
        sb.append("     , RSS_NET \n");
        sb.append("     , RSM_NET \n");
        sb.append("     , RSMOKU_NET \n");
        sb.append("     , RSSATEI_NET \n");
        sb.append("     , ASS_NET \n");
        sb.append("     , ASM_NET \n");
        sb.append("     , ASMOKU_NET \n");
        sb.append("     , ASSATEI_NET \n");
        sb.append("     , MSS_NET \n");
        sb.append("     , MSM_NET \n");
        sb.append("     , MSMOKU_NET \n");
        sb.append("     , MSSATEI_NET \n");
        sb.append("     , GSS_NET \n");
        sb.append("     , GSM_NET \n");
        sb.append("     , GMOKU_NET \n");
        sb.append("     , GSSATEI_NET \n");
        sb.append("     , MITUMORI_GAIYOU \n");
        sb.append("     , M_TEMP \n");
        sb.append("     , M_STATUS \n");
        sb.append("     , K_STATUS \n");
        sb.append("     , KSTATUS \n");
        sb.append("     , KTORIATUKAIN \n");
        sb.append("     , KSHONIN_DATE \n");
        sb.append("     , G_S_YOSO_SP \n");
        sb.append("     , G_MIKOMINET \n");
        sb.append("     , G_MRITU \n");
        sb.append("     , G_SORI \n");
        sb.append("     , TAI_KYAKU_YOSAN_HI \n");
        sb.append("     , K_SYOUNIN_NAME \n");
        sb.append("     , K_CHOSA2_NAME \n");
        sb.append("     , K_CHOSA_NAME \n");
        sb.append("     , K_TANTO_NAME \n");
        sb.append("     , K_SHOMUJIKO \n");
        sb.append("     , K_HUTAI_JYOKEN_FLG \n");
        sb.append("     , K_HUTAI_JYOKEN \n");
        sb.append("     , K_HUTAI_TMP \n");
        sb.append("     , NEGO \n");
        sb.append("     , K_TMP \n");
        sb.append("     , DECODE(M_HINAGATA,'0','��','1','��') M_HINAGATA \n");		//2009/02/24 ���`��Ԓǉ�
        sb.append("     , DECODE(E_HINAGATA,'0','��','1','��') E_HINAGATA \n");		//2009/02/24 ���`��Ԓǉ�
        // 2017/02/03 (NPC) kaneko Add(s)
        sb.append("     , TO_CHAR(M_SYOUNIN_DATE, 'YYYY/MM/DD') M_SYOUNIN_DATE \n");
        sb.append("     , TO_CHAR(K_SYOUNIN_DATE, 'YYYY/MM/DD') K_SYOUNIN_DATE \n");
        // 2017/02/03 (NPC) kaneko Add(e)
        sb.append("  FROM V_EST_SEISHIKI_SVF \n");
        sb.append(" WHERE KEY_QNO = '" + qno + "' \n");
        sb.append("   AND REV = TO_NUMBER('" + rev + "') \n");
        sb.append("   AND YS_FLG = '" + ysflg + "' \n");

        return this.sver.exeSelSQL( sb.toString(), "���[�o�͎���DB�����ŃG���[���������܂����B");
    }

    /**
     * �\�Z���������擾����
     * @param qno Q/#
     * @param rev REVITION
     * @param ysflg �\�Z�����t���O
     * @param ksflg ���ك^�C�v�t���O�iM�F���ώ��AK�F���I�����j
     * @return �������
     * @throws sptException
     */
    public sptList getPrintLstYosan(
      String qno
    , String rev
    , String ysflg
    , String ksflg
    ) throws sptException {

        StringBuffer sb = new StringBuffer("");
        sb.append("SELECT SPURT_NO \n");
        sb.append("     , REV \n");
        sb.append("     , YS_FLG \n");
        sb.append("     , SAKUSEIBU \n");
        sb.append("     , SAKUSEIKA \n");
        sb.append("     , SYURUI \n");
        sb.append("     , JOBGR_CODE \n");
        sb.append("     , BU_CODE \n");
        sb.append("     , MI_FORM \n");
        sb.append("     , KEIYAKU_CODE \n");
        sb.append("     , MT_KAITO_NITIGEN \n");
        sb.append("     , PLANT_CODE \n");
        sb.append("     , TANTO_NAME \n");
        sb.append("     , KEY_QNO \n");
        sb.append("     , QNO \n");
        sb.append("     , KYAKU_TAN_KA_NAME \n");
        sb.append("     , KYAKU_TAN_NAME \n");
        sb.append("     , JISSI_JIKI \n");
        sb.append("     , KYAKU_KEIYAKU_NO \n");
        sb.append("     , YOKYU_NOKI \n");
        sb.append("     , CHUMONBI \n");
        sb.append("     , TEIKEN_KAISU \n");
        sb.append("     , ONO \n");
        sb.append("     , KOKI_FROM \n");
        sb.append("     , KOKI_TO \n");
        sb.append("     , KYAKU_NAME \n");
        sb.append("     , KENMEI \n");
        sb.append("     , STATUSCODE \n");
        sb.append("     , SP \n");
        sb.append("     , MOKUHYO_SP \n");
        sb.append("     , KAKU_MIKOMI_SP \n");
        sb.append("     , MIKOMI_NET_SP \n");
        sb.append("     , MRITU_SP \n");
        sb.append("     , CHUCHO_YOS_SP \n");
        sb.append("     , M_SYOUNIN_NAME \n");
        sb.append("     , M_CHOSA_NAME \n");
        sb.append("     , M_TANTO_NAME \n");
        sb.append("     , M_SHOMUJIKO \n");
        sb.append("     , M_HUTAI_JYOKEN_FLG \n");
        sb.append("     , M_HUTAI_JYOKEN \n");
        sb.append("     , M_HUTAI_TEMP \n");
        sb.append("     , SHUKAN_JOBGR_CODE \n");
        sb.append("     , SORT1 \n");
        sb.append("     , SORT2 \n");
        sb.append("     , SORT3 \n");
        sb.append("     , N_JOBGR_CODE \n");
        sb.append("     , N_SHOSHO_KBN \n");
        sb.append("     , N_SHOSHO_CODE \n");
        sb.append("     , KAIKEI_JOBGR_CODE \n");
        sb.append("     , SHOSHO_NAME \n");
        sb.append("     , SHU_NET \n");
        sb.append("     , MIKO_NET \n");
        sb.append("     , MOKUHYO_NET \n");
        sb.append("     , SEKKEISATEI_NET \n");
        sb.append("     , BIKO \n");
        sb.append("     , TSS_NET \n");
        sb.append("     , TSM_NET \n");
        sb.append("     , TSMOKU_NET \n");
        sb.append("     , TSSATEI_NET \n");
        sb.append("     , JSS_NET \n");
        sb.append("     , JSM_NET \n");
        sb.append("     , JSMOKU_NET \n");
        sb.append("     , JSSATEI_NET \n");
        sb.append("     , RSS_NET \n");
        sb.append("     , RSM_NET \n");
        sb.append("     , RSMOKU_NET \n");
        sb.append("     , RSSATEI_NET \n");
        sb.append("     , ASS_NET \n");
        sb.append("     , ASM_NET \n");
        sb.append("     , ASMOKU_NET \n");
        sb.append("     , ASSATEI_NET \n");
        sb.append("     , MSS_NET \n");
        sb.append("     , MSM_NET \n");
        sb.append("     , MSMOKU_NET \n");
        sb.append("     , MSSATEI_NET \n");
        sb.append("     , GSS_NET \n");
        sb.append("     , GSM_NET \n");
        sb.append("     , GMOKU_NET \n");
        sb.append("     , GSSATEI_NET \n");
        sb.append("     , MITUMORI_GAIYOU \n");
        sb.append("     , M_TEMP \n");
        sb.append("     , M_STATUS \n");
        sb.append("     , K_STATUS \n");
        sb.append("     , DEN_KEIKAKU_YOSAN \n");
        sb.append("     , KAKUNINBI \n");
        sb.append("     , KAKUNIN_TAN_KA_1 \n");
        sb.append("     , KAKUNIN_TAN_1 \n");
        sb.append("     , KAKUNIN_COMMENT_1 \n");
        sb.append("     , YOSO_SP \n");
        sb.append("     , K_MIKOMINET \n");
        sb.append("     , K_MRITU \n");
        sb.append("     , K_SORI \n");
        sb.append("     , K_SYOUNIN_NAME \n");
        sb.append("     , K_CHOSA_NAME \n");
        sb.append("     , K_TANTO_NAME \n");
        sb.append("     , K_SHOMUJIKO \n");
        sb.append("     , K_HUTAI_JYOKEN_FLG \n");
        sb.append("     , K_HUTAI_JYOKEN \n");
        sb.append("     , K_HUTAI_TMP \n");
        sb.append("     , NEGO \n");
        sb.append("     , K_TMP \n");
        sb.append("     , DECODE(M_HINAGATA,'0','��','1','��') M_HINAGATA \n");		//2009/02/24 ���`��Ԓǉ�
        sb.append("     , DECODE(E_HINAGATA,'0','��','1','��') E_HINAGATA \n");		//2009/02/24 ���`��Ԓǉ�
        // 2017/02/03 (NPC) kaneko Add(s)
        sb.append("     , TO_CHAR(M_SYOUNIN_DATE, 'YYYY/MM/DD') M_SYOUNIN_DATE \n");
        sb.append("     , TO_CHAR(K_SYOUNIN_DATE, 'YYYY/MM/DD') K_SYOUNIN_DATE \n");
        // 2017/02/03 (NPC) kaneko Add(e)
        sb.append("  FROM V_EST_YOSAN_SVF \n");
        sb.append(" WHERE KEY_QNO = '" + qno + "' \n");
        sb.append("   AND REV = TO_NUMBER('" + rev + "') \n");
        sb.append("   AND YS_FLG = '" + ysflg + "' \n");
        // 2019/03/15 add(s) �������̉��y�[�W��ݒ�
        sb.append("   AND KESSAI_TYPE = '" + ksflg + "' \n");
        // 2019/03/15 add(s) �������̉��y�[�W��ݒ�

        return this.sver.exeSelSQL( sb.toString(), "���[�o�͎���DB�����ŃG���[���������܂����B");
    }

    /**
     * ���������m�F�̖��L�荀�ڂ�Ԃ�
     * @param qno QNO
     * @param rev Revision
     * @param ysFlg �\�Z�����t���O
     * @param mitEndFlg ���ό��I���t���O
     * @return ���������m�F�̖��L�荀�ڂ̓�����String
     * @throws sptException
     */
    public String getShomuCheckStr(
        String qno
      , String rev
      , String ysFlg
      , String mitEndFlg
    ) throws sptException{
        sptList shomulist = this.getShomuCheckList( qno, rev, ysFlg, mitEndFlg );
        return KessaiUtil.getShomuMondaiStr( shomulist, false, false );
    }

    /**
     * �������X�g������
     * {@link Kessai_Sver } �ɏ������ϑ�
     * @param qno QNO
     * @param rev Revision
     * @param ysFlg �\�Z�����t���O
     * @param mitEndFlg ���ό��I���t���O
     * @return ���������m�F�̖��L�荀�ڂ̓�����String
     * @throws sptException
     */
    private sptList getShomuCheckList(
        String qno
      , String rev
      , String ysFlg
      , String mitEndFlg
    ) throws sptException{
        Kessai_Sver ksver = new Kessai_Sver();
        ksver.init( conn );
        return ksver.getShomuCheckList( qno, rev, ysFlg, mitEndFlg );
    }


}
