import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { Ac001Component } from './view/ac001/ac001.component';
import { Ac002Component } from './view/ac002/ac002.component';
import { Ac020Component } from './view/ac020/ac020.component';
import { Ac030Component } from './view/ac030/ac030.component';
import { Ac031Component } from './view/ac031/ac031.component';
import { Ac035Component } from './view/ac035/ac035.component';
import { Ac036Component } from './view/ac036/ac036.component';
import { Ac050Component } from './view/ac050/ac050.component';
import { Ac080Component } from './view/ac080/ac080.component';
import { Ac081Component } from './view/ac081/ac081.component';
import { Ac085Component } from './view/ac085/ac085.component';
import { Ac086Component } from './view/ac086/ac086.component';
import { Ac100Component } from './view/ac100/ac100.component';
import { Ac101Component } from './view/ac101/ac101.component';
import { Ac110Component } from './view/ac110/ac110.component';
import { Ac180Component } from './view/ac180/ac180.component';
import { Ac181Component } from './view/ac181/ac181.component';
import { Ac190Component } from './view/ac190/ac190.component';
import { Ac210Component } from './view/ac210/ac210.component';
import { Ac300Component } from './view/ac300/ac300.component';
import { Ac301Component } from './view/ac301/ac301.component';
import { Ac302Component } from './view/ac302/ac302.component';
import { Ac309Component } from './view/ac309/ac309.component';
import { Ac310Component } from './view/ac310/ac310.component';
import { Ac311Component } from './view/ac311/ac311.component';
import { Ac312Component } from './view/ac312/ac312.component';
import { Ac320Component } from './view/ac320/ac320.component';
import { Ac321Component } from './view/ac321/ac321.component';
import { Ac322Component } from './view/ac322/ac322.component';
import { Ac380Component } from './view/ac380/ac380.component';
import { Ac381Component } from './view/ac381/ac381.component';
import { Ac701Component } from './view/ac701/ac701.component';
import { Ac900Component } from './view/ac900/ac900.component';
import { Ac910Component } from './view/ac910/ac910.component';
import { Ac999Component } from './view/ac999/ac999.component';
import { SampleTestComponent } from './view/sample-test/sample-test.component';
import { NpcTestComponent } from './view/npc-test/npc-test.component';
import { Ac901Component } from './view/ac901/ac901.component';
import { Ac090Component } from './view/ac090/ac090.component';
import { Ac010Component } from './view/ac010/ac010.component';
import { Ac011Component } from './view/ac011/ac011.component';
import { Ac015Component } from './view/ac015/ac015.component';
import { Ac510Component } from './view/ac510/ac510.component';


const routes: Routes = [
    { path: "", redirectTo: "view/ac999", pathMatch: "full" },
    { path: "changeFisicalYear", redirectTo: "view/ac999", pathMatch: "full" },
    {
        path: "refreshSetupTourOnResult",
        redirectTo: "view/ac999",
        pathMatch: "full"
    },
    { path: "view/ac001", component: Ac001Component },
    { path: "view/ac002", component: Ac002Component },
    { path: "view/ac010", component: Ac010Component },
    { path: "view/ac011", component: Ac011Component },
    { path: "view/ac015", component: Ac015Component },
    { path: "view/ac020", component: Ac020Component },
    { path: "view/ac030", component: Ac030Component },
    { path: "view/ac031", component: Ac031Component },
    { path: "view/ac035", component: Ac035Component },
    { path: "view/ac036", component: Ac036Component },
    { path: "view/ac050", component: Ac050Component },
    { path: "view/ac080", component: Ac080Component },
    { path: "view/ac081", component: Ac081Component },
    { path: "view/ac085", component: Ac085Component },
    { path: "view/ac086", component: Ac086Component },
    { path: "view/ac090", component: Ac090Component },
    { path: "view/ac100", component: Ac100Component },
    { path: "view/ac101", component: Ac101Component },
    { path: "view/ac110", component: Ac110Component },
    { path: "view/ac180", component: Ac180Component },
    { path: "view/ac181", component: Ac181Component },
    { path: "view/ac190", component: Ac190Component },
    { path: "view/ac210", component: Ac210Component },
    { path: "view/ac300", component: Ac300Component },
    { path: "view/ac320", component: Ac320Component },
    { path: "view/ac321", component: Ac321Component },
    { path: "view/ac322", component: Ac322Component },
    { path: "view/ac301", component: Ac301Component },
    { path: "view/ac302", component: Ac302Component },
    { path: "view/ac309", component: Ac309Component },
    { path: "view/ac310", component: Ac310Component },
    { path: "view/ac311", component: Ac311Component },
    { path: "view/ac312", component: Ac312Component },
    { path: "view/ac312", component: Ac312Component },
    { path: "view/ac380", component: Ac380Component },
    { path: "view/ac381", component: Ac381Component },
    { path: "view/ac510", component: Ac510Component },
    { path: "view/ac900", component: Ac900Component },
    { path: "view/ac901", component: Ac901Component },
    { path: "view/ac910", component: Ac910Component },
    { path: "view/ac999", component: Ac999Component },
    { path: "view/sample", component: SampleTestComponent },
    { path: "view/npc", component: NpcTestComponent }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
