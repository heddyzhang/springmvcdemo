import { Component, OnInit } from '@angular/core';
import { ViewEncapsulation } from '@angular/core';
import { AC000ResDto } from './dto/ac000/AC000ResDto';
import { IndexService } from './service/IndexService';
import { IndexResDto } from './dto/index/IndexResDto';
import { Ac000Component } from './view/ac000/ac000.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {

  indexResDto: IndexResDto = new IndexResDto();

  _ac000: Ac000Component;

  _executedAuth:boolean = false;

  constructor(private indexService: IndexService) {
    this.indexService.authCheck();
  }

  authenticated(ac000: Ac000Component): boolean {

    if (this.indexService.authenticated && !this._executedAuth) {
      this._executedAuth = true;
      ac000.getEcoInitial(0);
    }

    return this.indexService.authenticated;
  }

  /**
   * 初期処理完了
   */
  ngOnInitOnResultHandler(): void {
  }
}
