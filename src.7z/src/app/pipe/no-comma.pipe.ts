import { NgModule, Pipe, PipeTransform } from '@angular/core';

/**
 * Angular標準の DecimalPipe で整数値の桁揃えを行った際に強制的に行われるカンマ桁区切りを除去します。
 *
 * 例）
 *      {{ 12345 | number:'9.0-0' }}              // 出力： 000,012,345
 *      {{ 12345 | number:'9.0-0' | noComma }}    // 出力： 000012345
 */

@Pipe({
    name: 'noComma'
})
export class NoCommaPipe implements PipeTransform {

    transform(val: number): string {
        if (val !== undefined && val !== null) {
            return val.toString().replace(/,/g, "");
        } else {
            return "";
        }
    }
}

@NgModule({
    imports: [],
    declarations: [NoCommaPipe],
    exports: [NoCommaPipe]
})
export class NoCommaModule { }
