import { Pipe, PipeTransform } from "@angular/core";
import { substrByByte } from "../util/string.util";

/**
 * 渡された文字列を半角換算で切り出します
 * 使い方:
 *   value | substrByByte: length
 * 例:
 *   {{ 'あいうabc' | substrByByte: 8 }}
 *   整形後の値: あいうab
 */
@Pipe({name: 'substrByByte'})
export class SubstrByBytePipe implements PipeTransform {
    transform(value: string, length: number): string {
        return substrByByte(value, length);
    }
}
