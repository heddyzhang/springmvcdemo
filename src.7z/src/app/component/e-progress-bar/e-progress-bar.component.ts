import { Component, NgModule, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { WjInputModule, WjPopup } from 'wijmo/wijmo.angular2.input';

@Component({
  selector: 'e-progress-bar',
  templateUrl: './e-progress-bar.component.html',
  styleUrls: ['./e-progress-bar.component.css']
})
export class EProgressBarComponent {

    /** ポップアップの参照 */
    @ViewChild(WjPopup)
    private wjpopup:WjPopup;

    /** タイトル */
    public messageTitle:string = '実行中';

    /** 進捗値 */
    public progressCnt:number = 0;

    /** 完了値 */
    public completeCnt:number = 100;

    /** 進捗値管理を行うか */
    public useCnt:boolean = false;

    /** コンストラクタ */
    constructor() {
    }

    /**
     * ダイアログを表示する
     *
     * @param title
     * @param useCnt
     */
    public show(useCnt:boolean, completeCnt:number = 0, title:string = '実行中') {

        // パラメータの初期化
        this.useCnt = useCnt;
        this.messageTitle = title;
        this.progressCnt = 0;
        this.completeCnt = completeCnt;

        // ポップアップを表示
        this.wjpopup.show(true);
    }

    /**
     * ポップアップを閉じる
     */
    public close() {

        if (document.getElementById("progress-pop-progressBar") !== null) {
            document.getElementById("progress-pop-progressBar").style.width = '0%';
        }

        // ポップアップを閉じる
        this.wjpopup.hide();
    }

    /**
     *
     * @param progressCnt 進捗値
     * @param completeCnt 完了値
     */
    public change(progressCnt:number, completeCnt?:number) {

        // ポップアップ非表示時は、処理を中断する
        if (!this.wjpopup.isVisible) {
            return;
        }

        this.useCnt = true;

        // 進捗値と完了値を設定
        this.progressCnt = progressCnt === null ? 0 : progressCnt;
        if (completeCnt !== undefined) {
            this.completeCnt = completeCnt;
        }

        // プログレスバーの進捗を更新
        document.getElementById("progress-pop-progressBar").style.width = Math.floor((this.progressCnt * 100) / this.completeCnt) + '%';
    }
}

@NgModule({
    exports: [EProgressBarComponent],
    declarations: [EProgressBarComponent],
    imports: [CommonModule, FormsModule, WjInputModule],
})
export class EProgressBarModule {}
