import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EProgressBarComponent } from './e-progress-bar.component';

describe('EProgressBarComponent', () => {
  let component: EProgressBarComponent;
  let fixture: ComponentFixture<EProgressBarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EProgressBarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EProgressBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
