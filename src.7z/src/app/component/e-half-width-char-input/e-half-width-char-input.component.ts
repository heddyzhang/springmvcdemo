import { Component, NgModule } from "@angular/core";
import { Inject, Injector, ElementRef as elementRef, SkipSelf, Optional} from '@angular/core';
import { wjInputMaskMeta } from "wijmo/wijmo.angular2.input";
import { ETextInputComponent } from "../e-text-input/e-text-input.component";

interface ElementRef {
    nativeElement: HTMLElement;
}

/**
 * @classdesc 半角入力コンポーネント
 */
@Component({
    selector: 'e-half-width-char-input',
    template: wjInputMaskMeta.template,
    inputs: wjInputMaskMeta.inputs,
    outputs: wjInputMaskMeta.outputs,
})
export class EHalfWidthCharInputComponent extends ETextInputComponent {

    /** コンストラクタ */
    constructor(
        @Inject(elementRef) elRef: ElementRef,
        @Inject(Injector) injector: Injector,
        @Inject('ETextInputComponent') @SkipSelf() @Optional() parentCmp: any,
    ) {
        // super
        super(elRef, injector, parentCmp);
        // 半角のみ許可
        this.inputMode = "1";
    }
}

@NgModule({
    exports: [EHalfWidthCharInputComponent],
    declarations: [EHalfWidthCharInputComponent]
})
export class EHalfWidthCharInputModule {
}
