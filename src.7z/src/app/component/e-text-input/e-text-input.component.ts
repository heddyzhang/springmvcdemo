import { Component, Input, Output, EventEmitter, NgModule } from "@angular/core";
import { Inject, Injector, ElementRef as elementRef, SkipSelf, Optional} from '@angular/core';
import { EventArgs } from "wijmo/wijmo";
import { WjInputMask, wjInputMaskMeta } from "wijmo/wijmo.angular2.input";
import { getInputDefaultStyle, applyStyle, getRequiredStyle, removeDefaultWijmoInputStyle, TextAlign } from "../../util/css.util";
import { change1ByteAnd2ByteOnly, change1ByteAlphaNumOnly, change1ByteNumOnly, change1ByteOnly, changeTelNoOnly, substrByByte } from "../../util/string.util";

interface ElementRef {
    nativeElement: HTMLElement;
}

/**
 * @classdesc テキスト入力コンポーネント
 * 
 * 【値変更イベント(eOnValueChanged)について】
 * 　eOnValueChangedはユーザ操作(≒WjInputMaskのvalue/rawValue変更)を検知して発火するようにしているため、
 * 　プログラム側からeOnValueChangedを発火させたい場合は、WjInputMaskのvalue/rawValueに値をセットしてください。
 * 　独自プロパティ(eValue/eRawValue)を使用する際はeOnValueChangedが発火しないように制御してます。
 */
@Component({
    selector: 'e-text-input',
    template: wjInputMaskMeta.template,
    inputs: wjInputMaskMeta.inputs,
    outputs: wjInputMaskMeta.outputs,
})
export class ETextInputComponent extends WjInputMask {
    private _isEOnValueChanged: boolean = true; // 初期化時に値が変更されるイベントを発生させないようにする
    private _innerClass: string = getInputDefaultStyle(); // CSSスタイル定義
    private _innerStyle: CSSStyleDeclaration; // CSSスタイル定義
    private _required = false; // 必須フラグ
    private _textAlign: TextAlign = 'left'; // 文字寄せ方向
    private _maxLength: number = 0; // 最大入力可能桁数(バイト換算)
    private _inputMode: string = '0'; // 入力モード判定

    // イベント処理を親コンポーネントで実行するための宣言
    @Output() eOnValueChanged = new EventEmitter<EventArgs>();
    @Output() eOnLostFocus = new EventEmitter<EventArgs>();
    @Output() eOnGotFocus = new EventEmitter<EventArgs>();

    // 入力値
    @Input() set eValue(value: any) {
        // 値変更フラグをfalseにする
        this._isEOnValueChanged = false;
        // 値を編集する
        this.editValue(value);
    }
    get eValue(): any {
        return this.value;
    }
    // バインド設定
    @Output() eValueChange = new EventEmitter<any>();

    // 入力値(生データ)
    @Input() set eRawValue(value: any) {
        // 値変更フラグをfalseにする
        this._isEOnValueChanged = false;
        // 値を編集する
        this.editValue(value);
    }
    get eRawValue(): any {
        return this.rawValue;
    }
    // バインド設定
    @Output() eRawValueChange = new EventEmitter<any>();

    // CSSクラス定義
    @Input() set innerClass(value: string) {
        this._innerClass = getInputDefaultStyle() + ((value) ? " " + value: "");
        this.inputElement.className = this._innerClass;
    }

    // CSSスタイル定義
    @Input() set innerStyle(value: CSSStyleDeclaration) {
        this._innerStyle = value;
        applyStyle(this.inputElement, this._innerStyle);
    }

    // 必須フラグ
    @Input() set required(val: boolean) {
        this._required = val;
        this.inputElement.style.borderLeft = getRequiredStyle(this._required);
    }

    // 文字寄せ方向
    @Input() set textAlign(val: TextAlign) {
        this._textAlign = val;
        this.inputElement.style.textAlign = this._textAlign;
    }

    // 最大入力可能桁数(バイト換算)
    @Input() set maxLength(val: number) {
        this._maxLength = val;
        this.inputElement.maxLength = this._maxLength;
    }
    get maxLength(): number {
        return this._maxLength;
    }

    // 入力モード
    @Input() set inputMode(val: string) {
        this._inputMode = val;
    }

    // tabindex
    @Input() tabindex: number;

    /** コンストラクタ */
    constructor(
        @Inject(elementRef) elRef: ElementRef,
        @Inject(Injector) injector: Injector,
        @Inject('ETextInputComponent') @SkipSelf() @Optional() parentCmp: any,
    ) {
        // super
        super(elRef, injector, parentCmp);
        // maskの設定をする
        // TODO: 全角入力でカーソルが迷走するので、デフォルト値をセットする必要あり。
        // if (!this.mask) this.mask = 'ＺＺＺＺＺＺ';
    }

    /**
     * 初期表示時の処理
     */
    public ngOnInit(): void {
        // 必ず呼ぶこと
        super.ngOnInit();

        // Looperのスタイルと重複するため、Wijmoの一部デフォルトスタイルを無効化
        removeDefaultWijmoInputStyle(this.hostElement);
        // デフォルトのcssのclassをあてる
        this.inputElement.className = this._innerClass;
        // tabindexを設定する
        if (this.tabindex) this.inputElement.tabIndex = this.tabindex;

        // inputイベントの追加
        this.addEventListener(this.inputElement, 'input', this.input.bind(this));
    }

    /**
     * 値が変更されたときのイベント
     * @param e イベント
     */
    public onValueChanged(e?: EventArgs): void {
        // WijmoのonValueChangedをoverrideしているので、親のメソッドを自分で呼ぶ必要がある
        super.onValueChanged(e);

        // maskの設定を外さないとrawvalueのバインディングでカーソルが迷走する
        var _mask = this.mask;
        this.mask = null;

        // バインド元のセット内容を変更する
        // 警告(ExpressionChangedAfterItHasBeenCheckedError)が出ないよう非同期にする
        // ※画面の描画が終わる前に親コンポーネントのプロパティの変化を検知している
        setTimeout(() => {
            this.eValueChange.emit(this.value);
            this.eRawValueChange.emit(this.rawValue);
        });

        // 親コンポーネントのメソッドを呼ぶ
        if (this._isEOnValueChanged) this.eOnValueChanged.emit(e);

        // maskの設定を戻す
        this.mask = _mask;

        // 値変更フラグをtrueにする
        this._isEOnValueChanged = true;
    }

    /**
     * 値が変更されたときのイベント
     * @param e イベント
     */
    public input(e: Event): void {
        // 値を編集する
        this.editValue(this.rawValue);
    }

    /**
     * フォーカスが入ったときのイベント
     * @param e イベント
     */
    public onGotFocus(e?: EventArgs): void {
        // WijmoのonGotFocusをoverrideしているので、親のメソッドを自分で呼ぶ必要がある
        super.onGotFocus(e);
        // テキストを選択状態にする
        this.inputElement.select();
        // 親コンポーネントのメソッドを呼ぶ
        this.eOnGotFocus.emit(e);
    }

    /**
     * フォーカスが外れたときのイベント
     * @param e イベント
     */
    public onLostFocus(e?: EventArgs): void {
        // WijmoのonLostFocusをoverrideしているので、親のメソッドを自分で呼ぶ必要がある
        super.onLostFocus(e);
        // 親コンポーネントのメソッドを呼ぶ
        this.eOnLostFocus.emit(e);
    }

    /**
     * 値を編集する
     */
    private editValue(val: any): void {
        var value = val;
        if (val) {
            // 文字編集
            value = editStrings(value.toString(), this._inputMode);
            // 半角換算で桁数チェック＆切り出し
            value = substrByByte(value, this._maxLength);
        } else {
            value = null;
        }
        // 文字をセットする
        this.rawValue = value;
    }
}

/**
 * 文字列をモードによって変換する
 * @param s 対象の文字列
 * @param inputMode オプション(1:半角文字全て, 2:半角英数字のみ, 3:半角数字のみ, 4:電話番号)
 */
function editStrings (s: string, inputMode: string): string {
    var str: string = s;
    // 半角文字モード
    if (inputMode === '0') {
        str = change1ByteAnd2ByteOnly(str);
    } else if (inputMode === '1') {
        str = change1ByteOnly(str);
    } else if (inputMode === '2') {
        str = change1ByteAlphaNumOnly(str);
    } else if (inputMode === '3') {
        str = change1ByteNumOnly(str);
    } else if (inputMode === '4') {
        str = changeTelNoOnly(str);
    }
    return str;
}

@NgModule({
    exports: [ETextInputComponent],
    declarations: [ETextInputComponent]
})
export class ETextInputModule {
}
