import { Component, Input, Output, NgModule, EventEmitter } from "@angular/core";
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

/**
 * ボタンコンポーネント
 */
@Component({
    selector: 'view-base-button',
    templateUrl: './view-base-button.component.html',
})
export class ViewBaseButtonComponent {

    @Input() name: string = null;
    @Input() id: string = null;
    @Input() value: string = null;
    @Input() class: string = 'btn btn-default';
    @Input() style: CSSStyleDeclaration;
    @Input() tabindex: Number = null;
    private _disabled: string = null; // DISABLEDフラグ

    // イベント処理を親コンポーネントで実行するための宣言
    @Output() eButtonClick = new EventEmitter();

    // css
    @Input() set innerClass(val: string) {
        this.class = val;
    }

    // style
    @Input() set innerStyle(val: CSSStyleDeclaration) {
        this.style = val;
    }

    // disabledフラグ
    @Input() set disabled(val: boolean) {
        this._disabled = (val)? 'disabled': null;
    }

    /**
     * 初期化処理
     */
    ngOnInit(): void {
    }

    /**
     * ボタンクリック時、親コンポーネントのメソッドを呼ぶ
     */
    click(): void {
        this.eButtonClick.emit();
    }
}

@NgModule({
    exports: [ViewBaseButtonComponent],
    declarations: [ViewBaseButtonComponent],
    imports: [CommonModule, FormsModule]
})
export class ViewBaseButtonModule {
}
