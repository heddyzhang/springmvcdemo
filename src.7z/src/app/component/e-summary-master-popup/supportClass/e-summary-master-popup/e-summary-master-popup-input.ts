import { Component, NgModule, Input, Output, EventEmitter } from "@angular/core";
import { wjInputMaskMeta } from "wijmo/wijmo.angular2.input";
import { ETextInputComponent } from "../../../e-text-input/e-text-input.component";
import { SummaryMasterPopup } from "../../e-summary-master-popup";
import { EventArgs } from "wijmo/wijmo";

@Component({
    selector: 'e-summary-master-popup-input',
    template: wjInputMaskMeta.template,
    inputs: wjInputMaskMeta.inputs,
    outputs: wjInputMaskMeta.outputs,
})
/**
 * <e-summary-master-popup>と共に使用する
 */
export class ESummaryMasterPopupInput extends ETextInputComponent {

    @Input()
    /** 伝票区分 */
    public slipCls: number;

    @Input()
    /** 見出区分 */
    public summaryCls: number;

    @Input()
    /** ポップアップへの参照 */
    public summaryMasterPop: SummaryMasterPopup;

    /** 伝票摘要 or 伝票明細.仕訳摘要2 */
    @Input()
    set summaryMasterValue(value: string) {
        this.value = value;
    }
    get summaryMasterValue(): string {
        return this.value;
    }

    /** 変更イベント */
    @Output() public summaryMasterValueChange = new EventEmitter<string>();

    /**
     * 初期化処理
     */
    public ngOnInit(): void {
        // 親クラスの初期化
        super.ngOnInit();

        // フォーカス時の処理
        this.inputElement.addEventListener('focus', this.inputElementOnShowPop.bind(this));

        // クリック時の処理
        this.inputElement.addEventListener('click', this.inputElementOnShowPop.bind(this));

        // フォーカスを抜けた場合の処理
        this.inputElement.addEventListener('blur', this.inputElementOnBlur.bind(this));
    }

    /**
     * 値が変更されたときのイベント
     * @param e イベント
     */
    public onValueChanged(e?: EventArgs): void {
        super.onValueChanged(e);
        this.summaryMasterValue = this.value;
        this.summaryMasterValueChange.emit(this.value);
    }

    /**
     * フォーカス時の処理 / クリック時の処理
     * @param e
     */
    private inputElementOnShowPop(e): void {
        // 既に表示中の場合は処理を中断
        if (this.summaryMasterPop.wjpopup && this.summaryMasterPop.wjpopup.isVisible) {
            return;
        }
        // ポップアップを表示する
        this.summaryMasterPop.openSummaryMasterSelect(this);
    }

    /**
     * フォーカスを抜けた場合の処理
     * @param e
     */
    private inputElementOnBlur(e): void {
        // フォーカスの移動先
        var target: any = e.relatedTarget;

        // relatedTargetがサポートされていない場合
        if (!target) {
            target = document.activeElement;
        }

        // 摘要ポップアップへのフォーカス移動の場合は、処理を中断する
        if (target && (target.classList.contains('wj-popup')
            || target.classList.contains('e-summary-master-popup')
            || target.classList.contains('e-summary-master-pop-cell')
            || target.classList.contains('wj-cell')
        )) {
            return;
        }

        // ポップアップがダイアログを開いている場合はポップアップを閉じない
        if (this.summaryMasterPop.isDialogOpened) {
            return;
        }

        this.summaryMasterPop.onInputFocusout();

        // 摘要ポップアップを閉じる
        this.summaryMasterPop.hide();
    }
}

@NgModule({
    exports: [ESummaryMasterPopupInput],
    declarations: [ESummaryMasterPopupInput]
})
export class ESummaryMasterPopupModule {
}
