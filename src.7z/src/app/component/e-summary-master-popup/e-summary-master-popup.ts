import { Component, ViewEncapsulation, OnInit, Input, Output, EventEmitter, ViewChild, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { WjPopup, WjInputModule } from "wijmo/wijmo.angular2.input";
import { WjGridModule } from 'wijmo/wijmo.angular2.grid';
import { ETextInputModule } from "../e-text-input/e-text-input.component";
import { ViewBaseButtonModule } from "../view-base-button/view-base-button.component";
import { WjFlexGridEx, WjFlexGridModuleEx } from "../wj-flex-grid-ex/wj-flex-grid-ex";
import { CommonComponentService } from '../../service/CommonComponentService';
import { CommonComponentReqDto } from "../../dto/commonComponent/CommonComponentReqDto";
import { CommonComponentResDto } from "../../dto/commonComponent/CommonComponentResDto";
import { SummaryDto } from "../../dto/commonComponent/SummaryDto"
import { ESummaryMasterPopupInput } from './supportClass/e-summary-master-popup/e-summary-master-popup-input';
import { CollectionView, SortDescription } from 'wijmo/wijmo';
import { SelectionMode } from 'wijmo/wijmo.grid';
import { EAlertModule, EAlertComponent } from '../e-alert/e-alert.component';
import { isEmpty } from '../../util/string.util';

// 表示モード
type viewMode = "SELECT" | "EDIT";
// ソート順
type sortOrder = "PRIORITY" | "SEQ";
// 並び替えタイプ
type reorderType = "UP" | "DOWN";

@Component({
    selector: 'e-summary-master-popup',
    templateUrl: './e-summary-master-popup.html',
    styleUrls: ['./e-summary-master-popup.css'],
    encapsulation: ViewEncapsulation.None,
})
export class SummaryMasterPopup implements OnInit {
    /** アラート */
    @ViewChild(EAlertComponent)
    public eAlert: EAlertComponent;

    /**
     * ダイアログを開いているかどうか
     * 親コンポーネントでのフォーカス制御で利用
     */
    public isDialogOpened: boolean;

    /** 取得した摘要配列管理配列 */
    public summaryDtoList: CollectionView;

    /** 表示モード */
    public viewMode: viewMode = "SELECT";

    /** ソート順 */
    public sortOrder: sortOrder = "PRIORITY";

    /** 処理中かどうか */
    public isBusy: boolean;

    /** ポップアップの参照 */
    @ViewChild(WjPopup)
    public wjpopup: WjPopup;

    /** 摘要選択Grid */
    @ViewChild("summaryMasterGrid")
    public summaryMasterGrid: WjFlexGridEx;

    /** ポップアップ位置 X軸 */
    private _x: string;

    /** ポップアップ位置 Y軸 */
    private _y: string;

    @Input()
    /** ポップアップ位置 X軸 */
    public set x(value: string) {
        this._x = value;

        // 変更イベント
        this.xChange.emit(this._x);
    }

    @Input()
    /** ポップアップ位置 Y軸 */
    public set y(value: string) {
        this._y = value;

        // 変更イベント
        this.yChange.emit(this._y);
    }

    /** 変更イベント */
    @Output()
    public xChange = new EventEmitter();
    @Output()
    public yChange = new EventEmitter();

    /** inputへの参照 */
    private summaryMasterPopupInput: ESummaryMasterPopupInput;

    /** 最後に選択されていたソート順 */
    private lastSelectedSortOrder?: sortOrder;

    constructor(private commonComponentService: CommonComponentService) { }

    /**
     * 初期表示時の処理
     */
    ngOnInit() {
        // ポップアップの表示/非表示切り替えのアニメーションを削除
        this.wjpopup.fadeIn = false;
        this.wjpopup.fadeOut = false;

        // フォーカスが当たった際に、抜ける
        this.wjpopup.addEventListener(this.wjpopup.hostElement, 'focus', (e) => { this.summaryMasterPopupInput.inputElement.focus(); }, true);

        // フォーカスを受け付けなくする
        this.wjpopup.addEventListener(this.wjpopup.hostElement, 'mousedown', (e: MouseEvent) => {
            // 単純にフォーカスを受け付けなくするとグリッドの行を選択できなくなってしまうので、
            // セルがクリックされた場合はフォーカスイベントをスキップしないようにする
            // その代わりに、Inputの方のOnBlurイベントハンドラでフォーカスが移らないよう制御する
            if (e.srcElement.outerHTML.includes("e-summary-master-pop-cell")) {
                return;
            }

            // その他の場合はフォーカス移動イベントを無視する
            e.preventDefault();
        }, true);
    }

    /**
     * 摘要ポップアップを開く
     * @param target 入力中の入力欄
     */
    public openSummaryMasterSelect(target: ESummaryMasterPopupInput): void {
        // 入力対象への参照を保持
        this.summaryMasterPopupInput = target;

        // ポップアップを表示する
        this.wjpopup.show();

        // ポップアップ位置が指定されている場合は、位置を変更する
        if (this._x && this._y) {
            this.wjpopup.hostElement.style.left = this._x;
            this.wjpopup.hostElement.style.top = this._y;
        }

        // 表示モードを初期化する
        this.viewMode = "SELECT";

        // リストを初期化する
        // 初期状態(選択モード)の場合は行選択不可
        this.summaryMasterGrid.selectionMode = SelectionMode.None;

        // DBからデータ取得
        this.fetchSummaryData(() => {
            // ソート順初期値設定
            if (this.lastSelectedSortOrder) {
                // 最後に選択されていたソート順が保存されていたらそちらを採用
                this.sortBy(this.lastSelectedSortOrder);
            } else {
                // 最後に選択されていたソート順が保存されていない場合は重要度順にする
                this.sortBy("PRIORITY");
            }
        });
    }

    /**
     * 指定された順番で一覧をソートする
     * @param sortOrder ソート順
     */
    public sortBy(sortOrder: sortOrder) {
        // 変数の値を同期
        this.sortOrder = sortOrder;
        this.lastSelectedSortOrder = sortOrder;

        // ソート実行
        let sd: SortDescription;
        if (sortOrder === "PRIORITY") {
            sd = new SortDescription("usedCnt", false);
        } else {
            sd = new SortDescription("summarySeq", true);
        }
        this.summaryDtoList.sortDescriptions.clear();
        this.summaryDtoList.sortDescriptions.push(sd);
    }

    /**
     * 指定された表示モードに変更する
     * @param mode 表示モード
     */
    public changeViewModeTo(mode: viewMode) {
        // 変数の値を同期
        this.viewMode = mode;

        if (mode === "EDIT") {
            // 変更モードの場合は番号順固定
            this.sortBy("SEQ");
            // 変更モードの場合は行選択可能にする
            this.summaryMasterGrid.selectionMode = SelectionMode.Row;
            this.summaryMasterGrid.select(0, 0);
        } else {
            // 選択モードの場合は行選択不可にする
            this.summaryMasterGrid.selectionMode = SelectionMode.None;
        }
    }

    /**
     * 摘要ポップアップを閉じる
     */
    public hide(): void {
        // ポップアップの位置を保持する
        this.x = this.wjpopup.hostElement.style.left;
        this.y = this.wjpopup.hostElement.style.top;

        // Popupを閉じる
        this.summaryDtoList = null;
        this.wjpopup.hide();
    }

    /**
     * 選択された摘要を親コンポーネントにセットする
     * @param summary セットする摘要
     */
    public selectItem(summaryDto: SummaryDto) {
        // 変更モードの場合はセットしない
        if (this.viewMode === "EDIT") {
            return;
        }

        // 選択された摘要の利用回数をカウントアップする
        var reqDto: CommonComponentReqDto = new CommonComponentReqDto();
        reqDto.summaryDto = summaryDto;
        this.commonComponentService.updateCount(reqDto, function () { });

        // 親コンポーネントに値をセット
        this.summaryMasterPopupInput.summaryMasterValue = summaryDto.summary;
        this.summaryMasterPopupInput.summaryMasterValueChange.emit(summaryDto.summary);

        // ポップアップを閉じる
        this.hide();
    }

    /**
     * 位置変更ボタンの押下処理
     * @param item 押下したボタン情報
     */
    public reorder(type: reorderType) {
        // 一覧が空の場合は処理中止
        if (this.summaryDtoList.currentItem === null) {
            return;
        }

        try {
            // 処理中はUP/DOWNボタンを使用不可にする
            this.isBusy = true;

            // 現在選択されている行のインデックスを取得
            const currentIndex = this.summaryDtoList.currentPosition;

            // UPかつ1行目の場合はスキップ
            if (type === "UP" && currentIndex === 0) {
                this.isBusy = false;
                return;
            }

            // DOWNかつ最終行の場合はスキップ
            if (type === "DOWN" && currentIndex === this.summaryDtoList.itemCount - 1) {
                this.isBusy = false;
                return;
            }

            // 順番を入れ替えた状態のデータを作成
            // ※src = source = "元"
            // ※dest = destination = "先"
            // 順番入れ替え元の摘要SEQを取得
            const srcItem = this.summaryDtoList.currentItem;
            const srcSummarySeq = srcItem.summarySeq;

            // 順番入れ替え先の摘要SEQを取得
            const destIndex = type === "UP" ? currentIndex - 1 : currentIndex + 1; // 順番入れ替え先のインデックスを取得
            const destItem = this.summaryDtoList.items[destIndex];
            const destSummarySeq = destItem.summarySeq;

            // 順番を入れ替える
            srcItem.summarySeq = destSummarySeq;
            destItem.summarySeq = srcSummarySeq;

            // 作成したデータをサーバーに送ってDB更新
            var reqDto: CommonComponentReqDto = new CommonComponentReqDto();
            reqDto.summaryDtoList = [srcItem, destItem];
            this.commonComponentService.update(reqDto, (resDto: CommonComponentResDto) => {
                // グリッドの表示状態をリフレッシュ
                // フィルタをかけて正しい順番に並び替え
                this.sortBy(this.sortOrder);
                // 移動した行を選択状態にする
                this.summaryMasterGrid.select(destIndex, 1);                // 排他制御のために、更新日をDBから取得した値で最新の状態にする
                // this.summaryDtoList.itemsを丸ごと置き換えてしまうと、グリッドのフォーカス位置が
                // うまく反映されないので、ループで更新日だけ更新する
                this.summaryDtoList.items.forEach((item: SummaryDto) => {
                    const db = resDto.summaryDtoList.find(p =>
                        p.summaryId === item.summaryId
                        && p.slipCls === item.slipCls
                        && p.summaryCls === item.summaryCls);
                    item.updatedAt = db.updatedAt;
                })
                this.isBusy = false;
            });
        } catch (e) {
            this.isBusy = false;
            throw e;
        }
    }

    /**
     * 選択されている適用を削除する
     */
    public delete() {
        // どうしてもダイアログにフォーカスが移ってしまうので、ダイアログを開いている間は
        // Inputからフォーカスが離れてもポップアップが閉じられないようにする
        this.isDialogOpened = true; // このフラグをInputの方で見て判断

        // ダイアログが閉じられた際に状態を元に戻す関数
        const cleanup = () => {
            this.isDialogOpened = false;
            this.summaryMasterPopupInput.focus();
        }

        try {
            // 選択されている摘要を取得
            const selected = this.summaryDtoList.items.filter(item => item.isChecked);

            if (selected.length <= 0) {
                // ダイアログ「摘要を選択してください。」
                this.eAlert.message('211011', ["摘要"], null, () => {
                    cleanup();
                });
                return;
            }

            // ダイアログ「選択された情報を削除しますか？」
            this.eAlert.message('120021', [], null, () => {
                var reqDto: CommonComponentReqDto = new CommonComponentReqDto();
                reqDto.summaryDtoList = selected;

                // 選択された摘要をDBから削除
                this.commonComponentService.delete(reqDto, (resDto: CommonComponentResDto) => {
                    // 削除完了後にサーバー側から最新のデータ全件が返ってくるので一覧にセット
                    this.summaryDtoList = new CollectionView(resDto.summaryDtoList);
                    this.sortBy("SEQ");
                    this.summaryDtoList.moveCurrentToFirst();

                    // 削除した摘要と同じ摘要がInputに入力されていると、Inputのフォーカスアウトで
                    // また同じ摘要が登録されてしまうので、Inputの入力値を空にする
                    this.summaryMasterPopupInput.eValue = "";

                    // ダイアログ「一覧から対象を削除しました」
                    this.eAlert.message('100007', [], null, () => {
                        cleanup();
                    });
                });
            }, cleanup);
        } catch (e) {
            cleanup();
            throw e;
        }
    }

    /**
     * Inputフォーカスアウト時に呼び出される処理
     */
    public onInputFocusout() {
        // 入力されたテキストと比較するためのデータがないと処理が進められないので
        // まずDBから摘要の一覧を取得する
        this.fetchSummaryData(() => {
            // Inputに入力されているテキストを取得
            const text = this.summaryMasterPopupInput.summaryMasterValue;

            // 何も入力されていない場合はスキップ
            if (isEmpty(text)) {
                return;
            }

            // 既にDBに登録されている摘要の場合はスキップ
            const findIndexResult = this.summaryDtoList.items.findIndex((item: SummaryDto) => item.summary === text);
            if (findIndexResult !== -1) {
                return;
            }

            // 入力されたテキストに一致する番号がある場合は、そのデータの摘要をInputにセットする
            const findResult = this.summaryDtoList.items.find((item: SummaryDto) => item.summarySeq.toString() === text);

            if (findResult !== undefined) {
                this.summaryMasterPopupInput.eValue = findResult.summary;
                return;
            }

            // 入力されたテキストに一致する番号がない場合は、そのテキストを新規摘要としてDBに登録する
            const newSummaryDto = new SummaryDto();
            newSummaryDto.slipCls = this.summaryMasterPopupInput.slipCls;
            newSummaryDto.summaryCls = this.summaryMasterPopupInput.summaryCls;
            newSummaryDto.summary = text;
            newSummaryDto.usedCnt = 1;

            const reqDto = new CommonComponentReqDto();
            reqDto.summaryDto = newSummaryDto;

            this.commonComponentService.insert(reqDto, () => { })
        })
    }

    /**
     * DBから摘要データを取得してグリッドにセットする
     * @param f データ取得後に実行する関数
     */
    private fetchSummaryData(f?: Function) {
        this.summaryMasterGrid.itemsSource = null;

        const summaryDto = new SummaryDto();
        summaryDto.slipCls = this.summaryMasterPopupInput.slipCls;
        summaryDto.summaryCls = this.summaryMasterPopupInput.summaryCls;
        const reqDto = new CommonComponentReqDto();
        reqDto.summaryDto = summaryDto;

        this.commonComponentService.getSummary(
            reqDto,
            (resDto: CommonComponentResDto) => {
                // 摘要情報をセットする
                this.summaryDtoList = new CollectionView(resDto.summaryDtoList);
                // データ取得後に実行する関数を実行
                f();
            });
    }
}

@NgModule({
    exports: [SummaryMasterPopup],
    declarations: [SummaryMasterPopup],
    imports: [
        CommonModule,
        WjGridModule,
        FormsModule,
        ETextInputModule,
        ViewBaseButtonModule,
        WjInputModule,
        WjFlexGridModuleEx,
        EAlertModule,
    ],
})
export class SummaryMasterPopupModule { }
