import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AcPayableSlipComponent } from './ac-payable-slip.component';

describe('AcPayableSlipComponent', () => {
  let component: AcPayableSlipComponent;
  let fixture: ComponentFixture<AcPayableSlipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AcPayableSlipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AcPayableSlipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
