import { Component, NgModule, ViewChild, Input, Output, OnInit, EventEmitter, ViewEncapsulation } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { EDropDownListModule } from '../e-drop-down-list/e-drop-down-list.component';
import { EDateFieldModule } from '../e-date-field/e-date-field.component';
import { CommonInputSlipDto } from '../../dto/CommonInputSlipDto';
import { EAcTitlePopupInputModule, EAcTitlePopupInputComponent } from '../e-ac-title-popup-input/e-ac-title-popup-input.component';
import { EAcTitleInputModule } from '../e-ac-title-popup-input/supportClass/e-ac-title-input/e-ac-title-input.component';
import { EAcSubTitleInputModule } from '../e-ac-title-popup-input/supportClass/e-ac-sub-title-input/e-ac-sub-title-input.component';
import { ECustomerPopupInputModule } from '../e-customer-popup-input/e-customer-popup-input.component';
import { ECustomerInputModule } from '../e-customer-popup-input/supportClass/e-customer-input/e-customer-input.component';
import { NoCommaModule } from '../../pipe/no-comma.pipe';
import { WjFlexGridModuleEx, WjFlexGridEx } from '../wj-flex-grid-ex/wj-flex-grid-ex';
import { WjGridModule } from 'wijmo/wijmo.angular2.grid';
import { EMoneyInputModule } from '../e-money-input/e-money-input.component';
import { EMoneyLabelModule } from '../e-money-label/e-money-label.component';
import { EConsumptionTaxPopupInputModule, EConsumptionTaxPopupInputComponent } from '../e-consumption-tax-popup-input/e-consumption-tax-popup-input.component';
import { EConsumptionTaxInputModule } from '../e-consumption-tax-popup-input/supportClass/e-consumption-tax-input/e-consumption-tax-input';
import { ETextInputModule } from '../e-text-input/e-text-input.component';
import { InputSlipDetailDto, InputSlipDetailDtoHeader } from '../../dto/InputSlipDetailDto';
import { cloneObject } from '../../util/object.util';
import { EDateFieldExModule } from '../e-date-field-ex/e-date-field-ex.component';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { TaxInfoDto } from '../../dto/TaxInfoDto';
import { ESegmentSelectModule } from '../e-segment-select/e-segment-select.component';
import { ETaxRateSelectModule, ETaxRateSelectComponent } from '../e-tax-rate-select/e-tax-rate-select.component';
import { EPopupItem } from '../../dto/ePopupInput/EPopupItem';
import { EApprovalStampModule } from '../e-approval-stamp/e-approval-stamp.component';
import { ESummaryDatePopupModule } from '../e-summary-date-popup/e-summary-date-popup';
import { ESummaryDateInputModule } from '../e-summary-date-popup/supportClass/e-summary-date-input/e-summary-date-input';
import { ESummaryMasterPopupModule } from '../e-summary-master-popup/supportClass/e-summary-master-popup/e-summary-master-popup-input';
import { SummaryMasterPopupModule } from '../e-summary-master-popup/e-summary-master-popup';

/**
 * 【共通】消費税区分の初期値/パターン2のマトリックス用初期値分類
 */
enum Ptn2 {
    C_NONE = 0,     // 空欄
    C_DR   = 1,     // 借方科目.消費税コード
    C_CR   = 2,     // 貸方科目.消費税コード
    C_610  = 3,     // 610.課税売上
    C_710  = 4,     // 710.課税仕入
}

@Component({
    selector: 'ac-payable-slip',
    templateUrl: './ac-payable-slip.component.html',
    styleUrls: ['./ac-payable-slip.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class AcPayableSlipComponent implements OnInit {

    // 子コンポーネント
    @ViewChild('acpop') acpop: EAcTitlePopupInputComponent;
    @ViewChild('consumptionpop') consumptionpop: EConsumptionTaxPopupInputComponent;
    @ViewChild('taxRateSelect') taxRateSelect: ETaxRateSelectComponent;
    @ViewChild('slipListGrid') slipListGrid: WjFlexGridEx;

    // 必須：親画面のアプリケーションプロパティ
    @Input() public property: EcoKaikeiProperty;

    // 必須：親画面で選択された伝票
    @Input() set commonInputSlip(value: CommonInputSlipDto) {

        // キャンセルボタンで未編集状態に戻るためにオリジナルを保存
        this.commonInputSlipOriginal = value;

        // コンポーネント初期化中フェーズ以外はここでデータコンテキストを初期化する（初期化時は初期化完了時にreseAll()を呼び出す）
        if (this.isInitialized) {

            // データコンテキスト初期化
            this.resetAll();
        }
    }

    get commonInputSlip(): CommonInputSlipDto {
        return this._commonInputSlip;
    }

    // 必須：親画面で取得した参照モードフラグ
    private _isReferenceMode:boolean;
    @Input() set isReferenceMode(value:boolean) {

        this._isReferenceMode = value;

        // 親画面で最初に月次スライダーが選択された時点で、isReferenceMode が true から false に変化する場合がある。
        // commonInputSlipが変化せずに（例：nullからnullに変化等）isReferenceMode だけが変化すると commonInputSlip のセッターが実行されないので
        // ここでデータコンテキストを初期化する（初期化時は初期化完了時にreseAll()を呼び出す）
        if (this.isInitialized && (!this.commonInputSlipOriginal || this.commonInputSlipOriginal.journalId < 0)) {

            // 親画面が買掛伝票入力の場合
            if (this.parentView === "AC181") {
                // 表示制御 - 仕入先は参照モード以外は常時活性
                if (this.isReferenceMode) {
                    this.isDisabledCustomer = true;
                }
            }

            // ダミーの伝票を削除してresetAll()で作り直す
            this.commonInputSlipOriginal = null;

            // データコンテキスト初期化
            this.resetAll();
        }
    }

    get isReferenceMode(): boolean {
        return this._isReferenceMode;
    }

    // 必須：親画面のコード
    @Input() parentView:string;

    // 追加イベント
    @Output() addOnClick = new EventEmitter<any>();

    // 更新イベント
    @Output() commitOnClick = new EventEmitter<any>();

    // 削除イベント
    @Output() deleteOnClick = new EventEmitter<any>();

    // 親画面から渡される伝票DTO
    private _commonInputSlip: CommonInputSlipDto;
    private commonInputSlipOriginal: CommonInputSlipDto;

    // 伝票DTOに含まれる明細データの画面制御用ヘッダーリスト
    public slipDetailDtoHeaderList:InputSlipDetailDtoHeader[];

    // グリッドに表示すべき明細データだけを含んだリスト
    get visibleSlipDetailDtoHeaderList(): InputSlipDetailDtoHeader[] {
        return this.slipDetailDtoHeaderList.filter(s => s.visible);
    }

    // グリッド直下に表示する買掛金額合計（税抜）
    public totalAmount: number;

    // 設定された仕訳日に基づく税情報
    public taxInfo: TaxInfoDto;

    // 税込／税別フラグ
    public isTaxIncluded: boolean;

    // 編集中フラグ
    public isDirty: boolean = false;

    // 表示する貸借区分
    public dispAcDrCrCls: number[] = [0, 1, 2, 3];

    // 科目管理区分 -9:ALL
    public acManagementCls:number = -9;

    // マネーツリー口座管理区分 -1:ALL
    public mtAccountCls:number = -1;

    // 仕入先の非活性フラグ
    public isDisabledCustomer:boolean = false;

    // このコンポーネントのAngularデータバインディング機構の初期化が完了したかどうかを示すフラグ
    private isInitialized: boolean = false;

    public journalMonthTemplates: any[] = [
        { title: '通常月', value: 1 },
        { title: '決算月1', value: 13 }, { title: '決算月2', value: 14 }, { title: '決算月3', value: 15 }];

    public stampTemplates: any[] = [
        { header: '承認者', top: 'journalSealTopL', bottom: 'journalSealBottomL', section: 'journalSealSectionL', timestamp:'journalSealTimestampL' , stamp: 'isStampJournalSealL', approval: 'isApprovalJournalSealL'},
        { header: '確認者', top: 'journalSealTopC', bottom: 'journalSealBottomC', section: 'journalSealSectionC', timestamp:'journalSealTimestampC' , stamp: 'isStampJournalSealC', approval: 'isApprovalJournalSealC'},
        { header: '起票者', top: 'journalSealTopR', bottom: 'journalSealBottomR', section: 'journalSealSectionR', timestamp:'journalSealTimestampR' , stamp: 'isStampJournalSealR', approval: 'isApprovalJournalSealR'}];

    public industryTemplates: any[] = [
        { title: '', value: -1 },
        { title: '第一種', value: 1 }, { title: '第二種', value: 2 }, { title: '第三種', value: 3 },
        { title: '第四種', value: 4 }, { title: '第五種', value: 5 }, { title: '第六種', value: 6 }];

    // 【共通】消費税区分の初期値で使用する制御マトリックス
    private taxInputAvailabilityMatrix:any = {
        // パターン1 - 消費税関連項目の活性/非活性フラグ
        1: {
            // 税情報．課税方式＝０：免税事業者
            0: {
                // 貸方科目=０：対象外
                0: { 0: false, 1: false, 2: false, 3:false,},   // X | X | X | X
                // 貸方科目=１：売上科目
                1: { 0: false, 1: false, 2: false, 3:false,},   // X | X | X | X
                // 貸方科目=２：仕入科目
                2: { 0: false, 1: false, 2: false, 3:false,},   // X | X | X | X
                // 貸方科目=３：売上/仕入
                3: { 0: false, 1: false, 2: false, 3:false,},   // X | X | X | X
            },
            // 税情報．課税方式＝１：簡易課税
            1: {
                // 貸方科目=０：対象外
                0: { 0: false, 1: true , 2: false, 3:true ,},   // X | O | X | O
                // 貸方科目=１：売上科目
                1: { 0: true , 1: true , 2: false, 3:true ,},   // O | O | X | O
                // 貸方科目=２：仕入科目
                2: { 0: false, 1: false, 2: false, 3:true ,},   // X | X | X | O
                // 貸方科目=３：売上/仕入
                3: { 0: true , 1: true , 2: true , 3:true ,},   // O | O | O | O
            },
            // 税情報．課税方式＝２：原則課税
            2: {
                // 貸方科目=０：対象外
                0: { 0: false, 1: true , 2: true , 3:true ,},   // X | O | O | O
                // 貸方科目=１：売上科目
                1: { 0: true , 1: true , 2: false, 3:true ,},   // O | O | X | O
                // 貸方科目=２：仕入科目
                2: { 0: true , 1: false, 2: true , 3:true ,},   // O | X | O | O
                // 貸方科目=３：売上/仕入
                3: { 0: true , 1: true , 2: true , 3:true ,},   // O | O | O | O
            },
        },
        // パターン2 - 消費税コードの初期値
        2: {
            // 税情報．課税方式＝０：免税事業者
            0: {
                // 貸方科目=０：対象外
                0: { 0: false, 1: false, 2: false, 3:false,},   // X | X | X | X
                // 貸方科目=１：売上科目
                1: { 0: false, 1: false, 2: false, 3:false,},   // X | X | X | X
                // 貸方科目=２：仕入科目
                2: { 0: false, 1: false, 2: false, 3:false,},   // X | X | X | X
                // 貸方科目=３：売上/仕入
                3: { 0: false, 1: false, 2: false, 3:false,},   // X | X | X | X
            },
            // 税情報．課税方式＝１：簡易課税
            1: {
                // 貸方科目=０：対象外
                0: { 0: Ptn2.C_NONE, 1: Ptn2.C_DR  , 2: Ptn2.C_NONE, 3:Ptn2.C_DR  ,},   // X | O | X | O
                // 貸方科目=１：売上科目
                1: { 0: Ptn2.C_CR  , 1: Ptn2.C_610 , 2: Ptn2.C_NONE, 3:Ptn2.C_610 ,},   // O | O | X | O
                // 貸方科目=２：仕入科目
                2: { 0: Ptn2.C_NONE, 1: Ptn2.C_NONE, 2: Ptn2.C_NONE, 3:Ptn2.C_610 ,},   // X | X | X | O
                // 貸方科目=３：売上/仕入
                3: { 0: Ptn2.C_CR  , 1: Ptn2.C_610 , 2: Ptn2.C_610 , 3:Ptn2.C_610 ,},   // O | O | O | O
            },
            // 税情報．課税方式＝２：原則課税
            2: {
                // 貸方科目=０：対象外
                0: { 0: Ptn2.C_NONE, 1: Ptn2.C_DR  , 2: Ptn2.C_DR  , 3:Ptn2.C_DR  ,},   // X | O | O | O
                // 貸方科目=１：売上科目
                1: { 0: Ptn2.C_CR  , 1: Ptn2.C_610 , 2: Ptn2.C_NONE, 3:Ptn2.C_610 ,},   // O | O | X | O
                // 貸方科目=２：仕入科目
                2: { 0: Ptn2.C_CR  , 1: Ptn2.C_NONE, 2: Ptn2.C_710 , 3:Ptn2.C_610 ,},   // O | X | O | O
                // 貸方科目=３：売上/仕入
                3: { 0: Ptn2.C_CR  , 1: Ptn2.C_610 , 2: Ptn2.C_610 , 3:Ptn2.C_610 ,},   // O | O | O | O
            },
        },
    };


    constructor() {
    }

    ngOnInit() {
        console.log('ngOnInit: isReferenceMode = ' + this.isReferenceMode);

        // コンポーネント初期化済みフラグをセット
        this.isInitialized = true;

        console.log(`parentView = ${this.parentView}`);

        // 親画面が買掛伝票入力の場合
        if (this.parentView === "AC181") {
            // 貸借区分
            this.dispAcDrCrCls = [3];

            // 科目管理区分
            this.acManagementCls = 3;

            // マネーツリー口座管理区分
            this.mtAccountCls = 0;

            // 表示制御 - 仕入先は参照モード以外は常時活性
            if(this.isReferenceMode){
                this.isDisabledCustomer = true;
            }
        }

        // 親画面が買掛伝票入力（クレジット）の場合
        if (this.parentView === "AC205") {
            /** 貸借区分 */
            this.dispAcDrCrCls = [3];

            /** マネーツリー口座管理区分 -1:ALL */
            this.mtAccountCls = 1;
        }

        console.log(`aspay:dispAcDrCrCls = ${this.dispAcDrCrCls}, acManagementCls= ${this.acManagementCls}, mtAccountCls= ${this.mtAccountCls}`);

        // データコンテキスト初期化
        this.resetAll();

    }

    /**
     * データコンテキストを初期化
     */
    private resetAll(): void {

        // オリジナルの伝票が親画面から渡されなかった場合、新規の伝票を準備する
        if (!this.commonInputSlipOriginal) {

            this.commonInputSlipOriginal = new CommonInputSlipDto();

            // 仕訳日を初期化（今日の日付）ただし参照モード時を除く
            if (!this.isReferenceMode) {

                var today = new Date();
                // 会計期間（終了）を超えている場合は終了日で初期化
                if (today > this.property.ownershipDto.toDate) {
                    today = this.property.ownershipDto.toDate;
                }
                // 会計期間（開始）未満の場合は開始日で初期化
                else if (today < this.property.ownershipDto.fromDate) {
                    today = this.property.ownershipDto.fromDate;
                }
                this.commonInputSlipOriginal.journalDate = this.commonInputSlipOriginal.journalRawDate = today;
            }
        }

        // 新しい value を編集用に保存
        this._commonInputSlip = cloneObject(this.commonInputSlipOriginal);

        // 税情報を取得
        if (this._commonInputSlip.journalDate) {
            this.journalDateOnChange();
        }

        // 明細レコードのリストを画面制御情報を含んだヘッダークラスのリストに変換
        this.slipDetailDtoHeaderList = this._commonInputSlip.slipDetailDtoList.map(slip => this.initDetail(slip, true));

        // 諸口方式の場合はリストの先頭レコードを表示しない
        if (this._commonInputSlip.journalBuildmethod === 1 && this.slipDetailDtoHeaderList.length > 0) {

            // リストの先頭レコードのグリッド表示フラグを削除
            this.slipDetailDtoHeaderList[0].visible = false;
        }

        // 明細データがグリッド上での最小表示件数（3件）未満の時には、不足分の空レコードを追加する。
        var minimum = 3 - this.visibleSlipDetailDtoHeaderList.length;
        for (var i = 0; i < minimum; i++) {
            this.addDetailBtnOnClick();
        }

        //-----------------------------
        // データ補正処理
        //-----------------------------

        // TODO: e-date-field に Unixタイムスタンプをバインドすると ExpressionChangedAfterItHasBeenCheckedError が出るのを回避
        if (typeof(this._commonInputSlip.journalDate) === 'number') {
            this._commonInputSlip.journalDate = new Date(this._commonInputSlip.journalDate);
        }
        if (typeof(this._commonInputSlip.journalPaymentDate) === 'number') {
            this._commonInputSlip.journalPaymentDate = new Date(this._commonInputSlip.journalPaymentDate);
        }

        // TODO: e-text-input の eValue に null をバインドすると ExpressionChangedAfterItHasBeenCheckedError が出るのを回避
        if (this._commonInputSlip.journalSummary === null) {
            this._commonInputSlip.journalSummary = '';
        }

        // 仕訳IDが未設定（新規作成中で一度も更新ボタンが押されていない）の場合は印鑑操作できない
        var canStamp = this.commonInputSlip.journalId >= 0;

        // 利用者処理権限区分が、１：管理者、２：一般、４：会計事務所のいずれでもない場合、印鑑操作は不可
        canStamp = canStamp && (this.property.userAuthorityCls === 1 || this.property.userAuthorityCls === 2 || this.property.userAuthorityCls === 4);

        // 印鑑（左）の活性／非活性フラグを初期化
        if (canStamp && !this._commonInputSlip.journalSealTimestampL && this._commonInputSlip.journalSealTimestampC) {
            this.commonInputSlip.isStampJournalSealL = true;
        }
        // 印鑑（中）の活性／非活性フラグを初期化
        if (canStamp && !this._commonInputSlip.journalSealTimestampC && this._commonInputSlip.journalSealTimestampR) {
            this.commonInputSlip.isStampJournalSealC = true;
        }
        // 印鑑（右）の活性／非活性フラグを初期化
        if (canStamp && !this._commonInputSlip.journalSealTimestampR) {
            this.commonInputSlip.isStampJournalSealR = true;
        }

        // 押印済みフラグの初期化
        this.stampTemplates.forEach(t => {
            if (this._commonInputSlip[t.timestamp]) {
                this._commonInputSlip[t.approval] = true;
            }
        });

        this._commonInputSlip.slipDetailDtoList.forEach(s => {

            // TODO: InputSlipDetailDto.journalAmountが"null"になっているレコードが存在するのでデータを補正（データエラー？）
            if (s.journalAmount === null) {
                s.journalAmount = 0;
            }
            // TODO: InputSlipDetailDto.journalTaxAmountがnullになっているレコードが存在するのでデータを補正（データエラー？）
            if (s.journalTaxAmount === null) {
                s.journalTaxAmount = 0;
            }
            // TODO: e-text-input の eValue に null をバインドすると ExpressionChangedAfterItHasBeenCheckedError が出るのを回避
            if (s.journalSummaryTop === null) {
                s.journalSummaryTop = '';
            }
            if (s.journalSummaryBottom === null) {
                s.journalSummaryBottom = '';
            }

            // TODO: e-date-field に Unixタイムスタンプをバインドすると ExpressionChangedAfterItHasBeenCheckedError が出るのを回避
            if (typeof(s.journalPaymentDate) === 'number') {
                s.journalPaymentDate = new Date(s.journalPaymentDate);
            }

        });

        // 編集中フラグをリセット
        this.isDirty = false;
    }

    /**
     * 仕訳月が変更された
     */
    public journalMonthOnChange(): void {

        // 決算月１～３が選択された場合
        if (this.commonInputSlip.journalMonth > 12) {

            // 仕訳日を会計期間（終了）に設定する
            this.commonInputSlip.journalDate = new Date(this.property.ownershipDto.toDate);
        }

        // 編集中フラグをセット
        this.setDirtyFlag(null, 1);
    }

    /**
     * 仕訳日が変更された
     */
    public journalDateOnChange(): void {

        // 税情報を取得
        this.taxInfo = (new Date(this.commonInputSlip.journalDate)) <= (new Date(this.property.ownershipDto.toDate))? this.property.ownershipDto.currentTaxInfoDto: this.property.ownershipDto.nextTaxInfoDto;

        // 税込/税別フラグの設定
        this.isTaxIncluded = this.taxInfo.taxAccountingMethod === 1;

        // 「【共通】消費税区分の初期値」シート　パターン1初期化時参照
        this.slipDetailDtoHeaderList.forEach(item => {
            // すべての明細の消費税区分の制御系を初期化
            this.initConsumptionTax(item,1)
        });
    }

    /**
     * 消込FLGが変更された
     *
     * AngularJS 1.x で提供されていた ng-true-value/ng-false-value ディレクティブが Angular 2 以降で提供されておらず、
     * checkbox の ngModel で true/false 以外の値（1/0、"Yes"/"No" 等）をバインドできなくなった。
     * このため、変更イベントハンドラーでの処理が必要となった。
     */
    public journalClearingFlgOnChange(): void {

        // ビット反転
        this.commonInputSlip.journalClearingFlg = ~this.commonInputSlip.journalClearingFlg & 1;

        // 編集中フラグをセット
        this.setDirtyFlag(null, 63);
    }

    /**
     * 明細グリッドの初期化完了イベントハンドラー
     * @param grid
     */
    public slipListGridOnInitialized(grid:WjFlexGridEx): void {

        // 列ヘッダーの高さを設定 (HTML側で設定できない)
        grid.columnHeaders.rows.defaultSize = 22;

        // 行ヘッダーの幅を設定 (HTML側で設定できない)
        grid.rowHeaders.columns[0].width = 26;
    }

    /**
     * グリッドの itemsSource 変更イベントハンドラー
     */
    public slipGridItemsSourceOnChange(): void {

        // グリッド直下の売掛金額合計を計算
        this.calculateTotalAmount();
    }

    /**
     * グリッドの＋ボタンがクリックされた
     */
    public addDetailBtnOnClick(): void {

        // 詳細レコードを追加
        var slip = new InputSlipDetailDto();
        this._commonInputSlip.slipDetailDtoList.push(slip);

        // 初期化してリストの末尾に追加
        this.slipDetailDtoHeaderList.push(this.initDetail(slip, false));

        // 明細一覧を再表示する
        if (this.slipListGrid) {
            this.slipListGrid.collectionView.refresh();
            this.slipListGrid.refresh(true);
        }
    }

    /**
     * 詳細レコードの初期化
     * @param slip
     */
    private initDetail(slip:InputSlipDetailDto, hasData:boolean): InputSlipDetailDtoHeader {

        // 各項目の活性／非活性フラグを持つヘッダークラスでラップする
        var item = new InputSlipDetailDtoHeader(slip, hasData);

        // 勘定科目の制御系を初期化
        this.initAcTitle(item);

        // 消費税区分の制御系を初期化
        this.initConsumptionTax(item, 1);

        return item;
    }

    /**
     *【共通】勘定科目の制御 に関する処理
     * @param item
     */
    private initAcTitle(item:InputSlipDetailDtoHeader): void {

        /**
         * 【共通】勘定科目の制御 - 相手先／期日の制御
         */

        // 相手科目（借方科目）が未設定の場合は処理を行わない
        if (item.slip.drAcTitleId < 0) {
            console.log('initAcTitle: slip.drAcTitleId has not been set, so cancel this method.');
            return;
        }

        // 消費税コードに対応する消費税分類を取得
        var drItem:EPopupItem = this.acpop.searchAcTitleItemByID(item.slip.drAcTitleId);

        // 勘定科目(DB).補助科目制御区分=2:補助科目がある
        if (drItem.cls7 === 2) {

            // 相手先に-1が設定（表示上：空）される。
            item.slip.customerId = -1;
            // 期日を空にして非活性にする。
            item.slip.journalPaymentDate = null;
            item.isPaymentDateEnabled = false;
        }
        // 勘定科目(DB).科目管理区分=3:取引先の管理ができる科目
        else if (drItem.cls3 === 3) {

            // 相手先にヘッダの得意先が設定される。
            item.slip.customerId = this.commonInputSlip.customerId;

            // 勘定科目（DB）.貸借区分= ０：借方PL科目　または　１：貸方PL科目の場合
            if (drItem.tabCls === 0 || drItem.tabCls === 1) {

                // 期日を空にして
                item.slip.journalPaymentDate = null;
                // 非活性にする。
                item.isPaymentDateEnabled = false;
            }
            // 勘定科目（DB）.貸借区分= ２：借方ＢＳ科目　または　３：貸方ＢＳ科目の場合
            else  {

                // 期日にヘッダの仕訳日付の値が設定され
                item.slip.journalPaymentDate = this.commonInputSlip.journalDate;
                // 活性になる。
                item.isPaymentDateEnabled = true;
            }
        }
        // 上記以外
        else {

            // 相手先に-1が設定（表示上：空）される。
            item.slip.customerId = -1;
            // 期日を空にして非活性にする。
            item.slip.journalPaymentDate = null;
            item.isPaymentDateEnabled = false;
        }

        /**
         * 【共通】勘定科目の制御 - 部門の制御
         */

        // 勘定科目（DB）.貸借区分= ０：借方PL科目　または　１：貸方PL科目の場合
        if (drItem.tabCls === 0 || drItem.tabCls === 1) {

            // 部門が活性になる。
            item.isSegmentEnabled = true;
        }
        // 勘定科目（DB）.貸借区分= ２：借方ＢＳ科目　または　３：貸方ＢＳ科目の場合
        else  {

            // 部門は-1が設定され（表示上：空）
            item.slip.segmentId = -1;
            // 非活性
            item.isSegmentEnabled = false;
        }
    }

    /**
     * 【共通】消費税区分の初期値 に関する処理
     * @param item      詳細レコードのヘッダー
     * @param pattern  【共通】消費税区分の初期値のパターン番号（1:初期化時、2:変更時）
     */
    private initConsumptionTax(item:InputSlipDetailDtoHeader, pattern:number): void {

        /**
         *【共通】消費税区分の初期値／パターン1初期値 - 消費税関連項目の活性/非活性の制御
         * 税情報.課税方式（0:免税事業者、1:簡易課税、2:原則課税）ごとに消費税関連項目の制御を行う
         */

        // 税情報が未解決（仕訳日が未設定）である場合は処理を行わない
        if (!this.taxInfo) {
            console.log('initConsumptionTax: taxInfo has not been set, so cancel this method.');
            return;
        }

        // 税情報.課税方式 = 1:簡易課税 または 2:原則課税 の場合
        if (this.taxInfo.businessTaxClsMethod === 1 || this.taxInfo.businessTaxClsMethod === 2) {

            /**
             * 消費税関連項目の活性/非活性マトリックスから下記の条件にマッチするルールを抽出し、伝票詳細の各入力欄に適用する
             * ・税情報.課税方式
             * ・貸方科目の消費税コードに対応する消費税分類（税情報.課税方式が免税事業者以外の場合）
             * ・借方科目の消費税コードに対応する消費税分類（税情報.課税方式が免税事業者以外の場合）
             */

            // 貸方勘定科目が未設定である場合は処理を行わない
            if (this.commonInputSlip.crAcTitleId < 0) {
                console.log('initConsumptionTax: crAcTitleId has not been set, so cancel this method.');
                return;
            }

            // 相手科目（借方科目）が未設定の場合は処理を行わない
            if (item.slip.drAcTitleId < 0) {
                console.log('initConsumptionTax: slip.drAcTitleId has not been set, so cancel this method.');
                return;
            }
            // 補助科目が設定されている場合は補助科目コードに基づいて処理する
            var drAcTitleId = item.slip.drAcSubTitleId >= 0? item.slip.drAcSubTitleId: item.slip.drAcTitleId;

            // 消費税コードに対応する消費税分類を取得
            var drItem:EPopupItem = this.acpop.searchAcTitleItemByID(drAcTitleId);
            var crItem:EPopupItem = this.acpop.searchAcTitleItemByID(this.commonInputSlip.crAcTitleId);

            //------------------------------
            // TODO: 消費税分類を取得できない場合がある（データエラー？）
            //------------------------------
            if (!drItem) {
                console.error('Fatal Error: ac-payable-slip-component: missing dr ac title item. Id = ' + item.slip.drAcTitleId);
                return;
            }
            if (!crItem) {
                console.error('Fatal Error: ac-payable-slip-component: missing cr ac title item. Id = ' + this.commonInputSlip.crAcTitleId);
                return;
            }

            // マトリックスから消費税区分の活性/非活性フラグを設定する
            console.log(`crAcTitleOnChange: 課税方式-貸方消費税分類-借方消費税分類 = ${this.taxInfo.businessTaxClsMethod}-${crItem.cls4}-${drItem.cls4} = ${item.isTaxInputEnabled}`);
            item.isTaxInputEnabled = this.taxInputAvailabilityMatrix[this.taxInfo.businessTaxClsMethod][crItem.cls4][drItem.cls4];
            console.log(`crAcTitleOnChange: 課税方式-貸方消費税分類-借方消費税分類 = ${this.taxInfo.businessTaxClsMethod}-${crItem.cls4}-${drItem.cls4} = ${item.isTaxInputEnabled}`);

            // 上記マトリクスの結果が○の場合 科目が税と関連するため税の入力を行う
            if (item.isTaxInputEnabled) {

                // 消費税区分は活性になる。

                // パターン１の処理
                if (pattern === 1) {

                    if (this.taxInfo.businessTaxClsMethod === 1) {

                        // 業種は活性になる。
                        item.isTaxIndustryEnabled = true;
                    }
                    else {

                        // 業種は-1が設定され（表示上：空）、非活性
                        item.slip.industryId = -1;
                        item.isTaxIndustryEnabled = false;
                    }
                }
                // パターン2の処理
                else {

                    // マトリックスから消費税コードの初期値分類を取得
                    var ptn2:Ptn2 = this.taxInputAvailabilityMatrix[2][this.taxInfo.businessTaxClsMethod][crItem.cls4][drItem.cls4];

                    // item.isTaxInputEnabled===true なので、ptn2 は Ptn2.C_NONE 以外になっている。

                    // 消費税区分は活性になる。
                    item.isTaxInputEnabled = true;

                    // 消費税区分には上記のマトリクスの中の値が設定される。

                    // 借方科目の課税コード
                    if (ptn2 === Ptn2.C_DR) {
                        item.slip.consumptionTaxCd = drItem.cls5;
                    }
                    // 貸方科目の課税コード
                    else if (ptn2 === Ptn2.C_CR) {
                        item.slip.consumptionTaxCd = crItem.cls5;
                    }
                    // 610.課税売上
                    else if (ptn2 === Ptn2.C_610) {
                        item.slip.consumptionTaxCd = 610;
                    }
                    // 710.課税仕入
                    else if (ptn2 === Ptn2.C_710) {
                        item.slip.consumptionTaxCd = 710;
                    }

                    // 税情報.課税方式 = 1:簡易課税 の場合
                    if (this.taxInfo.businessTaxClsMethod === 1) {

                        // 業種には借方科目の勘定科目（DB）.簡易課税業種（左記が未設定の場合は税情報.簡易課税業種）が設定され、活性
                        // （設定済みの場合は変更しない）
                        if (item.slip.industryId < 0) {
                            item.slip.industryId = drItem.cls6;
                            item.isTaxIndustryEnabled = true;
                        }
                    }
                }

                // 【共通】消費税区分の制御シート
                // に基づき
                // 税率、内消費税の制御を実施
                this.consumptionTaxOnChange(item);
            }
        }

        // 税情報.課税方式 = 0:免税事業者 の場合 免税という設定のため、税の入力をしない。
        // または、上記マトリクスの結果が×の場合 科目が税と関連しないため税の入力を行わない
        if (this.taxInfo.businessTaxClsMethod === 0 || !item.isTaxInputEnabled) {

            // 消費税区分は-1が設定され（表示上：空）、非活性
            item.slip.consumptionTaxCd = -1;
            item.isTaxInputEnabled = false;
            // 業種は-1が設定され（表示上：空）、非活性
            item.slip.industryId = -1;
            item.isTaxIndustryEnabled = false;
            // 内消費税は空が設定され、非活性
            item.slip.journalTaxAmount = 0;
            item.isTaxAmountEnabled = false;
            // 税率は-1が設定され（表示上：空）、非活性
            item.slip.taxRateId = -1;
            item.isTaxRateEnabled = false;
        }
    }

    /**
     * 「貸方科目」が変更された
     */
    public crAcTitleOnChange(): void {

        // 画面制御用の各フラグを設定
        // すべての明細レコードに対して「相手科目」変更イベントの処理を行う
        this.slipDetailDtoHeaderList.forEach(slip => {
            this.drAcTitleOnChange(slip);
        });
    }

    /**
     * グリッドの「相手科目」が変更された
     */
    public drAcTitleOnChange(item:InputSlipDetailDtoHeader): void {

        /**
         *  画面制御 - 補助科目、相手先、部門の制御
         */
        this.initAcTitle(item);

        /**
         *  画面制御 - 税に関する項目の制御
         */

        // 相手科目（借方科目）が未設定の場合は処理を行わない
        if (item.slip.drAcTitleId < 0) {
            console.log('drAcTitleOnChange: slip.drAcTitleId has not been set, so cancel this method.');
            return;
        }

        // 消費税コードに対応する消費税分類を取得
        var drItem:EPopupItem = this.acpop.searchAcTitleItemByID(item.slip.drAcTitleId);

        // 勘定科目（DB）.補助科目制御区分=２：補助科目があるの場合
        if (drItem.cls7 === 2) {

            // 科目が補助を持つ場合、補助が確定してから消費税を入れる。

            // 消費税区分は-1が設定され（表示上：空）、非活性
            item.slip.consumptionTaxCd = -1;
            item.isTaxInputEnabled = false;
            // 業種は-1が設定され（表示上：空）、非活性
            item.slip.industryId = -1;
            item.isTaxIndustryEnabled = false;
            // 内消費税は空が設定され、非活性
            item.slip.journalTaxAmount = 0;
            item.isTaxAmountEnabled = false;
            // 税率は-1が設定され（表示上：空）、非活性
            item.slip.taxRateId = -1;
            item.isTaxRateEnabled = false;
        }
        // 上記以外
        // 科目が補助を持たない場合、消費税の入力をする。
        else {

            // 「【共通】消費税区分の初期値」シート　パターン② 科目の変更時
            // ※ここでは補助科目の消費税コードが選択される。(TODO: 左記のコメントの内容は仕様書の間違い？要確認)
            this.initConsumptionTax(item, 2);
        }
    }

    /**
     * グリッドの「補助」が変更された
     */
    public drAcSubTitleOnChange(item:InputSlipDetailDtoHeader): void {

        /**
         *  画面制御 - 税に関する項目の制御
         */

        // 相手科目（借方科目）が未設定の場合は処理を行わない
        if (item.slip.drAcSubTitleId < 0) {
            console.log('drAcSubTitleOnChange: slip.drAcSubTitleId has not been set, so cancel this method.');
            return;
        }

        // 「【共通】消費税区分の初期値」シート　パターン② 科目の変更時
        // ※ここでは補助科目の消費税コードが選択される。
        this.initConsumptionTax(item, 2);
    }

    /**
     * グリッドの「税込金額」または「内消費税」が変更された
     * @param item
     */
    public amountOnChange(item:InputSlipDetailDtoHeader): void {

        // 内消費税の制御
        this.calculateTaxAmount(item, 1);

        // グリッド下の合計を計算
        this.calculateTotalAmount();
    }

    /*
    * グリッドの「消費税」が変更された
    * @param item
    */
   public consumptionTaxOnChange(item:InputSlipDetailDtoHeader): void {

       console.log('consumptionTaxOnChange: consumptionTaxCd = ' + item.slip.consumptionTaxCd);

       /**
        * 【共通】消費税区分の制御
        */

       // 「消費税」が空欄ではない場合
       if (item.slip.consumptionTaxCd >= 0) {

            // 消費税計算区分を取得
            var popupItem = this.consumptionpop.searchConsumptionItemByID(item.slip.consumptionTaxCd);

            // 消費税区分（DB）.消費税計算区分 = １：消費税を自動で計算させる
            if (popupItem && popupItem.cls2 === 1) {

                // 税率が活性になる。
                item.isTaxRateEnabled = true;
                // 税率が空の場合、税率選択ボックスの先頭を設定する。
                // ※２０１９年１０月１日以降は１０％　２０１９年９月３０日以前は８％を設定 ←コンポーネントで制御する。
                if (!item.slip.taxRateId || item.slip.taxRateId < 0) {
                    item.slip.taxRateId = this.taxRateSelect.itemsSource[0].taxRateId;
                    // this.taxRateSelect.selectedIndex = 0;
                }
            }

            // 消費税区分（DB）.消費税計算区分 = ２：輸入取引で消費税が変更できない
            else if (popupItem && popupItem.cls2 === 2) {

                // 税率が活性になる。
                item.isTaxRateEnabled = true;
                // 税率が空の場合、税率選択ボックスの先頭を設定する。
                // ※２０１９年１０月１日以降は１０％　２０１９年９月３０日以前は８％を設定 ←コンポーネントで制御する。
                if (!item.slip.taxRateId || item.slip.taxRateId < 0) {
                    item.slip.taxRateId = this.taxRateSelect.itemsSource[0].taxRateId;
                    // this.taxRateSelect.selectedIndex = 0;
                }
            }
            // 消費税区分（DB）.消費税計算区分 = ０：消費税の計算をしない
            else {

                // 税率は空になり、非活性
                item.slip.taxRateId = -1;
                item.isTaxRateEnabled = false;
            }
        }
        // 「消費税」が空欄の場合
        else {
            item.slip.taxRateId = -1;
            item.isTaxRateEnabled = false;
        }

        /**
         * 【共通】内消費税の制御
         */
        this.calculateTaxAmount(item, 0);

        // グリッド下の合計を計算
        this.calculateTotalAmount();
   }

   /**
    * グリッドの「消費税率」が変更された
    * @param item
    */
   public taxRateOnChange(item:InputSlipDetailDtoHeader): void {

       // 内消費税の制御
       this.calculateTaxAmount(item, 1);

       // グリッド下の合計を計算
       this.calculateTotalAmount();

       // 編集中フラグをセット
       this.setDirtyFlag(item,17);
   }

    /**
     * グリッドの削除ボタンがクリックされた
     * @param item
     */
    public deleteDetailBtnOnClick(item:InputSlipDetailDtoHeader): void {

        // 配列から当該レコードを排除する
        this.commonInputSlip.slipDetailDtoList = this.commonInputSlip.slipDetailDtoList.filter(s => s !== item.slip);
        this.slipDetailDtoHeaderList = this.slipDetailDtoHeaderList.filter(h => h !== item);

        // 明細一覧を再表示する
        if (this.slipListGrid) {
            console.log('deleteDetailBtnOnClick: this.commonInputSlip.slipDetailDtoList');
            console.log(this.commonInputSlip.slipDetailDtoList);
            console.log(item.slip);
            console.log('deleteDetailBtnOnClick: this.commonInputSlip.slipDetailDtoList');
            console.log(this.slipDetailDtoHeaderList);
            console.log(item);
            this.slipListGrid.collectionView.refresh();
            this.slipListGrid.refresh(true);
        }

        // グリッド直下の売掛金額合計を計算
        this.calculateTotalAmount();

        // 編集中フラグをセット
        this.setDirtyFlag(null, 100);
    }

    /**
     * 伝票追加ボタンがクリックされた
     */
    public addBtnOnClick(): void {
        // データコンテキストを空のCommonInputSlipに置き換える
        this.commonInputSlipOriginal = new CommonInputSlipDto();

        // データコンテキストを初期化
        this.resetAll();

        // イベントを発火
        this.addOnClick.emit(this.commonInputSlip);
    }

    /**
     * 取消ボタンがクリックされた
     */
    public cancelBtnOnClick(): void {

        // データコンテキストを初期化
        this.resetAll();
    }

    /**
     * 伝票削除ボタンがクリックされた
     */
    public deleteBtnOnClick(): void {

        // 未編集のオリジナル版でイベントを発火
        // 親画面の確認メッセージで操作がキャンセルされる場合があるので、現在の編集内容は破棄せずに保留しておく
        this.deleteOnClick.emit(this.commonInputSlipOriginal);
    }

    /**
     * 更新ボタンがクリックされた
     */
    public updateBtnOnClick(): void {

        // クローンを作成
        var slip:CommonInputSlipDto = cloneObject(this.commonInputSlip);

        // データ補正

        // 仕訳月が決算月１～３の場合、
        if (slip.journalMonth > 12) {

            // 伝票入力共通DTO.会計年度コードにEcoKaikeiProperty.OwnershipDto.現在選択している会計年度を設定する。
            slip.fisicalYearCd = this.property.ownershipDto.selectFisicalYear;
        }
        // 通常月が選択された場合
        else {

            // 仕訳日付から会計年度と相対月を取得する
            var monthItem = this.property.getDateToItem(slip.journalDate);

            if (monthItem !== null) {
                //伝票入力共通DTO.仕訳相対月、伝票入力共通DTO.会計年度コードに設定する
                slip.fisicalYearCd = monthItem.fisicalYearCd;
                slip.journalMonth = monthItem.relativeMonth;
            }
        }

        //-----------------------------
        // 初期状態（未編集）のレコードを除いた伝票明細リストを作成
        //-----------------------------

        // 有意なデータを含んでいるレコード（hasData プロパティが true であるレコード）のみを抽出
        slip.slipDetailDtoList = this.slipDetailDtoHeaderList.filter(item => item.hasData).map(item => item.slip);

        //-----------------------------
        // データ補正
        //-----------------------------

        // Date を Unix タイムスタンプに変換
        for (var key in slip) {
            if (slip[key] instanceof Date) {
                slip[key] = (slip[key] as Date).getTime();
            }
        }
        slip.slipDetailDtoList.forEach(item => {
            for (var key in item) {
                if (item[key] instanceof Date) {
                    item[key] = (item[key] as Date).getTime();
                }
            }
        });

        // 仕訳伝票種別の設定
        slip.journalSlipType = 40;

        // イベントを発火
        this.commitOnClick.emit(slip);
    }

    /**
     * 入力項目の値が変更された
     */
    public setDirtyFlag(item:InputSlipDetailDtoHeader, n:number): void {

        console.log('setDirtyFlag: ' + n);

        if (item) {
            item.hasData = true;
        }
        if (!this.isDirty) {
            this.isDirty = true;
        }
    }

    /**
     *【共通】内消費税の制御 に関する処理
     * @param item
     * @param changeType  (０：消費税コードの変更、１：金額欄の変更)
     */
    private calculateTaxAmount(item: InputSlipDetailDtoHeader, changeType: number): void {

        console.log('calculateTaxAmount: item.slip.taxRateId = ' + item.slip.taxRateId);

        // 消費税区分が未設定の場合は処理を行わない
        if (item.slip.consumptionTaxCd < 0) {
            console.log('calculateTaxAmount: 消費税区分が未設定の場合');
            item.isTaxRateEnabled = false;
            item.slip.taxRateId = -1;
            item.slip.journalTaxAmount = 0;
            return;
        }

        // 消費税計算区分を取得
        var popupItem = this.consumptionpop.searchConsumptionItemByID(item.slip.consumptionTaxCd);

        // taxInfo.taxAccountingMethod は消費税経理処理方法を示す number 値
        // 消費税経理処理方法（−１：未設定　１：税込み　２：税抜き
        console.log('calculateTaxAmount: 消費税経理処理方法 = ' + this.taxInfo.taxAccountingMethod);
        item.isTaxAmountEnabled = false;
        if (this.taxInfo.taxAccountingMethod === 1 && popupItem.cls2 === 1) {
            // 1:税込み	１：消費税を自動で計算させる

            // 選択した消費税の情報を取得する
            var taxInfo = this.property.taxRateList.find(taxRate => taxRate.taxRateId === item.slip.taxRateId);

            // 税情報が取得できない場合は消費税をゼロにする
            if (!taxInfo) {
                item.slip.journalTaxAmount = 0;
                return;
            }

            // 消費税の計算
            // 設定されている金額を１００＋税率で割返し、税率を掛けた数に端数処理を行う
            var taxAmount = item.slip.journalAmount * taxInfo.consumptionTaxRate / (100 + taxInfo.consumptionTaxRate);

            // 消費税の端数処理
            item.slip.journalTaxAmount = this.calculateRounding(taxAmount);

        } else if (this.taxInfo.taxAccountingMethod === 1 && popupItem.cls2 === 2) {
            // 1:税込み	２：輸入取引で消費税が変更できない

            // 消費税コードによる内消費税の変更
            if (item.slip.consumptionTaxCd === 770 || item.slip.consumptionTaxCd === 771 || item.slip.consumptionTaxCd === 774) {
                item.slip.journalTaxAmount = 0;

            } else if (item.slip.consumptionTaxCd === 780 || item.slip.consumptionTaxCd === 781 || item.slip.consumptionTaxCd === 784) {
                item.slip.journalTaxAmount = item.slip.journalAmount;

            } else {
                item.slip.journalTaxAmount = 0;
            }
        } else if (this.taxInfo.taxAccountingMethod === 2 && popupItem.cls2 === 1) {
            item.isTaxAmountEnabled = true;

            // 2:税抜き	１：消費税を自動で計算させる
            // changeType は 消費税コードの変更か金額欄の変更かを示す
            // changeType (０：消費税コードの変更、１：金額欄の変更)
            if (changeType === 1) {
                // 金額変更時のみ、金額に税率/100 を掛けた値に端数処理を行う
                // 消費税の計算
                var taxAmount = item.slip.journalAmount * (taxInfo.consumptionTaxRate / 100);
                // 消費税の端数処理
                item.slip.journalTaxAmount = this.calculateRounding(taxAmount);
            }
        } else if (this.taxInfo.taxAccountingMethod === 2 && popupItem.cls2 === 2) {
            // 2:税抜き	２：輸入取引で消費税が変更できない
            item.slip.journalTaxAmount = 0;
        } else if ((this.taxInfo.taxAccountingMethod === 1 && popupItem.cls2 === 0) || (this.taxInfo.taxAccountingMethod === 2 && popupItem.cls2 === 0)) {
            // 1:税込み	０：消費税の計算をしない
            // 2:税抜き	０：消費税の計算をしない
            item.slip.journalTaxAmount = 0;
        }
    }

    /**
     * 端数処理
     * @param amount
     */
    public calculateRounding(amount: number): number {
        var resultNum = 0;

        // taxInfo.taxFractionCls は消費税の端数処理方法を示す number 値
        // −１：未設定　１：切上げ　２：切捨て　３：四捨五入
        if (this.taxInfo.taxFractionCls !== -1) {
            if (this.taxInfo.taxFractionCls === 1) {
                // 切上げ
                resultNum = Math.ceil(amount);
            } else if (this.taxInfo.taxFractionCls === 2) {
                // 切捨て
                resultNum = Math.floor(amount);
            } else if (this.taxInfo.taxFractionCls === 3) {
                // 四捨五入
                resultNum = Math.round(amount);
            }
        } else {
            // 未設定の場合は切上げ　TODO：暫定対応
            resultNum = Math.ceil(amount);
        }

        return resultNum;
    }

    /**
     * グリッド下の合計を計算
     */
    private calculateTotalAmount(): void {

        // 借方が諸口ではないレコードを抽出（TODO:諸口==複合の認識でよいか確認中）
        var arr:any[] = this.commonInputSlip.slipDetailDtoList.filter(item => item.drAcTitleId !== 997);

        // 税込金額を計算
        if (this.isTaxIncluded) {

            // 税込の場合
            arr = arr.map(item => item.journalAmount);
        } else {

            // 税別の場合
            arr = arr.map(item => item.journalAmount + item.journalTaxAmount);
        }

        this.totalAmount = arr.length > 0? arr.reduce((sum, val) => sum + val): 0;
    }
}

@NgModule({
    exports: [
        AcPayableSlipComponent
    ],
    declarations: [
        AcPayableSlipComponent,
    ],
    imports: [
        WjGridModule,
        WjFlexGridModuleEx,
        NoCommaModule,
        CommonModule,
        FormsModule,
        EDropDownListModule,
        EDateFieldModule,
        EDateFieldExModule,
        EAcTitlePopupInputModule,
        EAcTitleInputModule,
        EAcSubTitleInputModule,
        ECustomerPopupInputModule,
        ECustomerInputModule,
        EMoneyInputModule,
        EMoneyLabelModule,
        EConsumptionTaxPopupInputModule,
        EConsumptionTaxInputModule,
        ETextInputModule,
        ESegmentSelectModule,
        ETaxRateSelectModule,
        EApprovalStampModule,
        ESummaryDatePopupModule,
        ESummaryDateInputModule,
        ESummaryMasterPopupModule,
        SummaryMasterPopupModule,
    ]
})
export class AcPayableSlipModule {
}
