import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnlinkEviComponent } from './unlink-evi.component';

describe('UnlinkEviComponent', () => {
  let component: UnlinkEviComponent;
  let fixture: ComponentFixture<UnlinkEviComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnlinkEviComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnlinkEviComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
