import { Component, NgModule, Input, ViewChild, Output, EventEmitter } from '@angular/core';
import { EviHeaderModule } from '../evi-base/evi-header/evi-header.component';
import { EviImageModule } from '../evi-base/evi-image/evi-image.component';
import { HttpClientModule } from '@angular/common/http';
import { ViewBaseButtonModule } from '../view-base-button/view-base-button.component';
import { EAlertModule, EAlertComponent } from '../e-alert/e-alert.component';
import { WjFlexGridColumn } from 'wijmo/wijmo.angular2.grid';
import { WjFlexGridEx } from '../wj-flex-grid-ex/wj-flex-grid-ex';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { UnlinkEviService } from '../../service/UnlinkEviService';
import { EviPaginationComponent, EviPaginationModule } from '../evi-base/evi-pagination/evi-pagination.component';
import { UnlinkEviReqDto } from '../../dto/unlinkEvi/UnlinkEviReqDto';
import { UnlinkEviResDto } from '../../dto/unlinkEvi/UnlinkEviResDto'
import { UnprocessedEviResDto } from '../../dto/unprocessedEvi/UnprocessedEviResDto';
import { CommonEviDetailDto } from '../../dto/commonEvi/CommonEviDetailDto';
import { CommonEviImageOrder } from '../../dto/commonEvi/CommonEviImageOrder';
import { LogoutService } from '../../service/logoutServive';
import { IndexService } from '../../service/IndexService';
import { ViewBaseModule } from '../view-base/view-base.component';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { WjInputModule } from 'wijmo/wijmo.angular2.input';
import { AC000MessageDto } from '../../dto/ac000/AC000MessageDto';
import { ComponentBase } from '../../view/component-base';

@Component({
  selector: 'unlink-evi',
  templateUrl: './unlink-evi.component.html',
  styleUrls: ['./unlink-evi.component.css']
})
export class UnlinkEviComponent extends ComponentBase {

    @ViewChild("eAlert")
    eAlert: EAlertComponent;

    @ViewChild("eviPagination")
    eviPagination: EviPaginationComponent;

    /** 処理対象の証憑ID */
    @Input() voucherId: number;
    @Output() voucherIdChange = new EventEmitter<number>();
    @Output() unlinkVoucherId = new EventEmitter();

    /** 会計年度コード **/
    @Input() fisicalYearCd: number;

    /** 仕訳相対月 **/
    @Input() journalMonth: number;

    /** 仕訳伝票種別 **/
    @Input() journalSlipType: number;

    /** 仕訳ID */
    @Input() journalId: number;

    /** 仕訳.更新日時 */
    @Input() journalUpdateDate: Date;

    /** 編集モード(true:編集可能 false:編集不可) */
    @Input() isEditMode: boolean;

    /** 単体テストFLG(実画面からは未指定でよい) */
    @Input() isUnitTest: boolean;

    // メイン画像表示部の背景色
    private mainBackgroundColor: string = '#626262';

    // 証憑の一覧データ
    private voucherData: any = null;

    // 証憑詳細の一覧データ
    private _voucherDetailList: any[] = [];

    // 現在表示中の証憑詳細データindex
    private voucherDetailDispIndex = 0;

    // ポップアップ画像のBase64文字列
    private popupImageFileData: string = null;

    // API実行中の場合、フラグを立てておく
    private waitingApi: boolean = false;

    constructor(private unlinkEviService: UnlinkEviService, private property: EcoKaikeiProperty) {
        super(unlinkEviService, property);
    }

    // 現在表示中の証憑データに対して、証憑詳細が複数件存在するか？(複数存在する場合、複数あるように見せるため、サムネイルに白い影を付与する)
    private get isMultiPage(): boolean {
        return this.voucharDetailCount > 1 ? true : false;
    }

    // 画面に表示する証憑詳細データ(ページ番号一覧を表示)
    private get dispVoucherDetailList(): any[] {
        return this._voucherDetailList;
    }

    // 画面に表示する証憑詳細データ
    private get voucharDetailCount(): number {
        return this._voucherDetailList === null ? 0 : this._voucherDetailList.length;
    }

    // 現在表示中の証憑種類を表示
    private get voucherSortingName(): string {
        if (this.voucherData !== undefined && this.voucherData !== null) return this.voucherData["voucherSortingName"];
        return null;
    }

    // コンポーネント初期化時のライフサイクルメソッド
    ngOnInit() {
        this.doInitial();
    }

    // プロパティが変更された(親画面で表示対象データが変更された)際にもデータを再表示し直す。
    ngOnChanges() {
        this.doInitial();
    }

    // デバッグ用データのセット(テスト用)
    // private setDebugData() {
    //     let messageList: AC000MessageDto[] = this.property.messageDtoList;
    //     if (messageList === undefined || messageList === null) messageList = [];
    //     messageList.push({
    //         messageId: "120023",
    //         messageTitle: "更新確認",
    //         message: "(単体テスト)更新します。\nよろしいですか？",
    //         buttonPattern: 2
    //     });
    //     this.property.messageDtoList = messageList;
    // }

    // 標準出力(単体テストで出力)
    private outputLog(logString: string): void {
        if (this.isUnitTest !== undefined && this.isUnitTest !== null && this.isUnitTest === true) {
            console.log(logString);
        }
    }

    // 本コンポーネントの初期化処理
    private doInitial(): void {
        // 各変数の初期化
        this.voucherData = null;
        this._voucherDetailList = [];
        this.voucherDetailDispIndex = 0;
        this.popupImageFileData = null;
        this.waitingApi = false;

        // このif文内はコンポーネントの単体テスト用ロジックです。実際には利用されません。
        // if (this.isUnitTest !== undefined && this.isUnitTest !== null && this.isUnitTest === true) {
        //     this.setDebugData();
        // }

        // 編集モード(親コンポーネントからプロパティで渡されなかった場合、強制的に編集OKモードにする))
        if (this.isEditMode === undefined || this.isEditMode === null) this.isEditMode = true;

        // 対象証憑データを検索
        this.getInitial();
    }

    // 初期データの取得
    private getInitial(): void {
        // APIパラメータの設定
        const reqDto: UnlinkEviReqDto = new UnlinkEviReqDto();
        reqDto.voucherId = this.voucherId;
        this.outputLog(`voucherId=${reqDto.voucherId}`);

        this.waitingApi = true;
        this.unlinkEviService.getInitial(reqDto, (resDto: UnlinkEviResDto): void => {
            this.waitingApi = false;
            // 対象の証憑データを表示
            this.refreshVoucher(resDto);
            // 証憑データの詳細一覧
            this.refreshVoucherDetail(resDto);
        }, this.isUnitTest);
    }

    // 証憑画像表示順序の変更
    private voucherImageOrderChange(voucherImageOrderGrid: WjFlexGridEx): void {
        // 未処理証憑を並び変える
        const commonEviImageOrderList: CommonEviImageOrder[] = [];
        voucherImageOrderGrid.columnHeaders.columns.forEach((c: WjFlexGridColumn) => {
            const imageOrder: number = parseInt(c.name);
            const data: any = this._voucherDetailList.filter((v: any) => v["voucherImageOrder"] === imageOrder)[0];

            const commonEviImageOrder: CommonEviImageOrder = {...data};
            commonEviImageOrder.updateDate = data["updatedAt"];
            commonEviImageOrderList.push(commonEviImageOrder);
        });

        // 画像データを一旦クリア
        this.popupImageFileData = null;

        // APIパラメータの設定
        const reqDto: UnlinkEviReqDto = new UnlinkEviReqDto();
        reqDto.voucherId = this.voucherData["voucherId"];
        reqDto.updateDate = this.voucherData["updatedAt"];
        reqDto.commonEviImageOrderList = commonEviImageOrderList;

        this.waitingApi = true;
        this.unlinkEviService.voucherImageOrderChange(reqDto, (resDto: UnlinkEviResDto): void => {
            this.waitingApi = false;
            // 取得した未証憑データの詳細一覧
            this.refreshVoucherDetail(resDto);
        }, this.isUnitTest);
    }

    // 表示対象の証憑詳細画像を取得する
    private dispFileDate(): void {
        // 画像データを一旦クリア
        this.popupImageFileData = null;

        if (this._voucherDetailList !== null && this._voucherDetailList.length > 0) {
            // APIパラメータの設定
            const reqDto: UnlinkEviReqDto = new UnlinkEviReqDto()
            reqDto.fileId = this._voucherDetailList[this.voucherDetailDispIndex]["voucherImageFileId"];
            // 表示している証憑詳細のファイルIDを利用してAPIを実行し、画像ファイル(Base64文字列)を取得する。
            this.waitingApi = true;
            this.unlinkEviService.getFileData(reqDto, (resDto: UnprocessedEviResDto): void => {
                this.waitingApi = false;
                this.popupImageFileData = resDto.commonEviFileDataDto.fileData;
                // クリックしないと表示が反映されないっぽい。
                //this.eviPagination.refresh();
            }, this.isUnitTest);
        }
    }

    // リンク解除を実行
    private unlink(): void {
        // APIパラメータの設定
        const reqDto: UnlinkEviReqDto = new UnlinkEviReqDto();
        reqDto.voucherId = this.voucherData["voucherId"];
        reqDto.journalFisicalYearCd = this.fisicalYearCd;
        reqDto.journalMonth = this.journalMonth;
        reqDto.journalSlipType = this.journalSlipType;
        reqDto.journalId = this.journalId;
        reqDto.updateDate = this.changeNumberToData(this.voucherData["updatedAt"]);
        reqDto.journalUpdateDate = this.changeNumberToData(this.journalUpdateDate);
        this.outputLog(`[unlink-evi] unlink param:${JSON.stringify(reqDto)}`);

        this.waitingApi = true;
        this.unlinkEviService.unlink(reqDto, (resDto: UnlinkEviResDto): void => {
            this.waitingApi = false;
            // 画像データをクリア
            // (やらなくてもよいが、このコンポーネントは親画面によって表示されなくなる想定なので、ブラウザから不要なメモリ情報を開放する)
            this.voucherData = null;
            this._voucherDetailList = [];
            this.voucherDetailDispIndex = 0;
            this.popupImageFileData = null;

            // 親画面の証憑IDをクリア＋親コンポーネント画面のイベント発火させる
            // (親コンポーネント画面のイベント内容は、本コンポーネントから添付証憑コンポーネント(CP220)に切り替えてもらう想定)
            this.voucherIdChange.emit(null);
            this.unlinkVoucherId.emit();

            this.outputLog("[unlink-evi]success unlink");
        }, this.isUnitTest);
    }

    // サーバーから取得した証憑一覧データの表示
    private refreshVoucher(resDto: UnlinkEviResDto): void {
        this.voucherData = resDto.commonEviDto;
        this.voucherData["updatedAt"] = this.changeNumberToData(this.voucherData["updatedAt"]);
    }

    // サーバーから取得した証憑詳細データの表示
    private refreshVoucherDetail(resDto: UnlinkEviResDto): void {
        // 取得した未証憑データの詳細一覧
        const commonEviDetailDtoList: CommonEviDetailDto[] = (resDto.commonEviDetailDtoList === null ? [] : resDto.commonEviDetailDtoList);
        this._voucherDetailList = commonEviDetailDtoList;
        this._voucherDetailList.forEach((v: any) => v["updatedAt"] = this.changeNumberToData(v["updatedAt"]));

        // 証憑詳細データは1ページ目を表示
        this.voucherDetailDispIndex = 0;

        // 証憑詳細データ(1件目)の画像ファイルを取得
        this.dispFileDate();
    }

    // 日付データが数値になっている場合、日付型に変換する
    private changeNumberToData(targetDate: any): any {
        return ((typeof targetDate) === 'number') ? (new Date(targetDate)) : targetDate;
    }

    // ページを選択
    private selectPage(index: number): void {
        this.voucherDetailDispIndex = index;
        // 証憑詳細データの画像ファイルを取得
        this.dispFileDate();
    }

    // リンク解除ボタンクリック
    private unlinkBtnClick(): void {
        this.eAlert.message('120023', [], null, () => {
            this.unlink();
        });
    }
}

@NgModule({
    exports: [UnlinkEviComponent],
    declarations: [UnlinkEviComponent],
    imports: [
        BrowserModule,
        CommonModule,
        FormsModule,
        HttpClientModule,
        EAlertModule,
        ViewBaseButtonModule,
        ViewBaseModule,
        WjInputModule,
        EviHeaderModule,
        EviImageModule,
        EviPaginationModule
    ],
    providers: [
        EcoKaikeiProperty,
        UnlinkEviService,
        IndexService,
        LogoutService,
    ]
})
export class UnlinkEviModule {
}
