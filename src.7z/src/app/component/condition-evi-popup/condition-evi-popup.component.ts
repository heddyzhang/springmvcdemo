import { Component, NgModule, ViewChild, OnInit, ViewEncapsulation, Input, EventEmitter, Output } from "@angular/core";
import { WjPopup, WjInputModule } from "wijmo/wijmo.angular2.input";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { WjFlexGridModuleEx, WjFlexGridEx } from "../wj-flex-grid-ex/wj-flex-grid-ex";
import { WjGridModule } from "wijmo/wijmo.angular2.grid";
import { ViewBaseButtonModule } from "../view-base-button/view-base-button.component";
import { EDateFieldModule } from "../e-date-field/e-date-field.component";
import { EDropDownListModule } from "../e-drop-down-list/e-drop-down-list.component";
import { ConditionEviPopupService } from "../../service/ConditionEviPopupService";
import { ConditionEviPopupResDto } from "../../dto/conditionEviPopup/ConditionEviPopupResDto";
import { UserDto } from "../../dto/conditionEviPopup/UserDto";
import { ConditionEviPopupDto } from "../../dto/conditionEviPopup/ConditionEviPopupDto";
import { ConditionEviPopupResultDto } from "../../dto/conditionEviPopup/ConditionEviPopupResultDto";
import { ConditionEviPopupReqDto } from "../../dto/conditionEviPopup/ConditionEviPopupReqDto";

@Component({
    selector: 'condition-evi-popup',
    templateUrl: './condition-evi-popup.html',
    styleUrls: ['./condition-evi-popup.css'],
    encapsulation: ViewEncapsulation.None,
})
/**
 * 証憑表示条件PopUp
 */
export class ConditionEviPopupComponent implements OnInit {

    /** 検索条件：発生日付From */
    @Input() public occurrenceDateFrom: Date = null;

    /** 検索条件：発生日付To */
    @Input() public occurrenceDateTo: Date = null;

    /** 検索条件：送信者 */
    @Input() public createdUser: number;

    /** 証憑選択イベント */
    @Output() public voucherSelected = new EventEmitter<ConditionEviPopupResultDto>();

    /** ポップアップの参照 */
    @ViewChild("conditionEviPopup")
    public wjpopup: WjPopup;

    /** グリッドの参照 */
    @ViewChild("conditionEviGrid")
    public conditionEviGrid: WjFlexGridEx;

    /** 送信者リスト */
    public userDtoList: UserDto[];

    /** 未処理証憑リスト */
    public conditionEviPopupDtoList: ConditionEviPopupDto[];

    /** グリッド表示用リスト */
    public gridItemSource: any[];

    constructor(private service: ConditionEviPopupService) { }

    /**
     * 初期表示時の処理
     */
    public ngOnInit() {
        // ポップアップの表示/非表示切り替えのアニメーションを削除
        this.wjpopup.fadeIn = false;
        this.wjpopup.fadeOut = false;
    }

    /**
     * ポップアップを表示する
     */
    public show() {
        // 初期化
        this.conditionEviPopupDtoList = null;
        this.gridItemSource = null;
        this.userDtoList = null;

        // サーバーからデータ取得
        const reqDto = new ConditionEviPopupReqDto();
        this.service.getInitial(reqDto, (resDto: ConditionEviPopupResDto) => {
            this.conditionEviPopupDtoList = resDto.conditionEviPopupDtoList;

            // DBから取得した一覧の先頭に全件対象行を追加
            const all: ConditionEviPopupDto = { voucherSortingId: -1, voucherSortingName: "【全件対象】", occurrenceDate: null, createdUser: null };
            this.conditionEviPopupDtoList.unshift(all);

            // グリッドにデータ設定
            this.gridItemSource = this.filter(resDto.conditionEviPopupDtoList);
            this.conditionEviGrid.select(-1, -1);

            // 送信者ドロップダウンのデータ設定
            this.userDtoList = resDto.userDtoList;
            // 空の行を先頭に追加
            this.userDtoList.unshift({ userId: -1, userName: null });
        });

        // ポップアップを開く
        this.wjpopup.show();
    }

    /**
     * 日付変更時の処理
     */
    public occurrenceDateChanged() {
        this.gridItemSource = this.filter(this.conditionEviPopupDtoList);
    }

    /**
     * 送信者変更時の処理
     * @param selectedUserId 選択されているユーザーID
     */
    public createdUserChanged(selectedUserId: number) {
        this.createdUser = selectedUserId;
        this.gridItemSource = this.filter(this.conditionEviPopupDtoList);
    }

    /**
     * 一覧の証憑選択時の処理
     * @param voucherSortingId 選択された証憑の証憑分類ID
     */
    public selectItem(voucherSortingId: number) {
        // ポップアップを閉じる
        this.wjpopup.hide();

        // 親画面へ返す値を作成
        const result: ConditionEviPopupResultDto = {
            voucherSortingId: voucherSortingId,
            occurrenceDateFrom: this.occurrenceDateFrom,
            occurrenceDateTo: this.occurrenceDateTo,
            createdUser: this.createdUser,
        };

        // 選択変更イベント発火
        this.voucherSelected.emit(result);
    }

    /**
     * 画面で指定されている表示条件でフィルタリングする
     * @param data フィルタリングするデータ
     */
    private filter(data: ConditionEviPopupDto[]): any[] {
        if (!data) {
            return [];
        }

        // 全件対象行用トータル件数
        let totalCount = 0;

        // SQLでいうgroup byと集計処理を行う
        const summary = data.reduce((result, current) => {
            const element = result.find((p) => {
                return p.voucherSortingId === current.voucherSortingId
            });

            // 画面で指定されている検索条件に一致するかどうかチェック
            // 一致する場合は件数をカウントアップする
            let canCountUp = true;

            // 指定されている日付の範囲に入っているかを比較していく
            if (current.occurrenceDate) {
                // DBから取得した発生日付がUNIXタイムスタンプで返ってくるのでDateに変換
                if (typeof (current.occurrenceDate) === 'number') {
                    current.occurrenceDate = new Date(current.occurrenceDate);
                }
                // Fromを比較
                if (this.occurrenceDateFrom && current.occurrenceDate < this.occurrenceDateFrom) {
                    canCountUp = false;
                }
                // Toを比較
                if (this.occurrenceDateTo && this.occurrenceDateTo < current.occurrenceDate) {
                    canCountUp = false;
                }
            } else if (this.occurrenceDateFrom || this.occurrenceDateTo) {
                // DBの発生日付が空で、検索条件の日付が指定されている場合はカウントアップしない
                canCountUp = false;
            }

            // 指定されている作成者と一致するか
            if (this.createdUser !== null
                && this.createdUser !== -1 // 空行の場合
                && this.createdUser !== current.createdUser) {
                canCountUp = false;
            }

            // 画面の検索条件とは別に、そもそも証憑ファイル作成者が空(＝証憑ファイルが存在しない)の場合はカウントアップしない
            if (!current.createdUser) {
                canCountUp = false;
            }

            if (element) {
                // 既にリストに追加されている証憑の場合はカウントアップのみ行う
                if (canCountUp) {
                    element.voucherCount++;
                }
            } else {
                // まだリストに追加されていない証憑の場合はデータ追加
                result.push({
                    voucherSortingId: current.voucherSortingId,
                    voucherSortingName: current.voucherSortingName,
                    voucherCount: canCountUp ? 1 : "　", // 全角スペースを入れておかないと、セルクリックが反応しない
                });
            }

            // トータル件数カウントアップ
            if (canCountUp) {
                totalCount++;
            }

            return result;
        }, []);

        // トータル件数を全件対象行にセット
        const all = summary.find((p) => {
            return p.voucherSortingId === -1
        });
        all.voucherCount = totalCount;

        return summary;
    }
}

@NgModule({
    exports: [ConditionEviPopupComponent],
    declarations: [ConditionEviPopupComponent],
    imports: [
        CommonModule,
        FormsModule,
        EDateFieldModule,
        EDropDownListModule,
        ViewBaseButtonModule,
        WjInputModule,
        WjFlexGridModuleEx,
        WjGridModule
    ],
})
export class ConditionEviPopupModule { }
