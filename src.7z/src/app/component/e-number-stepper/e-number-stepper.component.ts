import { Component, Input, NgModule } from '@angular/core';
import { WjInputNumber, wjInputNumberMeta } from 'wijmo/wijmo.angular2.input'
import { applyStyle, getRequiredStyle, removeDefaultWijmoInputStyle, TextAlign } from "../../util/css.util";

@Component({
  selector: 'e-number-stepper',
  template: wjInputNumberMeta.template,
  inputs: wjInputNumberMeta.inputs,
  outputs: wjInputNumberMeta.outputs
})
export class ENumberStepperComponent extends  WjInputNumber {

    private _innerStyle: CSSStyleDeclaration; // CSSスタイル定義
    private _required = false; // 必須フラグs

    // CSSクラス定義
    @Input() set innerClass(value: string) {
        this.inputElement.className = value;
    }

    // CSSスタイル定義
    @Input() set innerStyle(value: CSSStyleDeclaration) {
        this._innerStyle = value;
        applyStyle(this.inputElement, this._innerStyle);
    }

    // 必須フラグ
    @Input() set required(val: boolean) {
        this._required = val;
        this.inputElement.style.borderRight = getRequiredStyle(this._required);
    }

    /**
     * 初期化処理
     */
    ngOnInit() {
        super.ngOnInit();
        // Looperのスタイルと重複するため、Wijmoの一部デフォルトスタイルを無効化
        removeDefaultWijmoInputStyle(this.hostElement);
    }
}

@NgModule({
    exports: [ENumberStepperComponent],
    declarations: [ENumberStepperComponent]
})
export class ENumberStepperModule {
}
