import { Component, OnInit, Input, Output, NgModule, EventEmitter } from "@angular/core";
import { getRequiredStyle } from "../../util/css.util";
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

/**
 * ボタンコンポーネント
 */
@Component({
    selector: 'e-text-area',
    templateUrl: './e-text-area.component.html',
})
export class ETextAreaComponent implements OnInit {

    @Input() name: string = null;
    @Input() id: string = null;
    @Input() value: string = null;
    private class: string = 'form-control';
    private style: {} = {};
    private _required = false; // 必須フラグ
    private _readonly: string = null; // 読み取り専用フラグ
    private _disabled: string = null; // DISABLEDフラグ

    // css
    @Input() set innerClass(val: string) {
        this.class = val;
    }

    // style
    @Input() set innerStyle(val: CSSStyleDeclaration) {
        this.style = val;
    }

    // 必須フラグ
    @Input() set required(val: boolean) {
        this._required = val;
    }

    // 読み取り専用フラグ
    @Input() set readonly(val: boolean) {
        if(val) {
            this._readonly = 'readonly';
        }
    }

    // disabledフラグ
    @Input() set disabled(val: boolean) {
        if(val) {
            this._disabled = 'disabled';
        }
    }

    /**
     * 初期化処理
     */
    ngOnInit(): void {
        // 必須のスタイル変更
        this.style['borderRight'] = getRequiredStyle(this._required);
    }
}

@NgModule({
    exports: [ETextAreaComponent],
    declarations: [ETextAreaComponent],
    imports: [CommonModule, FormsModule]
})
export class ETextAreaModule {
}
