import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EApprovalStampComponent } from './e-approval-stamp.component';

describe('EApprovalStampComponent', () => {
  let component: EApprovalStampComponent;
  let fixture: ComponentFixture<EApprovalStampComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EApprovalStampComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EApprovalStampComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
