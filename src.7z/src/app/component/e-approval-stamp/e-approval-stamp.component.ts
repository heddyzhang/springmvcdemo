import { Component, NgModule, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';

@Component({
  selector: 'e-approval-stamp',
  templateUrl: './e-approval-stamp.component.html',
  styleUrls: ['./e-approval-stamp.component.css']
})
export class EApprovalStampComponent implements OnInit {
    // stamp済状態か？ true:stamp状態 false:未stamp状態
    @Input() isApproved: boolean;
    @Output() isApprovedChange = new EventEmitter<boolean>();

    // stamp利用(押すことが)可能か？ true:可能 false:不可
    // 未stamp状態で承認したい場合、stamp済で削除したい場合はtrueを設定すること
    @Input() isStamp: boolean;

    // stampタイトル
    @Input() stampTitle: string;

    // stamp上段表示文字
    @Input() headerLabel: string;
    @Output() headerLabelChange = new EventEmitter<string>();

    // 部門(stamp中断)表示文字
    @Input() sectionLabel: string;
    @Output() sectionLabelChange = new EventEmitter<string>();

    // stamp下段表示文字
    @Input() fotterLabel: string;
    @Output() fotterLabelChange = new EventEmitter<string>();

    constructor(private property: EcoKaikeiProperty) {
        console.log(`userSealTop=${property.userSealTop}, userPosition=${property.userPosition}, userSealBottom=${property.userSealBottom}`);
    }

    ngOnInit() {
    }

    // スタンプONの処理
    public onClickStamp(): void {
        // 押せない場合は何もしない。
        if (this.isStamp === undefined || this.isStamp === null || !this.isStamp) return;

        if (this.isApproved) {
            // 承認済の場合:未stamp状態にする
            this.deleteStamp();
        } else {
            // 未承認の場合:stamp済にする
            this.onStamp();
        }
    }

    // スタンプしたときの処理(暫定で固定値をセット)
    // todo:session？からユーザー情報を登録するようにする。
    public onStamp(): void {
        this.headerLabel = this.property.userSealTop;
        this.sectionLabel = this.property.userPosition;
        this.fotterLabel = this.property.userSealBottom;
        this.isApproved = true;

        this.twowayDataBinding();
    }

    // スタンプをクリアするときの処理
    public deleteStamp(): void {
        this.headerLabel = null;
        this.sectionLabel = null;
        this.fotterLabel = null;
        this.isApproved = false;

        this.twowayDataBinding();
    }

    // スタンプを押したときの変更状態を親コンポーネントの変数と同期する(双方向データバインディング)
    private twowayDataBinding(): void {
        this.headerLabelChange.emit(this.headerLabel);
        this.sectionLabelChange.emit(this.sectionLabel);
        this.fotterLabelChange.emit(this.fotterLabel);
        this.isApprovedChange.emit(this.isApproved);
    }

    // 印鑑アイコンの表示有無
    public isDispStampImage(): boolean {
        return (this.isApproved === undefined || this.isApproved === null || !this.isApproved) && this.isStamp;
    }

    // 削除可能か？
    public isDeleteOkStamp(): boolean {
        return this.isApproved && this.isStamp;
    }

}

@NgModule({
    exports: [EApprovalStampComponent],
    declarations: [EApprovalStampComponent],
    imports: [
        CommonModule
    ]
})
export class EApprovalStampModule {
}
