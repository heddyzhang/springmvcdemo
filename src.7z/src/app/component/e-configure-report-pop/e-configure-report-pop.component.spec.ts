import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EConfigureReportPopComponent } from './e-configure-report-pop.component';

describe('EConfigureReportPopComponent', () => {
  let component: EConfigureReportPopComponent;
  let fixture: ComponentFixture<EConfigureReportPopComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EConfigureReportPopComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EConfigureReportPopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
