import { Component, NgModule, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { WjInputModule, WjPopup } from 'wijmo/wijmo.angular2.input';
import { ReqDtoBase } from '../../dto/ReqDtoBase';
import { EDropDownListModule } from '../e-drop-down-list/e-drop-down-list.component';

@Component({
  selector: 'e-configure-report-pop',
  templateUrl: './e-configure-report-pop.component.html',
  styleUrls: ['./e-configure-report-pop.component.css']
})
export class EConfigureReportPopComponent {

    /** 印刷リクエスト情報 */
    public dto: ReqDtoBase = new ReqDtoBase();

    /** 事業者名：表示するかどうか */
    public dispBusinessFlgs: any[] = [{label:'表示しない', value:false}, {label:'表示する', value:true}];

    /** 印刷日時：表示するかどうか 表示するならそのフォーマット */
    public dispPrintTimeFormats: any[] = [{label:'表示しない', value:''}
                                        , {label:'yyyy/mm/dd hh:mm:ss', value:'yyyy/MM/dd HH:mm:ss'}
                                        , {label:'yyyy/mm/dd', value:'yyyy/MM/dd'}
                                        , {label:'和暦y年m月d日 h時m分s秒', value:'GGGGyyyy年M月d日 H時m分s秒'}
                                        , {label:'和暦y年m月d日', value:'GGGGyyyy年M月d日'}];

    /** ポップアップの参照 */
    @ViewChild(WjPopup)
    private wjpopup:WjPopup;

    /** コンストラクタ */
    constructor() {
    }

    /**
     * ダイアログを表示する
     *
     * @param reqDto リクエスト情報
     * @param reportFunction 印刷の処理
     */
    public show(reqDto:ReqDtoBase, reportFunction:Function) {

        // DTOを渡す
        this.dto = reqDto;

        // ポップアップを表示
        this.wjpopup.show(true, (e) => {
            if (e.dialogResult === 'wj-hide-ok') {
                reportFunction();
            }
        });
    }
}

@NgModule({
    exports: [EConfigureReportPopComponent],
    declarations: [EConfigureReportPopComponent],
    imports: [CommonModule, FormsModule, WjInputModule, EDropDownListModule],
})
export class EConfigureReportPopModule {}
