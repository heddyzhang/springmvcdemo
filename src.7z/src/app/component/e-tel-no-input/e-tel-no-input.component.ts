import { Component, NgModule } from "@angular/core";
import { Inject, Injector, ElementRef as elementRef, SkipSelf, Optional} from '@angular/core';
import { wjInputMaskMeta } from "wijmo/wijmo.angular2.input";
import { ETextInputComponent } from "../e-text-input/e-text-input.component";

interface ElementRef {
    nativeElement: HTMLElement;
}

/**
 * @classdesc 電話番号入力コンポーネント
 */
@Component({
    selector: 'e-tel-no-input',
    template: wjInputMaskMeta.template,
    inputs: wjInputMaskMeta.inputs,
    outputs: wjInputMaskMeta.outputs,
})
export class ETelNoInputComponent extends ETextInputComponent {

    /** コンストラクタ */
    constructor(
        @Inject(elementRef) elRef: ElementRef,
        @Inject(Injector) injector: Injector,
        @Inject('ETextInputComponent') @SkipSelf() @Optional() parentCmp: any,
    ) {
        // super
        super(elRef, injector, parentCmp);
        // 電話番号入力で使用できる文字のみ許可
        this.inputMode = "4";
    }
}

@NgModule({
    exports: [ETelNoInputComponent],
    declarations: [ETelNoInputComponent]
})
export class ETelNoInputModule {
}
