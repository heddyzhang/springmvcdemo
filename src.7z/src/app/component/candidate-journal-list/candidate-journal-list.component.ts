import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'candidate-journal-list',
  templateUrl: './candidate-journal-list.component.html',
  styleUrls: ['./candidate-journal-list.component.css']
})
export class CandidateJournalListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
