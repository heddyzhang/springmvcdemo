import { Component, ViewEncapsulation, OnInit, Input, Output, EventEmitter, ViewChild, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { WjPopup, WjInputModule } from 'wijmo/wijmo.angular2.input';
import { ETextInputModule } from "../e-text-input/e-text-input.component";
import { WjFlexGridEx, WjFlexGridModuleEx } from "../wj-flex-grid-ex/wj-flex-grid-ex";
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { ESummaryDateInput } from './supportClass/e-summary-date-input/e-summary-date-input';
import { WjGridModule } from 'wijmo/wijmo.angular2.grid';

@Component({
    selector: 'e-summary-date-popup',
    templateUrl: './e-summary-date-popup.html',
    styleUrls: ['./e-summary-date-popup.css'],
    encapsulation: ViewEncapsulation.None,
})
/**
 * <e-summary-date-input>と共に使用する
 * 他のポップアップと表示位置を共有する場合は、x y とバインドする。
 * その他のパラメータを各自で設定することを想定していない。
 */
export class ESummaryDatePopup implements OnInit {
    /** 表示内容 */
    public summary: any[] = [{ value: "1月分" }, { value: "2月分" }, { value: "3月分" }, { value: "4月分" }, { value: "5月分" }, { value: "6月分" }, { value: "7月分" }, { value: "8月分" }, { value: "9月分" }, { value: "10月分" }, { value: "11月分" }, { value: "12月分" }];

    /** 日付変数*/
    public today: number;

    /** ポップアップ位置 X軸 */
    private _x: string;

    /** ポップアップ位置 Y軸 */
    private _y: string;

    @Input()
    /** ポップアップ位置 X軸 */
    public set x(value: string) {
        this._x = value;

        // 変更イベント
        this.xChange.emit(this._x);
    }

    @Input()
    /** ポップアップ位置 Y軸 */
    public set y(value: string) {
        this._y = value;

        // 変更イベント
        this.yChange.emit(this._y);
    }

    /** 変更イベント */
    @Output()
    public xChange = new EventEmitter();
    @Output()
    public yChange = new EventEmitter();

    /** inputへの参照 */
    private summaryDatePopupInput: ESummaryDateInput;

    /** ポップアップの参照 */
    @ViewChild("summaryDatePopup")
    public wjpopup: WjPopup;

    /** 日付選択Grid */
    @ViewChild("summaryGrid")
    private summaryGrid: WjFlexGridEx;

    constructor(private property: EcoKaikeiProperty) { }

    /**
     * 初期表示時の処理
     */
    public ngOnInit() {
        // ポップアップの表示/非表示切り替えのアニメーションを削除
        this.wjpopup.fadeIn = false;
        this.wjpopup.fadeOut = false;

        // フォーカスが当たった際に、抜ける
        this.wjpopup.addEventListener(this.wjpopup.hostElement, 'focus', (e) => { this.summaryDatePopupInput.inputElement.focus(); }, true);

        // フォーカスを受け付けなくする
        this.wjpopup.addEventListener(this.wjpopup.hostElement, 'mousedown', (e) => { e.preventDefault(); }, true);

        // 表示する年を取得、追加
        let currentYear = this.property.ownershipDto.selectFisicalYear;
        this.today = currentYear - 1;
        this.summary.push({ value: this.today + "年" });
        this.today = currentYear;
        this.summary.push({ value: this.today + "年" });
        this.today = currentYear + 1;
        this.summary.push({ value: this.today + "年" });
        this.today = currentYear + 2;
        this.summary.push({ value: this.today + "年" });
        this.summary.push({ value: "～" });
    }

    /**
     * 摘要ポップアップを開く
     * @param target 入力中の入力欄
     */
    public show(target: ESummaryDateInput) {
        // 入力対象への参照を保持
        this.summaryDatePopupInput = target;

        // Popup表示
        this.wjpopup.show();
        // ポップアップ位置が指定されている場合は、位置を変更する
        if (this._x && this._y) {
            this.wjpopup.hostElement.style.left = this._x;
            this.wjpopup.hostElement.style.top = this._y;
        }

        // 初期選択しない
        this.summaryGrid.select(-1, -1);
    }

    /**
     * 年選択処理
     * @param value 選択した年
     */
    public selectItem(value: string): void {
        // ポップアップの位置を保持する
        this.x = this.wjpopup.hostElement.style.left;
        this.y = this.wjpopup.hostElement.style.top;

        //画面に値をセット
        this.summaryDatePopupInput.summaryDate = value;
        this.summaryDatePopupInput.summaryDateChange.emit(value);
    }

    /**
     * 摘要ポップアップを閉じる
     */
    public hide(): void {
        // ポップアップの位置を保持する
        this.x = this.wjpopup.hostElement.style.left;
        this.y = this.wjpopup.hostElement.style.top;

        // ポップアップを閉じる
        this.wjpopup.hide();
    }
}

@NgModule({
    exports: [ESummaryDatePopup],
    declarations: [ESummaryDatePopup],
    imports: [CommonModule, FormsModule, ETextInputModule, WjInputModule, WjFlexGridModuleEx, WjGridModule],
})
export class ESummaryDatePopupModule { }
