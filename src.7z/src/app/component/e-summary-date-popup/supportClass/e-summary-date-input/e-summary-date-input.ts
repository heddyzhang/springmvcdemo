import { Component, NgModule, Input, Output, EventEmitter, ViewChild } from "@angular/core";
import { wjInputMaskMeta } from "wijmo/wijmo.angular2.input";
import { ETextInputComponent } from "../../../e-text-input/e-text-input.component";
import { ESummaryDatePopup } from "../../e-summary-date-popup";

@Component({
    selector: 'e-summary-date-input',
    template: wjInputMaskMeta.template,
    inputs: wjInputMaskMeta.inputs,
    outputs: wjInputMaskMeta.outputs,
})
/**
 * <e-summary-date-popup>と共に使用する
 * summaryDatePopupに<e-summary-date-popup>の参照を指定する
 * [(summaryDate)]に仕訳摘要2を設定する
 */
export class ESummaryDateInput extends ETextInputComponent {

    /** ポップアップへの参照 */
    @Input()
    public summaryDatePopup: ESummaryDatePopup;

    /** 初期表示 */
    @Input()
    public set summaryDate(value: string) {
        this.value = value;
    }
    /** 変更イベント */
    @Output() summaryDateChange = new EventEmitter<any>();

    /**
     * 初期化処理
     */
    public ngOnInit() {
        // 親クラスの初期化
        super.ngOnInit();

        // フォーカス時の処理
        this.inputElement.addEventListener('focus', this.inputElementOnShowPop.bind(this));

        // クリック時の処理
        this.inputElement.addEventListener('click', this.inputElementOnShowPop.bind(this));

        // フォーカスを抜けた場合の処理
        this.inputElement.addEventListener('blur', this.inputElementOnBlur.bind(this));

        // キー押下時の処理
        this.inputElement.addEventListener('keydown', this.inputElementOnKeydown.bind(this));
    }

    /**
     * フォーカス時の処理 / クリック時の処理
     * @param e イベント
     */
    public inputElementOnShowPop(e): void {
        // 既に表示中の場合は処理を中断
        if (this.summaryDatePopup.wjpopup && this.summaryDatePopup.wjpopup.isVisible) {
            return;
        }

        // 摘要ポップアップを開く
        this.summaryDatePopup.show(this);
    }

    /**
     * フォーカスを抜けた場合の処理
     * @param e イベント
     */
    private inputElementOnBlur(e): void {
        // フォーカスの移動先
        var target: any = e.relatedTarget;

        // relatedTargetがサポートされていない場合
        if (!target) {
            target = document.activeElement;
        }

        // 摘要ポップアップへのフォーカス移動の場合は、処理を中断する
        if (target && (target.classList.contains('wj-popup') || target.classList.contains('e-summary-date-pop'))) {
            return;
        }

        // 摘要ポップアップを閉じる
        this.summaryDatePopup.hide();
    }

    /**
     * キー押下時の処理
     * @param e イベント
     */
    private inputElementOnKeydown(e: KeyboardEvent): void {
        // 手入力不可にしたいのでe.preventDefault()でリードオンリーにするが、
        // タブとShift + タブでのフォーカス移動は許可する
        if (e.keyCode === 9 || (e.shiftKey && e.keyCode === 9)) {
            return;
        }

        // タブとShift + タブ以外の場合はキー押下処理をキャンセルする(＝リードオンリーにする)
        // HTMLのreadonly属性を使わない理由は、フォーカスがあたった際にカーソルがチカチカしないと
        // フォーカスがあたってるのかどうかわかりにくいから
        e.preventDefault();
    }
}

@NgModule({
    exports: [ESummaryDateInput],
    declarations: [ESummaryDateInput]
})
export class ESummaryDateInputModule { }
