export class ViewBaseButton {

    /**  */
    public display: boolean = false;
    /**  */
    public name: string = null;
    /**  */
    public id: string = null;
    /**  */
    public value: string = null;
    /**  */
    public disabled: boolean = false;
    /**  */
    public class: string = 'btn btn-view-base';
    /**  */
    public style: CSSStyleDeclaration;

    /**  */
    constructor (private list: {[key: string]: any}) {
        if (list == null) return;
        if (list['display']) this.display = list['display'];
        if (list['name']) this.name = list['name'];
        if (list['id']) this.id = list['id'];
        if (list['value']) this.value = list['value'];
        if (list['disabled']) this.disabled = list['disabled'];
        if (list['class']) this.class = list['class'];
        if (list['style']) this.style = list['style'];
    }
}
