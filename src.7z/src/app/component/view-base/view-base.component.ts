import { Component, Input, Output, OnInit, NgModule, EventEmitter, ViewChild } from "@angular/core";
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ViewBaseButtonModule } from "../view-base-button/view-base-button.component";
import { ViewBaseButton } from "./view-base.button";
import { EAlertModule, EAlertComponent } from "../e-alert/e-alert.component";

/**
 * ボタンコンポーネント
 */
@Component({
    selector: 'view-base',
    templateUrl: './view-base.component.html',
    styleUrls: ["./view-base.css"],
})
export class ViewBaseComponent implements OnInit {
    // headerの表示を制御
    public isHeaderDisplay = false;
    // footerの表示を制御
    public isFooterDisplay = false;

    // 共通で使用するアラート
    @ViewChild(EAlertComponent)
    public eAlert:EAlertComponent;

    // ヘッダーに表示するタイトル
    public _title: string = null;
    @Input() set title(val: string) {
        this.isHeaderDisplay = (val && val.length > 0)? true: false;
        this._title = val;
    }

    // フッターに表示するボタンの配列
    // ※配列数は10までとし、多い場合は捨てる
    public _viewBaseButtonList: ViewBaseButton[] = getViewBaseButtonList(null);
    @Input() set viewBaseButtonList(val: ViewBaseButton[]) {
        this.isFooterDisplay = ((val || val != null) && val.length > 0)? true: false;
        this._viewBaseButtonList = getViewBaseButtonList(val);
    }

    // イベント処理を親コンポーネントで実行するための宣言
    // ※テンプレートにイベントを記載しているが「@HostListener」を使う方法もある。
    @Output() method1 = new EventEmitter();
    @Output() method2 = new EventEmitter();
    @Output() method3 = new EventEmitter();
    @Output() method4 = new EventEmitter();
    @Output() method5 = new EventEmitter();
    @Output() method6 = new EventEmitter();
    @Output() method7 = new EventEmitter();
    @Output() method8 = new EventEmitter();
    @Output() method9 = new EventEmitter();
    @Output() method0 = new EventEmitter();

    /**
     * 初期化処理
     */
    ngOnInit(): void {
        // const button: ViewBaseButton = new ViewBaseButton();
        // button.value = 'btn01';
        // this.viewBaseButtonList.push(button);
    }

    /**
     * ショートカットキー１
     */
    shortcut1() {this.method1.emit()};

    /**
     * ショートカットキー２
     */
    shortcut2() {this.method2.emit()};

    /**
     * ショートカットキー３
     */
    shortcut3() {this.method3.emit()};

    /**
     * ショートカットキー４
     */
    shortcut4() {this.method4.emit()};

    /**
     * ショートカットキー５
     */
    shortcut5() {this.method5.emit()};

    /**
     * ショートカットキー６
     */
    shortcut6() {this.method6.emit()};

    /**
     * ショートカットキー７
     */
    shortcut7() {this.method7.emit()};

    /**
     * ショートカットキー８
     */
    shortcut8() {this.method8.emit()};

    /**
     * ショートカットキー９
     */
    shortcut9() {this.method9.emit()};

    /**
     * ショートカットキー０
     */
    shortcut0() {this.method0.emit()};

    /**
     * ボタン押下
     * 押下されたボタンのindexに該当するショートカットキーと同じ動作をする
     */
    click(index: number): void {
        switch (index) {
            case 0: this.shortcut1(); break;
            case 1: this.shortcut2(); break;
            case 2: this.shortcut3(); break;
            case 3: this.shortcut4(); break;
            case 4: this.shortcut5(); break;
            case 5: this.shortcut6(); break;
            case 6: this.shortcut7(); break;
            case 7: this.shortcut8(); break;
            case 8: this.shortcut9(); break;
            case 9: this.shortcut0(); break;
        }
    }

    /**
     * ショートカットの位置調整を行う
     */
    setFooterLeft(): void {
        // ショートカットが存在しない場合は抜ける
        if (!document.getElementById('footer')) return;

        // 位置調整
        document.getElementById('footer').style.left = (document.getElementById('pointer').offsetLeft
                            - document.documentElement.scrollLeft - document.body.scrollLeft) + 'px';
    }
}

/**
 * ボタン表示リストを作成
 * ※配列数は10までとし、多い場合は捨てる
 */
function getViewBaseButtonList(buttonList: ViewBaseButton[]): ViewBaseButton[] {
    const items: ViewBaseButton[] = [];
    for (let i = 0; i < 10; i++) {
        if ((buttonList || buttonList != null) && buttonList.length > i) {
            // ボタンの基本クラスをあてる
            if (buttonList[i].class) {
                buttonList[i].class = 'btn btn-view-base ' + buttonList[i].class;
            } else {
                buttonList[i].class = 'btn btn-view-base';
            }
            items.push(new ViewBaseButton(buttonList[i]));
        } else {
            items.push(new ViewBaseButton(null));
        }
    }
    return items;
}

@NgModule({
    exports: [ViewBaseComponent],
    declarations: [ViewBaseComponent],
    imports: [CommonModule, FormsModule, ViewBaseButtonModule, EAlertModule]
})
export class ViewBaseModule {
}
