import { Component, NgModule, ViewEncapsulation } from "@angular/core";
import { Inject, Injector, ElementRef as elementRef, SkipSelf, Optional } from '@angular/core';
import { wjComboBoxMeta } from "wijmo/wijmo.angular2.input";
import { EDropDownListComponent } from '../e-drop-down-list/e-drop-down-list.component';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { EventArgs } from "wijmo/wijmo";
import {EPopupItem} from '../../dto/ePopupInput/EPopupItem';

interface ElementRef {
    nativeElement: HTMLElement;
}

/**
 * @classdesc 部門ドロップダウンリストコンポーネント
 */
@Component({
    selector: 'e-segment-select',
    template: wjComboBoxMeta.template,
    inputs: wjComboBoxMeta.inputs,
    outputs: wjComboBoxMeta.outputs,
    styleUrls: ["../e-drop-down-list/e-drop-down-list.css"],
    encapsulation: ViewEncapsulation.None,
})
export class ESegmentSelectComponent extends EDropDownListComponent {
    constructor(private property: EcoKaikeiProperty,
        @Inject(elementRef) elRef: ElementRef,
        @Inject(Injector) injector: Injector,
        @Inject('EDropDownListComponent') @SkipSelf() @Optional() parentCmp: any, ) {
        super(elRef, injector, parentCmp);

        // ドロップダウンの内容を編集可能とする
        this.isEditable = true;

        // 表示するラベルと選択値を設定する
        this.labelField = "label";
        this.valueField = "id";

        // 配列を初期セット
        this.itemsSource = this.property.segmentPopupItemList;
    }

    /**
     * 初期化処理
     */
    public ngOnInit() {
        // 必ず呼ぶことwj-input-group-btn
        super.ngOnInit();

    }

    /**
     * フォーカスされた時の処理
     */
    public onGotFocus(e?: EventArgs): void {
        super.onGotFocus(e);
        // // 表示するラベルを変更する
        // this.labelField = "cd";
        // 表示するラベルを変更する
        this.displayMemberPath = "cd";
    }

    /**
     * フォーカスが外れた時の処理
     */
    public onLostFocus(e?: EventArgs): void {
        super.onLostFocus(e);
        // // 変更されたラベルを元に戻す
        // this.labelField = "label";
        // 表示するラベルを変更する
        this.displayMemberPath = "label";
    }

}

@NgModule({
    exports: [ESegmentSelectComponent],
    declarations: [ESegmentSelectComponent]
})
export class ESegmentSelectModule { }
