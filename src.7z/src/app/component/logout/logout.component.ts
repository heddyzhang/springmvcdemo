import { Component, OnInit, Inject } from '@angular/core';
import { LogoutService } from '../../service/logoutServive'

import { DOCUMENT } from '@angular/platform-browser';
import 'rxjs/add/operator/finally';
import { IndexService } from '../../service/IndexService';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  constructor(@Inject(DOCUMENT) private document: any, private logoutService: LogoutService, private indexService:IndexService, private property: EcoKaikeiProperty) {
  }

  logout() {
    this.logoutService.callLogout().finally(
      () => {
        this.indexService.authenticated = false;
        this.document.location.href = this.property.commonURL;
      }).
      subscribe();
  }

  ngOnInit() {
  }

}
