import {
  Component, Inject, Injector, NgModule, ElementRef,
  SkipSelf, Optional, forwardRef, ChangeDetectorRef,
  EventEmitter,
  HostListener
} from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { WjValueAccessorFactory } from 'wijmo/wijmo.angular2.directiveBase';
import {
  WjGridModule, WjFlexGrid, wjFlexGridMeta,
  WjFlexGridColumn, wjFlexGridColumnMeta
} from 'wijmo/wijmo.angular2.grid';
import { HeadersVisibility, CellRange, SelectionMode } from 'wijmo/wijmo.grid';

@Component({
  selector: 'wj-flex-grid-ex',
  template: wjFlexGridMeta.template,
    inputs: [...wjFlexGridMeta.inputs, 'myProperty'],
    outputs: [...wjFlexGridMeta.outputs, 'myPropertyChange'],
    providers: [
        { provide: 'WjComponent', useExisting: forwardRef(() => WjFlexGridEx) },
        ...wjFlexGridMeta.providers
    ]
})
export class WjFlexGridEx extends WjFlexGrid {

    /** 列ヘッダのみ表示をデフォルトにする */
    headersVisibility: HeadersVisibility = HeadersVisibility.Column;

    /**
     * [cellType]="'Row'" の際に、選択行を設定する
     */
    public selectionRow(r: number):void {

        // 描画を終了させる
        if (this.collectionView){
            this.collectionView.refresh();
        }
        this.invalidate();
        this.refresh(true);

        // 設定位置までスクロールする とりあえず 前後１セルは表示させる
        this.scrollIntoView(r - 1, 0, true);
        this.scrollIntoView(r + 1, 0, true);

        // 行選択を移動する
        if (this.selectionMode === SelectionMode.Row) {
            this.selection = new CellRange(r, 0, r);
        }
    }

    /**
     * [cellType]="'Cell'" の際に、入力欄にフォーカスを設定する
     */
    public focusCellInput(r: number, c: number):void {

        // 描画を終了させる
        this.refresh(true);

        // 設定位置までスクロールする とりあえず 前後１セルは表示させる
        this.scrollIntoView(r - 1, c, true);
        this.scrollIntoView(r + 1, c, true);
        this.scrollIntoView(r, c - 1, true);
        this.scrollIntoView(r, c + 1, true);
        this.scrollIntoView(r, c, true);

        // 行選択を移動する
        if (this.selectionMode === SelectionMode.Row) {
            this.selection = new CellRange(r, 0, r);
        }

        // 入力欄にフォーカスを設定する
        if (this.cells.getCellElement(r, c) && this.cells.getCellElement(r, c).children[0]
            && this.cells.getCellElement(r, c).children[0].children[0] && this.cells.getCellElement(r, c).children[0].children[0]['$WJ-CTRL']
            && this.cells.getCellElement(r, c).children[0].children[0]['$WJ-CTRL'].inputElement) {
            this.cells.getCellElement(r, c).children[0].children[0]['$WJ-CTRL'].inputElement.focus();
        }
    }

    /**
     * 選択を解除する
     */
    public selectionClear():void {

        // 選択を解除
        this.selection = new CellRange(-1, -1, -1, -1);
    }

    private _myProperty: string;
    myPropertyChange = new EventEmitter(false);

    get myProperty(): string {
        return this._myProperty;
    }
    set myProperty(value: string) {
        if (this._myProperty !== value) {
            this._myProperty = value;
            this.myPropertyChange.emit(value);
        }
    }

    /**
     * 初期化処理
     */
    ngOnInit() {
        super.ngOnInit();
    }

    @HostListener('window:sideMenuScaleEvent')
    /** windowのsideMenuScaleEventを監視 */
    public onSideMenuScaleEvent(): void {

        // 再描画を行う
        this.invalidate();
    }
}

@Component({
  selector: 'wj-flex-grid-column-ex',
  template: wjFlexGridColumnMeta.template,
  inputs: wjFlexGridColumnMeta.inputs,
  outputs: wjFlexGridColumnMeta.outputs,
  providers: [
      { provide: 'WjComponent', useExisting: forwardRef(() => WjFlexGridColumnEx) },
      ...wjFlexGridColumnMeta.providers
  ]
})
export class WjFlexGridColumnEx extends WjFlexGridColumn {

    /** 最小の幅を設定 */
    public minWidth:number = 20;
}


@NgModule({
  imports: [WjGridModule, BrowserModule, FormsModule],
  declarations: [WjFlexGridEx, WjFlexGridColumnEx],
  exports: [WjFlexGridEx, WjFlexGridColumnEx]
})
export class WjFlexGridModuleEx {
}
