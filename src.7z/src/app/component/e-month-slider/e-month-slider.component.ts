import { Component, OnInit, ViewEncapsulation, NgModule, Input, Inject, ElementRef as elementRef, Injector, SkipSelf, Optional, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { WjFlexGrid, wjFlexGridMeta } from 'wijmo/wijmo.angular2.grid';
import { inject } from '@angular/core/testing';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { MonthItemDto } from '../../dto/MonthItemDto';
import { Column, CellRangeEventArgs, SelectedState, HeadersVisibility, CellRange, FormatItemEventArgs, CellType } from 'wijmo/wijmo.grid';

interface ElementRef {
    nativeElement: HTMLElement;
}
/**
 *
 * <e-month-slider [(fisicalYearCd)]="_monthSliderFYCd" (eSelectChange)="monthSliderChage($event)"></e-month-slider>
 * fisicalYearCdにセットすることで、その会計年度のスライダーが作成されます。
 * 選択後のイベントは、eSelectChangeです。
 * イベントの中には、EMonthSliderSelectRMonthクラスです。
 *
 */
@Component({
    selector: 'e-month-slider',
    template: wjFlexGridMeta.template,
    inputs: wjFlexGridMeta.inputs,
    outputs: wjFlexGridMeta.outputs,
    styleUrls: ["./e-month-slider.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class EMonthSliderComponent extends WjFlexGrid {

    /** 会計年度 */
    private _fisocalYearCd: number = 0;

    @Input()
    /** true:幅が小さいモード false:幅が大きいモード */
    public simpleMode: boolean = false;

    @Output()
    /** 選択変更イベント */
    public eSelectChange = new EventEmitter();

    /** コンストラクタ */
    constructor(@Inject(elementRef) private elRef: ElementRef, @Inject(Injector) private injector: Injector,
        @Inject('EMonthSliderComponent') @SkipSelf() @Optional() private parentCmp: any,
        @Inject(ChangeDetectorRef) private cdRef: ChangeDetectorRef, private property: EcoKaikeiProperty) {

        super(elRef, injector, parentCmp, cdRef);

        // onMouseUpイベントにthisをバインドしておく
        this.onMouseUp = this.onMouseUp.bind(this);

        // これしないと配列が列になっちゃう
        this.autoGenerateColumns = false;

        // 編集できないよ
        this.isReadOnly = true;

        // キーボード操作をできないように修正
        this.addEventListener(this.hostElement, 'keydown', function(e) {
            if (e.key !== "Tab") {
                e.preventDefault();
            }
        }, true);

        // ヘッター消すぜ
        this.headersVisibility = HeadersVisibility.None;

        // 最初はなにも選びませ～ん
        this.select(-1, -1);
    }

    ngOnInit(): void {

        // マウスダウンした際に、マウスアップのイベントを監視する
        this.addEventListener(this.hostElement, 'mousedown', (e) => {
            // マウスアップした際のイベントで範囲を取得
            document.addEventListener('mouseup', this.onMouseUp);
        });
    }

    /**
     * マウスアップした際の処理
     * @param e
     */
    private onMouseUp(e): void {

        // イベント監視を破棄
        document.removeEventListener('mouseup', this.onMouseUp);

        //---------------------------------------------------
        // 列の開始から見て行って最初に選択状態になっている月を取得
        //---------------------------------------------------
        var fromNmonth: number;
        for (var i = 0; i < this.columns.length; i++) {
            // SelectedStateで選択状態がわかる
            var state: SelectedState = this.getSelectedState(0, i);
            if (state === SelectedState.Selected ||
                state === SelectedState.Cursor ||
                state === SelectedState.Active) {

                fromNmonth = this.getNmonth(i);
                break;
            }
        }

        //--------------------------------------------------------
        // 列の終わりから見て行って最初に選択状態になっている月を取得
        //--------------------------------------------------------
        var toNmonth: number;
        for (var i = this.columns.length - 1; i >= 0; i--) {
            var state: SelectedState = this.getSelectedState(0, i);;
            if (state === SelectedState.Selected ||
                state === SelectedState.Cursor ||
                state === SelectedState.Active) {

                toNmonth = this.getNmonth(i);
                break;
            }
        }

        //-----------------------------
        // from/toの情報をクラスにセット
        //-----------------------------
        var rMonth: EMonthSliderSelectRMonth = new EMonthSliderSelectRMonth();
        rMonth.fromRMonth = fromNmonth;
        rMonth.toRMonth = toNmonth;

        // イベントば～～～ん
        this.eSelectChange.emit(rMonth);
    }

    /**
     * setter
     * 対象の会計年度
     */
    @Input() set fisicalYearCd(value: number) {

        if (typeof (value) === "undefined") {
            return;
        }
        if (this._fisocalYearCd == value) {
            return;
        }
        this._fisocalYearCd = value;

        // カラムを初期化
        this.columns.clear();

        // グリッドの1行情報配列
        var emonthSliderItem: EMonthSliderItem[] = new Array(1);
        var nmonthCount: number = 1;
        var item: EMonthSliderItem = new EMonthSliderItem();
        // クライアント保有情報の月度情報でループ
        for (var i = 0; i < this.property.ownershipDto.monthItemDtoList.length; i++) {
            // 月度情報
            var monthItemDto: MonthItemDto = this.property.ownershipDto.monthItemDtoList[i];
            // 対象会計年度と同一
            if (monthItemDto.fisicalYearCd === value) {
                // 列を追加
                var column: Column = new Column({ binding: "label" + nmonthCount });
                if (this.simpleMode) {
                    if (monthItemDto.relativeMonth <= 12) {
                        column.width = 42;
                    }
                    else {
                        column.width = 56;
                    }
                }
                else {
                    column.width = 65;
                }

                column.align = 'center';
                column.cssClass = 'e-month-slider monthCell';

                this.columns.push(column);
                nmonthCount++;

                if (monthItemDto.relativeMonth == 1) {
                    item.nmonth1 = monthItemDto.relativeMonth;
                    item.label1 = this.modeLabelDisplay(monthItemDto.monthForDisplay);
                }
                else if (monthItemDto.relativeMonth == 2) {
                    item.nmonth2 = monthItemDto.relativeMonth;
                    item.label2 = this.modeLabelDisplay(monthItemDto.monthForDisplay);
                }
                else if (monthItemDto.relativeMonth == 3) {
                    item.nmonth3 = monthItemDto.relativeMonth;
                    item.label3 = this.modeLabelDisplay(monthItemDto.monthForDisplay);
                }
                else if (monthItemDto.relativeMonth == 4) {
                    item.nmonth4 = monthItemDto.relativeMonth;
                    item.label4 = this.modeLabelDisplay(monthItemDto.monthForDisplay);
                }
                else if (monthItemDto.relativeMonth == 5) {
                    item.nmonth5 = monthItemDto.relativeMonth;
                    item.label5 = this.modeLabelDisplay(monthItemDto.monthForDisplay);
                }
                else if (monthItemDto.relativeMonth == 6) {
                    item.nmonth6 = monthItemDto.relativeMonth;
                    item.label6 = this.modeLabelDisplay(monthItemDto.monthForDisplay);
                }
                else if (monthItemDto.relativeMonth == 7) {
                    item.nmonth7 = monthItemDto.relativeMonth;
                    item.label7 = this.modeLabelDisplay(monthItemDto.monthForDisplay);
                }
                else if (monthItemDto.relativeMonth == 8) {
                    item.nmonth8 = monthItemDto.relativeMonth;
                    item.label8 = this.modeLabelDisplay(monthItemDto.monthForDisplay);
                }
                else if (monthItemDto.relativeMonth == 9) {
                    item.nmonth9 = monthItemDto.relativeMonth;
                    item.label9 = this.modeLabelDisplay(monthItemDto.monthForDisplay);
                }
                else if (monthItemDto.relativeMonth == 10) {
                    item.nmonth10 = monthItemDto.relativeMonth;
                    item.label10 = this.modeLabelDisplay(monthItemDto.monthForDisplay);
                }
                else if (monthItemDto.relativeMonth == 11) {
                    item.nmonth11 = monthItemDto.relativeMonth;
                    item.label11 = this.modeLabelDisplay(monthItemDto.monthForDisplay);
                }
                else if (monthItemDto.relativeMonth == 12) {
                    item.nmonth12 = monthItemDto.relativeMonth;
                    item.label12 = this.modeLabelDisplay(monthItemDto.monthForDisplay);
                }
                else if (monthItemDto.relativeMonth == 13) {
                    item.nmonth13 = monthItemDto.relativeMonth;
                    item.label13 = this.modeLabelDisplay(monthItemDto.monthForDisplay);
                }
                else if (monthItemDto.relativeMonth == 14) {
                    item.nmonth14 = monthItemDto.relativeMonth;
                    item.label14 = this.modeLabelDisplay(monthItemDto.monthForDisplay);
                }
                else if (monthItemDto.relativeMonth == 15) {
                    item.nmonth15 = monthItemDto.relativeMonth;
                    item.label15 = this.modeLabelDisplay(monthItemDto.monthForDisplay);
                }
            }
        }
        emonthSliderItem[0] = item;

        this.itemsSource = emonthSliderItem;
    }

    /**
     * ラベルを変更する
     */
    private modeLabelDisplay(val: string): string {

        // モードによって、月度 -> 月 / 決算月 -> 決算 に変更
        return this.simpleMode? val.replace('月度', '月').replace('決算月', '決算') : val;
    }

    /**
     * 背景色の設定
     * @param e
     */
    public onFormatItem(e: FormatItemEventArgs): void {

        super.onFormatItem(e);

        // Cellのみ反映
        if (e.panel.cellType !== CellType.Cell) {
            return;
        }

        // 背景色を設定する
        if (e.col < 6) {
            e.cell.style.backgroundColor = '#FFFAF0';
        }
        else if (e.col < 12) {
            e.cell.style.backgroundColor = '#F0F8FF';
        }
        else {
            e.cell.style.backgroundColor = '#F5F5DC';
        }
    }

    /**
     * i+1番目の内部月をitemSourceから取得
     * @param i
     */
    private getNmonth(i: number): number {

        var nmonth: number;
        if (i == 0) {
            nmonth = this.itemsSource[0].nmonth1;
        }
        else if (i == 1) {
            nmonth = this.itemsSource[0].nmonth2;
        }
        else if (i == 2) {
            nmonth = this.itemsSource[0].nmonth3;
        }
        else if (i == 3) {
            nmonth = this.itemsSource[0].nmonth4;
        }
        else if (i == 4) {
            nmonth = this.itemsSource[0].nmonth5;
        }
        else if (i == 5) {
            nmonth = this.itemsSource[0].nmonth6;
        }
        else if (i == 6) {
            nmonth = this.itemsSource[0].nmonth7;
        }
        else if (i == 7) {
            nmonth = this.itemsSource[0].nmonth8;
        }
        else if (i == 8) {
            nmonth = this.itemsSource[0].nmonth9;
        }
        else if (i == 9) {
            nmonth = this.itemsSource[0].nmonth10;
        }
        else if (i == 10) {
            nmonth = this.itemsSource[0].nmonth11;
        }
        else if (i == 11) {
            nmonth = this.itemsSource[0].nmonth12;
        }
        else if (i == 12) {
            nmonth = this.itemsSource[0].nmonth13;
        }
        else if (i == 13) {
            nmonth = this.itemsSource[0].nmonth14;
        }
        else if (i == 14) {
            nmonth = this.itemsSource[0].nmonth15;
        }

        return nmonth;
    }

    /**
     * 内部月の開始と終了を設定し、選択状態にする
     * @param fromNmonth 選択開始内部月
     * @param toNmonth 選択終了内部月
     */
    public selectNMonth(fromNmonth:number, toNmonth:number): void {

        // 開始・終了にエラーがある場合は選択を解除
        if (fromNmonth === -1 || toNmonth === -1) {
            this.selectionClear();
        }
        // 指定された内部月の選択を行う
        else {
            this.select(new CellRange(0, fromNmonth - 1, 0, toNmonth - 1));
        }
    }

    /**
     * 選択を解除する
     */
    public selectionClear():void {

        // 選択を解除
        this.selection = new CellRange(-1, -1, -1, -1);
    }
}

@NgModule({
    exports: [EMonthSliderComponent],
    declarations: [EMonthSliderComponent]
})
export class EMonthSliderModule { }

/**
 * FlexGridの列情報
 */
export class EMonthSliderItem {

    nmonth1: number;
    label1: String;

    nmonth2: number;
    label2: String;

    nmonth3: number;
    label3: String;

    nmonth4: number;
    label4: String;

    nmonth5: number;
    label5: String;

    nmonth6: number;
    label6: String;

    nmonth7: number;
    label7: String;

    nmonth8: number;
    label8: String;

    nmonth9: number;
    label9: String;

    nmonth10: number;
    label10: String;

    nmonth11: number;
    label11: String;

    nmonth12: number;
    label12: String;

    nmonth13: number;
    label13: String;

    nmonth14: number;
    label14: String;

    nmonth15: number;
    label15: String;
}

/**
 * 選択変更で得られるFrom/Toのクラス
 */
export class EMonthSliderSelectRMonth {

    toRMonth: number;

    fromRMonth: number;

}
