import { Component, NgModule, ViewChild } from '@angular/core';
import { WjPopup, WjInputModule } from 'wijmo/wijmo.angular2.input';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { AC000MessageDto } from '../../dto/ac000/AC000MessageDto';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { WjFlexGridEx } from '../wj-flex-grid-ex/wj-flex-grid-ex';

@Component({
    selector: 'e-alert',
    templateUrl: './e-alert.component.html',
    styleUrls: ['./e-alert.component.css']
})
export class EAlertComponent {

    /** タイトル文言 */
    public messageTitle: string;

    /** 内容 */
    public messageContent: string;

    /** フォーカスターゲット */
    public targetId: string;

    /**
     * 10:インフォメーション
     * 11:警告
     * 12:確認
     * 21/22:エラー
     */
    public alertType: string;

    /**
     * 0:OK デフォルト:OK
     * 1:OK/CANCEL デフォルト:OK
     * 2:YES/NO デフォルト:YES
     */
    public buttonPattern: number;

    /** ポップアップの参照 */
    @ViewChild(WjPopup)
    private wjpopup: WjPopup;

    /** 1行に何文字入れるか */
    private CHAR_PER_LINE_CNT: number = 20;

    /** コンストラクタ */
    constructor(private property: EcoKaikeiProperty) {
    }

    /**
     * ダイアログを表示する
     *
     * @param messageId メッセージID
     * @param agreeFunction OK / YES の処理
     * @param disagreeFunction CANCEL / NO の処理
     */
    public message(messageId: string, words?: string[], clientTarget?: string, agreeFunction?: Function, disagreeFunction?: Function) {

        // メッセージDTOを取得
        var found: AC000MessageDto = this.messageDto(messageId, this.property.messageDtoList);

        // メッセージタイプを設定
        this.alertType = messageId.substr(0, 2);

        // メッセージタイトル / メッセージ / ボタン種
        this.messageTitle = found.messageTitle;
        this.messageContent = found.message.replace(/\\n/g, '\n');
        this.buttonPattern = found.buttonPattern;

        // 置換文字が存在する場合入れ替えを行う
        if (words !== undefined && words !== null) {
            for (var i: number = 0; i < words.length; i++) {
                this.messageContent = this.messageContent.replace(new RegExp('\\$\\{' + i + '\\}', 'g'), words[i]);
            }
        }

        // 文字数で改行を入れる
        var messageContents: string[] = new Array();

        // CHAR_PER_LINE_CNTを超える文字を、１行に設定した場合は改行を行う
        for (var messageContent of this.messageContent.split('\n')) {
            // CHAR_PER_LINE_CNT以上
            if (messageContent.length > this.CHAR_PER_LINE_CNT) {
                messageContents.push(messageContent.slice(0, this.CHAR_PER_LINE_CNT) + '\n' + messageContent.slice(this.CHAR_PER_LINE_CNT));
            }
            // CHAR_PER_LINE_CNT未満
            else {
                messageContents.push(messageContent);
            }
        }

        // 改行した文字を設定する
        this.messageContent = messageContents.join('\n');

        // ポップアップを表示
        this.wjpopup.show(true, (e) => {
            if (e.dialogResult === 'wj-hide-ok' && agreeFunction !== undefined) {
                agreeFunction();
            }
            //
            else if (e.dialogResult === 'wj-hide-cancel' && disagreeFunction !== undefined) {
                disagreeFunction();
            }

            // フォーカスを当てる
            if (clientTarget !== undefined && clientTarget !== null) {

                // gridのID : 行 : 列
                if (clientTarget.match(':') && clientTarget.split(':').length === 3 && document.getElementById(clientTarget.split(':')[0]) !== null
                    && (document.getElementById(clientTarget.split(':')[0])['$WJ-CTRL'] as WjFlexGridEx)) {
                    (document.getElementById(clientTarget.split(':')[0])['$WJ-CTRL'] as WjFlexGridEx).focusCellInput(
                        parseInt(clientTarget.split(':')[1]), parseInt(clientTarget.split(':')[2]));
                }
                else if (document.getElementById(clientTarget) !== null) {
                    document.getElementById(clientTarget).focus();
                }
            }
        });
    }

    /**
     * 強制的にプログラムから閉じる
     */
    public close(): void {

        if (this.isPopShow()) {
            // ポップアップを閉じる
            this.wjpopup.hide();
        }
    }

    /**
     * ポップアップが開いているかどうかを返す
     */
    public isPopShow(): boolean {

        // ポップアップが開いているかどうかを返す
        return this.wjpopup.isVisible;
    }

    /**
     * IDからメッセージ情報を取得する
     * @param searchId
     * @param messages
     */
    private messageDto(searchId: string, messages: AC000MessageDto[]): AC000MessageDto {

        // メッセージ情報を取得
        return messages.find(function (item) {
            return item.messageId === searchId;
        });
    }

    /**
     * 指定のボタンIDにフォーカスを設定する
     * @param btnId
     */
    public setFocusBtn(btnId: string): void {

        // ボタンIDにフォーカスを設定する
        if (document.getElementById(btnId)) {
            document.getElementById(btnId).focus();
        }
    }
}

@NgModule({
    exports: [EAlertComponent],
    declarations: [EAlertComponent],
    imports: [CommonModule, FormsModule, WjInputModule],
})
export class EAlertModule { }
