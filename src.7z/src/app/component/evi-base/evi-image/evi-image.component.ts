import { Component, OnInit, Input, NgModule, Output, EventEmitter } from '@angular/core';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'evi-image',
  templateUrl: './evi-image.component.html',
  styleUrls: ['./evi-image.component.css']
})
export class EviImageComponent implements OnInit {

    // 画像ファイルデータ(Base64文字列)
    @Input() activeImage: string;

    // 複数画像が存在するか？(true:存在する) ※存在する場合、複数あるように見せるために白い影をつける。
    @Input() isMultiPage: boolean;

    @Input() isPopupImageClick: boolean;

    // 画像表示の最大サイズ(横)
    @Input() maxImageSize: number;

    // 画像表示の縦サイズ(収まらない場合はスクロール表示)
    @Input() maxImageHeight: number;

    @Output() imageDbClick = new EventEmitter();

    // 画像をポップアップ表示を決定するcss:display属性値
    private popupImgDisplay: string;

    // ポップアップするimgタグのhtmlタグid
    private popupImgTagId: string;

    // ポップアップするimgタグを囲む半透明レイヤーのhtmlタグid
    private popuplayerTagId: string;

    private handleWindowResizeFunction = this.handleWindowResize.bind(this);

    constructor(private sanitizer: DomSanitizer) {
    }

    // コンポーネント初期化時のライフサイクルメソッド
    ngOnInit() {
        // ポップアップ画像のタグ用のhtml_idに乱数を付与する(本コンポーネントを複数配置する場合、htmlのidが重複しないための対策)
        const tagId: string = this.randomString();
        this.popupImgTagId = `evi-base-img-back-file-${tagId}`;
        this.popuplayerTagId = `evi-base-img-layer-${tagId}`;

        // 画像の最大サイズを指定(プロパティで指定されなかった場合はデフォルト値とする)))
        this.maxImageSize = (this.maxImageSize === undefined || this.maxImageSize === null) ? 240 : this.maxImageSize;
        this.maxImageHeight = (this.maxImageHeight === undefined || this.maxImageHeight === null) ? 460 : this.maxImageHeight;

        // 画像をシングルクリックでポップアップ表示するか？
        this.isPopupImageClick = (this.isPopupImageClick === undefined || this.isPopupImageClick === null) ? true : this.isPopupImageClick;

        this.closePopUpImage();
    }

    // コンポーネント破棄のライフサイクルメソッド
    ngOnDestroy() {
        this.removeResizeEvent();
    }

    // 画面リサイズ時のイベントを削除
    private removeResizeEvent(): void {
        // コンポーネントがクリアされる際に、ウインドウ変更イベントを消す(SPAなので不要になる消さないとどんどんたまってしまうため)
        window.removeEventListener('resize', this.handleWindowResizeFunction);
        //console.log("[evi-image]removeResizeEvent");
    }

    // 証憑詳細の画像をポップアップしている場合、画面サイズに合わせてポップアップ画像のサイズも連動する
    private handleWindowResize(): void {
        if (this.popupImgDisplay !== "none") this.resizePouUpImage();
        //console.log("[evi-image]on handleWindowResize");
    }

    // イベントを設定
    private eventListener(): void {
        this.removeResizeEvent();
        // 証憑詳細画像をポップアップで表示している場合、画面サイズを変更したときにポップアップ画像も連動してサイズ変更する
        window.addEventListener('resize', this.handleWindowResizeFunction);
        //console.log("[evi-image]addResizeEvent");
    }

    // ポップアップ画像を表示するか？
    private get isActivePopupImage(): boolean {
        if (this.activeImage !== null) return true;
        return false;
    }

    // ポップアップ画像表示
    private get activePopupImage(): SafeUrl {
        if (this.activeImage !== null) return this.sanitizer.bypassSecurityTrustUrl(`data:image/jpeg;base64,${this.activeImage}`);
        return null;
    }

    // 画像表示最大サイズ
    private get maxImageSizePx(): string {
        return this.maxImageSize + "px";
    }

    // 画像表示縦サイズ
    private get maxImageHeightPx(): string {
        return this.maxImageHeight + "px";
    }

    // 画像クリック
    private onImageClick(): void {
        if (this.isPopupImageClick) {
            this.dispPopUpImage();
        }
        //this.imageClick.emit();
    }

    // 画像ダブルクリック
    private onImageDbClick(): void {
        this.imageDbClick.emit();
    }

    // ポップアップ画像を非表示にする。
    private closePopUpImage(): void {
        this.removeResizeEvent();
        this.popupImgDisplay = "none";
    }

    // 選択された証憑詳細画像のポップアップ表示
    private dispPopUpImage(): void {
        this.eventListener();
        this.popupImgDisplay = "block";
        this.resizePouUpImage();
    }

    // 乱数生成
    private randomString(): string {
        const strLen: number = 32;
        const c: string = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        const cl: number = c.length;
        let r: string = "";
        for(let i=0; i<strLen; i++){
            r += c[Math.floor(Math.random()*cl)];
        }
        return r;
    }

    // 選択された証憑詳細画像のポップアップ表示＋サイズを変更
    private resizePouUpImage(): void {
        // 表示画像のサイズを取得
        const el: HTMLElement = document.getElementById(this.popupImgTagId);
        const img = new Image();
        img.src = el.getAttribute('src');
        const imgRatio: number = img.height / img.width;

        // 画面全体を覆う半透明レイヤーを表示
        const backImgLayer: HTMLElement = document.getElementById(this.popuplayerTagId);
        backImgLayer.style.width = window.innerWidth + "px";
        backImgLayer.style.height = window.innerHeight + "px";

        const winRatio: number = window.innerHeight / window.innerWidth;
        const margin: number = 50;

        let w: number;
        let h: number;
        if (imgRatio > winRatio) {
            // 画像の方がウィンドウより縦長 → 画像の高さをウィンドウに合わせる
            h = window.innerHeight - (2 * margin);
            w = h / imgRatio;
        } else {
            // ウィンドウの方が縦長 → 画像幅を元の画像に合わせる
            w = window.innerWidth - (2 * margin);
            h = w * imgRatio;
        }

        // 画像を表示
        el.style.left   = ((window.innerWidth - w) / 2) + 'px';
        el.style.top    = ((window.innerHeight - h) / 2) + 'px';
        el.style.width  = w + 'px';
        el.style.height = h + 'px';
    }

}

@NgModule({
    exports: [EviImageComponent],
    declarations: [EviImageComponent],
    imports: [
        CommonModule
    ]
})
export class EviImageModule {
}
