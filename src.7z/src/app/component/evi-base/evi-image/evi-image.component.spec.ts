import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EviImageComponent } from './evi-image.component';

describe('EviImageComponent', () => {
  let component: EviImageComponent;
  let fixture: ComponentFixture<EviImageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EviImageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EviImageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
