import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ChangeDetectorRef, NgModule } from '@angular/core';
import { WjFlexGridEx, WjFlexGridModuleEx } from '../../wj-flex-grid-ex/wj-flex-grid-ex';
import { CommonModule } from '@angular/common';
import { WjGridModule } from 'wijmo/wijmo.angular2.grid';

@Component({
  selector: 'evi-pagination',
  templateUrl: './evi-pagination.component.html',
  styleUrls: ['./evi-pagination.component.css']
})
export class EviPaginationComponent implements OnInit {

    /** 証憑画像表示順序Grid */
    @ViewChild("voucherImageOrderGrid")
    voucherImageOrderGrid: WjFlexGridEx;

    /** アクティブのページ番号 */
    @Input() activePageNumber: number;
    @Output() activePageNumberChange = new EventEmitter<number>();

    /** 編集モード(true:編集可能 false:編集不可) */
    @Input() isEditMode: boolean;

    /** 背景色 */
    @Input() mainBackgroundColor: string;

    /** ページを作成するリスト */
    @Input() pagingList: any[];

    /** ページ番号のカラム名 */
    @Input() pageColumnName: string;

    @Output() pageClick = new EventEmitter();

    @Output() changePageOrder = new EventEmitter();

    constructor(private changeDetectorRef: ChangeDetectorRef) {
    }

    ngOnInit() {
        // アクティブのページ番号
        if (this.activePageNumber === undefined || this.activePageNumber === null) this.activePageNumber = 0;
        // 編集モード(親コンポーネントからプロパティで渡されなかった場合、強制的に編集OKモードにする))
        if (this.isEditMode === undefined || this.isEditMode === null) this.isEditMode = true;

        // ページネーション部の背景色を設定
        this.voucherImageOrderGrid.hostElement.style.backgroundColor = this.mainBackgroundColor;
        this.voucherImageOrderGrid.hostElement.style.border = "none";
        this.voucherImageOrderGrid.hostElement.style.borderRadius = "0%";

        // ページ表示領域はFlexGridで作っている。サイズ変更を禁止する(0はサイズ変更できない)
        this.voucherImageOrderGrid.allowResizing = 0;

        // ページの並べ替えができるか？(1:できる 0:できない)
        if (!this.isEditMode) this.voucherImageOrderGrid.allowDragging = 0;
    }

    // ページ入れ替え
    private doChangePageOrder(): void {
        this.changePageOrder.emit(this.voucherImageOrderGrid);
    }

    // ページ番号をクリック
    private selectPage(selectPageNumber: number): void {
        this.activePageNumber = selectPageNumber;
        this.activePageNumberChange.emit(this.activePageNumber);
        this.pageClick.emit(this.activePageNumber);
    }

    // 対象ページの名称を取得
    private getPageName(data: any): string {
        return data[this.pageColumnName];
    }

    // 強制リフレッシュ
    public refresh(): void {
        // 下記の処理はstorybook上のテストでは入れないといけなかったが、通常に動かすと不要であることがわかったため削除
        //this.voucherImageOrderGrid.hostElement.click();
    }
}

@NgModule({
    exports: [EviPaginationComponent],
    declarations: [EviPaginationComponent],
    imports: [
        CommonModule,
        WjGridModule,
        WjFlexGridModuleEx,
    ]
})
export class EviPaginationModule {
}
