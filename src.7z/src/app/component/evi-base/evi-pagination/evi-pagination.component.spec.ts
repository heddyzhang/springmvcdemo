import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EviPaginationComponent } from './evi-pagination.component';

describe('EviPaginationComponent', () => {
  let component: EviPaginationComponent;
  let fixture: ComponentFixture<EviPaginationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EviPaginationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EviPaginationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
