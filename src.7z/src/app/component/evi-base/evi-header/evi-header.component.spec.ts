import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EviHeaderComponent } from './evi-header.component';

describe('EviHeaderComponent', () => {
  let component: EviHeaderComponent;
  let fixture: ComponentFixture<EviHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EviHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EviHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
