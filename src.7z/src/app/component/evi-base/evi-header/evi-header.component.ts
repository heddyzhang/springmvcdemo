import { Component, OnInit, Input, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'evi-header',
  templateUrl: './evi-header.component.html',
  styleUrls: ['./evi-header.component.css']
})
export class EviHeaderComponent implements OnInit {

    @Input() eviName: string;

    @Input() eviCount: number;

    constructor() {
    }

    ngOnInit() {
    }
}

@NgModule({
    exports: [EviHeaderComponent],
    declarations: [EviHeaderComponent],
    imports: [
        CommonModule
    ]
})
export class EviHeaderModule {
}
