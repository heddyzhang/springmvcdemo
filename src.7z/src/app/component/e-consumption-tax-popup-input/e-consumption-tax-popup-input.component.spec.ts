import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EConsumptionTaxPopupInputComponent } from './e-consumption-tax-popup-input.component';

describe('EConsumptionTaxPopupInputComponent', () => {
  let component: EConsumptionTaxPopupInputComponent;
  let fixture: ComponentFixture<EConsumptionTaxPopupInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EConsumptionTaxPopupInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EConsumptionTaxPopupInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
