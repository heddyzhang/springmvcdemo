import { Component, OnInit, Input, Output, ViewChild, NgModule, EventEmitter } from '@angular/core';
import { WjPopup, WjInputModule } from 'wijmo/wijmo.angular2.input';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { EPopupItem } from '../../dto/ePopupInput/EPopupItem';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { WjFlexGridModuleEx } from '../wj-flex-grid-ex/wj-flex-grid-ex';
import { WjGridModule } from 'wijmo/wijmo.angular2.grid';
import { EConsumptionTaxInputComponent } from './supportClass/e-consumption-tax-input/e-consumption-tax-input';

@Component({
  selector: 'e-consumption-tax-popup-input',
  templateUrl: './e-consumption-tax-popup-input.component.html',
  styleUrls: ['./e-consumption-tax-popup-input.component.css']
})
/**
 * <e-consumption-input>と共に使用する
 * 他のポップアップと表示位置を共有する場合は、x y とバインドする。
 * その他のパラメータを各自で設定することを想定していない。
 */
export class EConsumptionTaxPopupInputComponent implements OnInit {

    @Input()
    /** ポップアップ位置 X軸 */
    public set x(value:string) {

        this._x = value;

        // 変更イベント
        this.xChange.emit(this._x);
    }

    @Input()
    /** ポップアップ位置 Y軸 */
    public set y(value:string) {

        this._y = value;

        // 変更イベント
        this.yChange.emit(this._y);
    }

    /** 変更イベント */
    @Output()
    public xChange = new EventEmitter();
    @Output()
    public yChange = new EventEmitter();

    @ViewChild(WjPopup)
    /** ポップアップの参照 */
    public wjpopup:WjPopup;

    /** タブの表示 -1 : All 1 : 売上のみ 2 : 仕入のみ */
    public displayTab:number = -1;

    /** 選択中のタブ */
    public selectedTabCls:number = 1;

    /** 消費税内容 */
    public items:EConsumptionTaxPopupInputItem[];

    /** ポップアップ位置 X軸 */
    private _x:string;

    /** ポップアップ位置 Y軸 */
    private _y:string;

    /** 入力中の消費税入力欄への参照 */
    private consumptionTaxInput:EConsumptionTaxInputComponent;

    /** コンストラクタ */
    constructor(private property: EcoKaikeiProperty) {}

    /**
     * 初期化処理
     */
    public ngOnInit():void {

        // ポップアップの表示/非表示切り替えのアニメーションを削除
        this.wjpopup.fadeIn = false;
        this.wjpopup.fadeOut = false;

        // フォーカスが当たった際に、抜ける
        this.wjpopup.addEventListener(this.wjpopup.hostElement, 'focus', (e) => {this.consumptionTaxInput.inputElement.focus();}, true);

        // フォーカスを受け付けなくする
        this.wjpopup.addEventListener(this.wjpopup.hostElement, 'mousedown', (e) => {e.preventDefault();}, true);
    }

    /**
     * 消費税選択条件ポップアップを表示する
     * @param target 入力中の消費税入力欄
     */
    public show(target:EConsumptionTaxInputComponent):void {

        // 入力対象への参照を保持
        this.consumptionTaxInput = target;

        // タブの表示を設定
        this.displayTab = target.displayTab;

        // 初期選択タブを設定 => -1 : All 1 : 売上のみ 2 : 仕入のみ
        if (this.displayTab === 1 || this.displayTab === 2) {
            this.selectedTabCls = target.displayTab;
        }
        // ALL
        else {
            this.selectedTabCls = target.selectedTabCls;
        }

        // アイテムを作成
        this.gridItemRefresh();

        // 画面を表示する
        this.wjpopup.show();

        // ポップアップ位置が指定されている場合は、位置を変更する
        if (this._x && this._y) {
            this.wjpopup.hostElement.style.left = this._x;
            this.wjpopup.hostElement.style.top = this._y;
        }
    }

    /**
     * 消費税選択条件ポップアップを閉じる
     */
    public hide():void {

        // ポップアップの位置を保持する
        this.x = this.wjpopup.hostElement.style.left;
        this.y = this.wjpopup.hostElement.style.top;

        // ポップアップを閉じる
        this.wjpopup.hide();
    }

    /**
     * 消費税ボタンの押下処理
     * @param item 押下したボタン情報
     */
    public selectItem(item:EPopupItem):void{

        // 選択した消費税情報を設定する
        this.consumptionTaxInput.changeConsumptionTaxId(item.id, true);

        // 画面を閉じる
        this.hide();
    }

    /**
     * 消費税IDから選択情報を取得する
     * @param id 消費税ID
     */
    public searchConsumptionItemByID(id:number):EPopupItem {

        // 消費税情報を取得
        return this.property.consumptionTaxPopupItemList.find(function(item) {
            return item.id === id;
        });
    }

    /**
     * タブの変更イベント
     * @param val
     */
    public tabSelectChange(val: number): void {

        // 選択中のタブを保存
        this.selectedTabCls = val;

        // 一覧情報を再表示
        this.gridItemRefresh();
    }

    /**
     * 消費税情報一覧を作成する
     */
    public gridItemRefresh():void {

        // 一覧情報
        var consumptionTaxItems:EConsumptionTaxPopupInputItem[] = new Array();

        // 消費税１件の情報
        var consumptionTaxItem:EConsumptionTaxPopupInputItem = new EConsumptionTaxPopupInputItem();

        // 消費税1件毎に、表示条件を確認し、リストに詰め込む
        this.property.consumptionTaxPopupItemList.forEach(element => {

            // 表示を行うものを抜き出す
            if (this.filterFunction(element)) {
                // item1 / item2 / item3 の設定していない項目に設定
                if (!consumptionTaxItem.item1) {
                    consumptionTaxItem.item1 = element;
                } else if (!consumptionTaxItem.item2) {
                    consumptionTaxItem.item2 = element;
                } else if (!consumptionTaxItem.item3) {
                    consumptionTaxItem.item3 = element;
                }
                // item1 / item2 / item3 全てが設定済みの場合は、次の行に遷移
                else {
                    consumptionTaxItems.push(consumptionTaxItem);
                    consumptionTaxItem = new EConsumptionTaxPopupInputItem();
                    consumptionTaxItem.item1 = element;
                }
            }
        });

        // 1件目が設定済の場合に設定
        if (consumptionTaxItem.item1) {
            consumptionTaxItems.push(consumptionTaxItem);
        }

        // 一覧を設定
        this.items = consumptionTaxItems;
    }

    /**
     * 消費税情報のフィルター
     * @param item
     */
    private filterFunction(item: EPopupItem): boolean {

        // 入力欄の参照取得エラー
        if (!this.consumptionTaxInput) {
            return false;
        }

        // 消費税区分タブによる絞り込み
        if (item.tabCls && item.tabCls !== this.selectedTabCls) {
            return false;
        }

        // 絞り込み解除
        if (this.consumptionTaxInput.value === '') {
            return true;
        }

        // 絞り込み
        if (item.cd && item.cd.search(this.consumptionTaxInput.value) === 0) {
            return true;
        }

        // 絞り込み
        if (item.searchKey && item.searchKey.search(this.consumptionTaxInput.value) === 0) {
            return true;
        }

        return false;
    }
}

@NgModule({
    exports: [EConsumptionTaxPopupInputComponent],
    declarations: [EConsumptionTaxPopupInputComponent],
    imports: [CommonModule, FormsModule, WjInputModule, WjFlexGridModuleEx, WjGridModule],
})
export class EConsumptionTaxPopupInputModule {}

/**
 * 消費税選択に表示する内容
 */
export class EConsumptionTaxPopupInputItem {

    /** １列目の消費税内容 */
    public item1:EPopupItem;

    /** ２列目の消費税内容 */
    public item2:EPopupItem;

    /** ３列目の消費税内容 */
    public item3:EPopupItem;
}
