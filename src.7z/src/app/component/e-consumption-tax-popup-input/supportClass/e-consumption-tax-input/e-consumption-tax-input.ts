import { Component, NgModule, Input, Output, EventEmitter } from "@angular/core";
import { wjInputMaskMeta } from "wijmo/wijmo.angular2.input";
import { ETextInputComponent } from "../../../e-text-input/e-text-input.component";
import { EPopupItem } from "../../../../dto/ePopupInput/EPopupItem";
import { EConsumptionTaxPopupInputComponent } from "../../e-consumption-tax-popup-input.component";

@Component({
    selector: 'e-consumption-tax-input',
    template: wjInputMaskMeta.template,
    inputs: wjInputMaskMeta.inputs,
    outputs: wjInputMaskMeta.outputs,
})
/**
 * <e-consumption-tax-popup-input>と共に使用する
 * consumptionTaxPopに<e-consumption-popup-input>を指定する
 * [(consumptionId)]に消費税IDを設定する
 *
 * [(consumptionName)]は、Grid内で使用するときに設定する
 */
export class EConsumptionTaxInputComponent extends ETextInputComponent {

    @Input()
    /** ポップアップへの参照 */
    public consumptionTaxPop:EConsumptionTaxPopupInputComponent;

    @Input()
    /** 売上タブ　表示区分 */
    public showEarnings:boolean = true;

    @Input()
    /** 仕入タブ　表示区分 */
    public showPurchase:boolean = true;

    @Input()
    /** タブの表示 -1 : All 1 : 売上のみ 2 : 仕入のみ */
    public displayTab:number = -1;

    @Input()
    /** 初期選択のタブ 1 => 売上 2 => 仕入 */
    public selectedTabCls:number = 1;

    @Input()
    /** 消費税名称 */
    public consumptionTaxName:string;

    @Input()
    /** 消費税ID */
    public set consumptionTaxId(value:number) {
        this.changeConsumptionTaxId(value, false);
    }
    /** 消費税ID */
    public changeConsumptionTaxId(value:number, isValueChanged:boolean) {
        // 値が変更されたかを検知する
        var _isEOnValueChanged:boolean = (isValueChanged && this._consumptionTaxId != value)? true : false;
        // this.valueにセットする値を保持する
        var _value: any = null;

        this._consumptionTaxId = value;

        // 消費税IDから消費税情報を取得する
        this._item = this.consumptionTaxPop.searchConsumptionItemByID(value);

        // 消費税情報が取得できた場合は、略称を表示
        if (this._item) {
            // フォーカスが当たっている => コード表示
            if (document.activeElement === this.inputElement) {
                _value = this._item.cd;
            }
            // フォーカスが当たっていない => 略称表示
            else {
                _value = this._item.label;
            }

            // 略称
            this.consumptionTaxName = this._item.label;
        }
        // IDが存在しない場合は、空白
        else {
            _value = '';
            this.consumptionTaxName = '';
        }

        // 値を変更する
        if (_isEOnValueChanged) {
            this.value = _value;
        } else {
            this.eValue = _value;
        }
    }

    /** 変更イベント */
    @Output()
    public consumptionTaxIdChange = new EventEmitter();
    @Output()
    public consumptionTaxNameChange = new EventEmitter();

    /** 消費税ID */
    private _consumptionTaxId:number;

    /** 選択中のポップアップアイテム */
    private _item:EPopupItem;

    /**
     * 初期化処理
     */
    public ngOnInit():void {

        // 親クラスの初期化
        super.ngOnInit();

        // フォーカス時の処理
        this.inputElement.addEventListener('focus', this.inputElementOnShowPop.bind(this));

        // クリック時の処理
        this.inputElement.addEventListener('click', this.inputElementOnShowPop.bind(this));

        // キー入力を監視 => TAB押下時に補助を確定するため
        this.inputElement.addEventListener('keydown', this.inputElementOnKeydown.bind(this));

        // フォーカスを抜けた場合の処理
        this.inputElement.addEventListener('blur', this.inputElementOnBlur.bind(this));

        // 入力値の変更時の処理
        this.inputElement.addEventListener('input', this.inputElementOnInput.bind(this));
    }

    /**
     * 消費税選択ポップアップの選択時の処理
     * @param value 消費税ID
     */
    public selectItemId(value:number):void {

        // IDを設定する
        this.consumptionTaxId = value;

        // コード表示に変換する
        if (this._item) {
            this.eValue = this._item.cd;
        }
    }

    /**
     * フォーカス時の処理 / クリック時の処理
     * @param e
     */
    private inputElementOnShowPop(e):void {

        // 既に表示中の場合は処理を中断
        if (this.consumptionTaxPop.wjpopup && this.consumptionTaxPop.wjpopup.isVisible) {
            return;
        }

        // 選択中の場合は、コードに変換する
        if (this._item) {
            this.eValue = this._item.cd;
        }

        // 消費税選択ポップアップを表示する
        this.consumptionTaxPop.show(this);
    }

    /**
     * キーボード押下時の処理
     * @param e
     */
    private inputElementOnKeydown(e):void {

        // タブ移動時の処理
        if (e.key === 'Tab') {
            // 絞り込み条件によって選択アイテムを決定する
            this.setSelectedItem();
        }
    }

    /**
     * フォーカスを抜けた場合の処理
     * @param e
     */
    private inputElementOnBlur(e):void {

        // フォーカスの移動先
        var target: any = e.relatedTarget;

        // relatedTargetがサポートされていない場合
        if (!target) {
            target = document.activeElement;
        }

        // 消費税選択ポップアップへのフォーカス移動の場合は、処理を中断する
        if (target && (target.classList.contains('consumption')
            || target.classList.contains('wj-popup'))) {
            return;
        }

        // 絞り込み条件によって選択アイテムを決定する
        this.setSelectedItem();

        // 消費税選択ポップアップを閉じる
        this.consumptionTaxPop.hide();
    }

    /**
     * 入力値の変更時の処理
     * @param e
     */
    private inputElementOnInput(e):void {

        // 選択を解除する
        this._item = null;

        // 絞り込みを行う
        this.consumptionTaxPop.gridItemRefresh();
    }

    /**
     * 絞り込み条件によって選択アイテムを決定する
     */
    private setSelectedItem():void {

        // 1件に絞り込まれた場合は、その項目を選択値にする
        if (this.value.length > 0 && this.consumptionTaxPop.items.length === 1 && !this.consumptionTaxPop.items[0].item2) {
            this._item = this.consumptionTaxPop.items[0].item1;
        }

        // 選択時 => ID / 未選択時 => -1 を設定する
        this.changeConsumptionTaxId(this._item ? this._item.id : -1, true);

        // 変更イベント
        this.consumptionTaxIdChange.emit(this._consumptionTaxId);
        this.consumptionTaxNameChange.emit(this.consumptionTaxName);
    }
}

@NgModule({
    exports: [EConsumptionTaxInputComponent],
    declarations: [EConsumptionTaxInputComponent]
})
export class EConsumptionTaxInputModule {
}
