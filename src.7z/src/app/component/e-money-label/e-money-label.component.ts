import { Component, NgModule, ViewEncapsulation, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
    selector: 'e-money-label',
    templateUrl: './e-money-label.component.html',
    styleUrls: ['./e-money-label.component.css'],
    encapsulation: ViewEncapsulation.None,
})
export class EMoneyLabelComponent implements OnInit {
    // 編集後の入力値
    public value: number = null;

    // 入力値
    @Input() set eValue(value: any) {
        // 値をセットする
        this.value = (typeof value === 'number')? value: null;
        this.eValueChange.emit(this.value);
    }
    get eValue(): any {
        return this.value;
    }
    // バインド設定
    @Output() eValueChange = new EventEmitter<number>();

    // カンマ区切りの有無
    // true: カンマ区切りあり、false: カンマ区切りなし
    @Input() isCommaSeparate: boolean = true;

    // マイナス表記
    // 0: -、1: ▲
    // TODO: マイナス表記を変えること
    @Input() minusCls: string = '0';

    // カッコつきかどうか
    // true: ()をつける、false: ()をつけない
    @Input() isBrackets: boolean = false;
    
    constructor() { }

    ngOnInit() {
    }

}

@NgModule({
    exports: [EMoneyLabelComponent],
    declarations: [EMoneyLabelComponent],
    imports: [CommonModule, FormsModule],
})
export class EMoneyLabelModule {
}
