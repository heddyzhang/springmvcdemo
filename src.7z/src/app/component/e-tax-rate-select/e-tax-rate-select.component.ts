import { Component, Input, Output, NgModule, EventEmitter, ViewEncapsulation } from "@angular/core";
import { Inject, Injector, ElementRef as elementRef, SkipSelf, Optional } from '@angular/core';
import { wjComboBoxMeta } from "wijmo/wijmo.angular2.input";
import { EDropDownListComponent } from '../e-drop-down-list/e-drop-down-list.component';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { EventArgs} from 'wijmo/wijmo';

interface ElementRef {
    nativeElement: HTMLElement;
}

/**
 * @classdesc 消費税率ドロップダウンリストコンポーネント
 */
@Component({
    selector: 'e-tax-rate-select',
    template: wjComboBoxMeta.template,
    inputs: wjComboBoxMeta.inputs,
    outputs: wjComboBoxMeta.outputs,
    styleUrls: ["../e-drop-down-list/e-drop-down-list.css"],
    encapsulation: ViewEncapsulation.None,
})
export class ETaxRateSelectComponent extends EDropDownListComponent {
    public _targetdate: Date = null;
    // 入力値
    @Input() set targetdate(value: any) {
        // 指定した日付で選択できる税率を変更する
        if (value && this.property.taxRateList) {
            this.itemsSource = this.property.taxRateList.filter(
                date => (
                    date.usedFromDate <= value && value <= date.usedToDate
                ));
        } else {
            this.itemsSource = this.property.taxRateList;
        };
        // getで返す値をセット
        this._targetdate = value;
    }
    get targetdate(): any {
        return this._targetdate;
    }
    // バインド設定
    @Output() eValueChange = new EventEmitter<any>();


    constructor(private property: EcoKaikeiProperty,
        @Inject(elementRef) elRef: ElementRef,
        @Inject(Injector) injector: Injector,
        @Inject('EDropDownListComponent') @SkipSelf() @Optional() parentCmp: any, ) {
        super(elRef, injector, parentCmp);

        // ドロップダウンの内容を編集可能とする
        this.isEditable = true;

        // 表示するラベルと選択値を設定する
        this.labelField = "taxRateName";
        this.valueField = "taxRateId";

        // 配列を初期セット
        this.itemsSource = this.property.taxRateList;
    }

    /**
     * 初期表示時の処理
     */
    ngOnInit(): void {
        // 必ず呼ぶことwj-input-group-btn
        super.ngOnInit();
        //------------------------------
        // TODO: 引数で非表示にするかの処理未実装
        //------------------------------
        // this.showDropDownButton = false;


    }

    /**
     * フォーカスされた時の処理
     */
    public onGotFocus(e?: EventArgs): void {
        super.onGotFocus(e);
        // 表示するラベルを変更する
        this.displayMemberPath = "taxRateTitle";
        //------------------------------
        // TODO: 引数で非表示にするかの処理未実装
        //------------------------------
        // this.showDropDownButton = true;
    }

    /**
     * フォーカスが外れた時の処理
     */
    public onLostFocus(e?: EventArgs): void {
        super.onLostFocus(e);
        // 変更されたラベルを元に戻す
        this.displayMemberPath = "taxRateName";
        //------------------------------
        // TODO: 引数で非表示にするかの処理未実装
        //------------------------------
        // this.showDropDownButton = false;
    }
}

@NgModule({
    exports: [ETaxRateSelectComponent],
    declarations: [ETaxRateSelectComponent]
})
export class ETaxRateSelectModule { }
