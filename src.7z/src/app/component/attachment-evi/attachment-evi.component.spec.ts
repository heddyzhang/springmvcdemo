import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AttachmentEviComponent } from './attachment-evi.component';

describe('AttachmentEviComponent', () => {
  let component: AttachmentEviComponent;
  let fixture: ComponentFixture<AttachmentEviComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AttachmentEviComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AttachmentEviComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
