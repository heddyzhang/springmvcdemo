import { Component, OnInit, NgModule, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { ViewBaseButtonModule } from '../view-base-button/view-base-button.component';
import { EviHeaderModule } from '../evi-base/evi-header/evi-header.component';
import { EviImageModule } from '../evi-base/evi-image/evi-image.component';
import { EviPaginationModule, EviPaginationComponent } from '../evi-base/evi-pagination/evi-pagination.component';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { IndexService } from '../../service/IndexService';
import { LogoutService } from '../../service/logoutServive';
import { AttachmentEviService } from '../../service/AttachmentEviService';
import { AttachmentEviReqDto } from '../../dto/attachmentEvi/AttachmentEviReqDto';
import { AttachmentEviResDto } from '../../dto/attachmentEvi/AttachmentEviResDto';
import { AttachmentEviDto } from '../../dto/attachmentEvi/AttachmentEviDto';
import { ViewBaseModule } from '../view-base/view-base.component';
import { CommonEviDeleteDto } from '../../dto/commonEvi/CommonEviDeleteDto';
import { CommonEviDetailDto } from '../../dto/commonEvi/CommonEviDetailDto';
import { WjFlexGridEx } from '../wj-flex-grid-ex/wj-flex-grid-ex';
import { CommonEviImageOrder } from '../../dto/commonEvi/CommonEviImageOrder';
import { WjFlexGridColumn } from 'wijmo/wijmo.angular2.grid';
import { EAlertComponent, EAlertModule } from '../e-alert/e-alert.component';
import { AC000MessageDto } from '../../dto/ac000/AC000MessageDto';
import { ComponentBase } from '../../view/component-base';

@Component({
  selector: 'attachment-evi',
  templateUrl: './attachment-evi.component.html',
  styleUrls: ['./attachment-evi.component.css']
})
export class AttachmentEviComponent extends ComponentBase {

    @ViewChild("eAlert")
    eAlert: EAlertComponent;

    @ViewChild("eviPagination")
    eviPagination: EviPaginationComponent;

    /** 会計処理区分 */
    @Input() sortingSlipCls: number;

    /** 仕訳月（From） */
    @Input() journalDateFrom: Date;

    /** 仕訳月（To） */
    @Input() journalDateTo: Date;

    // /** 仕訳月（From） */
    // @Input() journalMonthFrom: string;

    // /** 仕訳月（To） */
    // @Input() journalMonthTo: string;

    /** 編集モード(true:編集可能 false:編集不可) */
    @Input() isEditMode: boolean;

    /** 単体テストFLG(実画面からは未指定でよい) */
    @Input() isUnitTest: boolean;

    /** 選択した添付証憑ID */
    @Input() selectedVoucherId: number;
    @Output() selectedVoucherIdChange = new EventEmitter<number>();

    // メイン画像表示部の背景色
    private mainBackgroundColor: string = '#626262';

    // 一度に表示する添付証憑の件数
    private attachmentEviDispcnt: number = 6;

    // 添付証憑一覧
    private attachmentEviList: any[];

    // 拡大表示している証憑ID
    private expansionVoucherId: number = null;

    // 拡大表示しているファイルデータ
    private expansionImageData: string = null;

    // 拡大表示している証憑情報
    private voucherData: any = null;

    // 拡大表示している証憑詳細の一覧データ
    private voucherDetailList: any[] = [];

    // 拡大表示している証憑詳細の一覧データの選択index
    private voucherDetailDispIndex = 0;

    // 現在表示中の添付証憑ページ数
    private attachmentEviPageNo = 1;

    // 添付証憑一覧の総件数
    private attachmentEviTotalCount: number = 0;

    // API実行中の場合、フラグを立てておく
    private waitingApi: boolean = false;

    constructor(private attachmentEviService: AttachmentEviService, private property: EcoKaikeiProperty) {
        super(attachmentEviService, property);
    }

    // コンポーネント初期表示時のライフサイクルフック
    ngOnInit() {
        this.doInitial();
    }

    // プロパティが変更された(親画面で表示対象データが変更された)際にもデータを再表示し直す。
    ngOnChanges() {
        this.doInitial();
    }

    // 添付証憑を1件でも取得しているか？
    private get isAttachmentEvi(): boolean {
        if (this.attachmentEviList === undefined || this.attachmentEviList === null) return false;
        return this.attachmentEviList.length > 0 ? true : false;
    }

    // [次へ]ボタンが利用可能か？
    private get isNextData(): boolean {
        if (this.waitingApi) return false;
        if (!this.isAttachmentEvi) return false;
        return (this.attachmentEviList[this.attachmentEviList.length-1]["rowNumber"] < this.attachmentEviTotalCount) ? true : false;
    }

    // [前へ]ボタンが利用可能か？
    private get isPrevData(): boolean {
        if (this.waitingApi) return false;
        return (this.attachmentEviPageNo > 1) ? true : false;
    }

    // 拡大画像表示中か？
    private get isExpansionImage(): boolean {
        return (this.expansionVoucherId === undefined || this.expansionVoucherId === null) ? false: true;
    }

    // 拡大表示中の証憑名称を取得
    private get expansionVoucherSortingName(): boolean {
        if (this.voucherData !== undefined && this.voucherData !== null) {
            return this.voucherData["voucherSortingName"];
        }
        return null;
    }

    // 拡大表示している証憑詳細が複数存在するか？
    private get isExpansionMultiPage(): boolean {
        if (this.voucherDetailList !== undefined && this.voucherDetailList !== null && this.voucherDetailList.length > 0) {
            return true;
        }
        return false;
    }

    // 日付データが数値になっている場合、日付型に変換する
    private changeNumberToData(targetDate: any): any {
        return ((typeof targetDate) === 'number') ? (new Date(targetDate)) : targetDate;
    }

    // 標準出力(単体テストで出力)
    private outputLog(logString: string): void {
        if (this.isUnitTest !== undefined && this.isUnitTest !== null && this.isUnitTest === true) {
            console.log(logString);
        }
    }

    // デバッグ用データのセット(テスト用)
    // private setDebugData() {
    //     let messageList: AC000MessageDto[] = this.property.messageDtoList;
    //     if (messageList === undefined || messageList === null) messageList = [];
    //     messageList.push({
    //         messageId: "120021",
    //         messageTitle: "削除確認",
    //         message: "(単体テスト)選択された情報を削除しますか？",
    //         buttonPattern: 2
    //     });
    //     this.property.messageDtoList = messageList;

    //     this.outputLog(`this.journalDateFrom:${this.journalDateFrom},this.journalDateTo:${this.journalDateTo}`);
    //     if (this.journalDateFrom === undefined || this.journalDateFrom === null) {
    //        this.journalDateFrom = new Date(2018, 1, 1);
    //     }
    //     if (this.journalDateTo === undefined || this.journalDateTo === null) {
    //         this.journalDateTo = new Date(2018, 12, 1);
    //     }
    // }

    private changeDateToString(target: Date): string {
        if (target === null) return null;
        const year:number = target.getFullYear();
        let month: number = target.getMonth() + 1;

        return (new String(year)).toString() + (month < 10 ? '0' + new String(month) : new String(month)).toString();
    }

    // 添付証憑一覧データを取得するためのパラメータを設定して取得する
    private getParamAttachmentEviList(): AttachmentEviReqDto {
        const reqDto: AttachmentEviReqDto = new AttachmentEviReqDto();
        reqDto.sortingSlipCls = this.sortingSlipCls;
        // reqDto.journalMonthFrom = this.journalMonthFrom;
        // reqDto.journalMonthTo = this.journalMonthTo;
        reqDto.journalMonthFrom = this.changeDateToString(this.journalDateFrom);
        reqDto.journalMonthTo = this.changeDateToString(this.journalDateTo);
        reqDto.page = this.attachmentEviPageNo;
        reqDto.dispCnt = this.attachmentEviDispcnt;
        this.outputLog(`sortingSlipCls=${reqDto.sortingSlipCls},journalMonthFrom=${reqDto.journalMonthFrom},journalMonthTo=${reqDto.journalMonthTo},page=${reqDto.page},dispCnt=${reqDto.dispCnt}`);
        return reqDto;
    }

    // 削除する添付証憑データ用のAPIパラメータを設定して取得する
    private getParamEviDeleteList(): CommonEviDeleteDto[] {
        const commonEviDeleteDtoList: CommonEviDeleteDto[] = [];
        if (this.selectedVoucherId !== undefined && this.selectedVoucherId !== null) {
            const commonEviDeleteDto: CommonEviDeleteDto = new CommonEviDeleteDto();
            const targetEviDataList: any[] = this.attachmentEviList.filter((v) => v["voucherId"] === this.selectedVoucherId);
            commonEviDeleteDto.updatedAt = this.changeNumberToData(targetEviDataList.length > 0 ? targetEviDataList[0]['updatedAt'] : null);
            commonEviDeleteDto.voucherId = this.selectedVoucherId;
            commonEviDeleteDtoList.push(commonEviDeleteDto);
        }
        return commonEviDeleteDtoList;
    }

    // 本コンポーネントの初期化処理
    private doInitial(): void {
        // 各変数の初期化
        this.attachmentEviList = null;
        this.expansionVoucherId = null;
        this.expansionImageData = null;
        this.voucherData = null;
        this.voucherDetailList = [];
        this.voucherDetailDispIndex = 0;
        this.attachmentEviPageNo = 1;
        this.attachmentEviTotalCount = 0;
        this.waitingApi = false;

        // このif文内はコンポーネントの単体テスト用ロジックです。実際には利用されません。
        // if (this.isUnitTest !== undefined && this.isUnitTest !== null && this.isUnitTest === true) {
        //     this.setDebugData();
        // }

        // 編集モード(親コンポーネントからプロパティで渡されなかった場合、強制的に編集OKモードにする))
        if (this.isEditMode === undefined || this.isEditMode === null) this.isEditMode = true;

        // 初期は拡大画像を表示しない
        this.expansionVoucherId = null;

        // 初期データの取得
        this.getInitial();
    }

    // 初期データの取得
    private getInitial(): void {
        // 表示するページ番号は1
        this.attachmentEviPageNo = 1;

        // APIパラメータの設定
        const reqDto: AttachmentEviReqDto = this.getParamAttachmentEviList();

        this.waitingApi = true;
        this.attachmentEviService.getInitial(reqDto, (resDto: AttachmentEviResDto): void => {
            this.waitingApi = false;
            // 添付証憑のデータ表示
            this.refreshAttachmentList(resDto);
        }, this.isUnitTest);
    }

    // 証憑一覧データを切り替える(次へ,前へ の処理)
    private getList(calcPageNoCount: number): void {
        // 表示するページ番号は1
        this.attachmentEviPageNo = this.attachmentEviPageNo + calcPageNoCount;

        // APIパラメータの設定
        const reqDto: AttachmentEviReqDto = this.getParamAttachmentEviList();

        this.waitingApi = true;
        this.attachmentEviService.getList(reqDto, (resDto: AttachmentEviResDto): void => {
            this.waitingApi = false;
            // 添付証憑のデータ表示
            this.refreshAttachmentList(resDto);
        }, this.isUnitTest);

    }

    // 選択した添付証憑の削除処理
    private delete(): void {
        const targetPage: number = 1;

        // APIパラメータの設定
        const reqDto: AttachmentEviReqDto = this.getParamAttachmentEviList();
        reqDto.page = targetPage;
        const commonEviDeleteDtoList: CommonEviDeleteDto[] = this.getParamEviDeleteList();
        reqDto.commonEviDeleteDtoList = commonEviDeleteDtoList;

        this.waitingApi = true;
        this.attachmentEviService.delete(reqDto, (resDto: AttachmentEviResDto): void => {
            this.waitingApi = false;
            // 表示するページ番号をクリア
            this.attachmentEviPageNo = targetPage;
            // 添付証憑のデータ表示
            this.refreshAttachmentList(resDto);
        }, this.isUnitTest);

    }

    // 選択(画像ダブルクリック)した証憑データを検索して、拡大画像を取得する
    private getDetail(): void {
        // APIパラメータの設定
        const reqDto: AttachmentEviReqDto = new AttachmentEviReqDto();
        reqDto.voucherId = this.expansionVoucherId;

        this.waitingApi = true;
        this.attachmentEviService.getDetail(reqDto, (resDto: AttachmentEviResDto): void => {
            this.waitingApi = false;
            // サーバーから取得した(選択した画像の)証憑データの表示
            this.refreshVoucher(resDto);
            // サーバーから取得した(選択した画像の)証憑詳細データの表示
            this.refreshVoucherDetail(resDto);
        }, this.isUnitTest);
    }

    // ファイル画像データを取得・表示する
    private dispFileDate(isChangeDetailOrder: boolean = false): void {
        // 画像データを一旦クリア
        this.expansionImageData = null;

        if (this.voucherDetailList !== null && this.voucherDetailList.length > 0) {
            // APIパラメータの設定
            const reqDto: AttachmentEviReqDto = new AttachmentEviReqDto()
            reqDto.fileId = this.voucherDetailList[this.voucherDetailDispIndex]["voucherImageFileId"];

            // 表示している証憑詳細のファイルIDを利用してAPIを実行し、画像ファイル(Base64文字列)を取得する。
            this.waitingApi = true;
            this.attachmentEviService.getFileData(reqDto, (resDto: AttachmentEviResDto): void => {
                this.waitingApi = false;
                this.expansionImageData = resDto.commonEviFileDataDto.fileData;
                // クリックしないと表示が反映されないっぽい。
                //this.eviPagination.refresh();
                // 添付証憑一覧の画像を入れ替え
                if (isChangeDetailOrder) {
                    this.changeImageTargetAttEvi();
                }

            }, this.isUnitTest);
        }
    }

    // 証憑画像表示順序の変更
    private voucherImageOrderChange(voucherImageOrderGrid: WjFlexGridEx): void {
        this.outputLog(`voucherImageOrderChange 1`);

        // 未処理証憑を並び変える
        const commonEviImageOrderList: CommonEviImageOrder[] = [];
        voucherImageOrderGrid.columnHeaders.columns.forEach((c: WjFlexGridColumn) => {
            const imageOrder: number = parseInt(c.name);
            const data: any = this.voucherDetailList.filter((v: any) => v["voucherImageOrder"] === imageOrder)[0];

            const commonEviImageOrder: CommonEviImageOrder = {...data};
            commonEviImageOrder.updateDate = data["updatedAt"];
            commonEviImageOrderList.push(commonEviImageOrder);
        });

        // 画像データを一旦クリア
        this.expansionImageData = null;

        this.outputLog(`voucherImageOrderChange 2`);
        // APIパラメータの設定
        const reqDto: AttachmentEviReqDto = new AttachmentEviReqDto();
        reqDto.voucherId = this.expansionVoucherId;
        reqDto.updateDate = this.voucherData["updatedAt"];
        reqDto.commonEviImageOrderList = commonEviImageOrderList;

        this.outputLog(`reqDto.voucherId=${reqDto.voucherId},reqDto.updateDate=${reqDto.updateDate},reqDto.commonEviImageOrderList=${reqDto.commonEviImageOrderList.length}`);
        reqDto.commonEviImageOrderList.forEach((v) => this.outputLog(JSON.stringify(v)));


        this.waitingApi = true;
        this.attachmentEviService.voucherImageOrderChange(reqDto, (resDto: AttachmentEviResDto): void => {
            this.waitingApi = false;
            // 取得した未証憑データの詳細一覧
            this.refreshVoucherDetail(resDto, true);
        }, this.isUnitTest);
    }

    // サーバーから取得した添付証憑一覧のデータ表示
    private refreshAttachmentList(resDto: AttachmentEviResDto): void {
        const attachmentEviDtoList: AttachmentEviDto[] = (resDto.attachmentEviDtoList === null ? [] : resDto.attachmentEviDtoList);
        this.attachmentEviList = attachmentEviDtoList;

        // 選択した証憑IDをクリア
        this.selectedVoucherId = null;
        // 拡大中の証憑IDをクリア
        this.expansionVoucherId = null;

        // 添付証憑の総件数を設定
        if (this.attachmentEviList !== undefined && this.attachmentEviList !== null && this.attachmentEviList.length > 0) {
            this.attachmentEviTotalCount = this.attachmentEviList[0]['totalCount'];
        } else {
            this.attachmentEviTotalCount = 0;
        }
    }

    // サーバーから取得した(選択した画像の)証憑データの表示
    private refreshVoucher(resDto: AttachmentEviResDto): void {
        this.voucherData = resDto.commonEviDtoList;
        this.voucherData["updatedAt"] = this.changeNumberToData(this.voucherData["updatedAt"]);
    }

    // サーバーから取得した(選択した画像の)証憑詳細データの表示
    private refreshVoucherDetail(resDto: AttachmentEviResDto, isChangeDetailOrder: boolean = false): void {
        // 取得した未証憑データの詳細一覧
        const commonEviDetailDtoList: CommonEviDetailDto[] = (resDto.commonEviDetailDtoList === null ? [] : resDto.commonEviDetailDtoList);
        this.voucherDetailList = commonEviDetailDtoList;
        this.voucherDetailList.forEach((v: any) => v["updatedAt"] = this.changeNumberToData(v["updatedAt"]));

        // 証憑詳細の表示件数は1件目とする
        this.voucherDetailDispIndex = 0;

        // 証憑詳細データ(1件目)の画像ファイルを取得
        this.dispFileDate(isChangeDetailOrder);
    }

    // 拡大表示している証憑の詳細1ページ目の画像データを、添付証憑一覧の対象証憑に上書きする
    // (証憑画像のページ入れ替え時)
    private changeImageTargetAttEvi() {
        // 拡大画像の1ページ目の画像データを入れ替える(拡大中に1ページ目の画像を変更している可能性がある)
        this.attachmentEviList.forEach((v) => {
            if (v['voucherId'] === this.expansionVoucherId) {
                v['fileData'] = this.expansionImageData;
            }
        });
    }

    // 現在表示中の証憑データを選択・実行
    private isSelectedVoucherId(voucherId: number): boolean {
        if (this.selectedVoucherId !== undefined && this.selectedVoucherId !== null && this.selectedVoucherId === voucherId) {
            return true;
        }
        return false;
    }

    // 添付証憑の選択
    private selectVoucherData(voucherId: number): void {
        this.selectedVoucherId = (this.selectedVoucherId === voucherId ? null : voucherId);
        this.selectedVoucherIdChange.emit(this.selectedVoucherId);
    }

    // 拡大画像表示(画像をダブルクリック)
    private objectClick(voucherId: number) {
        this.expansionVoucherId = voucherId;
        this.getDetail();
    }

    // [次へ]クリック
    private nextBtnClick(): void {
        this.getList(1);
    }

    // [前へ]クリック
    private beforeBtnClick(): void {
        this.getList(-1);
    }

    // 「表示変更」ボタンクリック
    private dispChangeBtnClick(): void {
        this.outputLog(`[Now Pending]UnprocessedEvi dispChangeBtnClick`);
    }

    // 「バインダ保存」ボタンクリック
    private binderSaveBtnClick(): void {
        this.outputLog(`[Now Pending]UnprocessedEvi binderSaveBtnClick`);
    }

    // 「削除」ボタンクリック
    private deleteBtnClick(): void {
        this.eAlert.message('120021', [], null, () => {
            this.delete();
        });
    }

    // ページを選択(拡大画像表示中)
    private selectPage(index: number): void {
        this.voucherDetailDispIndex = index;
        // 証憑詳細データの画像ファイルを取得
        this.dispFileDate();
    }

    // 「戻る」ボタンクリック(拡大画像表示中)
    private backBtnClick(): void {
        this.waitingApi = false;
        // 拡大画像の関連情報は不要になるためクリア
        this.expansionVoucherId = null;
        this.expansionImageData = null;
        this.voucherData = null;
        this.voucherDetailList = [];
        this.voucherDetailDispIndex = 0;
    }
}

@NgModule({
    exports: [AttachmentEviComponent],
    declarations: [AttachmentEviComponent],
    imports: [
        BrowserModule,
        CommonModule,
        FormsModule,
        HttpClientModule,
        EAlertModule,
        ViewBaseButtonModule,
        ViewBaseModule,
        EviHeaderModule,
        EviImageModule,
        EviPaginationModule
    ],
    providers: [
        EcoKaikeiProperty,
        AttachmentEviService,
        IndexService,
        LogoutService,
    ]
})
export class AttachmentEviModule {
}
