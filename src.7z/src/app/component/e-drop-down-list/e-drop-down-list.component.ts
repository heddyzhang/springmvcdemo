import { Component, Input, Output, EventEmitter, NgModule, ViewEncapsulation } from "@angular/core";
import { EventArgs, CancelEventArgs } from "wijmo/wijmo";
import { WjComboBox, wjComboBoxMeta } from "wijmo/wijmo.angular2.input";
import { getRequiredStyle, TextAlign } from "../../util/css.util";

/**
 * @classdesc ドロップダウンリストコンポーネント
 */
@Component({
    selector: 'e-drop-down-list',
    template: wjComboBoxMeta.template,
    inputs: wjComboBoxMeta.inputs,
    outputs: wjComboBoxMeta.outputs,
    styleUrls: ["./e-drop-down-list.css"],
    encapsulation: ViewEncapsulation.None,
})
export class EDropDownListComponent extends WjComboBox {
    private _required = false; // 必須フラグ
    private _textAlign: TextAlign = 'left'; // 文字寄せ方向
    private _maxLength: number = 0; // 最大入力可能桁数(バイト換算)

    // イベント処理を親コンポーネントで実行するための宣言
    @Output() eDropDownSelectChange = new EventEmitter();

    // 必須フラグ
    @Input() set required(val: boolean) {
        this._required = val;
        this.inputElement.style.borderLeft = getRequiredStyle(this._required);
    }

    // 文字寄せ方向
    @Input() set textAlign(val: TextAlign) {
        this._textAlign = val;
        this.inputElement.style.textAlign = this._textAlign;
    }

    // 最大文字数
    @Input() set maxLength(val: number) {
        this.inputElement.maxLength = val;
    }

    // リストに表示する内容を取得
    // ラベル列名
    @Input() set labelField(val: string) {
        // this._labelField = val;
        this.displayMemberPath = val;
    }
    // バリュー値列名
    private _valueField: string = 'value';
    @Input() set valueField(val: string) {
        this._valueField = val;
    }
    @Input() set dataprovider(val: any[]) {
        // selectedValueを初期化しないようにする
        var _selectedValue = this.selectedValue;
        // 配列セット
        this.itemsSource = (val) ?  val : [];
        // selectedValueを元に戻す
        this.selectedValue = _selectedValue;
    }

    @Input() set dataproviderText(val: any[]) {
        // textを初期化しないようにする
        var _text = this.text;
        // 配列セット
        this.itemsSource = (val) ?  val : [];
        // textを元に戻す
        this.text = _text;
    }

    // リストの選択値
    // @Input() defaultIndex: number; // デフォルト選択のインデックス
    // デフォルト選択のインデックス
    @Input() set defaultIndex(val: number) {
        this.selectedIndex = val;
    }
    // @Input() defaultValue: any; // デフォルト選択バリュー値
    // デフォルト選択バリュー値
    @Input() set defaultValue(val: any) {
        this.selectedValue = this.defaultValue;
    }
    get defaultValue(): any {
        return this.selectedValue;
    }

    // ドロップダウンボタン表示／非表示切替
    @Input() set isShowDropDownButton(val: boolean) {
        // ボタンを表示するかどうか
        this.showDropDownButton = val;
        // クリック時とフォーカス時にドロップダウンを出すかどうか
        this.inputElement.addEventListener('click', function(e) {
            this.isDroppedDown = !val;
        }.bind(this));
        this.inputElement.addEventListener('focus', function(e) {
            this.isDroppedDown = !val;
        }.bind(this));
    };

    /**
     * インデックス変更後
     * onSelectedIndexChanged
     */
    onSelectedIndexChanged(e?: EventArgs): void {
        // WijmoのonIsDroppedDownChangedをoverrideしているので、親のメソッドを自分で呼ぶ必要がある
        super.onSelectedIndexChanged(e);

        // 初期の場合以外イベントを実行できるようにする
        if (typeof this.selectedValue != 'object') {
            // ユーザー操作のみイベントを発火する
            if (this.containsFocus()) {
                this.eDropDownSelectChange.emit();
            }
        } else {
            // フィールド情報セット
            this.selectedValuePath = this._valueField;
        }
    }
}

@NgModule({
    exports: [EDropDownListComponent],
    declarations: [EDropDownListComponent]
})
export class EDropDownListModule { }
