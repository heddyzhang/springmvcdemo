import { Component, NgModule, Input, Output, ViewChild, EventEmitter, ViewEncapsulation, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { toggleClass, EventArgs } from "wijmo/wijmo";
import { WjTabPanel, WjNavModule } from "wijmo/wijmo.angular2.nav";

/**
 * @classdesc タブ表示コンポーネント
 */
@Component({
    selector: 'e-tab-bar',
    templateUrl: './e-tab-bar.component.html',
    styleUrls: ["./e-tab-bar.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class ETabBarComponent implements OnInit {
    // WjTabPanelオブジェクトを取得する
    @ViewChild(WjTabPanel)
    public tabBar: WjTabPanel;

    // バインドするタブの配列を取得する
    @Input() labelField = 'label'; // ラベル列名
    @Input() dataprovider: any[];

    // CSSを指定するためのコードを取得する
    @Input() colorType = 'default'; // ラベル列名

    // イベント処理を親コンポーネントで実行するための宣言
    @Output() eOnTabClick = new EventEmitter();

    /**
     * 選択中のアイテムを取得する
     */
    public get selectedItem():any {

        // 該当するアイテムがない場合はnullを返す
        if (!this.dataprovider || !this.dataprovider[this.tabBar.selectedIndex]) {
            return null;
        }

        // 選択中のアイテムを返す
        return this.dataprovider[this.tabBar.selectedIndex];
    }

    /**
     * 初期表示時の処理
     */
    ngOnInit(): void {
        // cssクラスをセットする
        toggleClass(this.tabBar.hostElement, 'e-tab-bar-' + this.colorType, true);
    }

    /**
     * タブクリック時の処理
     */
    private onTabClick(index: number): void {
        // タブの選択を変更する
        this.tabBar.selectedIndex = index;
        // 親コンポーネントのメソッドを呼ぶ
        this.eOnTabClick.emit();
    }
}

@NgModule({
    declarations: [ETabBarComponent],
    exports: [ETabBarComponent],
    imports: [CommonModule, FormsModule, WjNavModule],
})
export class ETabBarModule {
}
