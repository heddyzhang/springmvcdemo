import { Component, Input, Output, EventEmitter, NgModule } from "@angular/core";
import { Inject, Injector, ElementRef as elementRef, SkipSelf, Optional} from '@angular/core';
import { WjInputNumber, wjInputNumberMeta } from "wijmo/wijmo.angular2.input";
import { EventArgs } from "wijmo/wijmo";
import { getInputDefaultStyle, applyStyle, getRequiredStyle, removeDefaultWijmoInputStyle, TextAlign } from "../../util/css.util";
import { change1ByteNumOnly } from "../../util/string.util";

interface ElementRef {
    nativeElement: HTMLElement;
}

/**
 * @classdesc 数値入力コンポーネント
 */
@Component({
    selector: 'e-number-input',
    template: wjInputNumberMeta.template,
    inputs: wjInputNumberMeta.inputs,
    outputs: wjInputNumberMeta.outputs,
})
export class ENumberInputComponent extends WjInputNumber {
    private _isEOnValueChanged: boolean = true; // 初期化時に値が変更されるイベントを発生させないようにする
    private _innerClass: string = getInputDefaultStyle(); // CSSスタイル定義
    private _innerStyle: CSSStyleDeclaration; // CSSスタイル定義
    private _required = false; // 必須フラグ
    private _textAlign: TextAlign = 'right'; // 文字寄せ方向
    private _maxLength = 12; // 桁数(デフォルト12桁)
    private _decimalMaxLength = 0; // 小数の桁数(デフォルト0桁)
    private _isCommaSeparate: boolean = false; // カンマ区切り

    // イベント処理を親コンポーネントで実行するための宣言
    @Output() eOnValueChanged = new EventEmitter<EventArgs>();
    @Output() eOnLostFocus = new EventEmitter<EventArgs>();
    @Output() eOnGotFocus = new EventEmitter<EventArgs>();

    // 入力値
    @Input() set eValue(value: any) {
        // 値変更フラグをfalseにする
        this._isEOnValueChanged = false;
        // 値を変更する
        this.editValue(value);
    }
    get eValue(): any {
        return this.value;
    }
    // バインド設定
    @Output() eValueChange = new EventEmitter<number>();

    // CSSクラス定義
    @Input() set innerClass(value: string) {
        this._innerClass = getInputDefaultStyle() + ((value) ? " " + value: "");
        this.inputElement.className = this._innerClass;
    }

    // CSSスタイル定義
    @Input() set innerStyle(value: CSSStyleDeclaration) {
        this._innerStyle = value;
        applyStyle(this.inputElement, this._innerStyle);
    }

    // 必須フラグ
    @Input() set required(val: boolean) {
        this._required = val;
        this.inputElement.style.borderLeft = getRequiredStyle(this._required);
    }

    // 文字寄せ方向
    @Input() set textAlign(val: TextAlign) {
        this._textAlign = val;
        this.inputElement.style.textAlign = this._textAlign;
    }

    // 最大入力可能桁数(バイト換算)
    @Input() set maxLength(val: number) {
        this._maxLength = val;
    }
    @Input() set decimalMaxLength(val: number) {
        this._decimalMaxLength = val;
    }

    // カンマ区切りの有無
    @Input() set isCommaSeparate(val: boolean) {
        this._isCommaSeparate = val;
    }

    /** コンストラクタ */
    constructor(
        @Inject(elementRef) elRef: ElementRef,
        @Inject(Injector) injector: Injector,
        @Inject('ENumberInputComponent') @SkipSelf() @Optional() parentCmp: any,
    ) {
        // super
        super(elRef, injector, parentCmp);
        // 必須を外す(0がデフォルトで入らないようにする)
        this.isRequired = false;
    }

    /**
     * 初期表示時の処理
     */
    ngOnInit(): void {
        // 必ず呼ぶこと
        super.ngOnInit();

        // Looperのスタイルと重複するため、Wijmoの一部デフォルトスタイルを無効化
        removeDefaultWijmoInputStyle(this.hostElement);
        // デフォルトのcssのclassをあてる
        this.inputElement.className = this._innerClass;
        // カンマ表示の有無を設定する
        this.setFormat();
        // 最大入力桁数をセットする
        this.setMaxLength();

        // スピナーを廃止する
        this.addEventListener(this.inputElement, 'wheel', function(e) {
            e.preventDefault();
        }, true);

        // inputイベントの追加
        this.addEventListener(this.inputElement, 'input', this.input.bind(this));
        // TODO: テストコードです。後で消す。
        // // onfocusイベントの追加
        // this.addEventListener(this.inputElement, 'onclick', this.onfocus.bind(this));
        // // blurイベントの追加
        // this.addEventListener(this.inputElement, 'blur', this.blur.bind(this));
    }

    /**
     * 文字が変更されたときのイベント
     * @param e イベント
     */
    onValueChanged(e?: EventArgs): void {
        // WijmoのonValueChangedをoverrideしているので、親のメソッドを自分で呼ぶ必要がある
        super.onValueChanged(e);

        // バインド元のセット内容を変更する
        // 警告(ExpressionChangedAfterItHasBeenCheckedError)が出ないよう非同期にする
        // ※画面の描画が終わる前に親コンポーネントのプロパティの変化を検知している
        setTimeout(() => {
            if(this.eValueChange) this.eValueChange.emit(this.value);
        });

        // 親コンポーネントのメソッドを呼ぶ
        if (this._isEOnValueChanged) this.eOnValueChanged.emit(e);

        // 値変更フラグをtrueにする
        this._isEOnValueChanged = true;
    }

    /**
     * 値が変更されたときのイベント
     * @param e イベント
     */
    public input(e: Event): void {
        // 値を編集する
        this.editValue(this.inputElement.value);
    }

    /**
     * フォーカスが入ったときのイベント
     * @param e イベント
     */
    public onGotFocus(e?: EventArgs): void {
        // WijmoのonGotFocusをoverrideしているので、親のメソッドを自分で呼ぶ必要がある
        super.onGotFocus(e);
        // テキストを選択状態にする
        this.inputElement.select();
        // 親コンポーネントのメソッドを呼ぶ
        this.eOnGotFocus.emit(e);
    }

    /**
     * フォーカスが外れたときのイベント
     * @param e イベント
     */
    public onLostFocus(e?: EventArgs): void {
        // WijmoのonLostFocusをoverrideしているので、親のメソッドを自分で呼ぶ必要がある
        super.onLostFocus(e);
        // 親コンポーネントのメソッドを呼ぶ
        this.eOnLostFocus.emit(e);
    }

    /**
     * 値を編集する
     */
    private editValue(val: any): void {
        var value = val;

        // 初期化なし、空文字、NULLの場合は何も表示しない
        if (!value) {
            value = (this.isRequired)? 0 : null;
        }
        // number型の場合はセットする
        else if ((typeof value) === 'number') {
            value = value;
        }
        // string型の場合は数値のみセットする
        else if ((typeof value) === 'string') {
            value = parseInt(change1ByteNumOnly(value));
        }
        else {
            value = (this.isRequired)? 0 : null;
        }
        // 文字をセットする
        this.value = value;
    }

    /**
     * フォーマットの設定
     */
    private setFormat(): void {
        this.format = (this._isCommaSeparate) ? "N" + this._decimalMaxLength: "D" + this._decimalMaxLength;
    }

    /**
     * 桁数の設定
     */
    private setMaxLength(): void {
        // 小数点を考慮した最大値設定
        this.max = Math.pow(10, this._maxLength) - 1
            + ((this._decimalMaxLength > 0) ? 1 - Math.pow(0.1, this._decimalMaxLength): 0);
        // カンマ、小数点考慮した桁数設定
        this.inputElement.maxLength =
            this._maxLength
            + ((this._isCommaSeparate) ? Math.floor(this._maxLength / 3 - 1): 0)
            + this._decimalMaxLength
            + ((this._decimalMaxLength > 0) ? 1: 0);
    }
}

@NgModule({
    exports: [ENumberInputComponent],
    declarations: [ENumberInputComponent]
})
export class ENumberInputModule {
}
