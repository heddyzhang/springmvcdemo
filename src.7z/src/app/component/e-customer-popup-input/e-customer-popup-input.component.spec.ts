import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ECustomerPopupInputComponent } from './e-customer-popup-input.component';

describe('ECustomerPopupInputComponent', () => {
  let component: ECustomerPopupInputComponent;
  let fixture: ComponentFixture<ECustomerPopupInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ECustomerPopupInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ECustomerPopupInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
