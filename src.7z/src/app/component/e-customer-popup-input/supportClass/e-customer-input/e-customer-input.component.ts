import { Component, NgModule, Input, Output, EventEmitter } from "@angular/core";
import { wjInputMaskMeta } from "wijmo/wijmo.angular2.input";
import { ETextInputComponent } from "../../../e-text-input/e-text-input.component";
import { ECustomerPopupInputComponent } from "../../e-customer-popup-input.component";
import { EPopupItem } from "../../../../dto/ePopupInput/EPopupItem";

@Component({
    selector: 'e-customer-input',
    template: wjInputMaskMeta.template,
    inputs: wjInputMaskMeta.inputs,
    outputs: wjInputMaskMeta.outputs,
})
/**
 * <e-customer-popup-input>と共に使用する
 * customerPopに<e-customer-popup-input>を指定する
 * [(customerId)]に取引先IDを設定する
 * [acDrCrCls] または [acDrCls][acCrCls]に貸借区分を設定する
 *
 * [(customerName)]は、Grid内で使用するときに設定する
 */
export class ECustomerInputComponent extends ETextInputComponent {

    @Input()
    /** ポップアップへの参照 */
    public customerPop:ECustomerPopupInputComponent;

    @Input()
    /** 貸借区分 */
    public acDrCrCls:number = -1;

    @Input()
    /** 借方 : 貸借区分 */
    public acDrCls:number = -1;

    @Input()
    /** 貸方 : 貸借区分 */
    public acCrCls:number = -1;

    @Input()
    /** 取引先名称 */
    public customerName:string;

    @Input()
    /** 取引先ID */
    public set customerId(value:number) {
        this.changeCustomerId(value, false);
    }
    /** 取引先ID */
    public changeCustomerId(value:number, isValueChanged:boolean) {
        // 値が変更されたかを検知する
        var _isEOnValueChanged:boolean = (isValueChanged && this._customerId != value)? true : false;
        // this.valueにセットする値を保持する
        var _value: any = null;

        this._customerId = value;

        // 取引先IDから取引先情報を取得する
        this._item = this.customerPop.searchCustomerItemByID(value);

        // 取引先情報が取得できた場合は、略称を表示
        if (this._item) {
            // フォーカスが当たっている => コード表示
            if (document.activeElement === this.inputElement) {
                _value = this._item.cd;
            }
            // フォーカスが当たっていない => 略称表示
            else {
                _value = this._item.label;
            }

            // 略称
            this.customerName = this._item.label;
        }
        // IDが存在しない場合は、空白
        else {
            _value = '';
            this.customerName = '';
        }

        // 値を変更する
        if (_isEOnValueChanged) {
            this.value = _value;
        } else {
            this.eValue = _value;
        }
    }

    /** 変更イベント */
    @Output()
    public customerIdChange = new EventEmitter();
    @Output()
    public customerNameChange = new EventEmitter();

    /** 取引先ID */
    private _customerId:number;

    /** 選択中のポップアップアイテム */
    private _item:EPopupItem;

    /**
     * 初期化処理
     */
    public ngOnInit():void {

        // 親クラスの初期化
        super.ngOnInit();

        // フォーカス時の処理
        this.inputElement.addEventListener('focus', this.inputElementOnShowPop.bind(this));

        // クリック時の処理
        this.inputElement.addEventListener('click', this.inputElementOnShowPop.bind(this));

        // キー入力を監視 => TAB押下時に確定するため
        this.inputElement.addEventListener('keydown', this.inputElementOnKeydown.bind(this));

        // フォーカスを抜けた場合の処理
        this.inputElement.addEventListener('blur', this.inputElementOnBlur.bind(this));

        // 入力値の変更時の処理
        this.inputElement.addEventListener('input', this.inputElementOnInput.bind(this));
    }

    /**
     * 取引先選択ポップアップの選択時の処理
     * @param value 取引先ID
     */
    public selectItemId(value:number):void {

        // IDを設定する
        this.changeCustomerId(value, true);

        // コード表示に変換する
        if (this._item) {
            this.eValue = this._item.cd;
        }
    }

    /**
     * フォーカス時の処理 / クリック時の処理
     * @param e
     */
    private inputElementOnShowPop(e):void {

        // 既に表示中の場合は処理を中断
        if (this.customerPop.wjpopup && this.customerPop.wjpopup.isVisible) {
            return;
        }

        // 選択中の場合は、コードに変換する
        if (this._item) {
            this.eValue = this._item.cd;
        }

        // 取引先選択ポップアップを表示する
        this.customerPop.show(this);
    }

    /**
     * キーボード押下時の処理
     * @param e
     */
    private inputElementOnKeydown(e):void {

        // タブ移動時の処理
        if (e.key === 'Tab') {
            // 絞り込み条件によって選択アイテムを決定する
            this.setSelectedItem();
        }
    }

    /**
     * フォーカスを抜けた場合の処理
     * @param e
     */
    private inputElementOnBlur(e):void {

        // フォーカスの移動先
        var target: any = e.relatedTarget;

        // relatedTargetがサポートされていない場合
        if (!target) {
            target = document.activeElement;
        }

        // 取引先選択ポップアップへのフォーカス移動の場合は、処理を中断する
        if (target && (target.classList.contains('customer')
            || target.classList.contains('wj-popup'))) {
            return;
        }

        // 絞り込み条件によって選択アイテムを決定する
        this.setSelectedItem();

        // 取引先選択ポップアップを閉じる
        this.customerPop.hide();
    }

    /**
     * 入力値の変更時の処理
     * @param e
     */
    private inputElementOnInput(e):void {

        // 選択を解除する
        this._item = null;

        // 絞り込みを行う
        this.customerPop.gridItemRefresh();
    }

    /**
     * 絞り込み条件によって選択アイテムを決定する
     */
    private setSelectedItem():void {

        // 1件に絞り込まれた場合は、その項目を選択値にする
        if (this.value.length > 0 && this.customerPop.items.length === 1 && !this.customerPop.items[0].item2) {
            this._item = this.customerPop.items[0].item1;
        }

        // 選択時 => ID / 未選択時 => -1 を設定する
        this.customerId = this._item ? this._item.id : -1;

        // 変更イベント
        this.customerIdChange.emit(this._customerId);
        this.customerNameChange.emit(this.customerName);
    }
}

@NgModule({
    exports: [ECustomerInputComponent],
    declarations: [ECustomerInputComponent]
})
export class ECustomerInputModule {
}
