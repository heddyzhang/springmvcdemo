import { Component, OnInit, ViewChild, NgModule, Input, EventEmitter, Output } from '@angular/core';
import { WjPopup, WjInputModule } from 'wijmo/wijmo.angular2.input';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ECustomerInputComponent } from './supportClass/e-customer-input/e-customer-input.component';
import { WjGridModule } from 'wijmo/wijmo.angular2.grid';
import { EPopupItem } from '../../dto/ePopupInput/EPopupItem';
import { WjFlexGridModuleEx } from '../wj-flex-grid-ex/wj-flex-grid-ex';

@Component({
  selector: 'e-customer-popup-input',
  templateUrl: './e-customer-popup-input.component.html',
  styleUrls: ['./e-customer-popup-input.component.css']
})
/**
 * <e-customer-input>と共に使用する
 * 他のポップアップと表示位置を共有する場合は、x y とバインドする。
 * その他のパラメータを各自で設定することを想定していない。
 */
export class ECustomerPopupInputComponent implements OnInit {

    @Input()
    /** ポップアップ位置 X軸 */
    public set x(value:string) {

        this._x = value;

        // 変更イベント
        this.xChange.emit(this._x);
    }

    @Input()
    /** ポップアップ位置 Y軸 */
    public set y(value:string) {

        this._y = value;

        // 変更イベント
        this.yChange.emit(this._y);
    }

    @Input()
    /** タブの初期値 */
    public selectTab:number = -1;

    /** 変更イベント */
    @Output()
    public xChange = new EventEmitter();
    @Output()
    public yChange = new EventEmitter();

    @ViewChild(WjPopup)
    /** ポップアップの参照 */
    public wjpopup:WjPopup;

    /** 取引先区分 */
    public customerCls:number = -1;

    /** 取引先内容 */
    public items:ECustomerPopupInputItem[];

    /** 入力中の取引先入力欄への参照 */
    public customerInput:ECustomerInputComponent;

    /** ポップアップ位置 X軸 */
    private _x:string;

    /** ポップアップ位置 Y軸 */
    private _y:string;

    /** コンストラクタ */
    constructor(private property: EcoKaikeiProperty) {}

    /**
     * 初期化処理
     */
    public ngOnInit():void {

        // ポップアップの表示/非表示切り替えのアニメーションを削除
        this.wjpopup.fadeIn = false;
        this.wjpopup.fadeOut = false;

        // フォーカスが当たった際に、抜ける
        this.wjpopup.addEventListener(this.wjpopup.hostElement, 'focus', (e) => {this.customerInput.inputElement.focus();}, true);

        // フォーカスを受け付けなくする
        this.wjpopup.addEventListener(this.wjpopup.hostElement, 'mousedown', (e) => {e.preventDefault();}, true);
    }

    /**
     * 取引先選択条件ポップアップを表示する
     * @param target 入力中の取引先入力欄
     */
    public show(target:ECustomerInputComponent):void {

        // 入力対象への参照を保持
        this.customerInput = target;

        // 取引先区分を変更
        this.customerCls = this.selectTab;

        // アイテムを作成
        this.gridItemRefresh();

        // 画面を表示する
        this.wjpopup.show();

        // ポップアップ位置が指定されている場合は、位置を変更する
        if (this._x && this._y) {
            this.wjpopup.hostElement.style.left = this._x;
            this.wjpopup.hostElement.style.top = this._y;
        }
    }

    /**
     * 取引先選択条件ポップアップを閉じる
     */
    public hide():void {

        // ポップアップの位置を保持する
        this.x = this.wjpopup.hostElement.style.left;
        this.y = this.wjpopup.hostElement.style.top;

        // ポップアップを閉じる
        this.wjpopup.hide();
    }

    /**
     * 取引先ボタンの押下処理
     * @param item 押下したボタン情報
     */
    public selectItem(item:EPopupItem):void{

        // 選択した取引先情報を設定する
        this.customerInput.changeCustomerId(item.id, true);

        // 画面を閉じる
        this.hide();
    }

    /**
     * 取引先IDから選択情報を取得する
     * @param id 取引先ID
     */
    public searchCustomerItemByID(id:number):EPopupItem {

        // 取引先情報を取得
        return this.property.customerPopupItemList.find(function(item) {
            return item.id === id;
        });
    }

    /**
     * タブの変更イベント
     * @param val
     */
    public tabSelectChange(val: number): void {

        // 取引先区分を保存
        this.customerCls = val;

        // 一覧情報を再表示
        this.gridItemRefresh();
    }

    /**
     * 取引先情報一覧を作成する
     */
    public gridItemRefresh():void {

        // 一覧情報
        var customerItems:ECustomerPopupInputItem[] = new Array();

        // 取引先１件の情報
        var customerItem:ECustomerPopupInputItem = new ECustomerPopupInputItem();

        // 取引先1件毎に、表示条件を確認し、リストに詰め込む
        this.property.customerPopupItemList.forEach(element => {

            // 表示を行うものを抜き出す
            if (this.filterFunction(element)) {
                // item1 / item2 / item3 の設定していない項目に設定
                if (!customerItem.item1) {
                    customerItem.item1 = element;
                } else if (!customerItem.item2) {
                    customerItem.item2 = element;
                } else if (!customerItem.item3) {
                    customerItem.item3 = element;
                }
                // item1 / item2 / item3 全てが設定済みの場合は、次の行に遷移
                else {
                    customerItems.push(customerItem);
                    customerItem = new ECustomerPopupInputItem();
                    customerItem.item1 = element;
                }
            }
        });

        // 1件目が設定済の場合に設定
        if (customerItem.item1) {
            customerItems.push(customerItem);
        }

        // 一覧を設定
        this.items = customerItems;
    }

    /**
     * 取引先情報のフィルター
     * @param item
     */
    private filterFunction(item: EPopupItem): boolean {

        // 入力欄の参照取得エラー
        if (!this.customerInput) {
            return false;
        }

        // 貸借区分によるフィルター −１：未設定　１：得意先　２：仕入先　３：両方　４：社員
        // 2：借方ＢＳ科目 => ２：仕入先 不要
        // 3：貸方ＢＳ科目 => １：得意先 不要
        if ((this.customerInput.acDrCrCls === 2 && item.tabCls === 2)
            || (this.customerInput.acDrCrCls === 3 && item.tabCls === 1)) {
                return false;
        }

        // 借方 貸借区分によるフィルター −１：未設定　１：得意先　２：仕入先　３：両方　４：社員
        // 2：借方ＢＳ科目 => ２：仕入先 不要
        // 3：貸方ＢＳ科目 => １：得意先 不要
        if ((this.customerInput.acDrCls === 2 && item.tabCls === 2)
            || (this.customerInput.acDrCls === 3 && item.tabCls === 1)) {
                return false;
        }

        // 貸方 貸借区分によるフィルター −１：未設定　１：得意先　２：仕入先　３：両方　４：社員
        // 2：借方ＢＳ科目 => ２：仕入先 不要
        // 3：貸方ＢＳ科目 => １：得意先 不要
        if ((this.customerInput.acCrCls === 2 && item.tabCls === 2)
            || (this.customerInput.acCrCls === 3 && item.tabCls === 1)) {
                return false;
        }

        // 取引先区分によるフィルター
        if (this.customerCls !== -1 && this.customerCls !== item.tabCls) {
            return false;
        }

        // 絞り込み解除
        if (this.customerInput.value === '') {
            return true;
        }

        // 絞り込み
        if (item.cd && item.cd.search(this.customerInput.value) === 0) {
            return true;
        }

        // 絞り込み
        if (item.searchKey && item.searchKey.search(this.customerInput.value) === 0) {
            return true;
        }

        return false;
    }
}

@NgModule({
    exports: [ECustomerPopupInputComponent],
    declarations: [ECustomerPopupInputComponent],
    imports: [CommonModule, FormsModule, WjInputModule, WjFlexGridModuleEx, WjGridModule],
})
export class ECustomerPopupInputModule {}

/**
 * 取引先選択に表示する内容
 */
export class ECustomerPopupInputItem {

    /** １列目の取引先内容 */
    public item1:EPopupItem;

    /** ２列目の取引先内容 */
    public item2:EPopupItem;

    /** ３列目の取引先内容 */
    public item3:EPopupItem;
}
