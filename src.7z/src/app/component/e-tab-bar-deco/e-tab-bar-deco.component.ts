import { Component, NgModule, ViewEncapsulation } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { WjNavModule } from "wijmo/wijmo.angular2.nav";
import { ETabBarComponent, ETabBarModule } from "../e-tab-bar/e-tab-bar.component";

/**
 * @classdesc 装飾ありタブ表示コンポーネント
 * ※下記の実装はCSSファイルを差し替えるのみ。
 */
@Component({
    selector: 'e-tab-bar-deco',
    templateUrl: '../e-tab-bar/e-tab-bar.component.html',
    styleUrls: ["./e-tab-bar-deco.component.css"],
    encapsulation: ViewEncapsulation.None,
})
export class ETabBarDecoComponent extends ETabBarComponent {
}

@NgModule({
    declarations: [ETabBarDecoComponent],
    exports: [ETabBarDecoComponent],
    imports: [CommonModule, FormsModule, WjNavModule],
})
export class ETabBarDecoModule {
}
