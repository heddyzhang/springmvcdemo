export class Holidays {

    /**  */
    public date: string = null;
    /**  */
    public name: string = null;

    /**  */
    constructor (private list: {[key: string]: any}) {
        if (list == null) return;
        if (list['date']) this.date = list['date'];
        if (list['name']) this.name = list['name'];
    }
}
