import { Component, Input, Output, EventEmitter, NgModule, ViewEncapsulation } from "@angular/core";
import { EventArgs, CancelEventArgs, toggleClass } from "wijmo/wijmo";
import { WjInputDate, wjInputDateMeta } from "wijmo/wijmo.angular2.input";
import { dateFieldDefaultStyle, applyStyle, getRequiredStyle, TextAlign } from "../../util/css.util";
import { changeDateOnly } from "../../util/string.util";
import { NationalHolidayDto } from "../../dto/NationalHolidayDto";

/**
 * @classdesc 日付入力コンポーネント
 */
@Component({
    selector: 'e-date-field',
    template: wjInputDateMeta.template,
    inputs: wjInputDateMeta.inputs,
    outputs: wjInputDateMeta.outputs,
    styleUrls: ["./e-date-field.css"],
    encapsulation: ViewEncapsulation.None,
})
export class EDateFieldComponent extends WjInputDate {
    private _isEOnValueChanged: boolean = false; // 初期化時に値が変更されるイベントを発生させないようにする
    private _innerClass: string = dateFieldDefaultStyle; // CSSスタイル定義
    private _innerStyle: CSSStyleDeclaration; // CSSスタイル定義
    private _required = false; // 必須フラグ
    private _textAlign: TextAlign = 'right'; // 文字寄せ方向

    // イベント処理を親コンポーネントで実行するための宣言
    @Output() eOnValueChanged = new EventEmitter<EventArgs>();
    @Output() eOnLostFocus = new EventEmitter<EventArgs>();
    @Output() eOnGotFocus = new EventEmitter<EventArgs>();

    // 入力値
    @Input() set eValue(value: any) {

        // Wijimoの必須を外す(※デフォルトで今日の日付が出てしまうため)
        this.isRequired = false;
        // 日付型に変換
        var date: Date = (value) ? changeDateOnly(value): null;
        // eValue セッターはデータバインド経由で値が変化した時とカレンダー選択で値が変化した時にコールされる
        if (!(this.value && date && this.value.getTime() === date.getTime())) {
            // データバインド経由でコールされた場合かつ値が変化した場合はeOnValueChangedイベントが発火しないようにフラグをリセットする
            this._isEOnValueChanged = false;
        }
        // セットする
        this.value = (date) ? date : null;
    }
    get eValue(): any {
        return this.value;
    }
    // バインド設定
    @Output() eValueChange = new EventEmitter<Date>();

    // 祝日を取得
    private _holidays: {[key: string]: string} = this.getHolidayList(null);
    @Input() set holidays(val: NationalHolidayDto[]) {
        this._holidays = this.getHolidayList(val);
    }

    // キーボード入力許可
    // TODO:手入力有り無しを切り替えるようにする
    @Input() isKeyInput: boolean = false;

    // CSSクラス定義
    @Input() set innerClass(value: string) {
        this._innerClass = dateFieldDefaultStyle + ((value) ? " " + value: "");
        this.inputElement.className = this._innerClass;
    }

    // CSSスタイル定義
    @Input() set innerStyle(value: CSSStyleDeclaration) {
        this._innerStyle = value;
        applyStyle(this.inputElement, this._innerStyle);
    }

    // 必須フラグ
    @Input() set required(val: boolean) {
        this._required = val;
        this.inputElement.style.borderRight = getRequiredStyle(this._required);
    }

    // 文字寄せ方向
    @Input() set textAlign(val: TextAlign) {
        this._textAlign = val;
        this.inputElement.style.textAlign = this._textAlign;
    }

    // ドロップダウンボタン表示／非表示切替
    private _isShowDropDownButton: boolean = true;
    @Input() set isShowDropDownButton(val: boolean) {
        this._isShowDropDownButton = val;
        // ボタンを表示するかどうか
        this.showDropDownButton = this._isShowDropDownButton;
        // クリック時にドロップダウンを出すかどうか
        this.inputElement.addEventListener('click', function(e) {
            this.isDroppedDown = !this._isShowDropDownButton;
        }.bind(this));
    };

    /**
     * 初期化処理
     */
    ngOnInit() {
        // 必ず呼ぶこと
        super.ngOnInit();

        // Wijimoの必須を外す(※デフォルトで今日の日付が出てしまうため)
        this.isRequired = false;
        // 幅のスタイルをデフォルトで設定する
        if (!this.inputElement.style['width']) this.inputElement.style['width'] = "100px";

        // 値変更フラグをtrueにする
        this._isEOnValueChanged = true;
    }

    /**
     * onIsDroppedDownChanging
     */
    public onIsDroppedDownChanging(e?: CancelEventArgs): boolean {
        // WijmoのonIsDroppedDownChangingをoverrideしているので、親のメソッドを自分で呼ぶ必要がある
        super.onIsDroppedDownChanging(e);

        // 土日祝日をセットする
        vHolidays = this._holidays;
        this.itemFormatter = function(date: Date, element: HTMLElement) {
            // 祝日判定
            var holiday = getHoliday(date);
            toggleClass(element, 'calendar-holiday', holiday? true: false);
            element.title = holiday ? holiday : '';

            // 土日の色を変更する
            var weekday = date.getDay();
            toggleClass(element, 'calendar-sunday', weekday === 0);
            toggleClass(element, 'calendar-saturday', weekday === 6);
        }

        return true;
    }

    /**
     * 値が変更されたときのイベント
     * @param e イベント
     */
    public onValueChanged(e?: EventArgs): void {
        // WijmoのonValueChangedをoverrideしているので、親のメソッドを自分で呼ぶ必要がある
        super.onValueChanged(e);
        // バインド元のセット内容を変更する
        if (this.eValueChange) this.eValueChange.emit(this.value);
        // 親コンポーネントのメソッドを呼ぶ
        if (this._isEOnValueChanged) this.eOnValueChanged.emit(e);
        else this._isEOnValueChanged = true;
    }

    /**
     * フォーカスが入ったときのイベント
     * @param e イベント
     */
    public onGotFocus(e?: EventArgs): void {
        // WijmoのonGotFocusをoverrideしているので、親のメソッドを自分で呼ぶ必要がある
        super.onGotFocus(e);
        // テキストを選択状態にする
        this.inputElement.select();
        // ボタン非表示のときにフォーカス時にドロップダウンを出すかどうか
        if(!this.showDropDownButton) this.isDroppedDown = !this._isShowDropDownButton;
        // 親コンポーネントのメソッドを呼ぶ
        this.eOnGotFocus.emit(e);
    }

    /**
     * フォーカスが外れたときのイベント
     * @param e イベント
     */
    public onLostFocus(e?: EventArgs): void {
        // WijmoのonLostFocusをoverrideしているので、親のメソッドを自分で呼ぶ必要がある
        super.onLostFocus(e);
        // 親コンポーネントのメソッドを呼ぶ
        this.eOnLostFocus.emit(e);
    }

    /**
     * 祝日リストを加工する
     */
    getHolidayList(_holidays: NationalHolidayDto[]): {[key: string]: string} {
        const items: {[key: string]: string} = {};
        if (!_holidays) return items;
        for (let i = 0; i < _holidays.length; i++) {
            var date: Date = new Date(_holidays[i].holiday);
            var day = date.getDate(),
                month = date.getMonth() + 1,
                year = date.getFullYear();
            items[year + '/' + month + '/' + day] = (_holidays[i].holidayName) ? _holidays[i].holidayName.toString(): '';
        }
        return items;
    }
}

/**
 * 祝日を判別する
 */
var vHolidays: {[key: string]: string} = {};
function getHoliday(date: Date): string {
    // 年月日で判定
    var day = date.getDate(),
        month = date.getMonth() + 1,
        year = date.getFullYear(),
        holiday = vHolidays[year + '/' + month + '/' + day];
    if (holiday) return holiday;
    // 月日で判定
    holiday = vHolidays[month + '/' + day];
    if (holiday) return holiday;
    // 月週で判定
    var weekDay = date.getDay(),
        weekNum = Math.floor((day - 1) / 7) + 1;
        holiday = vHolidays[month + '/' + weekNum + '/' + weekDay];

    return holiday;
}

@NgModule({
    exports: [EDateFieldComponent],
    declarations: [EDateFieldComponent]
})
export class EDateFieldModule {
}
