import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchBankInputComponent } from './search-bank-input.component';

describe('SearchBankInputComponent', () => {
  let component: SearchBankInputComponent;
  let fixture: ComponentFixture<SearchBankInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchBankInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchBankInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
