import { Component, ViewEncapsulation, OnInit, Input, Output, EventEmitter, ViewChild, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { WjPopup, WjInputModule } from "wijmo/wijmo.angular2.input";
import { PopupTrigger } from "wijmo/wijmo.input";
import { HeadersVisibility, SelectionMode } from "wijmo/wijmo.grid";
import { ETextInputComponent, ETextInputModule } from "../e-text-input/e-text-input.component";
import { ViewBaseButtonComponent, ViewBaseButtonModule } from "../view-base-button/view-base-button.component";
import { WjFlexGridEx, WjFlexGridModuleEx } from "../wj-flex-grid-ex/wj-flex-grid-ex";
import { getRequiredStyle } from "../../util/css.util";
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { CommonComponentService } from '../../service/CommonComponentService';
import { CommonComponentReqDto } from "../../dto/commonComponent/CommonComponentReqDto";
import { CommonComponentResDto } from "../../dto/commonComponent/CommonComponentResDto";
import { BankDto } from "../../dto/commonComponent/BankDto";
import { BankBranchDto } from "../../dto/commonComponent/BankBranchDto";

@Component({
  selector: 'search-bank-input',
  templateUrl: './search-bank-input.component.html',
  styleUrls: ['./search-bank-input.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class SearchBankInputComponent implements OnInit {
    /** */
    public bank: string = null;
    public branch: string = null;

    /** */
    public bankSearchKey: string = null;
    public branchSearchKey: string = null;

    /** Grid用配列 */
    public bankList: BankDto[] = [];
    public bankDtoList: BankDto[];
    public branchList: BankBranchDto[] = [];
    public branchDtoList: BankBranchDto[];

    // イベント処理を親コンポーネントで実行するための宣言
    @Output() eOnBankChanged = new EventEmitter<Event>();

    /** ポップアップの参照 */
    @ViewChild("bankSearchPopup")
    private bankSearchPopup: WjPopup;

    /** 金融機関入力の参照 */
    @ViewChild("bankInput")
    private bankInput: ETextInputComponent;

    /** 支店入力の参照 */
    @ViewChild("branchInput")
    private branchInput: ETextInputComponent;

    /** 支店入力の参照 */
    @ViewChild("openBankSearchPopup")
    private openBankSearchPopup: ViewBaseButtonComponent;

    /** 金融機関コード選択Grid */
    @ViewChild("bankGrid")
    private bankGrid: WjFlexGridEx;

    /** 支店コード選択Grid */
    @ViewChild("branchGrid")
    private branchGrid: WjFlexGridEx;

    /** 決定ボタン */
    @ViewChild("commitButton")
    private commitButton: ViewBaseButtonComponent;

    /** 銀行コード */
    @Input() bankCode: string = null;

    /** 銀行名 */
    private _bankName: string = null;
    @Input() set bankName(val: string) {
        this.bank = val;
        this._bankName = val;
    };
    get bankName(): string {
        return this._bankName;
    };

    /* 支店コード */
    @Input() branchCode: string = null;

    /* 支店名 */
    private _branchName: string = null;
    @Input() set branchName(val: string) {
        this.branch = val;
        this._branchName = val;
    };
    get branchName(): string {
        return this._branchName;
    };

    /*  */
    @Output() bankCodeChange = new EventEmitter<any>();
    @Output() bankNameChange = new EventEmitter<any>();
    @Output() branchCodeChange = new EventEmitter<any>();
    @Output() branchNameChange = new EventEmitter<any>();

    // tabindex
    @Input() tabindex: Number = null;

    // 必須フラグ
    @Input() set required(val: boolean) {
        this.bankInput.inputElement.style.borderLeft = getRequiredStyle(val);
        this.branchInput.inputElement.style.borderLeft = getRequiredStyle(val);
    }

    // 必須フラグ
    @Input() set disabled(val: boolean) {
        this.bankInput.isDisabled = val;
        this.branchInput.isDisabled = val;
        this.openBankSearchPopup.disabled = val;
    }

    // constructor() { }
    constructor(
        private commonComponentService: CommonComponentService,
        private property: EcoKaikeiProperty
    ) {
    }

    /**
     * 初期表示時の処理
     */
    ngOnInit() {
        // 銀行名と支店名が取得できない場合、コードをセットする
        if(!this.bank) this.bank = this.bankCode;
        if(!this.branch) this.branch = this.branchCode;
    }

    /**
     * 銀行名を取得する
     */
    public getBankName() {
        // 前回入力された銀行コードから変更がない場合は処理を中断
        if (this.bankCode === this.bank) {
            this.bank = (this.bankName)? this.bankName: this.bankCode;
            return;
        }

        // リクエストを生成
        var reqDto: CommonComponentReqDto = new CommonComponentReqDto();
        reqDto.bankCode = this.bank;
        // 銀行検索
        this.commonComponentService.getBank(
            reqDto,
            function(resDto: CommonComponentResDto) {
                // 銀行情報をセットする
                this.bankCode = (resDto.bankDto.bankCode) ? resDto.bankDto.bankCode.toString(): this.bank;
                this.bankCodeChange.emit((resDto.bankDto.bankCode) ? resDto.bankDto.bankCode.toString(): this.bank);
                this.bank = (resDto.bankDto.bankCode) ? resDto.bankDto.bankName.toString(): this.bank;
                this.bankName = (resDto.bankDto.bankCode) ? resDto.bankDto.bankName.toString(): this.bank;
                this.bankNameChange.emit(this.bankName);

                // 支店情報を削除する
                this.branchCode = null;
                this.branchCodeChange.emit(null);
                this.branch = null;
                this.branchName = null;
                this.branchNameChange.emit(null);
        }.bind(this));

        // 親コンポーネントのイベントを実行する
        this.eOnBankChanged.emit();
    }

    /**
     * 支店名を取得する
     */
    public getBranchName() {
        // 前回入力された支店コードから変更がない場合は処理を中断
        if (this.branchCode === this.branch) {
            this.branch = (this.branchName)? this.branchName: this.branchCode;
            return;
        }

        // リクエストを生成
        var reqDto: CommonComponentReqDto = new CommonComponentReqDto();
        reqDto.bankCode = this.bankCode;
        reqDto.bankBranchCode = this.branch;
        // 支店検索
        this.commonComponentService.getBankBranch(reqDto, function(resDto: CommonComponentResDto) {
            this.branchCodeChange.emit((resDto.bankBranchDto.branchCode) ? resDto.bankBranchDto.branchCode: this.branch);
            this.branch = (resDto.bankBranchDto.branchCode) ? resDto.bankBranchDto.branchName: this.branch;
            this.branchNameChange.emit(this.branch);
        }.bind(this));

        // 親コンポーネントのイベントを実行する
        this.eOnBankChanged.emit();
    }

    /**
     * 銀行検索Popupを開く
     */
    public openBankSearch() {
        // 検索フォームに金融機関コードを入れる
        this.bankSearchKey = this.bankCode;
        // 支店の検索キーを初期化する
        this.branchSearchKey = null;
        // リストを初期化する
        this.bankList = [];
        this.bankDtoList = [];
        this.branchList = [];
        this.branchDtoList = [];

        // Popupフォーカスアウト時はCloseする
        this.bankSearchPopup.hideTrigger = PopupTrigger.Blur;
        // Popupドラッグ&ドロップOK
        this.bankSearchPopup.isDraggable = true;
        // Popup表示
        this.bankSearchPopup.show();

        // 銀行全件検索
        this.commonComponentService.getBankAll(
            new CommonComponentReqDto(),
            function (resDto: CommonComponentResDto) {
                // 銀行情報をセットする
                this.bankDtoList = resDto.bankDtoList;
                // データを検索する
                this.searchBankList();
        }.bind(this));
    }

    /**
     * 銀行検索Popupを閉じる
     */
    public commit() {
        // 銀行情報が変更されたかをチェックする
        var isBankChanged = false;
        if (this.bankGrid.selectedItems.length > 0 && this.branchGrid.selectedItems.length > 0) {
            if (this.bankCode !== this.bankGrid.selectedItems[0].bankCode
                || this.branchCode !== this.branchGrid.selectedItems[0].branchCode
            ) {
                isBankChanged = true;
            }
        }

        // 選択した銀行情報と支店情報を返却する
        this.bankCodeChange.emit((isBankChanged)? this.bankGrid.selectedItems[0].bankCode: null);
        this.bank = (isBankChanged)? this.bankGrid.selectedItems[0].bankName: null;
        this.bankNameChange.emit(this.bank);
        this.branchCodeChange.emit((isBankChanged)? this.branchGrid.selectedItems[0].branchCode: null);
        this.branch = (isBankChanged)? this.branchGrid.selectedItems[0].branchName: null;
        this.branchNameChange.emit(this.branch);

        // Popupを閉じる
        this.bankSearchPopup.hide();

        // 親コンポーネントのイベントを実行する
        if (isBankChanged) this.eOnBankChanged.emit();
    }

    /**
     * 金融機関コード検索のGrid表示
     * @param grid
     */
    public bankGridInitialized(grid: WjFlexGridEx): void {
        // Gridの設定
        this.bankGrid.headersVisibility = HeadersVisibility.Column;
        this.bankGrid.selectionMode = SelectionMode.Row;
        // 一番上を選択する
        if (this.bankGrid) this.bankGrid.select(0, 0);
    }

    /**
     * 一覧の再表示を行う
     */
    public bankGridRefresh(grid: WjFlexGridEx): void {
        // 参照エラー時は処理を中断
        if (!this.bankGrid || !this.bankGrid.collectionView) {
            return;
        }
    }

    /**
     * 金融機関コード検索のGridをフィルタ
     */
    public searchBankList() {
        // Listがない場合はreturn
        if (!this.bankDtoList) return;
        
        // 金融機関コード(完全一致)と金融機関名(前方一致)で検索する
        this.bankList = this.bankDtoList.filter (
            item => (
                item.bankCode === this.bankSearchKey ||
                item.bankName.toString().indexOf(this.bankSearchKey) === 0
            )
        );
        // 一番上を選択する
        this.bankGrid.select(0, 0);
    }

    /**
     * 金融機関コード検索のGridで選択値を変更した場合
     */
    public bankGridSelectChange() {
        // リクエストを生成
        var reqDto: CommonComponentReqDto = new CommonComponentReqDto();
        reqDto.bankCode = (this.bankGrid.selectedItems[0])? this.bankGrid.selectedItems[0].bankCode : this.bankCode;
        // 支店情報リスト検索
        this.commonComponentService.getBankBranchAll(
            reqDto,
            function (resDto: CommonComponentResDto) {
                // 銀行情報をセットする
                this.branchDtoList = resDto.bankBranchDtoList;
                // 支店コード検索のGridを再検索する
                this.searchBranchList();
        }.bind(this));
    }

    /**
     * 支店コード検索のGrid表示
     * @param grid
     */
    public branchGridInitialized(grid: WjFlexGridEx): void {
        // Gridの設定
        this.branchGrid.headersVisibility = HeadersVisibility.Column;
        this.branchGrid.selectionMode = SelectionMode.Row;
        // 一番上を選択する
        this.branchGrid.select(0, 0);
        // 支店コードの参照を設定
        // this.branchGrid = grid;
    }

    /**
     * 一覧の再表示を行う
     */
    public branchGridRefresh(): void {
        // 参照エラー時は処理を中断
        if (!this.branchGrid || !this.branchGrid.collectionView) {
            return;
        }
    }

    /**
     * 支店コード検索のGridをフィルタ
     */
    public searchBranchList(searchKey?: string) {
        // 支店コード検索キーをセットする
        this.branchSearchKey = searchKey;

        // 検索キーがない場合、銀行が選択されていない場合は処理中断
        if (!this.branchSearchKey || !this.bankGrid.selectedItems[0]) {
            this.branchList = null;
        } else {
            // 正規表現で検索する
            const reg = new RegExp('^[' + this.branchSearchKey + ']*$');
            // 支店名を選択された銀行コードとフリガナで検索する
            this.branchList = this.branchDtoList.filter (
                item => (
                    item.bankCode === this.bankGrid.selectedItems[0].bankCode &&
                    item.searchKey.match(reg)
                )
            );
            // 一番上を選択する
            this.branchGrid.select(0, 0);
        }

        // 支店コードが存在する場合、決定ボタンを押下可能とする
        this.commitButton.disabled = (!this.branchList || this.branchList.length === 0);
    }
}

@NgModule({
    exports: [SearchBankInputComponent],
    declarations: [SearchBankInputComponent],
    imports: [CommonModule, FormsModule, ETextInputModule, ViewBaseButtonModule, WjInputModule, WjFlexGridModuleEx],
})
export class SearchBankInputModule {}
