import { Component, Input, Output, EventEmitter, NgModule } from "@angular/core";
import { Inject, Injector, ElementRef as elementRef, SkipSelf, Optional} from '@angular/core';
import { WjInputNumber, wjInputNumberMeta } from "wijmo/wijmo.angular2.input";
import { EventArgs } from "wijmo/wijmo";
import { change1ByteNumOnly } from "../../util/string.util";
import { getInputDefaultStyle, applyStyle, getRequiredStyle, removeDefaultWijmoInputStyle, TextAlign } from "../../util/css.util";

interface ElementRef {
    nativeElement: HTMLElement;
}

/**
 * @classdesc 通貨入力コンポーネント
 */
@Component({
    selector: 'e-money-input',
    template: wjInputNumberMeta.template,
    inputs: wjInputNumberMeta.inputs,
    outputs: wjInputNumberMeta.outputs,
})
export class EMoneyInputComponent extends WjInputNumber {
    private _isEOnValueChanged: boolean = true; // 初期化時に値が変更されるイベントを発生させないようにする
    private _innerClass: string = getInputDefaultStyle(); // CSSスタイル定義
    private _innerStyle: CSSStyleDeclaration; // CSSスタイル定義
    private _required = false; // 必須フラグ
    private _textAlign: TextAlign = 'right'; // 文字寄せ方向
    private _minus: boolean = true; // マイナス許可フラグ

    // イベント処理を親コンポーネントで実行するための宣言
    @Output() eOnValueChanged = new EventEmitter<EventArgs>();
    @Output() eOnLostFocus = new EventEmitter<EventArgs>();
    @Output() eOnGotFocus = new EventEmitter<EventArgs>();

    // 入力値
    @Input() set eValue(value: any) {
        // 値変更フラグをfalseにする
        this._isEOnValueChanged = false;
        // 値を変更する
        this.value = (value)? parseInt(change1ByteNumOnly(value.toString())): null;
    }
    get eValue(): any {
        return this.value;
    }
    // バインド設定
    @Output() eValueChange = new EventEmitter<number>();

    // CSSクラス定義
    @Input() set innerClass(value: string) {
        this._innerClass = getInputDefaultStyle() + ((value) ? " " + value: "");
        this.inputElement.className = this._innerClass;
    }

    // CSSスタイル定義
    @Input() set innerStyle(value: CSSStyleDeclaration) {
        this._innerStyle = value;
        applyStyle(this.inputElement, this._innerStyle);
    }

    // 必須フラグ
    @Input() set required(val: boolean) {
        this._required = val;
        this.inputElement.style.borderLeft = getRequiredStyle(this._required);
    }

    // 文字寄せ方向
    @Input() set textAlign(val: TextAlign) {
        this._textAlign = val;
        this.inputElement.style.textAlign = this._textAlign;
    }

    // マイナス許可フラグ
    @Input() set minus(val: boolean) {
        this._minus = val;
        this.min = this._minus ? undefined : 0;
    }

    /** コンストラクタ */
    constructor(
        @Inject(elementRef) elRef: ElementRef,
        @Inject(Injector) injector: Injector,
        @Inject('EMoneyInputComponent') @SkipSelf() @Optional() parentCmp: any,
    ) {
        // super
        super(elRef, injector, parentCmp);
        // 必須を外す(0がデフォルトで入らないようにする)
        this.isRequired = false;
    }

    /**
     * 初期化処理
     */
    ngOnInit() {
        // 必ず呼ぶこと
        super.ngOnInit();

        // Looperのスタイルと重複するため、Wijmoの一部デフォルトスタイルを無効化
        removeDefaultWijmoInputStyle(this.hostElement);

        // デフォルトのcssのclassをあてる
        this.inputElement.className = this._innerClass;

        // デフォルトの文字寄せ方向
        this.textAlign = this._textAlign;

        // スピナーを廃止する
        this.addEventListener(this.inputElement, 'wheel', function(e) {
            e.preventDefault();
        }, true);

        // inputイベントの追加
        this.addEventListener(this.inputElement, 'input', this.input.bind(this));
    }

    /**
     * 文字が変更されたときのイベント
     * @param e イベント
     */
    onValueChanged(e?: EventArgs): void {
        // WijmoのonValueChangedをoverrideしているので、親のメソッドを自分で呼ぶ必要がある
        super.onValueChanged(e);

        // マイナスを許可しない場合は符号を無くす
        if (!this._minus) {
            if (this.value < 0) {
                this.value = 0 - this.value;
            }
        }

        // バインド元のセット内容を変更する
        // 警告(ExpressionChangedAfterItHasBeenCheckedError)が出ないよう非同期にする
        // ※画面の描画が終わる前に親コンポーネントのプロパティの変化を検知している
        setTimeout(() => {
            if(this.eValueChange) this.eValueChange.emit(this.value);
        });

        // 親コンポーネントのメソッドを呼ぶ
        if (this._isEOnValueChanged) this.eOnValueChanged.emit(e);

        // 値変更フラグをtrueにする
        this._isEOnValueChanged = true;
    }

    /**
     * 値が変更されたときのイベント
     * @param e イベント
     */
    public input(e: Event): void {
        // 親コンポーネントのメソッドを呼ぶ
        this.eOnValueChanged.emit(e);
        // // 値変更フラグをtrueにする
        // this._isEOnValueChanged = true;
    }

    /**
     * フォーカスが入ったときのイベント
     * @param e イベント
     */
    public onGotFocus(e?: EventArgs): void {
        // WijmoのonGotFocusをoverrideしているので、親のメソッドを自分で呼ぶ必要がある
        super.onGotFocus(e);
        // テキストを選択状態にする
        this.inputElement.select();
        // 親コンポーネントのメソッドを呼ぶ
        this.eOnGotFocus.emit(e);
    }

    /**
     * フォーカスが外れたときのイベント
     * @param e イベント
     */
    public onLostFocus(e?: EventArgs): void {
        // WijmoのonLostFocusをoverrideしているので、親のメソッドを自分で呼ぶ必要がある
        super.onLostFocus(e);
        // 親コンポーネントのメソッドを呼ぶ
        this.eOnLostFocus.emit(e);
    }
}

@NgModule({
    exports: [EMoneyInputComponent],
    declarations: [EMoneyInputComponent]
})
export class EMoneyInputModule {
}
