import { Component, NgModule } from "@angular/core";
import { Inject, Injector, ElementRef as elementRef, SkipSelf, Optional} from '@angular/core';
import { wjInputMaskMeta } from "wijmo/wijmo.angular2.input";
import { ETextInputComponent } from "../e-text-input/e-text-input.component";

interface ElementRef {
    nativeElement: HTMLElement;
}

/**
 * @classdesc 半角英数字入力コンポーネント
 */
@Component({
    selector: 'e-alpha-num-input',
    template: wjInputMaskMeta.template,
    inputs: wjInputMaskMeta.inputs,
    outputs: wjInputMaskMeta.outputs,
})
export class EAlphaNumInputComponent extends ETextInputComponent {

    /** コンストラクタ */
    constructor(
        @Inject(elementRef) elRef: ElementRef,
        @Inject(Injector) injector: Injector,
        @Inject('ETextInputComponent') @SkipSelf() @Optional() parentCmp: any,
    ) {
        // super
        super(elRef, injector, parentCmp);
        // 半角英数字のみ許可
        this.inputMode = "2";
    }
}

@NgModule({
    exports: [EAlphaNumInputComponent],
    declarations: [EAlphaNumInputComponent]
})
export class EAlphaNumInputModule {
}
