import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AcReceivableSlipComponent } from './ac-receivable-slip.component';

describe('AcReceivableSlipComponent', () => {
  let component: AcReceivableSlipComponent;
  let fixture: ComponentFixture<AcReceivableSlipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AcReceivableSlipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AcReceivableSlipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
