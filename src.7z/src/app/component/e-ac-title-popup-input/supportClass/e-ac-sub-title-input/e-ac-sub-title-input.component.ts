import { Component, NgModule, Input, Output, EventEmitter } from "@angular/core";
import { wjInputMaskMeta } from "wijmo/wijmo.angular2.input";
import { ETextInputComponent } from "../../../e-text-input/e-text-input.component";
import { EPopupItem } from "../../../../dto/ePopupInput/EPopupItem";
import { EAcTitlePopupInputComponent } from "../../../e-ac-title-popup-input/e-ac-title-popup-input.component";

@Component({
    selector: 'e-ac-sub-title-input',
    template: wjInputMaskMeta.template,
    inputs: wjInputMaskMeta.inputs,
    outputs: wjInputMaskMeta.outputs,
})
/**
 * <e-ac-title-popup-input>と共に使用する
 * acTitlePop<e-ac-title-popup-input>を指定する
 * [acTitleId]に勘定科目IDを設定する
 * [(selectedId)]に補助科目IDを設定する
 *
 * [(selectedName)]は、Grid内で使用するときに設定する
 */
export class EAcSubTitleInputComponent extends ETextInputComponent {

    /** 選択中の科目情報 */
    public get selectedItem():EPopupItem {
        return this._item;
    }

    @Input()
    /** ポップアップへの参照 */
    public acTitlePop:EAcTitlePopupInputComponent;

    @Input()
    /** 勘定科目ID */
    public acTitleId:number;

    @Input()
    /** 勘定科目名称 */
    public selectedName:string;

    @Input()
    /** 補助科目ID */
    public set selectedId(value:number) {
        this.changeSelectedId(value, false);
    }
    /** 補助科目ID */
    public changeSelectedId(value:number, isValueChanged:boolean) {
        // 値が変更されたかを検知する
        var _isEOnValueChanged:boolean = (isValueChanged && this._selectedId != value)? true : false;
        // this.valueにセットする値を保持する
        var _value: any = null;

        this._selectedId = value;

        // 勘定科目ID・補助科目IDから補助科目情報を取得する
        this._item = this.acTitlePop.searchAcSubTitleItemByID(this.acTitleId ,value);

        // 取引先情報が取得できた場合は、略称を表示
        if (this._item) {
            // フォーカスが当たっている => コード表示
            if (document.activeElement === this.inputElement) {
                _value = this._item.cd;
            }
            // フォーカスが当たっていない => 略称表示
            else {
                _value = this._item.label;
            }

            // 略称
            this.selectedName = this._item.label;
        }
        // IDが存在しない場合は、空白
        else {
            _value = '';
            this.selectedName = '';
        }

        // 値を変更する
        if (_isEOnValueChanged) {
            this.value = _value;
        } else {
            this.eValue = _value;
        }
    }

    /** 変更イベント */
    @Output()
    public selectedIdChange = new EventEmitter();
    @Output()
    public selectedNameChange = new EventEmitter();
    @Output()
    public selectedItemChange = new EventEmitter();

    /** true => 勘定科目 / false => 補助科目 */
    public isAcTitle:boolean = false;

    /** 補助科目ID */
    private _selectedId:number;

    /** 選択中のポップアップアイテム */
    private _item:EPopupItem;

    /**
     * 初期化処理
     */
    public ngOnInit():void {

        // 親クラスの初期化
        super.ngOnInit();

        // フォーカス時の処理
        this.inputElement.addEventListener('focus', this.inputElementOnShowPop.bind(this));

        // クリック時の処理
        this.inputElement.addEventListener('click', this.inputElementOnShowPop.bind(this));

        // キー入力を監視 => TAB押下時に補助を確定するため
        this.inputElement.addEventListener('keydown', this.inputElementOnKeydown.bind(this));

        // フォーカスを抜けた場合の処理
        this.inputElement.addEventListener('blur', this.inputElementOnBlur.bind(this));

        // 入力値の変更時の処理
        this.inputElement.addEventListener('input', this.inputElementOnInput.bind(this));
    }

    /**
     * フォーカス時の処理 / クリック時の処理
     * @param e
     */
    private inputElementOnShowPop(e):void {

        // 既に表示中の場合は処理を中断
        if (this.acTitlePop.wjpopup && this.acTitlePop.wjpopup.isVisible) {
            return;
        }

        // 勘定科目未設定時は処理を中断する
        if (this.isReadOnly) {
            return;
        }

        // 選択中の場合は、コードに変換する
        if (this._item) {
            this.eValue = this._item.cd;
        }

        // 取引先選択ポップアップを表示する
        this.acTitlePop.show(this, this.acTitleId);
    }

    /**
     * キーボード押下時の処理
     * @param e
     */
    private inputElementOnKeydown(e):void {

        // タブ移動時の処理
        if (e.key === 'Tab') {
            // 絞り込み条件によって選択アイテムを決定する
            this.setSelectedItem();
        }
    }

    /**
     * フォーカスを抜けた場合の処理
     * @param e
     */
    private inputElementOnBlur(e):void {

        // フォーカスの移動先
        var target: any = e.relatedTarget;

        // relatedTargetがサポートされていない場合
        if (!target) {
            target = document.activeElement;
        }

        // 勘定科目選択ポップアップへのフォーカス移動の場合は、処理を中断する
        if (target && (target.classList.contains('ac-title-pop')
            || target.classList.contains('wj-popup'))) {
            return;
        }

        // 絞り込み条件によって選択アイテムを決定する
        this.setSelectedItem();

        // 補助科目選択ポップアップを閉じる
        this.acTitlePop.hide();
    }

    /**
     * 入力値の変更時の処理
     * @param e
     */
    private inputElementOnInput(e):void {

        // 選択を解除する
        this._item = null;

        // 変更イベント
        this.selectedItemChange.emit(this._item);

        // 絞り込みを行う
        this.acTitlePop.gridItemRefresh();
    }

    /**
     * 絞り込み条件によって選択アイテムを決定する
     */
    private setSelectedItem():void {

        // 1件に絞り込まれた場合は、その項目を選択値にする
        if (this.value.length > 0 && this.acTitlePop.items.length === 1 && !this.acTitlePop.items[0].item2) {
            this._item = this.acTitlePop.items[0].item1;
        }

        // 選択時 => ID / 未選択時 => -1 を設定する
        this.changeSelectedId(this._item ? this._item.id : -1, true);

        // 変更イベント
        this.selectedIdChange.emit(this._selectedId);
        this.selectedNameChange.emit(this.selectedName);
        this.selectedItemChange.emit(this._item);
    }
}

@NgModule({
    exports: [EAcSubTitleInputComponent],
    declarations: [EAcSubTitleInputComponent]
})
export class EAcSubTitleInputModule {
}
