import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EAcTitlePopupInputComponent } from './e-ac-title-popup-input.component';

describe('EAcTitlePopupInputComponent', () => {
  let component: EAcTitlePopupInputComponent;
  let fixture: ComponentFixture<EAcTitlePopupInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EAcTitlePopupInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EAcTitlePopupInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
