import { Component, OnInit, NgModule, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { WjInputModule, WjPopup } from 'wijmo/wijmo.angular2.input';
import { WjFlexGridModuleEx } from '../wj-flex-grid-ex/wj-flex-grid-ex';
import { WjGridModule } from 'wijmo/wijmo.angular2.grid';
import { EPopupItem } from '../../dto/ePopupInput/EPopupItem';
import { EAcTitleInputComponent } from './supportClass/e-ac-title-input/e-ac-title-input.component';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { EAcSubTitleInputComponent } from './supportClass/e-ac-sub-title-input/e-ac-sub-title-input.component';

@Component({
  selector: 'e-ac-title-popup-input',
  templateUrl: './e-ac-title-popup-input.component.html',
  styleUrls: ['./e-ac-title-popup-input.component.css']
})
/**
 * <e-ac-title-input><e-ac-sub-title-input>と共に使用する
 * 他のポップアップと表示位置を共有する場合は、x y とバインドする。
 * その他のパラメータを各自で設定することを想定していない。
 */
export class EAcTitlePopupInputComponent implements OnInit {

    @Input()
    /** ポップアップ位置 X軸 */
    public set x(value:string) {

        this._x = value;

        // 変更イベント
        this.xChange.emit(this._x);
    }

    @Input()
    /** ポップアップ位置 Y軸 */
    public set y(value:string) {

        this._y = value;

        // 変更イベント
        this.yChange.emit(this._y);
    }

    /** 変更イベント */
    @Output()
    public xChange = new EventEmitter();
    @Output()
    public yChange = new EventEmitter();

    @ViewChild(WjPopup)
    /** ポップアップの参照 */
    public wjpopup:WjPopup;

    /** true => 勘定科目 / false => 補助科目 */
    public isAcTitle:boolean = false;

    /** 表示する貸借区分 */
    public dispAcDrCrCls: number[] = [0, 1, 2, 3];

    /** 貸借区分 */
    public acDrCrCls:number = -1;

    /** 科目集計コード */
    public acSummaryCd:number = -1;

    /** 科目管理区分 -9:ALL */
    public acManagementCls:number = -9;

    /** マネーツリー口座管理区分 -1:ALL */
    public mtAccountCls:number = -1;

    /** 勘定科目説明 */
    public messageContent:string = '';

    /** 取引先内容 */
    public items:EAcTitlePopupInputItem[];

    /** ポップアップ位置 X軸 */
    private _x:string;

    /** ポップアップ位置 Y軸 */
    private _y:string;

    /** 入力中の勘定科目入力欄への参照 */
    private acTitleInput:EAcTitleInputComponent | EAcSubTitleInputComponent;

    /** 勘定科目ID */
    private acTitleId:number = -1;

    /** コンストラクタ */
    constructor(private property: EcoKaikeiProperty) {}

    /**
     * 初期化処理
     */
    public ngOnInit():void {

        // ポップアップの表示/非表示切り替えのアニメーションを削除
        this.wjpopup.fadeIn = false;
        this.wjpopup.fadeOut = false;

        // フォーカスが当たった際に、抜ける
        this.wjpopup.addEventListener(this.wjpopup.hostElement, 'focus', (e) => {this.acTitleInput.inputElement.focus();}, true);

        // フォーカスを受け付けなくする
        this.wjpopup.addEventListener(this.wjpopup.hostElement, 'mousedown', (e) => {e.preventDefault();}, true);
    }

    /**
     * 取引先選択条件ポップアップを表示する
     * @param target 入力中の取引先入力欄
     */
    public show(target:EAcTitleInputComponent | EAcSubTitleInputComponent, acTitleId:number = -1):void {

        // 勘定科目か補助科目を判定
        this.isAcTitle = target.isAcTitle;

        // 貸借区分 / 集計コード を設定
        if (this.isAcTitle) {
            this.dispAcDrCrCls = (target as EAcTitleInputComponent).dispAcDrCrCls;
            this.acDrCrCls = (target as EAcTitleInputComponent).acDrCrCls;
            this.acManagementCls = (target as EAcTitleInputComponent).acManagementCls;
            this.acSummaryCd = (target as EAcTitleInputComponent).acSummaryCd;
            this.mtAccountCls = (target as EAcTitleInputComponent).mtAccountCls;
        }

        // 補助科目の際に、勘定科目IDを渡す
        this.acTitleId = acTitleId;

        // 入力対象への参照を保持
        this.acTitleInput = target;

        // アイテムを作成
        this.gridItemRefresh();

        // 画面を表示する
        this.wjpopup.show();

        // ポップアップ位置が指定されている場合は、位置を変更する
        if (this._x && this._y) {
            this.wjpopup.hostElement.style.left = this._x;
            this.wjpopup.hostElement.style.top = this._y;
        }
    }

    /**
     * 取引先選択条件ポップアップを閉じる
     */
    public hide():void {

        // ポップアップの位置を保持する
        this.x = this.wjpopup.hostElement.style.left;
        this.y = this.wjpopup.hostElement.style.top;

        // 説明文言を初期化
        this.messageContent = '';

        // ポップアップを閉じる
        this.wjpopup.hide();
    }

    /**
     * 勘定科目ボタン上にカーソルが入った際の処理
     * @param item
     */
    public enterItem(item:EPopupItem):void{

        // 説明を表示する
        this.messageContent = item.explanation ? item.explanation.replace(/\\n/g, '\n') : '';
    }

    /**
     * 勘定科目ボタンの押下処理
     * @param item 押下したボタン情報
     */
    public selectItem(item:EPopupItem):void{

        // 選択した取引先情報を設定する
        this.acTitleInput.changeSelectedId(item.id, true);

        // 画面を閉じる
        this.hide();
    }

    /**
     * 勘定科目IDから勘定科目情報を取得する
     * @param id 勘定科目ID
     */
    public searchAcTitleItemByID(id:number):EPopupItem{

        // 勘定科目情報を取得
        return this.property.acTitlePopupItemList.find(function(item) {
            return item.id === id;
        });
    }

    /**
     * 勘定科目IDが補助科目を持っているかを返す
     * @param id 勘定科目ID
     */
    public hasAcSubTitleItem(id:number, parentView:string):boolean{

        if(parentView && parentView == "AC205"){
            // 親画面の指定がある場合
            // item.cls1 は科目集計コードを表す
            // item.cls7 は補助科目制御区分を表す
            // 勘定科目の補助科目制御区分=「２：補助科目がある」の場合のみ活性
            var titleCheck =  this.property.acTitlePopupItemList.find(function(item) {
                return item.id === id && item.cls7 === 2;
            }) !== undefined;
            var subTitleCheck =this.property.acSubTitlePopupItemList.find(function(item) {
                return item.cls1 === id;
            }) !== undefined;

            return (titleCheck && subTitleCheck);
        }else{
            // 親画面の指定がない場合
            // 補助科目情報があるかどうか
            return this.property.acSubTitlePopupItemList.find(function(item) {
                return item.cls1 === id;
            }) !== undefined;
        }
    }

    /**
     * 勘定科目ID・補助科目IDから補助科目情報を取得する
     * @param id 勘定科目ID
     * @param subId 補助科目ID
     */
    public searchAcSubTitleItemByID(id:number, subId:number):EPopupItem {

        // 補助科目情報を取得
        return this.property.acSubTitlePopupItemList.find(function(item) {
            return item.id === subId && item.cls1 === id;
        });
    }

    /**
     * タブの変更イベント
     * @param val
     */
    public tabSelectChange(val: number): void {

        // 貸借区分の変更を保存
        this.acDrCrCls = val;

        // 一覧情報を再表示
        this.gridItemRefresh();
    }

    /**
     * 勘定科目情報一覧を作成する
     */
    public gridItemRefresh():void {

        // 一覧情報
        var acTitleItems:EAcTitlePopupInputItem[] = new Array();

        // （補助）勘定科目１件の情報
        var acTitleItem:EAcTitlePopupInputItem = new EAcTitlePopupInputItem();

        // 勘定科目・補助科目の配列を取得する
        var targetList:EPopupItem[] = this.isAcTitle ? this.property.acTitlePopupItemList
                                                     : this.property.acSubTitlePopupItemList;

        // 取引先1件毎に、表示条件を確認し、リストに詰め込む
        targetList.forEach(element => {

            // 表示を行うものを抜き出す
            if (this.filterFunction(element)) {
                // item1 / item2 / item3 の設定していない項目に設定
                if (!acTitleItem.item1) {
                    acTitleItem.item1 = element;
                } else if (!acTitleItem.item2) {
                    acTitleItem.item2 = element;
                } else if (!acTitleItem.item3) {
                    acTitleItem.item3 = element;
                }
                // item1 / item2 / item3 全てが設定済みの場合は、次の行に遷移
                else {
                    acTitleItems.push(acTitleItem);
                    acTitleItem = new EAcTitlePopupInputItem();
                    acTitleItem.item1 = element;
                }
            }
        });

        // 1件目が設定済の場合に設定
        if (acTitleItem.item1) {
            acTitleItems.push(acTitleItem);
        }

        // 一覧を設定
        this.items = acTitleItems;
    }

    /**
     * 勘定・補助科目情報のフィルター
     * @param item
     */
    private filterFunction(item: EPopupItem): boolean {

        // 入力欄の参照取得エラー
        if (!this.acTitleInput) {
            return false;
        }

        // 勘定科目
        if (this.isAcTitle) {

            // 表示タブに含まれない
            if (this.dispAcDrCrCls.indexOf(item.tabCls) === -1) {
                return false;
            }
            // 貸借区分によるフィルター
            else if (this.acDrCrCls !== -1 && this.acDrCrCls !== item.tabCls) {
                return false;
            }
            // 集計コードによる絞り込み
            else if (this.acSummaryCd !== -1 && this.acSummaryCd !== item.cls1) {
                return false;
            }
            // マネーツリー口座管理区分による絞り込み
            else if (this.mtAccountCls !== -1 && this.mtAccountCls !== item.cls2) {
                return false;
            }
            // 科目管理区分による絞り込み
            else if (this.acManagementCls !== -9 && this.acManagementCls !== item.cls3) {
                return false;
            }
        }
        // 補助科目
        else {
            // 勘定科目によるフィルター
            if (item.cls1 !== this.acTitleId) {
                return false;
            }
        }

        // 絞り込み解除
        if (this.acTitleInput.value === '') {
            return true;
        }

        // 絞り込み
        if (item.cd && item.cd.search(this.acTitleInput.value) === 0) {
            return true;
        }

        // 絞り込み
        if (item.searchKey && item.searchKey.search(this.acTitleInput.value) === 0) {
            return true;
        }

        return false;
    }
}

@NgModule({
    exports: [EAcTitlePopupInputComponent],
    declarations: [EAcTitlePopupInputComponent],
    imports: [CommonModule, FormsModule, WjInputModule, WjFlexGridModuleEx, WjGridModule],
})
export class EAcTitlePopupInputModule {}

/**
 * 勘定科目選択に表示する内容
 */
export class EAcTitlePopupInputItem {

    /** １列目の勘定科目内容 */
    public item1:EPopupItem;

    /** ２列目の勘定科目内容 */
    public item2:EPopupItem;

    /** ３列目の勘定科目内容 */
    public item3:EPopupItem;
}
