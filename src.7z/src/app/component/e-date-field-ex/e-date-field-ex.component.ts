import { Component, ViewEncapsulation, Input, NgModule } from "@angular/core";
import { Inject, Injector, ElementRef as elementRef, SkipSelf, Optional} from '@angular/core';
import { wjInputDateMeta } from "wijmo/wijmo.angular2.input";
import { EDateFieldComponent } from "../e-date-field/e-date-field.component";
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { MonthItemDto } from "../../dto/MonthItemDto";

interface ElementRef {
    nativeElement: HTMLElement;
}

/**
 * @classdesc 日付入力コンポーネント
 * ※EcoKaikeiPropertyを読み込んで使用する
 */
@Component({
    selector: 'e-date-field-ex',
    template: wjInputDateMeta.template,
    inputs: wjInputDateMeta.inputs,
    outputs: wjInputDateMeta.outputs,
    styleUrls: ["../e-date-field/e-date-field.css"],
    encapsulation: ViewEncapsulation.None,
})
export class EDateFieldExComponent extends EDateFieldComponent {

    /** コンストラクタ */
    constructor(
        @Inject(elementRef) elRef: ElementRef,
        @Inject(Injector) injector: Injector,
        @Inject('EDateFieldComponent') @SkipSelf() @Optional() parentCmp: any,
        private property: EcoKaikeiProperty,
    ) {
        super(elRef, injector, parentCmp);
    }

    // 日付選択範囲を設定するかどうか
    @Input() isRangeFromTo: boolean = false;

    /**
     * 初期化処理
     */
    ngOnInit() {
        super.ngOnInit();

        // 日付選択の範囲指定を設定する
        if (this.isRangeFromTo) {
            var monthItemDtoList: MonthItemDto[] = this.property.ownershipDto.monthItemDtoList;
            if (monthItemDtoList) {
                this.min = new Date(monthItemDtoList[0].fromDate);
                this.max = new Date(monthItemDtoList[monthItemDtoList.length - 1].toDate);
            }
        }

        // 祝日を設定する
        this.holidays = this.property.nationalHolidayDtoList;
    }
}

@NgModule({
    exports: [EDateFieldExComponent],
    declarations: [EDateFieldExComponent]
})
export class EDateFieldExModule {
}
