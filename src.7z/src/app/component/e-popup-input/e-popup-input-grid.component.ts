import { Component, NgModule, Input, ViewEncapsulation } from '@angular/core';
import { WjFlexGrid, wjFlexGridMeta, WjFlexGridColumn, WjFlexGridCellTemplate } from "wijmo/wijmo.angular2.grid";
import { ETextInputComponent } from "../e-text-input/e-text-input.component";
import { PopupTrigger } from "wijmo/wijmo.input";
import { GridPanel, HeadersVisibility, CellRangeEventArgs } from "wijmo/wijmo.grid";

@Component({
    selector: 'e-popup-input-grid',
    template: wjFlexGridMeta.template,
    inputs: wjFlexGridMeta.inputs,
    outputs: wjFlexGridMeta.outputs,
})
export class EPopupInputGridComponent extends WjFlexGrid {
    [x: string]: any;

    // Popupのヘッダーに表示するテキスト
    @Input() headerText = '';

    // リストに表示する内容を取得
    @Input() dataprovider: {[key: string]: string}[] = []; // データ
    @Input() labelField = 'member'; // ラベル列名
    @Input() valueField = 'value'; // バリュー値列名

    @Input() inputVal: string; // 入力値
    @Input() returnVal: string; // 返却値

    /**
     * 初期化処理
     * created()だとCSSのスタイルがあたらないためngOnInitを使う
     */
    ngOnInit(): void {
        // 必ず呼ぶこと
        super.ngOnInit();

        // Popupに表示するリストを作成
        this.itemsSource = getPopupList(this.dataprovider, this.labelField, this.valueField);
        this.headersVisibility = HeadersVisibility.None;
        this.itemFormatter = function(panel: GridPanel, r: number, c: number, cell: HTMLDivElement) {
            // カラム情報取得
            const col: WjFlexGridColumn = panel.columns[c];
            // column名取得
            const colname: string = col.name;

            // カラムが不正の場合は何もしない
            if (!colname) {
                return;
            }

            // 列のサイズ変更
            if (r === 0) {
                if (!colname.startsWith('disp_', 0)) {
                    col.width = 0;
                } else {
                    col.width = '*';
                }
            }

            // 'disp_**'の表示をHTMLへ変更する
            if (colname.startsWith('disp_', 0)) {
                cell.innerHTML = cell.innerText;
                cell.title = cell.innerText;
            }
        };
    }

    /**
     * FlexGrid表示内容変更
     */
    onSelectionChanged(e?: CellRangeEventArgs): void {
        super.onSelectionChanged(e);

        // セル取得
        const cell: HTMLElement = this.cells.getCellElement(e.row, e.col);

        this.inputVal = cell.innerText;
    }
}

/**
 * Popupの選択候補リストを作成
 */
function getPopupList(dataprovider: any[], labelField: string, valueField: string): {[key: string]: string}[] {
    const items = [];
    const colcount = 3;
    const count = dataprovider.length;

    // データ配列を表示する列数の倍数個に揃える
    if (count % colcount != 0) {
        for (let i = 0; i < count % colcount + 1; i++) {
            dataprovider.push({[valueField]: null, [labelField]: null});
        }
    }

    // データ配列を表示する列数の配列に入れ直し
    for (let i = 0; i < Math.ceil(count / colcount); i++) {
        const num: number = i * colcount;
        const item: {[key: string]: string} = {};
        for (let ii = 0; ii < colcount; ii++) {
            if (dataprovider[num + ii][valueField] != null && dataprovider[num + ii][labelField] != null) {
                item['disp_' + ii] = '<span style="width:20%;">' + dataprovider[num + ii][valueField] + '</span>';
                item['disp_' + ii] = item['disp_' + ii] + '&nbsp;&nbsp;';
                item['disp_' + ii] = item['disp_' + ii] + '<span style="width:*;">' + dataprovider[num + ii][labelField] + '</span>';
            } else {
                item['disp_' + ii] = null;
            }
            item['name_' + ii] = dataprovider[num + ii][labelField];
            item['value_' + ii] = dataprovider[num + ii][valueField];
        }
        items.push(item);
    }

    return items;
}

@NgModule({
    exports: [EPopupInputGridComponent],
    declarations: [EPopupInputGridComponent],
})
export class EPopupInputGridModule {}