import { Component, NgModule, Input, ViewEncapsulation } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { WjPopup, wjPopupMeta } from "wijmo/wijmo.angular2.input";
import { EPopupInputGridComponent } from "./e-popup-input-grid.component";
import { ETextInputComponent } from "../e-text-input/e-text-input.component";
import { PopupTrigger } from "wijmo/wijmo.input";
import { EventArgs, CancelEventArgs } from "wijmo/wijmo";

@Component({
    selector: 'e-popup-input',
    templateUrl: './e-popup-input.component.html',
    inputs: wjPopupMeta.inputs,
    outputs: wjPopupMeta.outputs,
})
export class EPopupInputComponent extends WjPopup {
    // Popupのヘッダーに表示するテキスト
    @Input() headerText = '';

    // リストに表示する内容を取得
    @Input() dataprovider: {[key: string]: string}[] = []; // データ
    @Input() labelField = 'member'; // ラベル列名
    @Input() valueField = 'value'; // バリュー値列名

    //
    @Input() inputVal: string;
    public returnVal: string = 'aa';

    /**
     * 初期化処理
     * created()だとCSSのスタイルがあたらないためngOnInitを使う
     */
    ngOnInit(): void {
        // 必ず呼ぶこと
        super.ngOnInit();

        // Popupを閉じた後にオブジェクトが削除されないようにする
        this.removeOnHide = false;
        // Popupフォーカスアウト時もCloseしない
        this.hideTrigger = PopupTrigger.None;
        // Popupドラッグ&ドロップOK
        this.isDraggable = true;
    }

    /**
     * ダイアログ表示処理
     */
    showDialog(callCompornent: ETextInputComponent): void {
        this.show(false, function(e) {
            if (e.dialogResult == 'wj-hide-ok') {
//                alert('OKがクリックされました。');
            } else if (e.dialogResult == 'wj-hide-cancel') {
//                callCompornent.value = this.inputVal;
            } else if (e.dialogResult == 'wj-hide') {
                callCompornent.value = this.inputVal;
            }
        });

        // フォーカスは元に戻す
        callCompornent.focus();
    }

//    onShown(e?: EventArgs): void {
//        // 必ず呼ぶこと
//        super.onShown(e);
//        alert('onShown');
//    }
//
//    onShowing(e: CancelEventArgs): boolean {
//
//        alert('onShowing');
//
//        // 必ず呼ぶこと
//        return super.onShowing(e);
//    }

    change(): void {
        alert();
    }
}

@NgModule({
    exports: [EPopupInputComponent, EPopupInputGridComponent],
    declarations: [EPopupInputComponent, EPopupInputGridComponent],
    imports: [CommonModule, FormsModule]
})
export class EPopupInputModule {}