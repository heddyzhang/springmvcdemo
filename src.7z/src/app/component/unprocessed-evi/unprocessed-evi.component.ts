import { Component, NgModule, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { WjFlexGridColumn } from "wijmo/wijmo.angular2.grid";
import { ViewBaseButtonModule } from "../view-base-button/view-base-button.component";
import { WjFlexGridEx } from "../wj-flex-grid-ex/wj-flex-grid-ex";
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { UnprocessedEviService } from '../../service/UnprocessedEviService';
import { UnprocessedEviReqDto } from '../../dto/unprocessedEvi/UnprocessedEviReqDto';
import { UnprocessedEviResDto } from '../../dto/unprocessedEvi/UnprocessedEviResDto';
import { CommonEviDto } from '../../dto/commonEvi/CommonEviDto';
import { CommonEviDetailDto } from '../../dto/commonEvi/CommonEviDetailDto';
import { CommonEviImageOrder } from '../../dto/commonEvi/CommonEviImageOrder';
import { ViewBaseModule } from '../view-base/view-base.component';
import { WjInputModule } from 'wijmo/wijmo.angular2.input';
import { EAlertModule, EAlertComponent } from '../e-alert/e-alert.component';
import { ComponentBase } from '../../view/component-base';
import { HttpClientModule } from '@angular/common/http';
import { CommonComponentService } from '../../service/CommonComponentService';
import { EviHeaderModule } from '../evi-base/evi-header/evi-header.component';
import { EviImageModule } from '../evi-base/evi-image/evi-image.component';
import { EviPaginationComponent, EviPaginationModule } from '../evi-base/evi-pagination/evi-pagination.component';

@Component({
    selector: 'unprocessed-evi',
    templateUrl: './unprocessed-evi.component.html',
    styleUrls: ['./unprocessed-evi.component.css']
})
export class UnprocessedEviComponent extends ComponentBase {

    @ViewChild("eAlert")
    eAlert: EAlertComponent;

    @ViewChild("eviPagination")
    eviPagination: EviPaginationComponent;

    /** 会計処理区分 */
    @Input() sortingSlipCls: number;

    /** 仕訳日付(From) */
    @Input() journalDateFrom: Date;

    /** 仕訳日付(TO) */
    @Input() journalDateTo: Date;

    /** 編集モード(true:編集可能 false:編集不可) */
    @Input() isEditMode: boolean;

    /** 選択した未証憑ID */
    @Input() selectedVoucherId: number;
    @Output() selectedVoucherIdChange = new EventEmitter<number>();

    /** 単体テストFLG(実画面からは未指定でよい) */
    @Input() isUnitTest: boolean;

    /** todo:暫定(ac180からこのプロパティで指定しているため。正しいプロパティ名に変更された後に削除する予定) */
    @Input() journalDate: Date;

    // メイン画像表示部の背景色
    private mainBackgroundColor: string = '#626262';

    // サムネイルをクリックしたときにポップアップ画像の表示スタイル
    private popupImgDisplay: string = "none";

    private imagePageIndex: number = 0;

    // ポップアップ画像のBase64文字列
    private popupImageFileData: string = null;

    // 証憑の一覧データ
    private _voucherList: any[] = [];

    // 現在表示中の証憑データindex
    private voucherDispIndex = 0;

    // 証憑詳細の一覧データ
    private _voucherDetailList: any[] = [];

    // 現在表示中の証憑詳細データindex
    private voucherDetailDispIndex = 0;

    // API実行中の場合、フラグを立てておく
    private waitingApi: boolean = false;

    // コンストラクタ
    constructor(private unprocessedEviService: UnprocessedEviService, private property: EcoKaikeiProperty) {
        super(unprocessedEviService, property);
    }

    // 証憑データを取得
    private get voucherList(): any[] {
        return this._voucherList;
    }

    // 証憑詳細データを取得
    private get voucherDetailList(): any[] {
        return this._voucherDetailList;
    }

    // 現在表示中の証憑種類を表示
    private get voucherSortingName(): string {
        if (this._voucherList !== null && this._voucherList.length > 0 && this.voucherDispIndex <= this._voucherList.length - 1) {
            return this._voucherList[this.voucherDispIndex]["voucherSortingName"];
        }
        return null;
    }

    // 画面に表示する証憑詳細データ(ページ番号一覧を表示)
    private get dispVoucherDetailList(): any[] {
        return this._voucherDetailList;
        // const startPage: number = this.getStartDataCount();
        // return this._voucherDetailList.filter((v, i, a) => (i >= startPage && i< startPage + this.pageMaxDataCount));
    }

    // 画面に表示する証憑データ件数
    private get voucharCount(): number {
        return this._voucherList === null ? 0 : this._voucherList.length;
    }

    // 画面に表示する証憑詳細データ
    private get voucharDetailCount(): number {
        return this._voucherDetailList === null ? 0 : this._voucherDetailList.length;
    }

    // 現在表示中の証憑データに対して、証憑詳細が複数件存在するか？(複数存在する場合、複数あるように見せるため、サムネイルに白い影を付与する)
    private get isMultiPage(): boolean {
        return this.voucharDetailCount > 1 ? true : false;
    }

    // [次へ]ボタンが利用可能か？
    private get isNextData(): boolean {
        if (this.waitingApi) return false;
        return (this._voucherList.length === 0 || (this.voucherDispIndex >= this._voucherList.length - 1)) ? false : true;
    }

    // [前へ]ボタンが利用可能か？
    private get isPrevData(): boolean {
        if (this.waitingApi) return false;
        return (this._voucherList.length > 1 && this.voucherDispIndex > 0) ? true : false;
    }

    // 現在表示中の証憑データを選択・実行
    private get isSelectedVoucherId(): boolean {
        return (this.selectedVoucherId !== undefined && this.selectedVoucherId !== null) ? true : false;
    }

    // コンポーネント初期化時のライフサイクルメソッド
    ngOnInit() {
        this.doInitial();
    }

    // プロパティが変更された(親画面で表示対象データが変更された)際にもデータを再表示し直す。
    ngOnChanges() {
        this.doInitial();
    }

    // デバッグ用データのセット(テスト用)
    // private setDebugData() {
    //     let messageList: AC000MessageDto[] = this.property.messageDtoList;
    //     if (messageList === undefined || messageList === null) {
    //         messageList = [];
    //     }
    //     messageList.push({
    //         messageId: "120021",
    //         messageTitle: "削除確認",
    //         message: "(単体テスト)選択された情報を削除しますか？",
    //         buttonPattern: 2
    //     });
    //     this.property.messageDtoList = messageList;

    //     this.outputLog(`this.journalDateFrom:${this.journalDateFrom},this.journalDateTo:${this.journalDateTo}`);
    //     if (this.journalDateFrom === undefined || this.journalDateFrom === null) {
    //        this.journalDateFrom = new Date(2018, 1, 1);
    //     }
    //     if (this.journalDateTo === undefined || this.journalDateTo === null) {
    //         this.journalDateTo = new Date(2018, 12, 1);
    //     }
    // }

    // 標準出力(単体テストで出力)
    private outputLog(logString: string): void {
        if (this.isUnitTest !== undefined && this.isUnitTest !== null && this.isUnitTest === true) {
            console.log(logString);
        }
    }

    private changeDateToString(target: Date): string {
        if (target === null) return null;
        const year:number = target.getFullYear();
        let month: number = target.getMonth() + 1;

        return (new String(year)).toString() + (month < 10 ? '0' + new String(month) : new String(month)).toString();
    }

    // 本コンポーネントの初期化処理
    private doInitial(): void {
        // 各変数の初期化
        this.imagePageIndex = 0;
        this.popupImageFileData = null;
        this._voucherList = [];
        this.voucherDispIndex = 0;
        this._voucherDetailList = [];
        this.voucherDetailDispIndex = 0;
        this.waitingApi = false;

        // このif文内はコンポーネントの単体テスト用ロジックです。実際には利用されません。
        // if (this.isUnitTest !== undefined && this.isUnitTest !== null && this.isUnitTest === true) {
        //     this.setDebugData();
        // }

        // 編集モード(親コンポーネントからプロパティで渡されなかった場合、強制的に編集OKモードにする))
        if (this.isEditMode === undefined || this.isEditMode === null) this.isEditMode = true;

        // 初期データの取得
        this.getInitial();
    }

    // 初期データの取得
    private getInitial(): void {
        // APIパラメータの設定
        const reqDto: UnprocessedEviReqDto = new UnprocessedEviReqDto();
        // TODO:現状は引数を仮で固定値を与えている。
        reqDto.sortingSlipCls = this.sortingSlipCls;
        reqDto.journalMonthFrom = this.changeDateToString(this.journalDateFrom);
        reqDto.journalMonthTo = this.changeDateToString(this.journalDateTo);
        this.outputLog(`sortingSlipCls=${reqDto.sortingSlipCls},journalMonthFrom=${reqDto.journalMonthFrom},journalMonthTo=${reqDto.journalMonthTo}`);

        this.waitingApi = true;
        this.unprocessedEviService.getInitial(reqDto, (resDto: UnprocessedEviResDto): void => {
            this.waitingApi = false;
            // 未証憑のデータ一覧
            this.refreshVoucher(resDto);
            // 1件目の未証憑データの詳細一覧
            this.refreshVoucherDetail(resDto, 0);
        }, this.isUnitTest);
    }

    // 対象の未処理証憑詳細の取得
    private getDetail(voucherCount: number): void {
        const searchVoucherIndex = this.voucherDispIndex + voucherCount;
        const reqDto: UnprocessedEviReqDto = new UnprocessedEviReqDto();
        reqDto.voucherId = this._voucherList[searchVoucherIndex]["voucherId"];

        this.waitingApi = true;
        this.unprocessedEviService.getDetail(reqDto, (resDto: UnprocessedEviResDto): void => {
            this.waitingApi = false;
            // 1件目の未証憑データの詳細一覧
            this.refreshVoucherDetail(resDto, searchVoucherIndex);
            // 証憑の選択状態を解除
            this.selectVoucherData(true);
        }, this.isUnitTest);
    }

    // 証憑画像表示順序の変更
    private voucherImageOrderChange(voucherImageOrderGrid: WjFlexGridEx): void {
        // this.pageShaping();
        // 未処理証憑を並び変える
        const commonEviImageOrderList: CommonEviImageOrder[] = [];
        voucherImageOrderGrid.columnHeaders.columns.forEach((c: WjFlexGridColumn) => {
            const imageOrder: number = parseInt(c.name);
            const data: any = this._voucherDetailList.filter((v: any) => v["voucherImageOrder"] === imageOrder)[0];

            const commonEviImageOrder: CommonEviImageOrder = {...data};
            commonEviImageOrder.updateDate = data["updatedAt"];
            commonEviImageOrderList.push(commonEviImageOrder);
        });

        // 画像データを一旦クリア
        this.popupImageFileData = null;

        // APIパラメータの設定
        const reqDto: UnprocessedEviReqDto = new UnprocessedEviReqDto();
        reqDto.voucherId = this._voucherList[this.voucherDispIndex]["voucherId"];
        reqDto.updateDate = this._voucherList[this.voucherDispIndex]["updatedAt"];
        reqDto.commonEviImageOrderList = commonEviImageOrderList;

        this.waitingApi = true;
        this.unprocessedEviService.voucherImageOrderChange(reqDto, (resDto: UnprocessedEviResDto): void => {
            this.waitingApi = false;
            // 取得した未証憑データの詳細一覧
            this.refreshVoucherDetail(resDto, null);
        }, this.isUnitTest);
    }

    // 表示対象の証憑詳細画像を取得する
    private dispFileDate(): void {
        // 画像データを一旦クリア
        this.popupImageFileData = null;

        if (this._voucherDetailList !== null && this._voucherDetailList.length > 0) {
            // APIパラメータの設定
            const reqDto: UnprocessedEviReqDto = new UnprocessedEviReqDto()
            reqDto.fileId = this._voucherDetailList[this.voucherDetailDispIndex]["voucherImageFileId"];
            // 表示している証憑詳細のファイルIDを利用してAPIを実行し、画像ファイル(Base64文字列)を取得する。
            this.waitingApi = true;
            this.unprocessedEviService.getFileData(reqDto, (resDto: UnprocessedEviResDto): void => {
                this.waitingApi = false;
                this.popupImageFileData = resDto.commonEviFileDataDto.fileData;
                // クリックしないと表示が反映されないっぽい。
                //this.eviPagination.refresh();
            }, this.isUnitTest);
        }
    }

    // 対象の未証憑データを削除
    private deleteBtnClick(): void {
        this.eAlert.message('120021', [], null, () => {
            // APIパラメータの設定
            const reqDto: UnprocessedEviReqDto = new UnprocessedEviReqDto();
            reqDto.voucherId = this._voucherList[this.voucherDispIndex]["voucherId"];
            reqDto.updateDate = this._voucherList[this.voucherDispIndex]["updatedAt"];
            // TODO:現状は引数を仮で固定値を与えている。
            reqDto.sortingSlipCls = this.sortingSlipCls;
            reqDto.journalMonthFrom = this.changeDateToString(this.journalDateFrom);
            reqDto.journalMonthTo = this.changeDateToString(this.journalDateTo);

            this.waitingApi = true;
            this.unprocessedEviService.delete(reqDto, (resDto: UnprocessedEviResDto): void => {
                this.waitingApi = false;
                // 取得した未証憑データ一覧
                this.refreshVoucher(resDto);
                // 取得した未証憑データの詳細一覧
                this.refreshVoucherDetail(resDto, 0);
                // 証憑の選択状態を解除
                this.selectVoucherData(true);
            }, this.isUnitTest);
        });
    }

    // 現在表示中の証憑データを選択(checkbox)
    private selectVoucherData(isClear: boolean): void {
        this.selectedVoucherId = ((!isClear && this.selectedVoucherId === null) ? this._voucherList[this.voucherDispIndex]["voucherId"] : null);
        this.selectedVoucherIdChange.emit(this.selectedVoucherId);
    }

    // サーバーから取得した証憑一覧データの表示
    private refreshVoucher(resDto: UnprocessedEviResDto): void {
        const commonEviDtoList: CommonEviDto[] = (resDto.commonEviDtoList === null ? [] : resDto.commonEviDtoList);
        this._voucherList = commonEviDtoList;
        this._voucherList.forEach((v: any) => v["updatedAt"] = this.changeNumberToData(v["updatedAt"]));
    }

    // サーバーから取得した証憑詳細データの表示
    private refreshVoucherDetail(resDto: UnprocessedEviResDto, searchVoucherIndex:number): void {
        // 取得した未証憑データの詳細一覧
        const CommonEviDetailDtoList: CommonEviDetailDto[] = (resDto.commonEviDetailDtoList === null ? [] : resDto.commonEviDetailDtoList);
        this._voucherDetailList = CommonEviDetailDtoList;
        this._voucherDetailList.forEach((v: any) => v["updatedAt"] = this.changeNumberToData(v["updatedAt"]));

        // 表示件数をカウントアップ
        if (searchVoucherIndex !== undefined && searchVoucherIndex !== null) this.voucherDispIndex = searchVoucherIndex;
        this.voucherDetailDispIndex = 0;

        // 未証憑詳細にindexを付与
        //this.addIndexVoucherDetailList();

        // ページ領域を整形
        this.pageShaping();

        // 証憑詳細データ(1件目)の画像ファイルを取得
        this.dispFileDate();
    }

    // 日付データが数値になっている場合、日付型に変換する
    private changeNumberToData(targetDate: any): any {
        return ((typeof targetDate) === 'number') ? (new Date(targetDate)) : targetDate;
    }

    // ページ領域を整形
    private pageShaping(): void {
        // const pagingField = document.getElementById("cp200-paging-field");
        // pagingField.style.visibility = "hidden";

        // window.setTimeout(() => {
        //     const pageHeaderCells = document.querySelectorAll(".wj-colheaders .wj-row .wj-cell");
        //     for (let i:number=0; i < pageHeaderCells.length; i++) {
        //         pageHeaderCells[i].firstChild.parentElement.style.padding = "0px";
        //         pageHeaderCells[i].firstChild.parentElement.style.height = "28px";
        //     }
        //     pagingField.style.visibility = "visible";
        // }, 200);
    }

    // ページを選択
    private selectPage(index: number): void {
        this.voucherDetailDispIndex = index;
        // 証憑詳細データの画像ファイルを取得
        this.dispFileDate();
    }

    // [次へ]クリック
    private nextBtnClick(): void {
        this.getDetail(1);
    }

    // [前へ]クリック
    private beforeBtnClick(): void {
        this.getDetail(-1);
    }

    // 「表示変更」ボタンクリック
    private dispChangeBtnClick(): void {
        this.outputLog(`[Now Pending]UnprocessedEvi dispChangeBtnClick`);
    }

    // 「バインダ保存」ボタンクリック
    private binderSaveBtnClick(): void {
        this.outputLog(`[Now Pending]UnprocessedEvi binderSaveBtnClick`);
    }

}

@NgModule({
    exports: [UnprocessedEviComponent],
    declarations: [UnprocessedEviComponent],
    imports: [
        BrowserModule,
        CommonModule,
        FormsModule,
        HttpClientModule,
        ViewBaseButtonModule,
        ViewBaseModule,
        EAlertModule,
        WjInputModule,
        EviHeaderModule,
        EviImageModule,
        EviPaginationModule
    ],
    providers: [
        EcoKaikeiProperty,
        UnprocessedEviService,
        CommonComponentService
    ]
})
export class UnprocessedEviModule {
}
