import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
@Injectable()
export class SideMenuScaleEvent {

    private emitEventSource = new Subject<any>();

    eventEmitted$ = this.emitEventSource.asObservable();

    emitEvent(e: any) {
        this.emitEventSource.next(e);
    }
}
