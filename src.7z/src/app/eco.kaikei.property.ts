import { Injectable } from "@angular/core";
import { AC000MessageDto } from "./dto/ac000/AC000MessageDto";
import { OwnershipDto } from "./dto/OwnershipDto";
import { NationalHolidayDto } from "./dto/NationalHolidayDto";
import { EPopupItem } from "./dto/ePopupInput/EPopupItem";
import { ViewChangeBeanBase } from "./bean/ViewChangeBeanBase";
import { MonthItemDto } from "./dto/MonthItemDto";
import { TaxRateDto } from "./dto/TaxRateDto";
import { AC000BusinessDto } from "./dto/ac000/AC000BusinessDto";

@Injectable()
export class EcoKaikeiProperty {
    constructor() {}

    /** 利用者認証画面のURL */
    get commonURL(): string {
        return "http://localhost:8081/common/ec001";
    }

    /** トップ画面が表示された回数 */
    private _topPageViewCount: number = 0;

    /** メッセージ一覧 */
    private _messageDtoList: AC000MessageDto[];

    /** 休日カレンダー */
    private _nationalHolidayDtoList: NationalHolidayDto[];

    /** セットアップツアー中 */
    private _isDuringSetupTour: boolean = false;

    /**
     * クライアント保有情報
     */
    private _ownershipDto: OwnershipDto;

    private _businessDto: AC000BusinessDto;

    /** 利用者処理権限区分
     * 1：管理者
     * 2：一般
     * 3：照会
     * 4：会計事務所
     * 5：経費精算のみ
     * 7：招待中
     * 9：招待承認済み
     */
    private _userAuthorityCls: number;

    /**
     * 印鑑で使用 利用者役職
     */
    public _userPosition: string;

    /**
     * 印鑑で使用 印鑑上部
     */
    public _userSealTop: string;

    /**
     * 印鑑で使用 印鑑下部
     */
    public _userSealBottom: string;

    /**
     * ポップアップ用勘定科目一覧
     */
    private _acTitlePopupItemList: EPopupItem[];

    /**
     * ポップアップ用補助科目一覧
     */
    private _acSubTitlePopupItemList: EPopupItem[];

    /**
     * ポップアップ用部門一覧
     */
    private _segmentPopupItemList: EPopupItem[];

    /**
     * ポップアップ用取引先一覧
     */
    private _customerPopupItemList: EPopupItem[];

    /**
     * ポップアップ用消費税区分一覧
     */
    private _consumptionTaxPopupItemList: EPopupItem[];

    /**
     * アプリケーション内での遷移用パラメータ
     */
    private _viewChangeBeans: ViewChangeBeanBase[] = new Array();

    /**
     * 消費税
     */
    private _taxRateList: TaxRateDto[];

    /**
     * 遷移用パラメータの設定
     * @param value 受け渡しパラメータ
     * @param fromAppId 遷移元のアプリケーションID
     * @param toAppId 遷移先のアプリケーションID
     */
    public setViewChangeBeans(
        value: ViewChangeBeanBase,
        fromAppId: string,
        toAppId: string
    ) {
        // 遷移元と遷移先のIDを設定する
        value.fromAppId = fromAppId;
        value.toAppId = toAppId;

        // 遷移用パラメータの設定
        this._viewChangeBeans.push(value);
    }

    /**
     * 遷移用パラメータの受けとり
     * @param thisAppId 遷移先のアプリケーションID
     * @param fromAppId 遷移元のアプリケーションID （任意）
     */
    public getViewChangeBeans(
        thisAppId: string,
        fromAppId?: string
    ): ViewChangeBeanBase {
        // 遷移用パラメータを取得する
        return this._viewChangeBeans
            .reverse()
            .find(
                item =>
                    item.toAppId === thisAppId &&
                    (!fromAppId || item.fromAppId === fromAppId)
            );
    }

    /**
     * 遷移用パラメータを初期化する
     */
    public clearViewChangeBeans(): void {
        // 遷移用パラメータの初期化
        this._viewChangeBeans = new Array();
    }

    /**
     * 表示用月度・決算ラベルを取得する
     *
     */
    public getMonthLabel(
        selectedYearCd: number,
        relativeMonth: number
    ): string {
        // 月度情報を取得する
        var monthItemDto: MonthItemDto = this.ownershipDto.monthItemDtoList.find(
            item =>
                item.fisicalYearCd === selectedYearCd &&
                item.relativeMonth === relativeMonth
        );

        if (monthItemDto) {
            return monthItemDto.monthForDisplay;
        }
        return "";
    }

    /**
     * 入力された日付に対してMonthItemDtoを返却する
     * @param targetDate
     */
    public getDateToItem(targetDate: Date): MonthItemDto {
        // 月度情報を取得する
        var monthItemDtoList: MonthItemDto[] = this.ownershipDto
            .monthItemDtoList;

        // 月度情報をループ
        for (var item of monthItemDtoList) {
            // 相対月13,14,15（決算月）の場合、スキップ
            if (
                item.relativeMonth === 13 ||
                item.relativeMonth === 14 ||
                item.relativeMonth === 15
            ) {
                continue;
            }
            // 入力引数が月度情報の月初から月末の間に含まれる場合返却する
            if (
                new Date(item.fromDate).getTime() <= targetDate.getTime() &&
                new Date(item.toDate).getTime() >= targetDate.getTime()
            ) {
                return item;
            }
        }
        console.log("getDateToItem ：合致する日付なし");
        return new MonthItemDto();
    }

    /**
     * 表示用月度・決算ラベルを取得する
     *
     */
    public getYearMonthLabel(
        selectedYearCd: number,
        relativeMonth: number
    ): string {
        // 月度情報を取得する
        var monthItemDto: MonthItemDto = this.ownershipDto.monthItemDtoList.find(
            item =>
                item.fisicalYearCd === selectedYearCd &&
                item.relativeMonth === relativeMonth
        );

        return (
            monthItemDto.yearForDisplay + "　" + monthItemDto.monthForDisplay
        );
    }

    /**
     * トップ画面が表示された回数
     */
    get topPageViewCount(): number {
        return this._topPageViewCount;
    }

    set topPageViewCount(value: number) {
        this._topPageViewCount = value;
    }

    /**
     * メッセージ一覧
     */
    get messageDtoList(): AC000MessageDto[] {
        return this._messageDtoList;
    }
    set messageDtoList(value: AC000MessageDto[]) {
        this._messageDtoList = value;
    }

    /**
     * 休日カレンダー
     */
    get nationalHolidayDtoList(): NationalHolidayDto[] {
        return this._nationalHolidayDtoList;
    }
    set nationalHolidayDtoList(value: NationalHolidayDto[]) {
        this._nationalHolidayDtoList = value;
    }

    /**
     * ポップアップ用勘定科目
     */
    get acTitlePopupItemList(): EPopupItem[] {
        return this._acTitlePopupItemList;
    }
    set acTitlePopupItemList(value: EPopupItem[]) {
        this._acTitlePopupItemList = value;
    }

    /**
     * ポップアップ用補助科目
     */
    get acSubTitlePopupItemList(): EPopupItem[] {
        return this._acSubTitlePopupItemList;
    }
    set acSubTitlePopupItemList(value: EPopupItem[]) {
        this._acSubTitlePopupItemList = value;
    }

    /**
     * ポップアップ用部門
     */
    get segmentPopupItemList(): EPopupItem[] {
        return this._segmentPopupItemList;
    }
    set segmentPopupItemList(value: EPopupItem[]) {
        this._segmentPopupItemList = value;
    }

    /**
     * ポップアップ用取引先
     */
    get customerPopupItemList(): EPopupItem[] {
        return this._customerPopupItemList;
    }
    set customerPopupItemList(value: EPopupItem[]) {
        this._customerPopupItemList = value;
    }

    /**
     * ポップアップ用消費税区分
     */
    get consumptionTaxPopupItemList(): EPopupItem[] {
        return this._consumptionTaxPopupItemList;
    }
    set consumptionTaxPopupItemList(value: EPopupItem[]) {
        this._consumptionTaxPopupItemList = value;
    }

    /**
     * セットアップツアー中か
     */
    public get isDuringSetupTour(): boolean {
        return this._isDuringSetupTour;
    }
    public set isDuringSetupTour(value: boolean) {
        this._isDuringSetupTour = value;
    }

    /** 利用者処理権限区分
     * 1：管理者
     * 2：一般
     * 3：照会
     * 4：会計事務所
     * 5：経費精算のみ
     * 7：招待中
     * 9：招待承認済み
     */
    get userAuthorityCls() {
        return this._userAuthorityCls;
    }
    set userAuthorityCls(value: number) {
        this._userAuthorityCls = value;
    }

    /**
     * 印鑑で使用 利用者役職
     */
    get userPosition() {
        let result: string = this._userPosition;
        return result;
    }
    set userPosition(_userPosition: string) {
        this._userPosition = _userPosition;
    }

    /**
     * 印鑑で使用 印鑑上部
     */
    get userSealTop() {
        let result: string = this._userSealTop;
        return result;
    }
    set userSealTop(_userSealTop: string) {
        this._userSealTop = _userSealTop;
    }

    /**
     * 印鑑で使用 印鑑下部
     */
    get userSealBottom() {
        let result: string = this._userSealBottom;
        return result;
    }
    set userSealBottom(_userSealBottom: string) {
        this._userSealBottom = _userSealBottom;
    }

    /**
     * クライアント保有情報
     */
    get ownershipDto() {
        return this._ownershipDto;
    }
    set ownershipDto(value: OwnershipDto) {
        this._ownershipDto = value;
    }

    /**
     * 消費税率一覧
     */
    get taxRateList(): TaxRateDto[] {
        return this._taxRateList;
    }
    set taxRateList(value: TaxRateDto[]) {
        this._taxRateList = value;
    }

    get businessDto() {
        return this._businessDto;
    }

    set businessDto(value: AC000BusinessDto) {
        this._businessDto = value;
    }
}
