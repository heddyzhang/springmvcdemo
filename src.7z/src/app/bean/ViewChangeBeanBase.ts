export class ViewChangeBeanBase {

    /** 遷移先のアプリケーションID */
    public toAppId:string;

    /** 遷移元のアプリケーションID */
    public fromAppId:string;
}
