import { ViewChangeBeanBase } from "./ViewChangeBeanBase";

/**
 * AC002からの遷移用パラメータ
 */
export class AC002ViewChangeBean extends ViewChangeBeanBase {

    /** コンストラクタ */
    constructor(selectedView: number) {

        super();

        // 表示中のタブ情報
        this.selectedView = selectedView;
    }

    /** 表示中のタブ情報 */
    public selectedView: number;
}
