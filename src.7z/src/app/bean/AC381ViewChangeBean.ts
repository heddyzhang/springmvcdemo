import { ViewChangeBeanBase } from "./ViewChangeBeanBase";

/**
 * AC381への遷移用パラメータ
 * AC380 => AC381
 */
export class AC381ViewChangeBean extends ViewChangeBeanBase {

    /** コンストラクタ */
    constructor(selectedYear: number, startMonth: number
        , endMonth: number, drAcTitleId: number, crAcTitleId: number
        , minJournalAmount: number, maxJournalAmount: number, journalSummary: string
        , selectSegment: number, selectSegmentId: number
    ) {
        super();

        // 選択中の会計年度
        this.selectedYear = selectedYear;
        // 集計開始月
        this.startMonth = startMonth;
        // 集計終了月
        this.endMonth = endMonth;
        // 借方科目
        this.drAcTitleId = drAcTitleId;
        // 貸方科目
        this.crAcTitleId = crAcTitleId;
        // 最小金額
        this.minJournalAmount = minJournalAmount;
        // 最大金額
        this.maxJournalAmount = maxJournalAmount;
        // 摘要
        this.journalSummary = journalSummary;
        // 部門の選択
        this.selectSegment = selectSegment;
        // 部門コード
        this.selectSegmentId = selectSegmentId;
    }

    /** 当年度 / 翌年度 */
    public selectedYear: number;

    /** 選択開始月 */
    public startMonth: number = -1;

    /** 選択終了月 */
    public endMonth: number = -1;

    /** 借方科目 */
    public drAcTitleId: number = -1;

    /** 貸方科目 */
    public crAcTitleId: number = -1;

    /** 最小金額 */
    public minJournalAmount: number = 0;

    /** 最大金額 */
    public maxJournalAmount: number = 0;

    /** 摘要 */
    public journalSummary: string = "";

    /** 部門の選択フラグ（０：全社対応、１：選択した部門 */
    public selectSegment: number = 0;

    /** 選択された部門コード */
    public selectSegmentId: number = -1;
}
