import { ViewChangeBeanBase } from "./ViewChangeBeanBase";

/**
 * AC322への遷移用パラメータ
 * AC320 => AC322
 */
export class AC322ViewChangeBean extends ViewChangeBeanBase {

     /** コンストラクタ */
     constructor(selectedYear: number, showSubTitle: boolean, startMonth: number
        , endMonth: number, selectSheet: number, selectUnit: number, acTaxSummary: number, selectSettle: boolean
        , selectCompanyTotal: boolean, selectAllDepartments: boolean, segmentId: number) {

        super();

        // 選択中の会計年度
        this.selectedYear = selectedYear;
        // 補助科目を表示するかどうか
        this.showSubTitle = showSubTitle;
        // 集計開始月
        this.startMonth = startMonth;
        // 集計終了月
        this.endMonth = endMonth;
        // 作成
        this.selectSheet = selectSheet;
        // 単位
        this.selectUnit = selectUnit;
        // 消費税(0: 税抜き 1: 税込)
        this.acTaxSummary = acTaxSummary;
        // 決算の扱い
        this.selectSettle = selectSettle;
        //部門（全社集計）
        this.selectCompanyTotal = selectCompanyTotal;
        //部門（全部門別）
        this.selectAllDepartments = selectAllDepartments;
        //選択部門 (-1は"指定なし")
        this.segmentId = segmentId;

    }

    /** 当年度 / 翌年度 */
    public selectedYear: number;

    /** 補助科目を表示する フラグ */
    public showSubTitle: boolean = false;

    /** 選択開始月 */
    public startMonth: number = -1;

    /** 選択終了月 */
    public endMonth: number = -1;

    /** 作成 (0: 集計表 1: 推移表) */
    public selectSheet: number = 0;

    /** 単位 (0: 円 1: 千円 2: 百万円) */
    public selectUnit: number = 0;

    // 事業者の税情報
    // 税込み処理中: 1: 消費税込（金額 + 消費税） 2: 消費税抜き (金額)
    // 税抜き処理中: 1: 消費税抜き (金額) 2: なし
    public acTaxSummary: number = 1;

    /** 決算の扱い (true: 決算を最終月に含める false: 決算を最終月に含めない) */
    public selectSettle: boolean = false;

    //部門（全社集計）
    public selectCompanyTotal: boolean = false;

    //部門（全部門別）
    public selectAllDepartments: boolean = false;

    //選択部門 (-1は"指定なし")
    public segmentId: number = -1;
}
