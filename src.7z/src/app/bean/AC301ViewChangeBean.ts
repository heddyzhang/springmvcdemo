import { ViewChangeBeanBase } from "./ViewChangeBeanBase";

/**
 * AC301への遷移用パラメータ
 * AC300 => AC301
 */
export class AC301ViewChangeBean extends ViewChangeBeanBase {

    /** コンストラクタ */
    constructor(selectedYear: number, showSubTitle: boolean, startMonth: number
        , endMonth: number, selectUnit: number) {

        super();

        // 選択中の会計年度
        this.selectedYear = selectedYear;
        // 補助科目を表示するかどうか
        this.showSubTitle = showSubTitle;
        // 集計開始月
        this.startMonth = startMonth;
        // 集計終了月
        this.endMonth = endMonth;
        // 単位
        this.selectUnit = selectUnit;
    }

    /** 当年度 / 翌年度 */
    public selectedYear: number;

    /** 補助科目を表示する フラグ */
    public showSubTitle: boolean = false;

    /** 選択開始月 */
    public startMonth: number = -1;

    /** 選択終了月 */
    public endMonth: number = -1;

    /** 単位 (0: 円 1: 千円 2: 百万円) */
    public selectUnit: number = 0;
}
