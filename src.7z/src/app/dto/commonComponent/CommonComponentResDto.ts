import { BankDto } from "./BankDto";
import { BankBranchDto } from "./BankBranchDto";
import { ResDtoBase } from "../ResDtoBase";
import { ProgressDto } from "./ProgressDto";
import { SummaryDto } from "./SummaryDto";

export class CommonComponentResDto extends ResDtoBase{

    /**
	 * 銀行情報
	 */
	public bankDto:BankDto;;

	/**
	 * 銀行情報配列
	 */
	public bankDtoList: BankDto[];

	/**
	 * 銀行支店情報
	 */
	public bankBranchDto: BankBranchDto;

	/**
	 * 銀行支店情報配列
	 */
	public bankBranchDtoList: BankBranchDto[];

	/**
	 * 進捗管理DTO
	 */
    public progressDto: ProgressDto;

    /**
	 * 摘要DTO
	 */
	public summaryDtoList: SummaryDto[];
}
