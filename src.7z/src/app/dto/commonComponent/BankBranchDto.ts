export class BankBranchDto {
    public bankCode: String;
	public branchCode: String;
	public branchName: String;
	public branchNameKana: String;
	public searchKey: String;
}