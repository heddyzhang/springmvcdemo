/**
 * 進捗管理DTO
 */
export class ProgressDto {

    /** プログレスID */
	public progressId:number;

	/** 完了値 */
	public completeCnt: number;

	/** 進捗値 */
	public progressCnt: number;

	/** ステータス */
	public progressSts: number;
}