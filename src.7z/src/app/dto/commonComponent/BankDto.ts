export class BankDto {

    /** 銀行コード */
    public bankCode: String;
    /** 銀行名 */
    public bankName: String;
    /** 銀行名カナ */
    public bankNameKana: String;
    /** 検索キー */
    public searchKey: String;
}


