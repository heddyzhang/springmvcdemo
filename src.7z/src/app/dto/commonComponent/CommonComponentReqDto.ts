import { ReqDtoBase } from "../ReqDtoBase";
import { ProgressDto } from "./ProgressDto";
import { SummaryDto } from "./SummaryDto";

export class CommonComponentReqDto extends ReqDtoBase{

    /**
	 * 銀行コード
	 */
	public bankCode: String;

	/**
	 * 支店コード
	 */
	public bankBranchCode: String;

	/**
	 * 進捗管理DTO
	 */
    public progressDto: ProgressDto;

    /**
	 * 摘要DTO
	 */
    public summaryDto: SummaryDto;

    /**
	 * 摘要DTOList
	 */
    public summaryDtoList: SummaryDto[]


}
