export class SummaryDto {
    /* 摘要ID */
	public summaryId: string;
	/* 伝票区分 */
	public slipCls: number;
	/* 見出区分 */
	public summaryCls: number;
	/* 摘要 */
	public summary: string;
	/* 摘要SEQ */
	public summarySeq: number;
	/* 使用回数 */
	public usedCnt: number;
	/* 事業者ID */
	public businessId: number;
	/* 作成日 */
	public createdAt: Date;
	/* 作成者 */
	public createdUser: number;
	/* 更新日 */
	public updatedAt: Date;
	/* 更新者 */
    public updatedUser: number;
    /* チェックされているかどうか */
    public isChecked: boolean;
}
