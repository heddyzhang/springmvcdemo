import { ResDtoBase } from "../ResDtoBase";
import { AC190SlipHeaderDto } from "./AC190SlipHeaderDto";
import { AC190SlipDetailDto } from "./AC190SlipDetailDto";
import { CommonInputSlipDto } from "../CommonInputSlipDto";

/**
 * TODO: このファイルは AC180ResDto.ts をコピーしただけの内容なので、仕様が決まったら正式な内容に書き換えること。
 */

export class AC190ResDto extends ResDtoBase {

	/** List<伝票（見出表示）Dto> */
	public ac190SlipHeaderDtoList: AC190SlipHeaderDto[];

	/** <伝票（見出表示）Dto> */
	public ac190SlipHeaderDto: AC190SlipHeaderDto;

	/** List<伝票（明細表示）Dto> */
	public ac190SlipDetailDtoList: AC190SlipDetailDto[];

	/** List<伝票入力共通DTO> */
	public commonInputSlipDtoList: CommonInputSlipDto[];
}
