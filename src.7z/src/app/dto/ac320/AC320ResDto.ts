import { ResDtoBase } from "../ResDtoBase";

export class AC320ResDto extends ResDtoBase {


}
