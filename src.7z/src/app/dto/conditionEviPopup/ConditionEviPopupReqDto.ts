import { ReqDtoBase } from "../ReqDtoBase";

export class ConditionEviPopupReqDto extends ReqDtoBase {

	/**	仕訳月（From） */
    public journalMonthFrom: string;

	/**	仕訳月（To） */
    public journalMonthTo: string;
}
