export class ConditionEviPopupResultDto {
	/** 証憑分類ID */
    public voucherSortingId: number;

    /** 発生日付From */
    public occurrenceDateFrom: Date;

    /** 発生日付To */
    public occurrenceDateTo: Date;

    /** 送信者 */
    public createdUser: number;
}
