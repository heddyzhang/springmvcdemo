import { ResDtoBase } from "../ResDtoBase";
import { ConditionEviPopupDto } from "./ConditionEviPopupDto";
import { UserDto } from "./UserDto";

export class ConditionEviPopupResDto extends ResDtoBase {

	/** List<利用者Dto> */
    public userDtoList: UserDto[];

	/** List<未処理証憑Dto> */
	public conditionEviPopupDtoList: ConditionEviPopupDto[];
}
