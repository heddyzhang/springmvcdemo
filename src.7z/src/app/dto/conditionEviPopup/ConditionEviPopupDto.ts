export class ConditionEviPopupDto {

	/** 証憑分類ID */
	public voucherSortingId: number;

	/** 証憑分類名称 */
    public voucherSortingName: string;

	/** 発生日付 */
	public occurrenceDate: Date;

	/** 作成者 */
	public createdUser: number;
}
