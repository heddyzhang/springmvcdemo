export class UserDto {
	/** 利用者ID */
    public userId: number;

	/** 利用者名 */
    public userName: string;
}
