/**
 * 事業者・会計年度情報Dto クライアント表示用
 */
export class AC110CourseDto {

    /** 部門ごとに損益を管理する */
    public segmentCls: boolean = false;

    /** 製造原価報告書を作成する */
    public courseCls: boolean = false;


}
