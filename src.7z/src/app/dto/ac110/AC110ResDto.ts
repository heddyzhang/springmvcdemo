import { ResDtoBase } from "../ResDtoBase";


/**
 * 利用者招待
 * 通信パラメータ
 */
export class AC110ResDto extends ResDtoBase {

}
