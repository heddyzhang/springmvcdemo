export class AC110SendMailDto {

    /** メールアドレス */
    public mailAddress: string;
}
