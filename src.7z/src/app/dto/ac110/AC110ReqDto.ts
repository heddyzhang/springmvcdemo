import { ReqDtoBase } from "../ReqDtoBase";
import { AC110SendMailDto } from "./AC110SendMailDto";

/**
 * 利用者招待
 * 通信パラメータ
 */
export class AC110ReqDto extends ReqDtoBase {

    /** メール送信用情報 */
    public sendMailDto: AC110SendMailDto;
}
