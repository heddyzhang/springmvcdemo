import { ResDtoBase } from "../ResDtoBase";
import { AC312TransitionDto } from "./AC312TransitionDto";

export class AC312ResDto extends ResDtoBase{

    /** 推移表データ */
    public transitionDtoList:AC312TransitionDto[];
}
