export class AC311SummaryDto {

	/** 勘定科目ID */
    public acTitleId: number = -1;

    /** 勘定科目名略称 */
    public acTitleNickname: string = null;

	/** 補助科目ID */
    public acSubTitleId: number = -1;

    /** 補助科目名略称 */
    public acSubTitleNickname: string = null;

	/** 前残 */
    public lastBalance: number = -1;

    /** 借方発生総額 */
    public drSummary: number = -1;

    /** 貸方発生総額 */
    public crSummary: number = -1;

	/** 当残 */
    public currentBalance: number = -1;

	/** 背景色 */
    public backgroundColor: string = null;

	/** 背景色 */
    public backgroundColorInt: number = -1;
}
