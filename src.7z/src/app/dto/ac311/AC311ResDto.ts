import { ResDtoBase } from "../ResDtoBase";
import { AC311SummaryDto } from "./AC311SummaryDto";

export class AC311ResDto extends ResDtoBase{

    /** 集計表データ */
    public summaryDtoList:AC311SummaryDto[];
}
