import { ResDtoBase } from "../ResDtoBase";
import { AC210VoucherSortingDto } from "./AC210VoucherSortingDto";
import { AC210VoucherFileDto } from "./AC210VoucherFileDto";

/**
 * 証憑分類情報
 * 通信パラメータ
 */
export class AC210ResDto extends ResDtoBase {

    /** 選択可能ページ */
    public maxPages: number;

    /** 証憑分類マスタ一覧データ */
    public voucherSortingDtoList: AC210VoucherSortingDto[];

    /** 未分類サムネイル一覧データ */
    public voucherFileDtoList: AC210VoucherFileDto[];

    /** 原本ファイル */
    public voucherFileDto: AC210VoucherFileDto;
}
