/**
 * 未分類ファイル
 */
export class AC210VoucherFileInsertDto {

    /** 証憑ファイルID */
    public voucherFileIds: number[];

    /** 証憑分類ID */
    public voucherSortingId: number;

    /** 解析結果：日付 */
    public jsonDate: Date;
}
