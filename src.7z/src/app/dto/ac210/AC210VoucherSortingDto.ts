/**
 * 証憑分類
 */
export class AC210VoucherSortingDto {

    /** 証憑分類ID */
    public voucherSortingId: number;

    /** 証憑分類名称 */
    public voucherSortingName: string;
}
