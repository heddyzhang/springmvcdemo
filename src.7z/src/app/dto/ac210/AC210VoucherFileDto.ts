/**
 * 未分類ファイル
 */
export class AC210VoucherFileDto {

    /** 証憑ファイルID */
    public voucherFileId: number;

    /** 解析結果：日付 */
    public jsonDate: Date;

    /** 解析結果：証憑分類ID */
    public jsonVoucherSortingId: number;

    /** ファイルデータ */
    public fileData: string;

    /** 更新日 */
    public updatedAt: Date;
}
