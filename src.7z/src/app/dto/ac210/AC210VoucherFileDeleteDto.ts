/**
 * 未分類ファイル 削除用パラメータ
 */
export class AC210VoucherFileDeleteDto {

    /** 証憑ファイルID */
    public voucherFileId: number;

    /** 更新日 */
    public updatedAt: Date;
}
