import { ReqDtoBase } from "../ReqDtoBase";
import { AC210VoucherFileDeleteDto } from "./AC210VoucherFileDeleteDto";
import { AC210VoucherFileInsertDto } from "./AC210VoucherFileInsertDto";

/**
 * 証憑分類情報
 * 通信パラメータ
 */
export class AC210ReqDto extends ReqDtoBase {

    /** 表示ページ */
    public page: number;

    /** 証憑ファイルID */
    public voucherFileId: number;

    /** 削除用 */
    public voucherFileDeleteDto: AC210VoucherFileDeleteDto;

    /** 登録用 */
    public voucherFileInsertDto: AC210VoucherFileInsertDto;
}
