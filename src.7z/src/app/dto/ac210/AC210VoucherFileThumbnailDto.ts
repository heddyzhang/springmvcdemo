/**
 * 未分類ファイル
 */
export class AC210VoucherFileThumbnailDto {

    /** 証憑ファイルID */
    public voucherFileId1: number;

    /** ファイルデータ */
    public fileData1: string;

    /** 更新日 */
    public updatedAt1: Date;

    /** 証憑ファイルID */
    public voucherFileId2: number;

    /** ファイルデータ */
    public fileData2: string;

    /** 更新日 */
    public updatedAt2: Date;

    /** 証憑ファイルID */
    public voucherFileId3: number;

    /** ファイルデータ */
    public fileData3: string;

    /** 更新日 */
    public updatedAt3: Date;
}
