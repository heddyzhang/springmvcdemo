/**
 * 事業者・会計年度情報Dto 更新用
 */
export class AC010BusinessUpdateDto {

    /** 事業者名称 */
    public businessName: string = '';

    /** 事業者名称 */
    public businessShortname: string;

    /** 決算期 */
    public settlementYear: string;

    /** 代表者名 */
    public businessRepName: string;

    /** 年度表示 */
    public settlementDispyear: number;

    /** 月度表示 */
    public settlementDispmonth: number;

    /** 事業者所在地郵便番号 */
    public businessZipCd: string;

    /** 事業者所在地住所1 */
    public businessAddress1: string;

    /** 事業者所在地住所2 */
    public businessAddress2: string;

    /** 事業者連絡先電話番号 */
    public businessPhoneNo: string;

    /** 更新日 事業者 */
    public businessUpdatedAt: Date;

    /** 更新日 会計年度 */
    public fisicalYearUpdatedAt: Date;
}
