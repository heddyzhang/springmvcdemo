import { ResDtoBase } from "../ResDtoBase";
import { AC010BusinessDto } from "./AC010BusinessDto";
import { OwnershipDto } from "../OwnershipDto";

/**
 * 事業者登録情報
 * 通信パラメータ
 */
export class AC010ResDto extends ResDtoBase {

    /** 表示用 事業者登録情報 */
    public businessDto: AC010BusinessDto;

    /** クライアント保有情報 */
    public ownershipDto: OwnershipDto;

    /** 郵便番号検索結果 住所 上段 */
    public address1: string;

    /** 郵便番号検索結果 住所 下段 */
    public address2: string;
}
