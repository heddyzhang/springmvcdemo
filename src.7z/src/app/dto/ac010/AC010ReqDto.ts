import { ReqDtoBase } from "../ReqDtoBase";
import { AC010BusinessUpdateDto } from "./AC010BusinessUpdateDto";

/**
 * 事業者登録情報
 * 通信パラメータ
 */
export class AC010ReqDto extends ReqDtoBase {

    /** 更新用 事業者登録情報 */
    public updateDto: AC010BusinessUpdateDto;

    /** 郵便番号検索用 */
    public zipCd: string;
}
