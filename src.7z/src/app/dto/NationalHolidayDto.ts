export class NationalHolidayDto {

    public holiday: Date;

    public holidayName: String;
}