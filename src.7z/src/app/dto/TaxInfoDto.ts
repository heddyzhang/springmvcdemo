export class TaxInfoDto {

	/** 課税方式 */
	public businessTaxClsMethod: number;

	/** 簡易課税業種 */
	public businessIndustry: number;

	/** 消費税経理処理方法 */
	public taxAccountingMethod: number;

	/** 消費税端数処理方法 */
	public taxFractionCls: number;
}