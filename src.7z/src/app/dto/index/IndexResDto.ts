export class IndexResDto{
    
    public authCd:number;
    
    constructor (
    ) {
        this.authCd = 9;
    }
}