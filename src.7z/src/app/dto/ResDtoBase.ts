export class ResDtoBase {

    /** レスポンスコード */
    public responseCd: number;

    /** 処理発行テーブルの発行ID */
    public publishId: string;

    /** メッセージID「実態：「メッセージ種別」+「メッセージID」」 */
    public messageId: string;

    /** メッセージに埋め込む文字の配列 */
    public umekomiList: string[];

    /** クライアントのコンポーネントを一意に識別する文字 */
    public clientTarget: string;

    /** 最終環境更新日時 */
    public updatedEnvironment: Date;

    /** 環境更新日時エラー */
    public isEnvironmentError: boolean;

    constructor(
    ) { }
}
