import { InputSlipDetailDto } from "./InputSlipDetailDto";

export class CommonInputSlipDto {

	/** 会計年度コード */
    public  fisicalYearCd: number = -1;

	/** 仕訳相対月 */
    public journalMonth: number = 1;

	/** 仕訳伝票種別 */
    public journalSlipType: number = -1;

	/** 仕訳ID */
    public journalId: number = -1;

	/** 証憑ID */
    public voucherId: number | null = null;    // 証憑ID または null

	/** 証憑名称 */
    public voucherLinkName: string = null;

	/** 仕訳日付 */
    public journalDate: Date = null;

	/** 税込金額 */
    public journalAmount: number = 0;

	/** 消費税額 */
    public journalTax: number = 0;

	/** 支払予定日 */
    public journalPaymentDate: Date = null;

	/** 借方勘定科目ID */
    public drAcTitleId: number = -1;

	/** 借方補助科目ID */
    public drAcSubTitleId: number = -1;

	/** 貸方勘定科目ID */
    public crAcTitleId: number = -1;

	/** 貸方補助科目ID */
    public crAcSubTitleId: number = -1;

	/** 生仕訳日付 */
    public journalRawDate: Date = null;

	/** 生摘要 */
    public journalRaw: string = null;

	/** 伝票摘要 */
    public journalSummary: string = null;

	/** 伝票明細作成方式 */
    public journalBuildmethod: number = 0;

	/** 支払先名称 */
    public journalPayName: string = null;

	/** 入金先名称 */
    public journalReceivedName: string = null;

	/** 取引先ID */
    public customerId: number = -1;

	/** 消込FLG */
    public journalClearingFlg: number = 0;

	/** 消込年度 */
    public journalCliaringYear: number = 0;

	/** 印鑑日付左 */
    public journalSealTimestampL: Date = null;

	/** 印鑑上段左 */
    public journalSealTopL: string = null;

	/** 印鑑下段左 */
    public journalSealBottomL: string = null;

	/** 印鑑部署左 */
    public journalSealSectionL: string = null;

	/** 印鑑日付中央 */
    public journalSealTimestampC: Date = null;

	/** 印鑑上段中央 */
    public journalSealTopC: string = null;

	/** 印鑑下段中央 */
    public journalSealBottomC: string = null;

	/** 印鑑部署中央 */
    public journalSealSectionC: string = null;

	/** 印鑑日付右 */
    public journalSealTimestampR: Date = null;

	/** 印鑑上段右 */
    public journalSealTopR: string = null;

	/** 印鑑下段右 */
    public journalSealBottomR: string = null;

	/** 印鑑部署右 */
    public journalSealSectionR: string = null;

    /** (左)印鑑を押せるかどうか？ */
    public isStampJournalSealL: boolean = false;

    /** (左)印鑑押下済みか？ */
    public isApprovalJournalSealL: boolean = false;

    /** (中央)印鑑を押せるかどうか？ */
    public isStampJournalSealC: boolean = false;

    /** (中央)印鑑押下済みか？ */
    public isApprovalJournalSealC: boolean = false;

    /** (右)印鑑を押せるかどうか？ */
    public isStampJournalSealR: boolean = false;

    /** (右)印鑑押下済みか？ */
    public isApprovalJournalSealR: boolean = false;

	/** 更新日付 */
	public updatedAt: Date = null;

	/** 伝票明細リスト */
    public slipDetailDtoList: InputSlipDetailDto[] = [];

}
