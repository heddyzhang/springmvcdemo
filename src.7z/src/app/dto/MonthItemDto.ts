/**
 * 月度情報Dto
 * eco.kaikei.web.dto.MonthItemDto.java
 */
export class MonthItemDto {

    /** 会計年度CD */
    public fisicalYearCd: number;

    /** 相対月 1～13～19*/
    public relativeMonth: number;

    /** 当期or翌期 */
    public currentTerm: number;

    /** 外部月 */
    public absoluteMonth: number;

    /** 月初 */
    public fromDate: Date;

    /** 月初 年 */
    public fromDateYear: number;

    /** 月初 月 */
    public fromDateMonth: number;

    /** 月初 日 */
    public fromDateDay: number;

    /** 月末 */
    public toDate: Date;

    /** 月末 年 */
    public toDateYear: number;

    /** 月末 月 */
    public toDateMonth: number;

    /** 月末 日 */
    public toDateDay: number;

    /** 表示月(年度) */
	public yearForDisplay: string;

	/** 表示月(月度) */
	public monthForDisplay: string;
}
