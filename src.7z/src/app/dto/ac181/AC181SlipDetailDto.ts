export class AC181SlipDetailDto {

	/** 会計年度コード */
    public fisicalYearCd: number;

	/** 仕訳相対月 */
    public journalMonth: number;

	/** 仕訳伝票種別 */
    public journalSlipType: number;

	/** 仕訳ID */
    public journalId: number;

	/** 仕訳明細ID */
    public journalDetailId: number;

	/** 仕訳行NO */
    public journalSlipLineNo: number;

	/** 日付/NO */
    public dateNo: string;

	/** 借方科目 */
    public drTitle: string;

	/** 貸方科目 */
    public crTitle: string;

	/** 相手先 */
    public customer: string;

	/** 消費税 */
    public taxRate: string;

	/** 金額 */
    public amount: string;

	/** 摘要 */
    public summary: string;

	/** 部門／事業 */
    public segmentIndustry: string;

	/** 期日 */
    public paymentDate: string;
}

