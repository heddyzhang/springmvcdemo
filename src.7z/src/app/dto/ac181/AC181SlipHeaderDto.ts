export class AC181SlipHeaderDto {

	/** 会計年度コード */
    public fisicalYearCd: number;

	/** 仕訳相対月 */
    public journalMonth: number;

	/** 仕訳伝票種別 */
    public journalSlipType: number;

	/** 仕訳ID */
    public journalId: number;

	/** 空列(件数) */
    public ken: string;

	/** 日付/NO */
    public dateNo: string;

	/** 借方科目 */
    public drTitle: string;

	/** 貸方科目 */
    public crTitle: string;

	/** 相手先 */
    public customer: string;

	/** 金額 */
    public amount: string;

	/** 摘要 */
    public summary: string;

	/** 入金予定日 */
    public paymentDate: string;

	/** 証憑 */
    public voucherLink: string;
}
