import { ResDtoBase } from "../ResDtoBase";
import { AC181SlipHeaderDto } from "./AC181SlipHeaderDto";
import { AC181SlipDetailDto } from "./AC181SlipDetailDto";
import { CommonInputSlipDto } from "../CommonInputSlipDto";

export class AC181ResDto extends ResDtoBase {

	/** List<伝票（見出表示）Dto> */
	public ac181SlipHeaderDtoList: AC181SlipHeaderDto[];

	/** <伝票（見出表示）Dto> */
	public ac181SlipHeaderDto: AC181SlipHeaderDto;

	/** List<伝票（明細表示）Dto> */
	public ac181SlipDetailDtoList: AC181SlipDetailDto[];

	/** List<伝票入力共通DTO> */
	public commonInputSlipDtoList: CommonInputSlipDto[];
}
