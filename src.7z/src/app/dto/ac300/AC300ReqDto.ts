import { ReqDtoBase } from "../ReqDtoBase";

export class AC300ReqDto extends ReqDtoBase {

    /** 印刷対象の会計年度 */
    public selectedYear: number;

    /** 印刷対象 (0: 集計表 1: 推移表) */
    public selectSheet: number = 0;

    /** 補助科目を表示する フラグ */
    public showSubTitle: boolean = false;

    /** 選択開始月 */
    public startMonth: number = -1;

    /** 選択終了月 */
    public endMonth: number = -1;

    /** 単位 (0: 円 1: 千円 2: 百万円) */
    public selectUnit: number = 0;

    /** 決算の扱い (true: 決算を最終月に含める false: 決算を最終月に含めない) */
    public selectSettle: boolean = false;
}
