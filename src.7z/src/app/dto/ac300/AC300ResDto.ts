import { ResDtoBase } from "../ResDtoBase";

export class AC300ResDto extends ResDtoBase{

}
