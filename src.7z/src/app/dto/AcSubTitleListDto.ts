import { ResDtoBase } from "./ResDtoBase";
import { EPopupItem } from "./ePopupInput/EPopupItem";

export class AcSubTitleListDto extends ResDtoBase {
    acSubTileList: EPopupItem[];
}
