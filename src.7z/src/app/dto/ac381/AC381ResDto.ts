import { ResDtoBase } from "../ResDtoBase";
import { AC381journalDto } from "./AC381journalDto";

export class AC381ResDto extends ResDtoBase{

    /** 仕訳票データ */
    public journalDtoList:AC381journalDto[];
}
