import { ReqDtoBase } from "../ReqDtoBase";

export class AC381ReqDto extends ReqDtoBase{

	/** 印刷対象の会計年度 */
	public selectedYear: number = -1;

	/** 選択開始月 */
	public startMonth: number = -1;
	
	/** 選択終了月 */
	public endMonth: number = -1;
	
	/** 借方科目 */
	public drAcTitleId: number = -1;
	
	/** 貸方科目 */
	public crAcTitleId: number = -1;
	
	/** 最小金額 */
	public minJournalAmount: number = -1;
	
	/** 最大金額 */
	public maxJournalAmount: number = -1;
	
	/** 摘要 */
	public journalSummary: string = "";
	
	/** 部門の選択フラグ（０：全社対応、１：選択した部） */
	public selectSegment: number = -1;
	
	/** 部門ID */
	public selectSegmentId: number = -1;

}
