/**
 * 仕訳票
 */
export class AC381journalDto {

    /** 仕訳日付 */
    public journalDate: Date;

    /** 会計年度コード */
    public fisicalYearCd: number;

    /** 仕訳相対月 */
    public journalMonth: number;

    /** 仕訳伝票種別 */
    public journalSlipType: number;

    /** 仕訳ID */
    public journalId: number;

    /** 仕訳明細ID */
    public journalDetailId: number;

    /** 仕訳伝票名称 */
    public journalSlipName: String;

    /** 借方勘定科目ID */
    public drAcTitleId: number;

    /** 借方勘定科目名 */
    public drTitle: String;

    /** 借方補助科目ID */
    public drAcSubTitleId: number;

    /** 借方補助科目名 */
    public drTitleSub: String;

    /** 借方科目消費税分類 */
    public drConsumptionTaxCls: number;

    /** 貸方勘定科目ID */
    public crAcTitleId: number;

    /** 貸方勘定科目名 */
    public crTitle: String;

    /** 貸方補助科目ID */
    public crAcSubTitleId: number;

    /** 貸方補助科目名 */
    public crTitleSub: String;

    /** 貸方科目消費税分類 */
    public crConsumptionTaxCls: number;

    /** 金額 */
    public journalAmount: number;

    /** 消費税金額 */
    public journalTaxAmount: number;

    /** 消費税コード */
    public consumptionTaxCd: number;

    /** 消費税略称 */
    public consumptionTaxShortname: String;

    /** 消費税ID */
    public taxRateId: number;

    /** 消費税率名称 */
    public taxRateName: String;

    /** 仕訳摘要1 */
    public journalSummaryTop: String;

    /** 仕訳摘要2 */
    public journalSummaryBottom: String;

    /** 部門ID */
    public segmentId: number;

    /** 部門略称 */
    public segmentNickname: String;

    /** 業種 */
    public industryId: number;

    /** 業種名称 */
    public industry: String;

    /** 取引先ID */
    public customerId: number;

    /** 取引先略称 */
    public customerShortName: String;

    /** 支払予定日 */
    public journalPaymentDate: Date;

    /** 事業者ID */
    public businessId: number;

    /** 事業者名称 */
    public businessName: String;

    /** 消費税事業者区分 */
    public businessTaxCls: number;

    /** 消費税課税方法 */
    public businessTaxMethod: number;

    /** 消費税経理処理方法 */
    public taxAccountingMethod: number;

    /** 背景色 */
    public backgroundColor: string = '#FFFFFF';

    /** 背景色 */
    public backgroundColorInt: number;
}
