export class AC036AmountSumDto{

    /** 勘定科目ID */
    public acTitleId: number;

    /** 補助科目ID */
    public acSubTitleId: number;

    /** 勘定科目コード */
    public acTitleCd: number;

    /** 補助科目コード */
    public acSubTitleCd: number;

    /** 勘定科目名略称 */
    public acTitleNickname: string;

    /** 補助科目名略称 */
    public acSubTitleNickname: string;

    /** 貸借区分 ２：借方ＢＳ科目　３：貸方ＢＳ科目 */
    public acDrcrCls: number;

    /** 残高0 : 会計年度の期首残高。 */
    public amountSumBa0: number;

    /** 残高0 : 補助科目の会計年度の期首残高。 */
    public subAmountSumBa0: number;

    /** 更新日 */
    public updatedAt: Date;
}
