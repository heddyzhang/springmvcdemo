import { ResDtoBase } from "../ResDtoBase";
import { AC036AmountSumDto } from "./AC036AmountSumDto";

export class AC036ResDto extends ResDtoBase{

    /**
     * 初期処理・取消処理・更新処理
     */
    // 補助科目の残高一覧
    public amountSumDtoList:AC036AmountSumDto[];
}
