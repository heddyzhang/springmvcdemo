import { ReqDtoBase } from "../ReqDtoBase";
import { AC036UpdateAmountSumDto } from "./AC036UpdateAmountSumDto";

export class AC036ReqDto extends ReqDtoBase{

    /**
     * 絞り込み条件
     */
    // 貸借区分
    public acDrcrCls: number;

    // 使用していない科目を表示するかどうか true:全表示 false:使用科目のみ
    public showNotUse: boolean;

    /**
     * 更新処理用
     */
    // 補助科目の残高一覧
    public updateAmountSumDtoList:AC036UpdateAmountSumDto[];
}
