export class AC036UpdateAmountSumDto{

    /** 勘定科目ID */
    public acTitleId: number;

    /** 補助科目ID */
    public acSubTitleId: number;

    /** 貸借区分 ２：借方ＢＳ科目　３：貸方ＢＳ科目 */
    public acDrcrCls: number;

    /** 残高0 : 会計年度の期首残高。 */
    public amountSumBa0: number;

    /** 残高0 : 補助科目の会計年度の期首残高。 */
    public subAmountSumBa0: number;

    /** 更新日 */
    public updatedAt: Date;
}
