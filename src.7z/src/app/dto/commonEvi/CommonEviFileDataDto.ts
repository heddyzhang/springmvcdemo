export class CommonEviFileDataDto {
	/** ファイル名 */
	public fileName: string;

	/** 画像ファイルデータ(Base64エンコード文字列) */
	public fileData: string;
}
