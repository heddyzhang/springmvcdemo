export class CommonEviDeleteDto {
	/** 証憑ID */
	public voucherId: number;

	/** 更新日 */
	public updatedAt: Date;
}
