export class CommonEviDetailDto {
	/** 証憑ID */
	public voucherId: number;

	/** 証憑画像表示順序 */
	public voucherImageOrder: number;

	/** 証憑ファイルID */
	public voucherFileId: number;

	/** 証憑画像用ファイルID(UUID) */
	public voucherImageFileId: any;

	// /** 証憑画像用ファイルID(UUID) */
	// public imgFileId: any;

	// /** 証憑画像用ファイル名 */
	// public imgFileName: string;

	/** 証憑画像用ファイルデータ(byte[]) */
	// public imgFileData: any[];

	/** サムネイル画像用ファイルID(UUID) */
	// public thumbnailFileId: any;

	// /** サムネイル画像用ファイル名 */
	// public thumFileName: string;

	// /** サムネイル画像用ファイルデータ(Base64文字列) → 画像はページ切り替え時に取得するためこのフィールドは廃止 */
	// public thumFileData: string;

	/** 更新日 */
    public updatedAt: Date;
}
