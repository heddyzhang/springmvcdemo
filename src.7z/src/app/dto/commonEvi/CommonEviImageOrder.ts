export class CommonEviImageOrder {
	/** 証憑ID */
	public voucherId: number;

	/** 証憑ファイルID */
	public voucherFileId: number;

	/** 証憑画像表示順序 */
	public voucherImageOrder: number;

	/** 更新日 */
	public updateDate: Date;
}
