import { MonthItemDto } from "./MonthItemDto";
import { TaxInfoDto } from "./TaxInfoDto";

export class OwnershipDto {

    /** 最終環境更新日時 */
    public updatedEnvironment: Date;

    /** 現在選択している会計年度 */
    public selectFisicalYear: number;

    /** 会計期間From */
	public fromDate: Date;

	/** 会計期間To */
	public toDate: Date;

    /** 最新年度 */
    public currentYear: number;

    /** 処理中の会計年度が最新かどうかのflg */
    public newFisicalYear: boolean;

    /** 部門管理区分 */
    public segmentCls: number;

    /** 製造原価管理区分 */
    public costreportCls: number;

    /** 月度情報 */
    public monthItemDtoList: MonthItemDto[];

    /** 当期_税情報 */
	public currentTaxInfoDto: TaxInfoDto = new TaxInfoDto();

	/** 翌期_税情報 */
	public nextTaxInfoDto: TaxInfoDto = new TaxInfoDto();

}
