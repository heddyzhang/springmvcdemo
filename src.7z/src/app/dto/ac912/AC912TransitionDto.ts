/**
 * 貸借対照表 推移表
 */
export class AC912TransitionDto {

    /** 勘定科目ID */
    public acTitleId: number;

    /** 勘定科目名略称 */
    public acTitleNickname: string;

    /** 補助科目ID */
    public acSubTitleId: number;

    /** 補助科目名略称 */
    public acSubTitleNickname: string;

    /** 前残 */
    public balance0: number;

    /** 内部月：１ */
    public balance1: number;

    /** 内部月：２ */
    public balance2: number;

    /** 内部月：３ */
    public balance3: number;

    /** 内部月：４ */
    public balance4: number;

    /** 内部月：５ */
    public balance5: number;

    /** 内部月：６ */
    public balance6: number;

    /** 内部月：７ */
    public balance7: number;

    /** 内部月：８ */
    public balance8: number;

    /** 内部月：９ */
    public balance9: number;

    /** 内部月：１０ */
    public balance10: number;

    /** 内部月：１１ */
    public balance11: number;

    /** 内部月：１２ */
    public balance12: number;

    /** 内部月：決算 */
    public balance15: number;

    /** 内部月：合計残高 */
    public balanceSum: number;

    /** 背景色 */
    public backgroundColor: string = '#FFFFFF';

    /** 背景色 */
    public backgroundColorInt: number;
}
