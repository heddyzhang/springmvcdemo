import { ResDtoBase } from "../ResDtoBase";
import { AC912TransitionDto } from "./AC912TransitionDto";

export class AC912ResDto extends ResDtoBase{

    /** 推移表データ */
    public transitionDtoList:AC912TransitionDto[];
}
