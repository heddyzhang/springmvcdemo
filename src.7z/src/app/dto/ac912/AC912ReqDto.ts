import { ReqDtoBase } from "../ReqDtoBase";

export class AC912ReqDto extends ReqDtoBase{

    /** 当年度 / 翌年度 */
    public selectedYear: number;

    /** 補助科目を表示する フラグ */
    public showSubTitle: boolean = false;

    /** 選択開始月 */
    public startMonth: number = -1;

    /** 選択終了月 */
    public endMonth: number = -1;

    /** 単位 (0: 円 1: 千円 2: 百万円) */
    public selectUnit: number = 0;

    /** 決算の扱い (true: 決算を最終月に含める false: 決算を最終月に含めない) */
    public selectSettle: boolean = false;
}
