import { ResDtoBase } from "../ResDtoBase";
import { EPopupItem } from "./EPopupItem";

export class EPopupInputResDto extends ResDtoBase {
    
    public itemList: EPopupItem[];

    constructor(
  
    ) {
      super();
    }
  
  }