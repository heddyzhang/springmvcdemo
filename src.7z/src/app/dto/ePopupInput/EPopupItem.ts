export class EPopupItem {

    /** 内部ID */
	public id: number;

	/** 汎用1 */
	public cls1: number;

	/** 汎用2 */
	public cls2: number;

	/** 汎用3 */
	public cls3: number;

	/** 汎用4 */
	public cls4: number;

	/** 汎用5 */
	public cls5: number;

	/** 汎用6 */
	public cls6: number;

	/** 汎用7 */
	public cls7: number;

	/** 汎用8 */
	public cls8: number;

	/** 外部コード */
	public cd: string;

	/** 検索キー */
	public searchKey: string;

	/** ラベル */
    public label: string;

	/** タブ区分 */
	public tabCls: number;

	/** 説明 */
	public explanation: string;
    value: any;

    constructor(

    ) {
    }

  }
