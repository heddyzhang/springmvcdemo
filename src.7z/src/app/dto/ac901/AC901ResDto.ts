import { ResDtoBase } from "../ResDtoBase";

export class AC901ResDto extends ResDtoBase {

    public addNum: number;
    
}