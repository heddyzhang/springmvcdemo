import { ReqDtoBase } from "../ReqDtoBase";

export class AC901ReqDto extends ReqDtoBase {

    public num1: number;

    public num2: number;
}