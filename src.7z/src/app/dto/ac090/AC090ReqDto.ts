import { ReqDtoBase } from "../ReqDtoBase";
import { AC090MtAccountsDto } from "./AC090MtAccountsDto";
import { AC090AcTitleDto } from "./AC090AcTitleDto";

export class AC090ReqDto extends ReqDtoBase {
    public accountCls : number;

    public accountId : number;

    public authInputValue: string;

    public transactionSinceDate: Date;

    public ac090MtAccountsItem: AC090MtAccountsDto;

    public acSubTitleItem: AC090AcTitleDto;
}
