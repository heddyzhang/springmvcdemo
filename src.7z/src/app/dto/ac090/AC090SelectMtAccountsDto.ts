import { AC090MtAccountsDto } from "./AC090MtAccountsDto";

export class AC090SelectMtAccountsDto extends AC090MtAccountsDto {

}
