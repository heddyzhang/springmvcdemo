import { ResDtoBase } from "../ResDtoBase";
import { AC090MtAccountsDto } from "./AC090MtAccountsDto";

export class AC090ResDto extends ResDtoBase {

    /** 口座一覧 */
    public mtAccountsDtoList: AC090MtAccountsDto[];

    public mtLinkCallbackUrl: string;

    public mtLinkResult: string;
}
