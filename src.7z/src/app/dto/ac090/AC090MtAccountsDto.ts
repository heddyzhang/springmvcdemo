/**
 * 口座情報
 */
export class AC090MtAccountsDto {

    public accountCls: number;
	public accountId: number;
	public accountGroup: number;
	public accountType: string;
	public accountTypeName: string;
	public accountSubtype: string;
    public aggregationState: string;
    public aggregationStateName: string;
	public aggregationStatus: string;
	public lastAggregatedAt: Date;
	public lastAggregatedSuccess: Date;
	public currency: string;
	public currentBalance: number;
	public institutionEntityKey: string;
	public institutionAccountName: string;
	public institutionAccountNumber: string;
	public nickname: string;
	public mtCreatedAt: Date;
	public mtUpdateAt: Date;
	public institutionAccountType: string;
	public branchName: string;
	public createdAt: Date;
	public createdUser: number;
	public updatedAt: Date;
	public updatedUser: number;
    public mtRetrydateAt: Date;
    public mtLastUpdatedAt: Date;
    public displayLastUpdate: string;
	public institutionType: string;
	public institutionDisplayName: string;
    public mtCtl: number;
    public displayMtCtl: string;
	public mtExists: number;
	public acTitleId: number;
	public acSubTitleId: number;
	public acTitleCd: number;
	public acSubTitleCd: number;
	public acTitleName: string;
	public acSubTitleName: string;
	public acSubTitleNickname: string;
}
