export class AC090AcTitleDto
{
    public acTitleId: number;

    public acTitleCd: number;

    public acSubTitleId: number = 0;

    public acSubTitleCd: number;

    public acTitleName: string;

    public acTitleNickname: string;

    public acDrcrCls: number;
}
