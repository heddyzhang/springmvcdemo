export class TaxRateDto {

    /** 消費税ID */
    public taxRateId: number;
    /** 表示順序 */
    public dispSeq: number;
    /** 消費税率 */
    public consumptionTaxRate: number;
    /** 消費税率名称 */
    public taxRateName: string;
    /** 軽減税率区分 */
    public reducedCls: number;
    /** 国税分税率 */
    public nationalTaxRate: number;
    /** 地方税税率 */
    public localTaxRate: number;
    /** 適用開始日 */
    public usedFromDate: Date;
    /** 適用終了日 */
    public usedToDate: Date;
    /** 作成日 */
    public createdAt: Date;
    /** 作成者 */
    public createdUser: number;
    /** 更新日 */
    public updatedAt: Date;
    /** 更新者 */
    public updatedUser: number;
    /** 画面表示用の名称(DBにはないカラム) */
    public taxRateTitle: string;

}


