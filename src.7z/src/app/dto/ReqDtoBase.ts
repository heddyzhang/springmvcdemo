export class ReqDtoBase {
    /** 会計年度ID */
    public fisicalYearCd: number;

    /** 印刷設定 事業者名の表示・非表示 */
    public dispBusinessFlg: boolean;

    /** 印刷設定 印刷日時の表示・非表示 */
    public dispPrintTimeFormat: string;

    /** 最終環境更新日時 */
    public updatedEnvironment: Date;

    /** ポーリング処理のプログレスID */
    public progressId: number;

    //チェックのみか否か　true:チェックのみ/false:チェック後更新処理まで実施する
    public checkOnly: boolean;
}
