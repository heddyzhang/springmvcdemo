import { ResDtoBase } from "../ResDtoBase";
import { AC301SummaryDto } from "./AC301SummaryDto";

export class AC301ResDto extends ResDtoBase{

    /** 集計表データ */
    public summaryDtoList:AC301SummaryDto[];
}
