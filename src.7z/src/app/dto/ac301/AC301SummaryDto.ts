/**
 * 貸借対照表 集計表
 */
export class AC301SummaryDto {

    /** 勘定科目ID */
    public acTitleId: number;

    /** 勘定科目名略称 */
    public acTitleNickname: string;

    /** 補助科目ID */
    public acSubTitleId: number;

    /** 補助科目名略称 */
    public acSubTitleNickname: string;

    /** 前残 */
    public lastBalance: number;

    /** 借方発生総額 */
    public drSummary: number;

    /** 貸方発生総額 */
    public crSummary: number;

    /** 当残 */
    public currentBalance: number;

    /** 背景色 */
    public backgroundColor: string = '#FFFFFF';

    /** 背景色 */
    public backgroundColorInt: number;
}
