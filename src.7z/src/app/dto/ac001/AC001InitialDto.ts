import { AC001YearInfoDto } from "./AC001YearInfoDto";

export class AC001InitialDto  {

    /** 年度情報 */
	public yearInfoDtoList: AC001YearInfoDto[];
}