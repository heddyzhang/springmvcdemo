export class AC001YearInfoDto  {

    /** 会年年度 */
	public fisicalYearCd: number;

	/** 表示ラベル */
	public label: String;

	/** 最新 */
	public newest: boolean;
}