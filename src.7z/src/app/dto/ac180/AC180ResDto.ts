import { ResDtoBase } from "../ResDtoBase";
import { AC180SlipHeaderDto } from "./AC180SlipHeaderDto";
import { AC180SlipDetailDto } from "./AC180SlipDetailDto";
import { CommonInputSlipDto } from "../CommonInputSlipDto";

export class AC180ResDto extends ResDtoBase {

	/** List<伝票（見出表示）Dto> */
	public ac180SlipHeaderDtoList: AC180SlipHeaderDto[];

	/** <伝票（見出表示）Dto> */
	public ac180SlipHeaderDto: AC180SlipHeaderDto;

	/** List<伝票（明細表示）Dto> */
	public ac180SlipDetailDtoList: AC180SlipDetailDto[];

	/** List<伝票入力共通DTO> */
	public commonInputSlipDtoList: CommonInputSlipDto[];
}
