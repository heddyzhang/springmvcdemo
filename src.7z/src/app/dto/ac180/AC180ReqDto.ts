import { ReqDtoBase } from "../ReqDtoBase";
import { CommonInputSlipDto } from "../CommonInputSlipDto";

export class AC180ReqDto extends ReqDtoBase {

	/** 会計年度（仕訳用） */
	public fisicalYearCdJournal: number;

	/**	内部月（From） */
    public journalMonthFrom: number;

	/**	内部月（To） */
    public journalMonthTo: number;

    /** 伝票入力共通DTO */
	public commonInputSlipDto: CommonInputSlipDto;
}
