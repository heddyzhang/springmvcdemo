import { ResDtoBase } from "../ResDtoBase";
import { CommonEviDto } from "../commonEvi/CommonEviDto";
import { CommonEviDetailDto } from "../commonEvi/CommonEviDetailDto";
import { CommonEviFileDataDto } from "../commonEvi/CommonEviFileDataDto";

export class UnlinkEviResDto extends ResDtoBase {
	/** 未処理証憑Dto */
	public commonEviDto: CommonEviDto;

    /** List<未処理証憑詳細Dto> */
    public commonEviDetailDtoList: CommonEviDetailDto[];
}
