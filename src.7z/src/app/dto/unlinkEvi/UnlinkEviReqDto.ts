import { ReqDtoBase } from "../ReqDtoBase";
import { CommonEviImageOrder } from "../commonEvi/CommonEviImageOrder";

export class UnlinkEviReqDto extends ReqDtoBase {
    /** 証憑ID */
    public voucherId: number;

    /** 証憑画像用ファイルID(UUID) */
    public fileId: any;

    /** 会計年度コード **/
    public journalFisicalYearCd: number;

    /** 仕訳相対月 **/
    public journalMonth: number;

    /** 仕訳伝票種別 **/
    public journalSlipType: number;

    /** 仕訳ID */
    public journalId: number;

    /**	List<詳細画像表示順序> */
    public commonEviImageOrderList: CommonEviImageOrder[]

	/** 更新日付 */
    public updateDate: Date;

	/** 更新日付 */
    public journalUpdateDate: Date;
}
