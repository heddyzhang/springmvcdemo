import { ReqDtoBase } from "../ReqDtoBase";
import { AC015FisicalYearUpdateDto } from "./AC015FisicalYearUpdateDto";

/**
 * 消費税設定
 * 通信パラメータ
 */
export class AC015ReqDto extends ReqDtoBase {

    /** 選択中の会計年度ID */
    public selectedFisicalYearCd: number;

    /** 更新用 消費税設定情報 */
    public updateDto: AC015FisicalYearUpdateDto;
}
