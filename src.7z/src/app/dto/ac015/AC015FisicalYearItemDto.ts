/**
 * 対象となる事業年度一覧Dto クライアント表示用
 */
export class AC015FisicalYearItemDto {

    /** XXXX年度 : settlement_dispyearによって期初日と期末日の年に切り替わる */
    public label: string = '';

    /** 会計年度コード */
    public fisicalYearCd: number;

    /** 期初日 ～ 期末日 */
    public fisicalYearFromToDate: string;
}
