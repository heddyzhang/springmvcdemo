import { ResDtoBase } from "../ResDtoBase";
import { AC015FisicalYearDto } from "./AC015FisicalYearDto";
import { AC015FisicalYearItemDto } from "./AC015FisicalYearItemDto";
import { OwnershipDto } from "../OwnershipDto";

/**
 * 消費税設定
 * 通信パラメータ
 */
export class AC015ResDto extends ResDtoBase {

    /** 表示用 消費税設定情報 */
    public fisicalYearDto: AC015FisicalYearDto;

    /** 表示用 対象となる事業年度一覧情報 */
    public fisicalYearListDto: AC015FisicalYearItemDto[];

    /** クライアント保有情報 */
    public ownershipDto: OwnershipDto;
}
