/**
 * 会計年度情報Dto クライアント表示用
 */
export class AC015FisicalYearDto {

    /** 0: 免税 1: 課税（原則） 2: 課税（簡易） */
    public businessTaxClsMethod: number = -1;

    /** 仕入税額控除 −１：未設定　０：比例配分　１：個別対応 */
    public purchaseTaxDeductionCls: number = -1;

    /** 簡易課税業種 -1：未設定 1：第一種事業（卸売業） 2：第二種事業（小売業）
     *  3：第三種事業（製造業等） 4：第四種事業（その他の事業） 5：第五種事業（サービス業等） 6：第六種事業（不動産業） */
    public businessIndustry: number = -1;

    /** 消費税経理処理方法 */
    public taxAccountingMethod: number = -1;

    /** 消費税端数処理方法 */
    public taxFractionCls: number = -1;

    /** 更新日 */
    public updatedAt: Date;
}
