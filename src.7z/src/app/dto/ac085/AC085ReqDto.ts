import { ReqDtoBase } from "../ReqDtoBase";
import { AC085UpdateAmountSumDto } from "./AC085UpdateAmountSumDto";

export class AC085ReqDto extends ReqDtoBase{

    /** 選択中の勘定科目ID */
    public selectedAcTitleId:number;

    /**
     * 更新処理用
     */
    /** 取引先・社員残高一覧 */
    public updateAmountSumDtoList:AC085UpdateAmountSumDto[];
}
