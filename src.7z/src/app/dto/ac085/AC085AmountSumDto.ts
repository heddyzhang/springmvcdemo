export class AC085AmountSumDto{

    /** 科目集計コード */
    public acSummaryCd: number;
    /** 取引先コード */
    public customerId: number;
    /** 勘定科目ID */
    public acTitleId: number;

    /** 取引先管理NO */
    public customerManagementNo: string;
    /** 取引先略称 */
    public customerShortName: string;
    /** 取引先カナ : 取引先の検索文字。英数カナ14文字 */
    public customerKana: string;
    /** 取引先区分名称 */
    public customerClsName: string;
    /** 残高0 : 会計年度の期首残高。 */
    public amountSumBa0: number;

    /** 更新日 */
    public updatedAt: Date;
}
