export class AC085AcTitleDto{

    /** 勘定科目ID */
    public acTitleId: number;
    /** 科目名称 */
    public acTitleNickname: string;
}
