import { ResDtoBase } from "../ResDtoBase";
import { AC085AmountSumDto } from "./AC085AmountSumDto";
import { AC085AcTitleDto } from "./AC085AcTitleDto";

export class AC085ResDto extends ResDtoBase{

    /**
     * 初期処理・取消処理・更新処理
     */
    // 取引先・社員残高一覧
    public amountSumDtoList:AC085AmountSumDto[];

    /**
     * 初期処理
     */
    // 勘定科目一覧
    public acTitleDtoList:AC085AcTitleDto[];
}
