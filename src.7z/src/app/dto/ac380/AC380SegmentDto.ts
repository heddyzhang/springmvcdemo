export class AC380SegmentDto {

    /** segmentIdによるパラメータ */

    /** 部門名 */
    public label:string;

    /** 部門Id */
    public value:number;


    constructor(label: string, value: number) {
        this.value = value;
        this.label = label;
    }

}
