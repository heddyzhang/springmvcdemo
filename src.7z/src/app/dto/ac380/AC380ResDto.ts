import { ResDtoBase } from "../ResDtoBase";

export class AC380ResDto extends ResDtoBase {

}
