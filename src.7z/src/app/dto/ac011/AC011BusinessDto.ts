/**
 * 事業者・会計年度情報Dto クライアント表示用
 */
export class AC011BusinessDto {

    /** 部門ごとに損益を管理する */
    public segmentCls: boolean = false;

    /** 帳票タイトル */
    public segmentTitle: string = '';

    /** 製造原価報告書を作成する */
    public costreportCls: boolean = false;

    /** 証憑から会計伝票を起票する */
    public evidenceUsedFlg: boolean = false;

    /** タイムスタンプを押す */
    public timestampUsedFlg: number = -1;

    /** MoneyTree連携 */
    public moneytreeUsedFlg: boolean = false;

    /** 自動的に仕訳候補を提案する */
    public autojournalUsedFlg: boolean = false;

    /** 自動仕訳不合格判定率 */
    public sortingFailRate: number = 0;

    /** 自動仕訳自動判定率 */
    public sortingSuccessRate: number = 0;

    /** 利用コース */
    public usedCourseCls: number = 0;

    /** お試し期間かどうか true:期間内 */
    public isTrialPeriod: boolean = false;

    /** 更新日 事業者 */
    public businessUpdatedAt: Date;

    /** 更新日 会計年度 */
    public fisicalYearUpdatedAt: Date;
}
