import { ResDtoBase } from "../ResDtoBase";
import { AC011BusinessDto } from "./AC011BusinessDto";
import { OwnershipDto } from "../OwnershipDto";

/**
 * ご利用形態
 * 通信パラメータ
 */
export class AC011ResDto extends ResDtoBase {

    /** 表示用 事業者登録情報 */
    public businessDto: AC011BusinessDto;

    /** クライアント保有情報 */
    public ownershipDto: OwnershipDto;
}
