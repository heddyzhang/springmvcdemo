/**
 * 事業者・会計年度情報Dto 更新用
 */
export class AC011BusinessUpdateDto {

    /** 部門ごとに損益を管理する */
    public segmentCls: boolean;

    /** 帳票タイトル */
    public segmentTitle: string;

    /** 製造原価報告書を作成する */
    public costreportCls: boolean;

    /** 証憑から会計伝票を起票する */
    public evidenceUsedFlg: boolean;

    /** タイムスタンプを押す */
    public timestampUsedFlg: number;

    /** MoneyTree連携 */
    public moneytreeUsedFlg: boolean;

    /** 自動的に仕訳候補を提案する */
    public autojournalUsedFlg: boolean;

    /** 自動仕訳不合格判定率 */
    public sortingFailRate: number;

    /** 自動仕訳自動判定率 */
    public sortingSuccessRate: number;

    /** 更新日 事業者 */
    public businessUpdatedAt: Date;

    /** 更新日 会計年度 */
    public fisicalYearUpdatedAt: Date;
}
