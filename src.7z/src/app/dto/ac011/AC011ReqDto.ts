import { ReqDtoBase } from "../ReqDtoBase";
import { AC011BusinessUpdateDto } from "./AC011BusinessUpdateDto";

/**
 * ご利用形態
 * 通信パラメータ
 */
export class AC011ReqDto extends ReqDtoBase {

    /** 更新用 事業者登録情報 */
    public updateDto: AC011BusinessUpdateDto;
}
