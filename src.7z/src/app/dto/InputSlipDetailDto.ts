export class InputSlipDetailDto {

	/** 仕訳明細ID */
    public journalDetailId: number = -1;

	/** 借方勘定科目ID */
    public drAcTitleId: number = -1;

	/** 借方補助科目ID */
    public drAcSubTitleId: number = -1;

	/** 貸方勘定科目ID  */
    public crAcTitleId: number = -1;

	/** 貸方補助科目ID */
    public crAcSubTitleId: number = -1;

	/** 消費税コード */
    public consumptionTaxCd: number = -1;

	/** 消費税ID */
    public taxRateId: number = -1;

	/** 業種 */
    public industryId: number = -1;

	/** 金額 */
    public journalAmount: number = 0;

	/** 消費税金額 */
    public journalTaxAmount: number = 0;

	/** 支払予定日 */
    public journalPaymentDate: Date = null;

	/** 仕訳摘要1 */
    public journalSummaryTop: string = '';

	/** 仕訳摘要2 */
    public journalSummaryBottom: string = '';

	/** 取引先ID */
    public customerId: number = -1;

	/** 部門ID */
    public segmentId: number = -1;
}

// 画面制御用プロパティを含む拡張クラス

export class InputSlipDetailDtoHeader {

    constructor (slip:InputSlipDetailDto, hasData:boolean) {
        this.slip = slip;
        this.hasData = hasData;
    }

    // データコンテキスト
    slip: InputSlipDetailDto;

    // データ有りフラグ
    hasData: boolean = false;

    // グリッドに表示する
    visible: boolean = true;

    // 消費税コードの活性/非活性フラグ
    isTaxInputEnabled: boolean = false;

    // 業種の活性/非活性フラグ
    isTaxIndustryEnabled: boolean = false;

    // 税率の活性/非活性フラグ
    isTaxRateEnabled: boolean = false;

    // 内消費税の活性/非活性フラグ
    isTaxAmountEnabled: boolean = false;

    // 相手先の活性/非活性フラグ
    isCustomerEnabled: boolean = false;

    // 部門の活性/非活性フラグ
    isSegmentEnabled: boolean = false;

    // 期日の活性/非活性フラグ
    isPaymentDateEnabled: boolean = false;
}

