// 各種定義
export const maxNumberLength: number = 12;
