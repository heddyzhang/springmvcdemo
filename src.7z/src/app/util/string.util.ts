/**
 * 文字列が空かどうか判定する
 * @param s 対象の文字列
 */
export function isEmpty(s: string): boolean {
    return s === null
        || s === undefined
        || (s.length !== undefined && s.length === 0)
        || Object.keys(s).length === 0;
}

/**
 * 文字列が空でないかどうか判定する
 * @param s 対象の文字列
 */
export function isNotEmpty(s: string): boolean {
    return !isEmpty(s);
}

/**
 * 半角換算で文字列を切り出す
 * (半角：1バイト、全角：2バイト)
 * @param s 対象の文字列
 * @param maxLen 最大桁数
 */
export function substrByByte(s: string, maxLen: number): string {
    if (!s) {
        return "";
    }

    if (maxLen <= 0) {
        return s;
    }

    const len = byteLen(s);
    const diff = len - maxLen;

    if (diff <= 0) {
        return s;
    } else {
        const sliced = s.substr(0, s.length - 1);
        return substrByByte(sliced, maxLen);
    }
}

/**
 * 文字列のバイト長を計算する
 * (半角：1バイト、全角：2バイト)
 * @param s 対象の文字列
 */
export function byteLen(s: string): number {
    let r = 0;
    for (let i = 0; i < s.length; i++) {
        r += byte(s.substring(i, i + 1));
    }
    return r;
}

/**
 * 文字列を全角(2byte)と半角文字のみに変換する
 * @param s 対象の文字列
 */
export function change1ByteAnd2ByteOnly(s: string): string {
    return changeByteStrings(s, '0');
}

/**
 * 文字列を半角文字のみに変換する
 * @param s 対象の文字列
 */
export function change1ByteOnly(s: string): string {
    return changeByteStrings(s, '1');
}

/**
 * 文字列を半角英数のみに変換する
 * @param s 対象の文字列
 */
export function change1ByteAlphaNumOnly(s: string): string {
    return changeByteStrings(s, '2');
}

/**
 * 文字列を半角数値のみに変換する
 * @param s 対象の文字列
 */
export function change1ByteNumOnly(s: string): string {
    return changeByteStrings(s, '3');
}

/**
 * 文字列を電話番号で使用できる文字のみに変換する
 * @param s 対象の文字列
 */
export function changeTelNoOnly(s: string): string {
    return changeByteStrings(s, '4');
}

/**
 * 文字列を日付で使用できる文字のみに変換して日付型で返却する
 * @param s 対象の文字列
 */
 export function changeDateOnly(s: string): Date {
    // 日付型チェック
    if (isDate(s)) return new Date(s);

    // 日付型でない場合、日付に変換できる文字列かどうかを精査する
    var ss: string = changeByteStrings(s, '5');

    // 日付型を返却する
    return (isDate(ss)) ? new Date(ss): null;
}

/**
 * 日付型チェック
 * @param s 対象の文字列
 */
function isDate(s: string) {
    var d: Date = new Date(s);
    return (d.toString() === 'Invalid Date') ? false: true;
}

/**
 * 1文字のバイト長を計算する(半角：1バイト、全角：2バイト、その他：0バイト)
 * 　参考：http://www.asahi-net.or.jp/~ax2s-kmtn/ref/unicode/index.html
 * @param s 対象の文字列
 */
function byte(s: string): number {
    // undifineは0バイトとし、無視する
    if (!s) return 0;

    let r = 0;
    const c = s.charCodeAt(0);

    // ＜1byte換算＞
    // C0制御文字、基本ラテン文字: 0x0〜0x80,
    // 0xf8f0,
    // 半角CJK句読点、半角片仮名: 0xff61〜0xff9f, 0xf8f1〜0xf8f3
    if ((c >= 0x0 && c <= 0x80) || (c == 0xf8f0) || (c >= 0xff61 && c <= 0xff9f) || (c >= 0xf8f1 && c <= 0xf8f3)) {
        r = 1;
    // ＜2byte換算＞
    // 全角ASCII、金額記号: 0xff00〜0xff5e, 0xffe0〜0xffe6
    // CJKの記号及び句読点：0x3000～0x3007
    // ひらがな: 0x3040〜0x309f
    // 全角カタカナ: 0x30a0〜0x30ff
    // 漢字: 0x3400〜0x9fff, 0xf900～0xfaff
    } else if (
        (c >= 0xff00 && c <= 0xff5e) || (c >= 0xffe0 && c <= 0xffe6) ||
        (c >= 0x3000 && c <= 0x3007) ||
        (c >= 0x3040 && c <= 0x309f) ||
        (c >= 0x30a0 && c <= 0x30ff) ||
        (c >= 0x3400 && c <= 0x9fff) || (c >= 0xf900 && c <= 0xfaff)
    ) {
        r = 2;
    // ＜0byte換算＞
    // サロゲートペア: 0xd800〜0xdbff, 0xdc00〜0xdfff
    } else if (
        (c >= 0xd800 && c <= 0xdbff) || (c >= 0xdc00 && c <= 0xdfff)
    ) {
        r = 0;
    }

    return r;
}

/**
 * 文字列を入力内容に合わせて変換する
 * @param s 対象の文字列
 * @param option オプション(0:2byteの全角と半角文字全て, 1:半角文字全て, 2:半角英数字のみ, 3:半角数字のみ, 4:電話番号, 5:日付)
 */
function changeByteStrings(s: string, option: string): string {
    // サロゲートペアに対応した配列を宣言する
    var sArray: string[] = s.match(/[\uD800-\uDBFF][\uDC00-\uDFFF]|[^\uD800-\uDFFF]/g) || [];
    var str: string = '';

    // 正規表現を定義
    const regAlphaNum = new RegExp(/^[0-9a-zA-Z]*$/);
    const regNum = new RegExp(/^[0-9]+$/);
    const regTelNo = new RegExp(/^[0-9\-()]+$/);
    const regDate = new RegExp(/^[0-9\-/]+$/);

    for (let i = 0; i < s.length; i++) {
        var c = sArray[i];
        var b: number = byte(c);
        // undifineを無視する
        if (b === 0) continue;
        // 全角(2byte)と半角文字以外を省く
        if (option === '0' && b > 2) continue;
        // 全角文字を省く
        if (option != '0' && b != 1) continue;
        // 半角英数字以外を省く
        if (option === '2' && !c.match(regAlphaNum)) continue;
        // 半角数字以外を省く
        if (option === '3' && !c.match(regNum)) continue;
        // 電話番号で使用できる文字以外を省く
        if (option === '4' && !c.match(regTelNo)) continue;
        // 日付で使用できる文字以外を省く
        if (option === '5' && !c.match(regDate)) continue;
        // 有効文字を加える
        str += c;
    }

    // 日付で使用できない文字は空にする
    // if (option === '5' && !str.match(regDate)) return null;

    return str;
}
