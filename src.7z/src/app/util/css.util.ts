import { removeClass } from "wijmo/wijmo";

// 各種定義
export type TextAlign = 'right' | 'left';
export const RequiredStyle: string = '4px solid #f00';
export const NotRequiredStyle: string = '4px solid transparent';
export let inputDefaultStyle: string = null; // スタイル定義は styles.css 参照
export const dateFieldDefaultStyle: string = '';

/**
 * CSSスタイル定義を適用する
 * @param elem 適用先の要素
 * @param style 適用するCSSスタイル定義
 */
export function applyStyle(elem: HTMLElement, style: CSSStyleDeclaration) {
    if (style) {
        Object.keys(style).forEach((key) => {
            elem.style[key] = style[key];
        });
    }
}

/**
 * 要素からWijmo Input系コントロールでLooperとスタイルが重複するクラスを削除する
 * @param elem 対象の要素
 */
export function removeDefaultWijmoInputStyle(elem: Element) {
    removeClass(elem, 'wj-content');
    removeClass(elem, 'wj-control');
}

/**
 * 必須の場合のスタイルを取得します
 * @param required 必須フラグ
 */
export function getRequiredStyle(required: boolean): string {
    return required ? RequiredStyle : NotRequiredStyle;
}
/**
 * e-text-input 系コンポーネントの既定のCSSクラス名を取得する。
 * IE とそれ以外でスタイルセットを動的に使い分ける仕組み。
 */
export function getInputDefaultStyle(): string {
    if (!inputDefaultStyle) {
        // UserAgetn を小文字に正規化
        const ua = window.navigator.userAgent.toLowerCase();
        // IE かどうか判定
        const isIE = (ua.indexOf('msie') >= 0 || ua.indexOf('trident') >= 0);
        inputDefaultStyle = isIE? 'e-input-control-ie': 'e-input-control';
    }
    return inputDefaultStyle;
}
