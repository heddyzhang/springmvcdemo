/**
 * オブジェクトのクローンを作成
 * @param source
 */
export function cloneObject(source:any): any {

    var result = Object.assign({}, source);

    for (let key in source) {
        if (source[key] !== undefined && source[key] !== null && source[key].constructor === Array) {
            result[key] = source[key].map(x => cloneObject(x));
        }
    }

    return result;
}
