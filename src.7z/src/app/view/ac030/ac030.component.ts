import { Component, OnInit, ViewChild } from '@angular/core';
import { AC030Service } from '../../service/AC030Service';
import { Router } from '@angular/router';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { AppType, ComponentBase } from '../component-base';
import { AC030ReqDto } from '../../dto/ac030/AC030ReqDto';
import { AC030AcTitleDto } from '../../dto/ac030/AC030AcTitleDto';
import { ETabBarDecoComponent } from '../../component/e-tab-bar-deco/e-tab-bar-deco.component';
import { WjFlexGridEx } from '../../component/wj-flex-grid-ex/wj-flex-grid-ex';
import { AC030ResDto } from '../../dto/ac030/AC030ResDto';
import { AC030AcSubTitleDto } from '../../dto/ac030/AC030AcSubTitleDto';
import { AC030UpdateAcTitleDto } from '../../dto/ac030/AC030UpdateAcTitleDto';
import { AC030UpdateAcSubTitleDto } from '../../dto/ac030/AC030UpdateAcSubTitleDto';
import { AC030DeleteAcSubTitleDto } from '../../dto/ac030/AC030DeleteAcSubTitleDto';
import { ResDtoBase } from '../../dto/ResDtoBase';

@Component({
    selector: 'app-ac030',
    templateUrl: './ac030.component.html',
    styleUrls: ['./ac030.component.css']
})
/**
 * AC030
 * 勘定科目登録
 * 一覧常時
 */
export class Ac030Component extends ComponentBase {

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.D_Master;

    /** 貸借区分フィルタタブへの参照 */
    @ViewChild('tabBarDeco') tabBarDeco: ETabBarDecoComponent;

    /** 主科目一覧への参照 */
    @ViewChild('acTitleGrid') acTitleGrid: WjFlexGridEx;

    /** 補助科目一覧への参照 */
    @ViewChild('acSubTitleGrid') acSubTitleGrid: WjFlexGridEx;

    /** Popupの座標 */
    popX: string;
    popY: string;

    /** 貸借区分フィルタタブのリスト */
    public acDrcrClsFilterTemplates: any[] = [
        { value: 2, label: "　　資産　　" },
        { value: 3, label: "　負債・資本　" },
        { value: 0, label: "　　費用　　" },
        { value: 1, label: "売上・その他" },
        { value: -1, label: "　　ALL　　" },
    ];

    /** 科目管理区分ドロップダウン */
    public acManagementClsMList: any[] = [
        { value: 0, label: "未設定" },
        { value: 1, label: "補助科目の設定が可能な科目" },
        { value: 3, label: "取引先の管理が出来る科目" },
    ];

    /** 科目管理区分ドロップダウン */
    public acManagementClsCashMList: any[] = [
        { value: 0, label: "未設定" },
        { value: 1, label: "補助科目の設定が可能な科目" },
    ];

    /** 事業区分ドロップダウン */
    public businessIndustryMList: any[] = [
        { value: -1, label: "未設定" },
        { value: 1, label: "第一種" },
        { value: 2, label: "第二種" },
        { value: 3, label: "第三種" },
        { value: 4, label: "第四種" },
        { value: 5, label: "第五種" },
        { value: 6, label: "第六種" },
    ];

    /** 使用していない科目を表示 true:全表示 false:使用科目のみ */
    public showNotUse: boolean = true;

    /** 貸借区分フィルタの選択値 初期値 */
    public acDrCrCls: number = -1;

    /** List<勘定科目Dto> */
    public acTitleDtoList: AC030AcTitleDto[];

    /** List<勘定科目Dto>（取消用） */
    public bkupAcTitleDtoList: AC030AcTitleDto[];

    /** 補助科目一覧 */
    public acSubTitleDtoList: AC030AcSubTitleDto[];

    /** 選択中の勘定科目 */
    public selectedAcTitle: AC030AcTitleDto = new AC030AcTitleDto();

    /** 課税方式 */
    public businessTaxClsMethod: number;

    /** 更新を行う前の勘定科目一覧の選択行 */
    public tmpRow: number;

    constructor(private ac030Service: AC030Service, private property: EcoKaikeiProperty, private router: Router) {
        super(ac030Service, property)
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // ショートカットを表示
        super.displayShortCutBtn(3, 10);

        // 課税方式の設定
        this.businessTaxClsMethod = this.property.ownershipDto.currentTaxInfoDto.businessTaxClsMethod;

        // 初期情報を取得
        this.ac030Service.getInitial(new AC030ReqDto(), this.getInitialOnResult);
    }

    public switch() {
        this.router.navigate(['view/ac031']);
    }

    /**
     * 貸借区分タブクリック
     * タブで選択したものに応じて主科目一覧をフィルタする。
     */
    public filterTabClick(): void {

        // 選択中のアイテムが取得できなかった際は処理を抜ける
        if (!this.tabBarDeco.selectedItem) {
            return;
        }

        // 選択中の貸借区分フィルタタブの値を設定
        this.acDrCrCls = this.tabBarDeco.selectedItem.value;


        // 一覧の再表示を行う
        this.flexGridRefresh();

        // フィルタ後に選択行が存在しない場合は先頭を選択
        if (this.acTitleGrid.selectedItems.length === 0) {
            this.acTitleGrid.select(0, 0);
        }
        console.log(this.acTitleGrid);
    }

    /**
     * 使用・未使用フィルタ
     * 主科目一覧.使用に従って一覧をフィルタする。
     */
    public useCheckBoxClick(): void {
        this.flexGridRefresh();

        // フィルタ後に選択行が存在しない場合は先頭を選択
        if (this.acTitleGrid.selectedItems.length === 0) {
            this.acTitleGrid.select(0, 0);
        }
    }

    /**
     * 主科目の選択
     * 主科目一覧をクリックした時
     * @param grid
     */
    public acTitleListClick(grid): void {

        if (grid.selectedItems.length !== 0) {
            // 主科目の選択が行われている場合
            this.selectedAcTitle = grid.selectedItems[0];
            this.acSubTitleDtoList = this.selectedAcTitle.acSubTitleDtoList;
        } else {
            // 主科目の選択が行われていない場合
            this.acSubTitleDtoList = null;
        }

    }

    /**
     * 内容の編集終了
     */
    public cellInput(): void {

        // 通常モード時 取消・更新ボタンを活性
        if (!this.isReferenceMode) {
            super.enabledShortCutBtn(3, true);
            super.enabledShortCutBtn(10, true);
        }

        this.selectedAcTitle.editFlg = 1;
    }

    /**
     * 補助科目の追加
     * 補助科目一覧に行を追加
     */
    public addSubBtnClick() {
        var acSubTitleDto: AC030AcSubTitleDto = new AC030AcSubTitleDto();
        acSubTitleDto.acSubTitleId = -1;
        acSubTitleDto.acTitleName = '';
        acSubTitleDto.acTitleNickname = ''
        acSubTitleDto.searchName = ''
        acSubTitleDto.consumptionTaxCls = this.selectedAcTitle.consumptionTaxCls;
        acSubTitleDto.consumptionTaxCd = this.selectedAcTitle.consumptionTaxCd;
        acSubTitleDto.businessIndustry = this.selectedAcTitle.businessIndustry;
        this.acSubTitleDtoList.push(acSubTitleDto);

        // 補助科目一覧を再表示する
        this.acSubTitleGrid.collectionView.refresh();
        this.acSubTitleGrid.refresh(true);
    }

    /**
     * 削除ボタンの押下処理
     * 補助科目行を削除
     * @param deleteItem
     */
    public deleteSubBtnClick(deleteItem: AC030AcSubTitleDto): void {

        // データ取得に失敗
        if (deleteItem === null) {
            return;
        }

        // 確認ダイアログ 選択された情報を削除しますか？
        this.eAlert.message('120021', [], null, () => {
            // 追加行の削除
            if (deleteItem.acSubTitleId === -1) {
                this.acSubTitleDtoList.splice(this.acSubTitleDtoList.findIndex(n => n === deleteItem), 1);
                this.acSubTitleGrid.collectionView.refresh();

                return;
            }

            // リクエストDTO
            var reqDto: AC030ReqDto = new AC030ReqDto();
            reqDto.deleteAcSubTitleDto = new AC030DeleteAcSubTitleDto();
            reqDto.deleteAcSubTitleDto.acTitleId = this.selectedAcTitle.acTitleId;
            reqDto.deleteAcSubTitleDto.acSubTitleId = deleteItem.acSubTitleId;
            reqDto.deleteAcSubTitleDto.updatedAt = deleteItem.updatedAt;
            // 補助科目の削除処理
            this.ac030Service.deleteAcSubTitle(reqDto, this.deleteAcSubTitleOnResult);
        });
    }

    /**
     * 取消ボタンの押下処理
     * 編集前に戻す
     */
    public cancelBtnClick(): void {

        // 変更を取り消す
        this.acTitleDtoList = JSON.parse(JSON.stringify(this.bkupAcTitleDtoList));
        // 選択を取消
        this.acTitleGrid.select(0, 0);
        // ボタンの制御
        super.enabledShortCutBtn(3, false);
        super.enabledShortCutBtn(10, false);
    }

    /**
     * 更新ボタンの押下処理
     * クライアントの情報を収集しサーバサイドへ通信し勘定科目（DB)の更新を行う。
     */
    public updateBtnClick(): void {

        // 補助科目にエラーがある場合trueになる。
        var subCheckFlg = false;

        // 入力チェック
        for (var i: number = 0; i < this.acTitleGrid.collectionView.items.length; i++) {
            var item: AC030AcTitleDto = this.acTitleGrid.collectionView.items[i];

            if (item.editFlg == 1) {
                // 編集フラグが１の場合でかつ、勘定科目使用区分チェックボックスがついている場合に実施
                if (!item.acTitleName && item.acUseClsFlg == true) {
                    // 主科目一覧.使用チェックボックスがチェック付きで かつ 勘定科目名が空の場合はエラー
                    this.eAlert.message('210001', ['勘定科目名'], null, () => {
                        // 部門名称にフォーカスを設定
                        this.acTitleGrid.select(i, 0);
                        this.acTitleGrid.focusCellInput(i, 3);
                    });

                    return;
                }

                if (!item.acTitleNickname && item.acUseClsFlg == true) {
                    // 主科目一覧.使用チェックボックスがチェック付きで かつ 略称が空の場合はエラー
                    this.eAlert.message('210001', ['勘定科目略称'], null, () => {
                        // 部門名称にフォーカスを設定
                        this.acTitleGrid.select(i, 0);
                        this.acTitleGrid.focusCellInput(i, 4);
                    });

                    return;
                }

                if (!item.searchName && item.acUseClsFlg == true) {
                    // 主科目一覧.使用チェックボックスがチェック付きで かつ 検索名称が空の場合はエラー
                    this.eAlert.message('210001', ['勘定科目検索名称'], null, () => {
                        // 部門名称にフォーカスを設定
                        this.acTitleGrid.select(i, 0);
                        this.acTitleGrid.focusCellInput(i, 5);
                    });

                    return;
                }

                // 補助科目DTO チェック
                // このループでエラーを見つけた場合、collectionViewをループさせ補助の入力欄をフォーカスさせる。
                for (var acSubTitleDto of item.acSubTitleDtoList) {

                    // 補助科目コード、補助科目名、補助科目略称、補助科目検索名称が空の場合エラー
                    if (!acSubTitleDto.acSubTitleCd
                        || !acSubTitleDto.acTitleName
                        || !acSubTitleDto.acTitleNickname
                        || !acSubTitleDto.searchName) {
                        this.acTitleGrid.select(i, 0);
                        this.acSubTitleGrid.itemsSource = this.acSubTitleDtoList;
                        this.acSubTitleGrid.collectionView.refresh();
                        subCheckFlg = true;
                        break;
                    }
                }

                if (subCheckFlg) {
                    // 補助科目のcollectionViewをループ
                    for (var j: number = 0; j < this.acSubTitleGrid.collectionView.items.length; j++) {
                        var subItem: AC030AcSubTitleDto = this.acSubTitleGrid.collectionView.items[j];
                        if (!subItem.acSubTitleCd) {
                            // コードが空の場合はエラー
                            this.eAlert.message('210001', ['補助科目コード'], null, () => {
                                // 補助科目コードにフォーカスを設定
                                this.acSubTitleGrid.select(j, 0);
                                this.acSubTitleGrid.focusCellInput(j, 0);
                            });

                            return;
                        }

                        if (!subItem.acTitleName) {
                            // 勘定科目名が空の場合はエラー
                            this.eAlert.message('210001', ['補助科目名'], null, () => {
                                // 補助科目コードにフォーカスを設定
                                this.acSubTitleGrid.select(j, 0);
                                this.acSubTitleGrid.focusCellInput(j, 1);
                            });

                            return;
                        }

                        if (!subItem.acTitleNickname) {
                            // 略称が空の場合はエラー
                            this.eAlert.message('210001', ['補助科目略称'], null, () => {
                                // 補助科目コードにフォーカスを設定
                                this.acSubTitleGrid.select(j, 0);
                                this.acSubTitleGrid.focusCellInput(j, 2);
                            });

                            return;
                        }

                        if (!subItem.searchName) {
                            // 検索名称が空の場合はエラー
                            this.eAlert.message('210001', ['補助科目検索名称'], null, () => {
                                // 補助科目コードにフォーカスを設定
                                this.acSubTitleGrid.select(j, 0);
                                this.acSubTitleGrid.focusCellInput(j, 3);
                            });

                            return;
                        }
                    }
                }
            }
        }

        // 確認ダイアログ 更新します。よろしいですか？
        this.eAlert.message('120023', [], null, () => {
            // リクエストDTO
            var reqDto: AC030ReqDto = new AC030ReqDto();

            // サーバに送るリクエストDTO
            var updateAcTitleDtoList: AC030UpdateAcTitleDto[] = new Array(0);

            // ループさせ編集フラグが１になっているもののみを詰め込み
            for (var acTitleDto of this.acTitleDtoList) {
                if (acTitleDto.editFlg == 1) {
                    var updateAcTitleDto: AC030UpdateAcTitleDto = new AC030UpdateAcTitleDto();
                    updateAcTitleDto.acTitleId = acTitleDto.acTitleId;
                    updateAcTitleDto.acTitleCd = acTitleDto.acTitleCd;
                    updateAcTitleDto.acTitleName = acTitleDto.acTitleName;
                    updateAcTitleDto.acTitleNickname = acTitleDto.acTitleNickname;
                    updateAcTitleDto.searchName = acTitleDto.searchName;
                    updateAcTitleDto.consumptionTaxCd = acTitleDto.consumptionTaxCd;
                    updateAcTitleDto.acManagementCls = acTitleDto.acManagementCls;
                    updateAcTitleDto.acTitleSummary = acTitleDto.acTitleSummary;
                    updateAcTitleDto.acUseClsFlg = acTitleDto.acUseClsFlg;
                    updateAcTitleDto.businessIndustry = acTitleDto.businessIndustry;
                    updateAcTitleDto.updatedAt = acTitleDto.updatedAt;

                    var updateAcSubTitleDtoList: AC030UpdateAcSubTitleDto[] = new Array(0);
                    if (acTitleDto.acManagementCls === 1 && acTitleDto.mtAccountCls == 0) {
                        // 科目管理区分が「１:補助科目を管理する」かつマネーツリー口座管理区分 が「0：設定できない科目」の時補助科目リストを格納
                        for (var acSubTitleDto of acTitleDto.acSubTitleDtoList) {
                            var updateAcSubTitleDto: AC030UpdateAcSubTitleDto = new AC030UpdateAcSubTitleDto();
                            updateAcSubTitleDto.acSubTitleId = acSubTitleDto.acSubTitleId;
                            updateAcSubTitleDto.acSubTitleCd = acSubTitleDto.acSubTitleCd;
                            updateAcSubTitleDto.acTitleName = acSubTitleDto.acTitleName;
                            updateAcSubTitleDto.acTitleNickname = acSubTitleDto.acTitleNickname;
                            updateAcSubTitleDto.searchName = acSubTitleDto.searchName;
                            updateAcSubTitleDto.consumptionTaxCd = acSubTitleDto.consumptionTaxCd;
                            updateAcSubTitleDto.businessIndustry = acSubTitleDto.businessIndustry;
                            updateAcSubTitleDto.updatedAt = acSubTitleDto.updatedAt;
                            updateAcSubTitleDtoList.push(updateAcSubTitleDto);
                        }
                    }
                    updateAcTitleDto.updateAcSubTitleDtoList = updateAcSubTitleDtoList;
                    updateAcTitleDtoList.push(updateAcTitleDto);
                }

            }

            reqDto.updateAcTitleDtoList = updateAcTitleDtoList;

            // 更新処理の呼び出し
            this.ac030Service.update(reqDto, this.updateOnResult);
        });


    }

    /**
     * 一覧の再表示を行う
     */
    private flexGridRefresh(): void {

        // 参照エラー時は処理を中断
        if (!this.acTitleGrid || !this.acTitleGrid.collectionView) {
            return;
        }

        // フィルターの設定
        this.acTitleGrid.collectionView.filter = this.filterFunction.bind(this);
    }

    /**
     * 貸借区分 / 使用していない科目を表示しない によるフィルタ
     * @param item
     */
    private filterFunction(item: AC030AcTitleDto): boolean {

        // 使用していない科目を表示しない
        if (!this.showNotUse && item.acUseClsFlg === false) {
            return false;
        }

        // 貸借区分 => 絞り込み
        if (this.acDrCrCls !== -1 && this.acDrCrCls !== item.acDrcrCls) {
            return false;
        }

        return true;
    }

    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     * @param resDto
     */
    private getInitialOnResult(resDto: AC030ResDto): void {

        // 主科目一覧の設定
        this.acTitleDtoList = resDto.acTitleDtoList;
        this.bkupAcTitleDtoList = JSON.parse(JSON.stringify(this.acTitleDtoList));

        // 初期表示時の選択
        this.selectedAcTitle = this.acTitleDtoList[0];
        this.acSubTitleDtoList = this.selectedAcTitle.acSubTitleDtoList;

        // 貸借区分フィルタを初期化（ALL）
        this.tabBarDeco.tabBar.selectedIndex = 4;

        // 印刷　活性
        // 取消・更新　非活性
        super.enabledShortCutBtn(8, true);
        super.enabledShortCutBtn(3, false);
        super.enabledShortCutBtn(10, false);

    }

    /**
     * 更新処理 完了
     * @param resDto
     */
    private updateOnResult(resDto: AC030ResDto): void {

        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            if (resDto.errorActitleId) {
                // 勘定科目IDが設定されて返却した場合、一覧を選択する。
                for (var i: number = 0; i < this.acTitleGrid.collectionView.items.length; i++) {
                    var item: AC030AcTitleDto = this.acTitleGrid.collectionView.items[i];
                    if (resDto.errorActitleId === item.acTitleId) {
                        this.acTitleGrid.select(i, 0);
                    }
                }
            }
            return;
        }

        // 主科目一覧の設定
        this.acTitleDtoList = resDto.acTitleDtoList;
        this.bkupAcTitleDtoList = JSON.parse(JSON.stringify(this.acTitleDtoList));

        // 勘定科目ポップアップを更新
        this.property.acTitlePopupItemList = resDto.acTitlePopupItemList;
        this.property.acSubTitlePopupItemList = resDto.acSubTitlePopupItemList;

        // 取消・更新　非活性
        super.enabledShortCutBtn(3, false);
        super.enabledShortCutBtn(10, false);
    }

    /**
     *  補助科目削除処理 完了
     * @param resDto
     */
    private deleteAcSubTitleOnResult(resDto: AC030ResDto): void {

        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        if (resDto.bkupAcSubTitleDto) {
            // 補助科目の更新日時が進んでいるため削除しようとしたレコードを再取得し表示
            this.acSubTitleDtoList.splice(
                this.acSubTitleDtoList.findIndex(n => n.acSubTitleId === resDto.bkupAcSubTitleDto.acSubTitleId), 1, resDto.bkupAcSubTitleDto);

        } else {

            // 勘定科目ポップアップを更新
            this.property.acSubTitlePopupItemList = resDto.acSubTitlePopupItemList;

            // 削除した補助科目を一覧から削除
            this.acSubTitleDtoList.splice(this.acSubTitleDtoList.findIndex(n => n.acSubTitleId === resDto.deleteAcSubTitleResult), 1);
        }


        this.acSubTitleGrid.collectionView.refresh();

        // 削除した対象でbackup
        this.bkupAcTitleDtoList = JSON.parse(JSON.stringify(this.acTitleDtoList));
    }
}
