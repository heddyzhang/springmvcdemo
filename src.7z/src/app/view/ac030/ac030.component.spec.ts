import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac030Component } from './ac030.component';

describe('Ac030Component', () => {
  let component: Ac030Component;
  let fixture: ComponentFixture<Ac030Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac030Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac030Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
