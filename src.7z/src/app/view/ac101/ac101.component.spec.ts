import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac101Component } from './ac101.component';

describe('Ac101Component', () => {
  let component: Ac101Component;
  let fixture: ComponentFixture<Ac101Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac101Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac101Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
