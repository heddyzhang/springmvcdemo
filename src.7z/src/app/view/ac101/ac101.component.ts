import { Component, OnInit } from '@angular/core';
import { ComponentBase, AppType } from '../component-base';
import { AC101Service } from '../../service/AC101Service';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { AC101ReqDto } from '../../dto/ac101/AC101ReqDto';
import { AC101ResDto } from '../../dto/ac101/AC101ResDto';
import { AC101SendMailDto } from '../../dto/ac101/AC101SendMailDto';

@Component({
    selector: 'app-ac101',
    templateUrl: './ac101.component.html',
    styleUrls: ['./ac101.component.css']
})
export class Ac101Component extends ComponentBase {

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.F_Administrator;

    /** コンストラクタ */
    constructor(private ac101Service: AC101Service, private property: EcoKaikeiProperty) {
        super(ac101Service, property);
    }

    /** メールアドレス */
    public mailAddress1: string = '';

    /** メールアドレス：確認用 */
    public mailAddress2: string = '';

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // 初期情報を取得
        this.ac101Service.getInitial(new AC101ReqDto(), this.getInitialOnResult);
    }

    /**
     * メールを送信ボタンの押下処理
     */
    public sendMail(): void {

        // 必須項目のチェック
        // 招待する方のメールアドレス
        if (!this.mailAddress1) {
            // "招待する方のメールアドレス"は入力必須の項目です。
            this.eAlert.message('210001', ['招待する方のメールアドレス'], 'mailAddress1');
            return;
        }
        // メールアドレスの確認
        else if (!this.mailAddress2) {
            // "メールアドレスの確認"は入力必須の項目です。
            this.eAlert.message('210001', ['確認用のメールアドレス'], 'mailAddress2');
            return;
        }
        // 招待する方のメールアドレスとメールアドレスの確認が異なる場合
        else if (this.mailAddress1 !== this.mailAddress2) {
            // "確認用のメールアドレス"が一致していません。
            this.eAlert.message('211035', ['確認用のメールアドレス'], 'mailAddress1');
            return;
        }

        // メールを送信します。\nよろしいですか？
        this.eAlert.message('120027', [], null, () => {

            // リクエストを生成
            var reqDto: AC101ReqDto = new AC101ReqDto();
            reqDto.sendMailDto = new AC101SendMailDto();

            // メールアドレス
            reqDto.sendMailDto.mailAddress = this.mailAddress1;

            // メールを送信処理を実行
            this.ac101Service.sendMail(reqDto, this.sendMailOnResult);
        });
    }

    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     */
    private getInitialOnResult(resDto: AC101ResDto): void {

        // フォーカスを設定する
        document.getElementById('mailAddress1').focus();

        // TODO 手続きの進捗状況一覧情報
    }

    private sendMailOnResult(resDto: AC101ResDto): void {

        // TODO 手続きの進捗状況一覧情報
    }
}
