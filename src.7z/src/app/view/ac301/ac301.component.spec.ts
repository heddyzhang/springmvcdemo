import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac301Component } from './ac301.component';

describe('Ac301Component', () => {
  let component: Ac301Component;
  let fixture: ComponentFixture<Ac301Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac301Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac301Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
