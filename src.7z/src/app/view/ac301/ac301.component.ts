import { Component, ViewChild } from '@angular/core';
import { ComponentBase, AppType } from '../component-base';
import { EConfigureReportPopComponent } from '../../component/e-configure-report-pop/e-configure-report-pop.component';
import { AC301Service } from '../../service/AC301Service';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { Router } from '@angular/router';
import { AC301ViewChangeBean } from '../../bean/AC301ViewChangeBean';
import { AC300ViewChangeBean } from '../../bean/AC300ViewChangeBean';
import { AC301ReqDto } from '../../dto/ac301/AC301ReqDto';
import { AC301SummaryDto } from '../../dto/ac301/AC301SummaryDto';
import { CellType, FormatItemEventArgs } from 'wijmo/wijmo.grid';
import { WjFlexGridEx } from '../../component/wj-flex-grid-ex/wj-flex-grid-ex';
import { AC301ResDto } from '../../dto/ac301/AC301ResDto';
import { MonthItemDto } from '../../dto/MonthItemDto';

@Component({
    selector: 'app-ac301',
    templateUrl: './ac301.component.html',
    styleUrls: ['./ac301.component.css']
})
export class Ac301Component extends ComponentBase {

    /** アプリケーションIDを設定 */
    private appID: string = 'ac301';

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.C_Report;

    @ViewChild('reportPop')
    /** 印刷条件ポップアップ */
    private reportPop: EConfigureReportPopComponent;

    @ViewChild(WjFlexGridEx)
    /** グリッドへの参照 */
    private flexGrid: WjFlexGridEx;

    /** 選択中の会計年度 */
    public selectedYear: number;

    /** 補助科目を表示する フラグ */
    public showSubTitle: boolean = false;

    /** 選択開始月 */
    private startMonth: number = -1;

    /** 選択終了月 */
    private endMonth: number = -1;

    /** 単位 (0: 円 1: 千円 2: 百万円) */
    public selectUnit: number = 0;

    /**  */
    public summaryDtoList: AC301SummaryDto[];

    /** ショートカットボタン */
    protected shortcutBtnDefs: any = {
        'all': [
            { tagNo: 1, enabled: true }, { tagNo: 8, enabled: true },
        ],
    }

    /** コンストラクタ */
    constructor(private ac301Service: AC301Service, private property: EcoKaikeiProperty, private router: Router) {
        super(ac301Service, property);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // ショートカットを表示
        super.displayShortCutBtn(1, 8);

        // ショートカットボタンの名称を変える
        this.viewBaseButton1.value = '戻る';
        this.shortCutRefresh();

        // ショートカットの制御を行う
        this.setShortcutBtnDefs('all');

        // Ac300からの受け渡しパラメータを設定する
        var bean: AC301ViewChangeBean = this.property.getViewChangeBeans(this.appID) as AC301ViewChangeBean;

        // 選択中の会計年度
        this.selectedYear = bean.selectedYear;

        // 補助科目を表示する フラグ
        this.showSubTitle = bean.showSubTitle;

        // 選択開始月
        this.startMonth = bean.startMonth;

        // 選択終了月
        this.endMonth = bean.endMonth;

        // 期間開始
        var startMonth: string = this.property.getYearMonthLabel(this.selectedYear, this.startMonth);

        // 期間終了
        var endMonth: string = this.property.getYearMonthLabel(this.selectedYear, this.endMonth);

        // タイトル部分に期間を表示
        this.base.title = '貸借対照表　' + startMonth + '～' + endMonth;

        // 単位 (0: 円 1: 千円 2: 百万円)
        this.selectUnit = bean.selectUnit;

        // 初期情報を取得
        var req: AC301ReqDto = new AC301ReqDto();
        req.selectedYear = this.selectedYear;
        req.startMonth = this.startMonth;
        req.endMonth = this.endMonth;
        req.selectUnit = this.selectUnit;

        this.ac301Service.getInitial(req, this.getInitialOnResult);
    }

    /**
     * 背景色の設定
     * @param e
     */
    public formatItem(e: FormatItemEventArgs): void {

        // Cellのみ反映
        if (e.panel.cellType === CellType.Cell) {
            // 背景色を設定する
            e.cell.style.backgroundColor = this.flexGrid.collectionView.items[e.row].backgroundColor;
        }
    }

    /**
     * 一覧の再表示を行う
     */
    public flexGridRefresh(): void {

        // 参照エラー時は処理を中断
        if (!this.flexGrid || !this.flexGrid.collectionView) {
            return;
        }

        // フィルターの設定
        this.flexGrid.collectionView.filter = this.filterFunction.bind(this);
    }

    /**
     * 補助科目を表示するかどうか
     * @param item
     */
    private filterFunction(item: AC301SummaryDto): boolean {

        // 補助科目を表示しない
        if (!this.showSubTitle && item.acSubTitleId !== null && item.acSubTitleId !== -1) {
            return false;
        }

        return true;
    }

    /**
     * 戻るボタンの押下処理
     */
    public removeBtnClick(): void {

        // 遷移用パラメータを生成する
        var ac300bean: AC300ViewChangeBean = new AC300ViewChangeBean(this.selectedYear
            , this.showSubTitle, this.startMonth, this.endMonth, 0, this.selectUnit, false);

        // パラメータの設定を行う
        this.property.setViewChangeBeans(ac300bean, this.appID, 'ac300');

        // 貸借対照表
        this.router.navigate(['view/ac300', { param: '1' }]);
    }

    /**
     * 印刷ボタンの押下処理
     */
    public printBtnClick(): void {

        // リクエストを生成
        var reqDto: AC301ReqDto = new AC301ReqDto();
        reqDto.selectedYear = this.selectedYear;
        reqDto.showSubTitle = this.showSubTitle;
        reqDto.startMonth = this.startMonth;
        reqDto.endMonth = this.endMonth;
        reqDto.selectUnit = this.selectUnit;

        this.reportPop.show(reqDto, () => {
            // 印刷のプレ処理 => 印刷 を行う
            this.ac301Service.onPrint(reqDto, '集計表');
        });
    }

    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     */
    private getInitialOnResult(resDto: AC301ResDto): void {

        // 一覧表を作成
        this.summaryDtoList = resDto.summaryDtoList;
    }
}
