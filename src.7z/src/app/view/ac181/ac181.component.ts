import { Component, OnInit, Output, EventEmitter, ViewChild } from '@angular/core';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { ComponentBase, AppType } from '../component-base';
import { AC181Service } from '../../service/AC181Service';
import { AC181ReqDto } from '../../dto/ac181/AC181ReqDto';
import { AC181ResDto } from '../../dto/ac181/AC181ResDto';
import { CommonInputSlipDto } from '../../dto/CommonInputSlipDto';
import { CellRangeEventArgs, GridPanel } from 'wijmo/wijmo.grid';
import { AC181SlipHeaderDto } from '../../dto/ac181/AC181SlipHeaderDto';
import { AC181SlipDetailDto } from '../../dto/ac181/AC181SlipDetailDto';
import { EMonthSliderSelectRMonth } from '../../component/e-month-slider/e-month-slider.component';
import { UnprocessedEviComponent } from '../../component/unprocessed-evi/unprocessed-evi.component';
import { WjFlexGridEx } from '../../component/wj-flex-grid-ex/wj-flex-grid-ex';

enum AC181GridMode {
    // 見出表示モード
    M_Header = 0,
    // 明細表示モード
    M_Detail = 1
}

@Component({
    selector: 'app-ac181',
    templateUrl: './ac181.component.html',
    styleUrls: ['./ac181.component.css']
})
export class Ac181Component extends ComponentBase {

    // 子コンポーネント
    @ViewChild('slipListGrid') slipListGrid: WjFlexGridEx;

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.B_CreateSlip;

    // 見出／明細スイッチ
    public gridMode: AC181GridMode = AC181GridMode.M_Header;

    // 見出／明細切り替えボタンの表示文字テンプレート
    public gridModeButtonLabels = ['明細表示', '見出表示'];

    // 当期／翌期
    public fisicalYearCd: number = this.property.ownershipDto.selectFisicalYear;

    // 月次スライダーで選択された開始月と終了月
    public selectedFromMonth: number = -1;
    public selectedToMonth: number = -1;
    public selectedFromDate: Date = null;
    public selectedToDate: Date = null;

    // サーバーから取得したレスポンスデータ
    private resDto: AC181ResDto;

    // グリッドにバインドする伝票リスト
    public slipList: AC181SlipHeaderDto[] | AC181SlipDetailDto[];

    // 子コンポーネント（CP040）にバインドした伝票入力共通DTO
    public commonInputSlip: CommonInputSlipDto;

    // 証憑コンポーネントで選択された証憑ID
    public selectedVoucherId: number | null = null;    // 証憑ID（数値）または null

    // 子コンポーネント（CP040）にバインドした伝票入力共通DTO
    public parentView: string = "AC181";

    constructor(private ac181Service: AC181Service, public property: EcoKaikeiProperty) {
        super(ac181Service, property);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // 月次スライダーの選択状態を初期化
        this.selectedFromMonth = -1;
        this.selectedToMonth = -1;
        this.selectedFromDate = null;
        this.selectedToDate = null;

        // サーバーから取得したレスポンスデータ
        this.resDto = null;

        // グリッドにバインドする伝票リスト
        this.slipList = null;

        // 子コンポーネント（CP040）にバインドした伝票入力共通DTO
        this.commonInputSlip = null;

        // 証憑コンポーネントで選択された証憑ID
        this.selectedVoucherId = null;
    }

    /**
     * 当期/翌期ボタンのクリックイベントハンドラー
     * @param addition
     */
    public fySelectionOnChange(addition: number): void {
        // getSlipList 呼び出し時の会計年度パラメーターをセットする（翌期の場合は+1する）
        this.fisicalYearCd = this.property.ownershipDto.selectFisicalYear + addition;
    }

    /**
     * 見出/明細切り替えボタンのクリックイベントハンドラー
     */
    public gridModeButtonOnClick(): void {
        // M_Header(0) と M_Detail(1) をビット反転
        this.gridMode = ~this.gridMode & 1;
        // グリッドのデータソースを変更
        this.slipList = this.gridMode === AC181GridMode.M_Header ? this.resDto.ac181SlipHeaderDtoList : this.resDto.ac181SlipDetailDtoList;
    }

    /**
     * 月度バーの選択変更処理
     * @param event 選択中の月
     */
    public monthSliderChage(event: EMonthSliderSelectRMonth): void {

        // 選択された開始月と終了月を保存
        this.selectedFromMonth = event.fromRMonth;
        this.selectedToMonth = event.toRMonth;

        // 月情報から日付を取得
        var mItem = this.property.ownershipDto.monthItemDtoList.find(m => m.fisicalYearCd === this.fisicalYearCd && m.fromDateMonth === event.fromRMonth);
        if (mItem) {
            this.selectedFromDate = new Date(mItem.fromDate);
        }
        mItem = this.property.ownershipDto.monthItemDtoList.find(m => m.fisicalYearCd === this.fisicalYearCd && m.toDateMonth === event.toRMonth);
        if (mItem) {
            this.selectedToDate = new Date(mItem.toDate);
        }

        // 選択された期間の買掛伝票を取得
        var req_dto = new AC181ReqDto();
        req_dto.fisicalYearCd = req_dto.fisicalYearCdJournal = this.fisicalYearCd;
        req_dto.journalMonthFrom = this.selectedFromMonth;
        req_dto.journalMonthTo = this.selectedToMonth;
        this.ac181Service.getSlipList(req_dto, this.getSlipListOnResult);
    }

    /**
     * グリッドの行選択変更イベントハンドラー
     */
    public gridSelectionChanged(e: CellRangeEventArgs): void {

        // グリッドで選択されたレコードに対応する伝票入力共通DTOをCP040にバインドする
        this.setCurrentSlip(e.panel.grid.selectedItems[0]);
    }

    /**
     * グリッドで選択されたレコードに対応する伝票入力共通DTOをCP040にバインドする
     * @param slip
     */
    private setCurrentSlip(slip: any): void {

        console.log('selectionChanged: journalId = ' + (slip ? slip.journalId : '-'));

        if (slip) {
            // グリッドで選択されたレコードに対応する伝票入力共通DTOをCP040にバインドする
            // commonInputSlipDto は会計年度コード、仕訳相対月、仕訳伝票種別、仕訳IDでマッチングする
            this.commonInputSlip = this.resDto.commonInputSlipDtoList
                .filter(dto =>
                    dto.fisicalYearCd === slip.fisicalYearCd &&
                    dto.journalMonth === slip.journalMonth &&
                    dto.journalSlipType === slip.journalSlipType &&
                    dto.journalId === slip.journalId)[0];

            // データエラーチェック
            if (!this.commonInputSlip) {
                console.error("FATAL ERROR: ac180.component: 致命的なデータエラーを検出しました。会計年度コード、仕訳相対月、仕訳伝票種別、仕訳ID にマッチする共通入力レコードがありません。");
                return;
            }

            // 証憑IDを抽出
            this.selectedVoucherId = this.commonInputSlip.voucherId? this.commonInputSlip.voucherId: null;
        }
        else {
            this.commonInputSlip = null;
            this.selectedVoucherId = null;
        }
    }

    /**
     * acPayableSlip で伝票追加ボタンがクリックされた
     * @param slip
     */
    public addBtnOnClick(slip: CommonInputSlipDto): void {

        // グリッドの選択状態をクリアー
        this.slipListGrid.select(-1, -1);

        // unprocessed-evi(CP200) を表示
        this.commonInputSlip = null;
        this.selectedVoucherId = null;
    }

    /**
     * acPayableSlip で伝票削除ボタンがクリックされた
     * @param slip
     */
    public deleteBtnOnClick(slip: CommonInputSlipDto): void {

        // 確認ダイアログ 選択された情報を削除しますか？
        this.eAlert.message('120021', [], null, () => {

            // 削除用リクエストを生成する
            var reqDto: AC181ReqDto = new AC181ReqDto();
            reqDto.commonInputSlipDto = slip;

            // 現在の証憑IDをセットする
            reqDto.commonInputSlipDto.voucherId = this.selectedVoucherId;

            // API 呼び出し
            this.ac181Service.delete(reqDto, this.deleteOnResult);
        });
    }

    /**
     * acPayableSlip で更新ボタンがクリックされた
     * @param slip
     */
    public updateBtnOnClick(slip: CommonInputSlipDto): void {

        //-----------------------------
        // 入力チェック
        //-----------------------------

        // 伝票入力共通DTO.貸方勘定科目ID
        if (slip.crAcTitleId === -1) {
            // "貸方科目"は入力必須の項目です。
            this.eAlert.message('210001', ['貸方科目']);
            return;
        }
        // 伝票入力共通DTO.取引先ID
        if (slip.customerId === -1) {
            // "仕入先"は入力必須の項目です。
            this.eAlert.message('210001', ['仕入先']);
            return;
        }

        var hasError = false;

        slip.slipDetailDtoList.forEach(item => {

            // 伝票入力共通DTO.伝票明細リスト.借方勘定科目ID
            if (!hasError && item.drAcTitleId === -1) {

                // "相手科目"は入力必須の項目です。
                this.eAlert.message('210001', ['相手科目']);
                hasError = true;
                return;
            }

            // 伝票入力共通DTO.伝票明細リスト.金額
            if (!hasError && !item.journalAmount) {

                // "金額"は入力必須の項目です。
                this.eAlert.message('210001', ['金額']);
                hasError = true;
                return;
            }
        });

        // エラーがあった場合は処理を中止
        if (hasError) {
            return;
        }

        // 確認ダイアログ 入力したデータを登録しますか？
        this.eAlert.message('120022', [], null, () => {

            //-----------------------------
            // API 呼び出し
            //-----------------------------

            var req = new AC181ReqDto();
            req.commonInputSlipDto = slip;
            req.fisicalYearCd = req.fisicalYearCdJournal = this.fisicalYearCd;
            req.journalMonthFrom = this.selectedFromMonth;
            req.journalMonthTo = this.selectedToMonth;

            // 現在の証憑IDをセットする
            req.commonInputSlipDto.voucherId = this.selectedVoucherId;

            if (slip.journalId === -1) {

                // 新規データの場合のみ必要なパラメーター
                req.commonInputSlipDto.fisicalYearCd = this.fisicalYearCd;

                // 新規データの場合は insert
                this.ac181Service.insert(req, this.insertOnResult);
            }
            else {
                // 既存データの場合は update
                this.ac181Service.update(req, this.updateOnResult);
            }
        });
    }

    /**
     * UnlinkEvi から「リンク解除」イベントが発行された（削除ボタンクリック？）
     */
    public unlinkEviOnUnlink(): void {
        // 「リンク解除」のクリックは、CP030の「取消」ボタンの活性／非活性化に影響しない。
        // リンク解除がクリックされた（CP030側でvoucharIdが-1にリセットされた）→CP030側で「取消」ボタンがクリックされた。という流れがあった場合でも、voucharIdは元の値に復元される必要はない。
        this.selectedVoucherId = null;
    }

    /**
     * /api/ac181/getSlipList 呼び出し完了時のコールバック関数
     * @param res サーバーから取得した伝票データ
     */
    public getSlipListOnResult(res: AC181ResDto): void {

        // API側でエラーを検出した(messageIdが "1xxxxx" でない)場合は何も処理しない
        if (res.messageId && !res.messageId.match(/^1/)) {
            return;
        }

        console.log(res);

        // レスポンスデータを保存
        this.resDto = res;

        // 見出表示／明細表示 スイッチにより AC181SlipHeaderDto か AC181SlipDetailDto を選択してグリッドにバインド
        this.slipList = this.gridMode === AC181GridMode.M_Header ? this.resDto.ac181SlipHeaderDtoList : this.resDto.ac181SlipDetailDtoList;

        // グリッド初期化時に selectionChanged イベントが発火しないので手動でCP040へのデータバインドを行う
        this.setCurrentSlip(this.slipList.length > 0 ? this.slipList[0] : null);
    }

    /**
     * /api/ac181/insert 呼び出し完了時のコールバック関数
     * @param res
     */
    private insertOnResult(res: AC181ResDto): void {

        // API側でエラーを検出した(messageIdが "1xxxxx" でない)場合は何も処理しない
        if (res.messageId && !res.messageId.match(/^1/)) {
            return;
        }

        // サーバから返された伝票（見出表示）Dtoを
        // 伝票一覧（見出表示）の最後に追加する。
        this.resDto.ac181SlipHeaderDtoList.push(res.ac181SlipHeaderDto);

        // サーバから返された伝票（明細表示）Dtoを
        // 伝票一覧（明細表示）の最後に追加する。
        this.resDto.ac181SlipDetailDtoList = this.resDto.ac181SlipDetailDtoList.concat(res.ac181SlipDetailDtoList);

        // サーバから返された伝票入力共通DTOを
        // List<伝票入力共通DTO>の最後に追加する。
        this.resDto.commonInputSlipDtoList = this.resDto.commonInputSlipDtoList.concat(res.commonInputSlipDtoList);

        // グリッドの選択状態をクリアー
        this.slipListGrid.select(-1, -1);
        this.slipListGrid.collectionView.refresh();
        this.slipListGrid.refresh(true);

        // 買掛伝票入力を初期化する。（追加モード）
        // 買掛伝票入力.仕訳日付について、先ほど入力した情報を設定する。
        var header = res.ac181SlipHeaderDto;
        var slip = this.resDto.commonInputSlipDtoList.find(s => s.journalMonth === header.journalMonth && s.journalSlipType === header.journalSlipType && s.journalId === header.journalId);
        if (slip) {
            var newSlip = new CommonInputSlipDto();
            newSlip.journalDate = slip.journalDate;
            this.commonInputSlip = newSlip;
        }
    }

    /**
     * /api/ac181/update 呼び出し完了時のコールバック関数
     * @param res
     */
    private updateOnResult(res: AC181ResDto): void {

        // API側でエラーを検出した(messageIdが "1xxxxx" でない)場合は何も処理しない
        if (res.messageId && !res.messageId.match(/^1/)) {
            return;
        }

        var header = res.ac181SlipHeaderDto;

        // サーバから返された伝票（見出表示）Dtoを伝票一覧（見出表示）の該当する行
        // （キー：仕訳相対月、仕訳伝票種別、仕訳ID）を置き換える。
        var slip:any = this.resDto.ac181SlipHeaderDtoList.find(s => s.journalMonth === header.journalMonth && s.journalSlipType === header.journalSlipType && s.journalId === header.journalId);
        var index = this.resDto.ac181SlipHeaderDtoList.indexOf(slip);
        this.resDto.ac181SlipHeaderDtoList.splice(index, 1, res.ac181SlipHeaderDto);

        // サーバから返された伝票（明細表示）Dtoを伝票一覧（明細表示）の該当する行
        // （キー：仕訳相対月、仕訳伝票種別、仕訳ID）を置き換える。
        slip = this.resDto.ac181SlipDetailDtoList.find(s => s.journalMonth === header.journalMonth && s.journalSlipType === header.journalSlipType && s.journalId === header.journalId);
        index = this.resDto.ac181SlipDetailDtoList.indexOf(slip);
        this.resDto.ac181SlipDetailDtoList = this.resDto.ac181SlipDetailDtoList.filter(s => s.journalMonth !== slip.journalMonth || s.journalSlipType !== slip.journalSlipType || s.journalId !== slip.journalId);
        this.resDto.ac181SlipDetailDtoList.splice(index, 0, ...res.ac181SlipDetailDtoList);

        // サーバから返された伝票入力共通DTOをList<伝票入力共通DTO>の該当する行
        // （キー：仕訳相対月、仕訳伝票種別、仕訳ID）を置き換える。
        var slip:any = this.resDto.commonInputSlipDtoList.find(s => s.journalMonth === header.journalMonth && s.journalSlipType === header.journalSlipType && s.journalId === header.journalId);
        var index = this.resDto.commonInputSlipDtoList.indexOf(slip);
        this.resDto.commonInputSlipDtoList.splice(index, 1, res.commonInputSlipDtoList[0]);

        // 明細一覧を再表示する
        if (this.slipListGrid) {
            index = this.slipListGrid.selectedRows[0].index;
            this.slipListGrid.collectionView.refresh();
            this.slipListGrid.refresh(true);
            this.slipListGrid.select(index, 1);
        }
    }

    /**
     * /api/ac181/delete 呼び出し完了時のコールバック関数
     * @param res
     */
    private deleteOnResult(res: AC181ResDto): void {

        // API側でエラーを検出した(messageIdが "1xxxxx" でない)場合は何も処理しない
        if (res.messageId && !res.messageId.match(/^1/)) {
            return;
        }

        var slip:any = this.slipListGrid.selectedItems[0];

        // 削除した伝票の情報を元に伝票一覧（見出表示）の該当する行
        // （キー：仕訳相対月、仕訳伝票種別、仕訳ID）を削除する。
        this.resDto.ac181SlipHeaderDtoList = this.resDto.ac181SlipHeaderDtoList.filter(s => s.journalMonth !== slip.journalMonth || s.journalSlipType !== slip.journalSlipType || s.journalId !== slip.journalId);

        // 削除した伝票の情報を元に伝票一覧（明細表示）の該当する行
        // （キー：仕訳相対月、仕訳伝票種別、仕訳ID）を削除する。
        this.resDto.ac181SlipDetailDtoList = this.resDto.ac181SlipDetailDtoList.filter(s => s.journalMonth !== slip.journalMonth || s.journalSlipType !== slip.journalSlipType || s.journalId !== slip.journalId);

        // 削除した伝票の情報を元にList<伝票入力共通DTO>の該当する行
        // （キー：仕訳相対月、仕訳伝票種別、仕訳ID）を削除する。
        this.resDto.commonInputSlipDtoList = this.resDto.commonInputSlipDtoList.filter(s => s.journalMonth !== slip.journalMonth || s.journalSlipType !== slip.journalSlipType || s.journalId !== slip.journalId);

        // グリッドのデータソースを変更
        this.slipList = this.gridMode === AC181GridMode.M_Header ? this.resDto.ac181SlipHeaderDtoList : this.resDto.ac181SlipDetailDtoList;

        setTimeout(() => {

            // グリッドの選択状態をクリアー
            this.slipListGrid.select(-1, -1);

            // 買掛伝票入力を初期化する。（追加モード）
            this.commonInputSlip = null;
            this.selectedVoucherId = null;
        }, 0);
    }

    /**
     * 変数がNumber型かどうかを判定するヘルパールーチン（Angular の ngIf 条件式で typeof が使えないため）
     */
    public isNumber(val: any): boolean {
        return typeof val === 'number';
    }

}
