import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac181Component } from './ac181.component';

describe('Ac181Component', () => {
  let component: Ac181Component;
  let fixture: ComponentFixture<Ac181Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac181Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac181Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
