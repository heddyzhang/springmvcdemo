import { Component, ViewChild } from '@angular/core';
import { AC086Service } from '../../service/AC086Service';
import { AC086ReqDto } from '../../dto/ac086/AC086ReqDto';
import { AC086ResDto } from '../../dto/ac086/AC086ResDto';
import { AC086SegmentDto } from '../../dto/ac086/AC086SegmentDto';
import { WjFlexGridEx } from '../../component/wj-flex-grid-ex/wj-flex-grid-ex';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { AC086DeleteSegmentDto } from '../../dto/ac086/AC086DeleteSegmentDto';
import { ComponentBase, AppType } from '../component-base';
import { AC086UpdateSegmentDto } from '../../dto/ac086/AC086UpdateSegmentDto';
import { AC086FisicalYearItemDto } from '../../dto/ac086/AC086FisicalYearItemDto';
import { AC086FisicalYearDto } from '../../dto/ac086/AC086FisicalYearDto';

@Component({
    selector: "app-ac086",
    templateUrl: "./ac086.component.html",
    styleUrls: ["./ac086.component.css"]
})
export class Ac086Component extends ComponentBase {
    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.D_Master;

    /** 表示中のデータ */
    public selectItem: AC086FisicalYearDto = new AC086FisicalYearDto();

    /** 保存中のデータ */
    public tmpItem: AC086FisicalYearDto = new AC086FisicalYearDto();

    /** 対象となる事業年度一覧 */
    public dropList: AC086FisicalYearItemDto[] = new Array();

    /** 選択中の事業年度ラベル */
    public selectedFisicalYearFromToDate: string = "";

    /** 選択中の会計年度コード */
    public selectedFisicalYearCd: number = -1;

    /** 一覧内容 */
    public segmentDtoList: AC086SegmentDto[];

    /** 一覧内容(取消用) */
    private tmpSegmentDtoList: AC086SegmentDto[];

    public isNewFisicalYear: boolean;

    @ViewChild(WjFlexGridEx)
    /** グリッドへの参照 */
    private flexGrid: WjFlexGridEx;

    /** 編集中（未保存の編集データが存在する） */
    private isDirty: boolean = false;

    /** ショートカットボタン（取消・更新・印刷） */
    protected shortcutBtnDefs: any = {
        reference: [
            { tagNo: 1, enabled: false },
            { tagNo: 3, enabled: false },
            { tagNo: 10, enabled: false }
        ],
        insert: [
            { tagNo: 1, enabled: true },
            { tagNo: 3, enabled: false },
            { tagNo: 10, enabled: false }
        ],
        "insert-dirty": [
            { tagNo: 1, enabled: true },
            { tagNo: 3, enabled: true },
            { tagNo: 10, enabled: true }
        ]
    };

    /** コンストラクタ */
    constructor(
        private ac086Service: AC086Service,
        private property: EcoKaikeiProperty
    ) {
        super(ac086Service, property);
        this.isNewFisicalYear = property.ownershipDto.newFisicalYear;
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {
        // ショートカットを表示
        super.displayShortCutBtn(1, 3, 10);

        // 初期情報を取得
        this.ac086Service.getInitial(
            new AC086ReqDto(),
            this.getInitialOnResult
        );
    }

    /**
     * 事業年度の切り替え表示
     */
    public getAgain(index: number): void {
        // 変更がない場合は処理を中断する
        if (this.selectedFisicalYearCd === this.dropList[index].fisicalYearCd) {
            return;
        }

        // 選択中の会計年度コード
        this.selectedFisicalYearCd = this.dropList[index].fisicalYearCd;
        // ラベル部分の設定
        this.selectedFisicalYearFromToDate = this.dropList[index].fisicalYearFromToDate;

        // 選択中の会計年度コードを設定する
        var req: AC086ReqDto = new AC086ReqDto();
        req.selectedFisicalYearCd = this.selectedFisicalYearCd;

        // 情報を再取得
        this.ac086Service.getSegment(req, (resDto: AC086ResDto) => {
            // 一覧表を作成
            this.segmentDtoList = resDto.segmentDtoList;
            this.tmpSegmentDtoList = JSON.parse(JSON.stringify(this.segmentDtoList));

            // ショートカットボタンの制御を行う
            this.updateShortcutButtonStatus();
        });
    }

    /**
     * 一覧へのデータの読み込み時
     */
    public flexGridRefresh(): void {
        // 1件以上データが存在する時
        if (this.segmentDtoList && this.segmentDtoList.length > 0) {
            // 部門コードの先頭行にフォーカスをあてる
            this.flexGrid.refresh();
            this.flexGrid.focusCellInput(0, 0);
        }
    }

    /**
     * 部門内容の編集
     */
    public cellInput(): void {
        if (!this.isDirty) {
            this.isDirty = true;
            // ショートカットボタンの制御を行う
            this.updateShortcutButtonStatus();
        }
    }

    /**
     * Tabキーの押下処理
     */
    public setNextFocus(e: any, item: AC086SegmentDto): void {
        // 既存のTab移動を止める
        e.preventDefault();

        // 対象行を取得
        var selectedRow: number = this.flexGrid.collectionView.items.findIndex(
            element => {
                return element === item;
            }
        );

        // 入力欄にフォーカスを当てる
        this.flexGrid.focusCellInput(selectedRow + 1, 0);
    }

    /**
     * Shift + Tabキーの押下処理
     */
    public setBeforeFocus(e: any, item: AC086SegmentDto): void {
        // 既存のTab移動を止める
        e.preventDefault();

        // 対象行を取得
        var selectedRow: number = this.flexGrid.collectionView.items.findIndex(
            element => {
                return element === item;
            }
        );

        // 入力欄にフォーカスを当てる
        this.flexGrid.focusCellInput(selectedRow - 1, 2);
    }

    /**
     * 削除ボタンの押下処理
     * @param deleteItem
     */
    public deleteRowBtnClick(deleteItem: AC086SegmentDto): void {
        // データ取得に失敗
        if (deleteItem === null || deleteItem.segmentId === 9999) {
            return;
        }

        // 確認ダイアログ 選択された情報を削除しますか？
        this.eAlert.message("120021", [], null, () => {
            // 追加行の削除
            if (deleteItem.segmentId === -1) {
                // 対象の行を削除
                this.segmentDtoList.splice(
                    this.segmentDtoList.findIndex(n => n === deleteItem),
                    1
                );
                this.flexGrid.collectionView.refresh();

                return;
            }

            // 登録済みの部門の削除 => 削除用のリクエストを生成
            var reqDto: AC086ReqDto = new AC086ReqDto();
            var reqDeleteItem: AC086DeleteSegmentDto = new AC086DeleteSegmentDto();
            reqDeleteItem.segmentId = deleteItem.segmentId;
            reqDeleteItem.updatedAt = deleteItem.updatedAt;
            reqDto.deleteSegmentDto = reqDeleteItem;

            // 取消処理を実行
            this.ac086Service.delete(reqDto, this.deletelOnResult);
        });
    }

    /**
     * 追加ボタンの押下処理
     */
    public addRowBtnClick(): void {
        // 新規データ
        var segmentItem: AC086SegmentDto = new AC086SegmentDto();
        segmentItem.segmentId = -1;
        segmentItem.segmentManagementNo = "";
        segmentItem.segmentName = "";
        segmentItem.segmentNickname = "";
        this.segmentDtoList.push(segmentItem);

        // 一覧を再表示する
        this.flexGrid.collectionView.refresh();
        this.flexGrid.refresh(true);

        // 変更フラグを設定
        this.isDirty = true;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();

        // 部門コードにフォーカスを設定
        this.flexGrid.focusCellInput(
            this.flexGrid.collectionView.items.findIndex(
                item => item === segmentItem
            ),
            0
        );
    }

    /**
     * 取消ボタンの押下処理
     */
    public cancelBtnClick(): void {
        // 変更を取り消す
        this.segmentDtoList = JSON.parse(
            JSON.stringify(this.tmpSegmentDtoList)
        );

        // 変更フラグを初期化
        this.isDirty = false;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 更新ボタンの押下処理
     * @param grid
     */
    public updateBtnClick(): void {
        // 必須チェック
        for (
            var i: number = 0;
            i < this.flexGrid.collectionView.items.length;
            i++
        ) {
            var item: AC086SegmentDto = this.flexGrid.collectionView.items[i];
            // 部門コード
            if (item.segmentManagementNo === "") {
                // エラーダイアログ 部門コードは入力必須の項目です。
                this.eAlert.message("210001", ["部門コード"], null, () => {
                    // 部門コードにフォーカスを設定
                    this.flexGrid.focusCellInput(i, 0);
                });

                return;
            }
            // 部門名称
            else if (item.segmentName === "") {
                // エラーダイアログ 部門名称は入力必須の項目です。
                this.eAlert.message("210001", ["部門名称"], null, () => {
                    // 部門名称にフォーカスを設定
                    this.flexGrid.focusCellInput(i, 1);
                });

                return;
            }
            // 部門略称
            else if (item.segmentNickname === "") {
                // エラーダイアログ 略称は入力必須の項目です。
                this.eAlert.message("210001", ["略称"], null, () => {
                    // 部門略称にフォーカスを設定
                    this.flexGrid.focusCellInput(i, 2);
                });

                return;
            }
        }

        // 確認ダイアログ 更新します。よろしいですか？
        this.eAlert.message("120023", [], null, () => {
            // リクエストを生成
            var reqDto: AC086ReqDto = new AC086ReqDto();
            reqDto.updateSegmentDtoList = new Array(0);
            reqDto.fisicalYearCd = this.selectedFisicalYearCd;
            for (
                var i: number = 0;
                i < this.flexGrid.collectionView.items.length;
                i++
            ) {
                // 入力情報を取得
                var inputItem: AC086SegmentDto = this.flexGrid.collectionView
                    .items[i];

                // 更新情報を作成
                var updateItem: AC086UpdateSegmentDto = new AC086UpdateSegmentDto();
                // 部門ID
                updateItem.segmentId = inputItem.segmentId;
                // 部門コード
                updateItem.segmentManagementNo = inputItem.segmentManagementNo;
                // 部門名称
                updateItem.segmentName = inputItem.segmentName;
                // 部門略称
                updateItem.segmentNickname = inputItem.segmentNickname;
                // 更新日
                updateItem.updatedAt = inputItem.updatedAt;

                reqDto.updateSegmentDtoList.push(updateItem);
            }

            // 更新処理を実行
            this.ac086Service.update(reqDto, this.updateOnResult);
        });
    }

    /**
     * ショートカットボタンの制御を行う
     */
    private updateShortcutButtonStatus(): void {
        // ショートカット
        var mode: string = "";

        // 参照モード
        if (this.isReferenceMode) {
            mode = "reference";
        }
        // 通常モード
        else {
            mode = this.isDirty ? "insert-dirty" : "insert";
        }
        // ショートカットの制御を行う
        this.setShortcutBtnDefs(mode);
    }

    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     */
    private getInitialOnResult(resDto: AC086ResDto): void {
        // 入力内容を表示する
        this.selectItem = resDto.fisicalYearDto;
        this.tmpItem = Object.assign({}, resDto.fisicalYearDto);
        this.dropList = resDto.fisicalYearListDto;

        // ラベル部分の設定
        this.selectedFisicalYearFromToDate = this.dropList[0].fisicalYearFromToDate;
        // 表示中の会計年度を保持
        this.selectedFisicalYearCd = this.dropList[0].fisicalYearCd;

        // 一覧表を作成
        this.segmentDtoList = resDto.segmentDtoList;
        this.tmpSegmentDtoList = JSON.parse(
            JSON.stringify(this.segmentDtoList)
        );

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 削除処理 完了
     * @param resDto
     */
    private deletelOnResult(resDto: AC086ResDto): void {
        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        // 一覧表を作成
        this.segmentDtoList = resDto.segmentDtoList;
        this.tmpSegmentDtoList = JSON.parse(
            JSON.stringify(this.segmentDtoList)
        );

        // 部門ポップアップ用の一覧を設定する
        this.property.segmentPopupItemList = resDto.segmentPopupList;

        // 変更フラグを初期化
        this.isDirty = false;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 更新処理 完了
     * @param resDto
     */
    private updateOnResult(resDto: AC086ResDto): void {
        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        // 一覧表を作成
        this.segmentDtoList = resDto.segmentDtoList;
        this.tmpSegmentDtoList = JSON.parse(
            JSON.stringify(this.segmentDtoList)
        );

        // 部門ポップアップ用の一覧を設定する
        this.property.segmentPopupItemList = resDto.segmentPopupList;

        // 変更フラグを初期化
        this.isDirty = false;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }
}
