import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac086Component } from './ac086.component';

describe('Ac086Component', () => {
  let component: Ac086Component;
  let fixture: ComponentFixture<Ac086Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac086Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac086Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
