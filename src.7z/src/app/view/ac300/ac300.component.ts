import { Component, ViewChild } from '@angular/core';
import { ComponentBase, AppType } from '../component-base';
import { AC300Service } from '../../service/AC300Service';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { AC300ReqDto } from '../../dto/ac300/AC300ReqDto';
import { EConfigureReportPopComponent } from '../../component/e-configure-report-pop/e-configure-report-pop.component';
import { EMonthSliderSelectRMonth, EMonthSliderComponent } from '../../component/e-month-slider/e-month-slider.component';
import { Router } from '@angular/router';
import { AC301ViewChangeBean } from '../../bean/AC301ViewChangeBean';
import { AC302ViewChangeBean } from '../../bean/AC302ViewChangeBean';
import { AC300ViewChangeBean } from '../../bean/AC300ViewChangeBean';

@Component({
    selector: 'app-ac300',
    templateUrl: './ac300.component.html',
    styleUrls: ['./ac300.component.css']
})
export class Ac300Component extends ComponentBase {

    /** アプリケーションIDを設定 */
    private appID: string = 'ac300';

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.C_Report;

    @ViewChild('reportPop')
    /** 印刷条件ポップアップ */
    private reportPop: EConfigureReportPopComponent;

    @ViewChild(EMonthSliderComponent)
    /** 月度バー */
    private monthSlider: EMonthSliderComponent;

    /** 0: 当年度 1: 翌年度 (=> 最新年度のみ翌年度表示) */
    public selectedYear: number;

    /** 当年度 */
    public selectFisicalYear: number = 0;
    /** 翌年度 */
    public selectFisicalNextYear: number = 0;

    /** 翌年度を表示するかどうか */
    public displayNextYear: boolean = true;

    /** 補助科目を表示する フラグ */
    public showSubTitle: boolean = false;

    /** 選択開始月 */
    private startMonth: number = -1;

    /** 選択終了月 */
    private endMonth: number = -1;

    /** 作成対象 (0: 集計表 1: 推移表) */
    public selectSheet: number = 0;

    /** 単位 (0: 円 1: 千円 2: 百万円) */
    public selectUnit: number = 0;

    /** 決算の扱い (true: 決算を最終月に含める false: 決算を最終月に含めない) */
    public selectSettle: boolean = false;

    /** ショートカットボタン */
    protected shortcutBtnDefs: any = {
        'summary-none': [
            { tagNo: 7, enabled: false }, { tagNo: 8, enabled: false },
        ],
        'summary': [
            { tagNo: 7, enabled: true }, { tagNo: 8, enabled: true },
        ],
        'transition-none': [
            { tagNo: 7, enabled: false }, { tagNo: 8, enabled: false },
        ],
        'transition': [
            { tagNo: 7, enabled: true }, { tagNo: 8, enabled: true },
        ],
    }

    /** コンストラクタ */
    constructor(private ac300Service: AC300Service, private property: EcoKaikeiProperty, private router: Router) {
        super(ac300Service, property);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // ショートカットを表示
        super.displayShortCutBtn(7, 8);

        // 最新年度のみ翌年度表示
        this.displayNextYear = this.property.ownershipDto.newFisicalYear;

        // 年度切り替え時の会計年度コードを設定する
        this.selectFisicalYear = this.property.ownershipDto.selectFisicalYear;
        this.selectFisicalNextYear = this.property.ownershipDto.selectFisicalYear + 1;

        // 画面遷移パラメータを取得
        var bean: AC300ViewChangeBean = this.property.getViewChangeBeans(this.appID) as AC300ViewChangeBean;

        // メニューからの呼び出し
        if (!bean) {
            // 初期値として当年度を指定
            this.selectedYear = this.property.ownershipDto.selectFisicalYear;
        }
        // 画面遷移時
        else {
            // 選択中の会計年度
            this.selectedYear = bean.selectedYear;
            // 補助科目を表示するかどうか
            this.showSubTitle = bean.showSubTitle;
            // 集計開始月
            this.startMonth = bean.startMonth;
            // 集計終了月
            this.endMonth = bean.endMonth;
            // 作成
            this.selectSheet = bean.selectSheet;
            // 単位
            this.selectUnit = bean.selectUnit;
            // 決算の扱い
            this.selectSettle = bean.selectSettle;
        }

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 対象年度の変更処理
     */
    public selectFisicalYearChange(): void {

        // 選択を解除
        this.startMonth = -1;
        this.endMonth = -1;

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 作成帳票の変更処理
     */
    public selectSheetClsChange(): void {

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 月度バーの選択変更処理
     * @param event 選択中の月
     */
    public monthSliderChage(event: EMonthSliderSelectRMonth): void {

        // 開始月を設定
        this.startMonth = event.fromRMonth;

        // 終了月を設定
        this.endMonth = event.toRMonth;

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 月度バーにデータを設定した際の処理
     */
    public itemsSourceChanged(monthSlider: EMonthSliderComponent): void {

        // データの取得に失敗した際は、処理を中断する
        if (!monthSlider.collectionView) {
            return;
        }

        // 選択を行う
        monthSlider.selectNMonth(this.startMonth, this.endMonth);
    }

    /**
     * 表示ボタンの押下処理
     */
    public displayBtnClick(): void {

        // 表示条件をもとに 集計表 に遷移する
        if (this.selectSheet === 0) {

            // 遷移用パラメータを生成する
            var ac301bean: AC301ViewChangeBean = new AC301ViewChangeBean(this.selectedYear
                , this.showSubTitle, this.startMonth, this.endMonth, this.selectUnit);

            // パラメータの設定を行う
            this.property.setViewChangeBeans(ac301bean, this.appID, 'ac301');

            // 貸借対照表 集計表
            this.router.navigate(['view/ac301', { param: '1' }]);
        }
        // 表示条件をもとに 推移表に遷移する
        else if (this.selectSheet === 1) {

            // 遷移用パラメータを生成する
            var ac302bean: AC302ViewChangeBean = new AC302ViewChangeBean(this.selectedYear
                , this.showSubTitle, this.startMonth, this.endMonth, this.selectUnit, this.selectSettle);

            // パラメータの設定を行う
            this.property.setViewChangeBeans(ac302bean, this.appID, 'ac302');

            // 貸借対照表 集計表
            this.router.navigate(['view/ac302', { param: '1' }]);
        }
    }

    /**
     * 印刷ボタンの押下処理
     */
    public printBtnClick(): void {

        // リクエストを生成
        var reqDto: AC300ReqDto = new AC300ReqDto();
        // 印刷対象の会計年度
        reqDto.selectedYear = this.selectedYear;
        // 印刷対象 (0: 集計表 1: 推移表)
        reqDto.selectSheet = this.selectSheet;
        // 補助科目を表示する フラグ
        reqDto.showSubTitle = this.showSubTitle;
        // 選択開始月
        reqDto.startMonth = this.startMonth;
        // 選択終了月
        reqDto.endMonth = this.endMonth;
        // 単位 (0: 円 1: 千円 2: 百万円)
        reqDto.selectUnit = this.selectUnit;
        // 決算の扱い (0: そのまま表示（決算１に含める） 1: 最終月に含める)
        reqDto.selectSettle = this.selectSettle;
        // タイトルを設定
        var title: string = this.selectSheet === 0 ? '集計表' : '推移表';

        this.reportPop.show(reqDto, () => {
            // 印刷のプレ処理 => 印刷 を行う
            this.ac300Service.onPrint(reqDto, title);
        });
    }

    /**
     * ショートカットボタンの制御を行う
     */
    private updateShortcutButtonStatus(): void {

        // ショートカット
        var mode: string;

        // 集計表
        if (this.selectSheet === 0) {

            // 集計表 選択の有無
            mode = this.startMonth === -1 ? 'summary-none' : 'summary';
        }
        // 推移表
        else if (this.selectSheet === 1) {

            // 推移表 選択の有無
            mode = this.startMonth === -1 ? 'transition-none' : 'transition';
        }

        // ショートカットの制御を行う
        this.setShortcutBtnDefs(mode);
    }
}
