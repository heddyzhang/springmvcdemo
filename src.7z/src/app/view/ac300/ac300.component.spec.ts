import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac300Component } from './ac300.component';

describe('Ac300Component', () => {
  let component: Ac300Component;
  let fixture: ComponentFixture<Ac300Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac300Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac300Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
