import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac309Component } from './ac309.component';

describe('Ac309Component', () => {
  let component: Ac309Component;
  let fixture: ComponentFixture<Ac309Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac309Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac309Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
