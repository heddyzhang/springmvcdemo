import {AC309ReqDto} from '../../dto/ac309/AC309ReqDto';
import {AC309ResDto} from '../../dto/ac309/AC309ResDto';
import { AC309SearchConditionsDto } from '../../dto/ac309/AC309SearchConditionsDto';
import { AC309Service } from '../../service/AC309Service';
import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-ac309',
  templateUrl: './ac309.component.html',
  styleUrls: ['./ac309.component.css']
})
export class Ac309Component implements OnInit {

  public resDto: AC309ResDto;

  constructor(private ac309Service: AC309Service) {}

  ngOnInit() {

    this.ac309Service.onInit().subscribe(
      event => {
        
      }
    )
  }

  /**
   * 検索ボタンクリック
   */
  onSearch(): void {

    //-------------------
    // TODO
    //-------------------
    const reqDto: AC309ReqDto = new AC309ReqDto();
    const serarhConditionsDto:AC309SearchConditionsDto = new AC309SearchConditionsDto();
    reqDto.searchConditionsDto = serarhConditionsDto;


    this.ac309Service.onSearch(reqDto).subscribe(
      event => {
        this.resDto = event;
        this.onSearchResult();
      }
    );
  }

  /**
   * ショートカット 印刷クリック
   */
  onPrint():void {

    //-------------------
    // TODO 印刷条件
    //-------------------
    const reqDto: AC309ReqDto = new AC309ReqDto();
    const serarhConditionsDto:AC309SearchConditionsDto = new AC309SearchConditionsDto();
    reqDto.searchConditionsDto = serarhConditionsDto;
    serarhConditionsDto.acTitleId = 101;

    //---------------------
    // 印刷準備処理
    //---------------------
    this.ac309Service.outputReserve(reqDto).subscribe(
      event => {
        this.resDto = event;
        this.outputReserveResult();
      }
    );

  }

  //=============================
  //
  // resultHandler
  //
  //=============================

  /**
   * 仕訳明細取得 完了
   */
  onSearchResult(): void {
  }

  /**
   * 印刷準備処理 完了
   */
  outputReserveResult():void {
    const serviceUrl: string = 'print/ac309/仕訳帳?id=';
    window.open(`${serviceUrl}` + this.resDto.publishId, '_blank');
  }

}
