import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ac361',
  templateUrl: './ac361.component.html',
  styleUrls: ['./ac361.component.css']
})
export class Ac361Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
