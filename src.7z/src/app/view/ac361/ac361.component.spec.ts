import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac361Component } from './ac361.component';

describe('Ac361Component', () => {
  let component: Ac361Component;
  let fixture: ComponentFixture<Ac361Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac361Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac361Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
