import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { AC000MenuDto } from "../../../dto/ac000/AC000MenuDto";
import { Ac000Util } from "./ac000util";

@Component({
    selector: "top-menu",
    templateUrl: "./top.menu.html",
    styles: [
        `
            .btn {
                border-radius: 0;
            }
        `
    ]
})
export class topMenu {
    constructor(public util: Ac000Util) {}

    // メニュー情報
    _menuMaster: AC000MenuDto;

    @Input()
    public set menuMaster(_menuMaster: AC000MenuDto) {
        this._menuMaster = _menuMaster;
    }

    public get menuMaster(): AC000MenuDto {
        return this._menuMaster;
    }

    public IsShow(menu: AC000MenuDto): boolean {
        return this.util.IsShow(menu);
    }
}
