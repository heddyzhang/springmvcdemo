import { EcoKaikeiProperty } from "../../../eco.kaikei.property";
import { AC000MenuDto } from "../../../dto/ac000/AC000MenuDto";
import { Injectable } from "@angular/core";

@Injectable()
export class Ac000Util {
    constructor(public property: EcoKaikeiProperty) {}

    public IsShow(menu: AC000MenuDto): boolean {
        //部門の登録
        if (menu.id === 601606) {
            if (this.property.ownershipDto.segmentCls === 1) {
                return true;
            } else {
                return false;
            }
        } //製造原価集計表
        else if (menu.id === 105 && menu.rootId === 301301) {
            if (this.property.ownershipDto.costreportCls === 1) {
                return true;
            } else {
                return false;
            }
        } //MoneyTree管理画面
        else if (menu.id === 601605) {
            return this.property.businessDto.moneytreeUsedFlg;
        } //証憑から会計伝票を起票する
        else if (menu.id === 401401) {
            return this.property.businessDto.evidenceUsedFlg;
        }

        var showPattern;

        //処理中会計年度 ＝ 最新年度
        if (this.property.ownershipDto.newFisicalYear) {
            showPattern = menu.showPatern1;
        } else {
            //処理中会計年度 ≠ 最新年度
            showPattern = menu.showPatern2;
        }

        if (showPattern === null) {
            return false;
        }

        return this.getShowPattern(showPattern);
    }

    private getShowPattern(showPattern: string): boolean {
        var isShow;

        switch (this.property.userAuthorityCls) {
            //1：管理者
            case 1:
                isShow = showPattern.substr(0, 1);
                break;
            //2：一般
            case 2:
                isShow = showPattern.substr(1, 1);
                break;
            //4：会計事務所
            case 4:
                isShow = showPattern.substr(2, 1);
                break;
            //3：照会
            case 3:
                isShow = showPattern.substr(3, 1);
                break;
        }

        if (isShow === "s") {
            return true;
        } else {
            return false;
        }
    }
}
