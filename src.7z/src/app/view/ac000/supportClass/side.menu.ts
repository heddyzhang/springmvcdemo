import { Component, Input, Output, EventEmitter } from "@angular/core";
import { AC000MenuDto } from "../../../dto/ac000/AC000MenuDto";
import { Ac000Util } from "./ac000util";

@Component({
    selector: "side-menu",
    templateUrl: "./side.menu.html",
    styleUrls: ["./side.menu.css"]
})
export class sideMenu {
    constructor(public util: Ac000Util) {}

    // サイド・メニュー情報
    @Input() public sideMenuInf: AC000MenuDto;

    // 選択中のメニュー
    @Input() public selectedSideMenu: AC000MenuDto;

    // メニューのヘッダー
    @Input() public header: string;

    // サイドメニューの表示切替フラグ
    @Input() public sideMenuDisp: boolean;

    @Output() sideMenuSwitchEvent = new EventEmitter();

    public onClickSwitch() {
        this.sideMenuSwitchEvent.emit();
    }

    public IsShow(menu: AC000MenuDto): boolean {
        return this.util.IsShow(menu);
    }
}
