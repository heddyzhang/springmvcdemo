import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac000Component } from './ac000.component';

describe('Ac000Component', () => {
  let component: Ac000Component;
  let fixture: ComponentFixture<Ac000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac000Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
