import { Component, OnInit, HostListener } from "@angular/core";
import { AC000Service } from "../../service/AC000Servive";
import { AC000MenuDto } from "../../dto/ac000/AC000MenuDto";
import { Router, NavigationStart } from "@angular/router";
import { SideMenuScaleEvent } from "../../event/side.menu.scale.event";
import { EcoKaikeiProperty } from "../../eco.kaikei.property";
import { AC000ResDto } from "../../dto/ac000/AC000ResDto";
import { AC000ReqDto } from "../../dto/ac000/AC000ReqDto";
import { WjPopup } from "wijmo/wijmo.angular2.input";
import { AC000LoginUserDto } from "../../dto/ac000/AC000LoginUserDto";
import { LogoutService } from "../../service/logoutServive";
import { DatePipe } from "@angular/common";
import { AC000UserInfoDto } from "../../dto/ac000/AC000UserInfoDto";

@Component({
    selector: "app-ac000",
    templateUrl: "./ac000.component.html",
    styleUrls: ["./ac000.component.css"]
})
export class Ac000Component implements OnInit {
    private BTN_LABEL_1: string = "ログイン中のユーザ数：";

    // 画面上部メニュー情報
    public menuMaster: AC000MenuDto[];

    // 画面サイドメニュー情報
    public sideMenuInf: AC000MenuDto;

    // 選択中のメニュー情報
    public selectedSideMenu: AC000MenuDto;

    // サイド・メニュー表示制御フラグ true:通常表示 false:縮小表示
    public sideMenuDisp: boolean;

    // サイド・メニューのヘッダー
    public sideHeader: string;

    /** ログイン中ユーザの数 */
    public loginUserBTNLabel: string = "";

    /** ログイン中ユーザの配列情報 */
    public loginUserList: AC000LoginUserDto[];

    public businessName: string;

    public businessShortname: string;

    public businessRepName: string;

    public userName: string;

    public fisicalYearTerm: string;

    constructor(
        private ac000Service: AC000Service,
        private sideMenuScaleEvent: SideMenuScaleEvent,
        private logoutService: LogoutService,
        private router: Router,
        private property: EcoKaikeiProperty,
        private datepipe: DatePipe
    ) {
        this.router.events.subscribe(event => {
            if (event instanceof NavigationStart) {
                // 画面遷移（ルーディング）前に実行される処理
                this.NavigationStart_Result(event.url);
                console.log(event);
            }
        });
    }

    /**
     * ×ボタンで閉じた際の処理
     * @param event
     */
    @HostListener("window:unload", ["$event"])
    public unloadHandler(event) {
        this.logoutService
            .callLogout()
            .finally(() => {
                document.location.href = this.property.commonURL;
            })
            .subscribe();
    }

    /**
     * ×ボタンで閉じた際の処理
     * @param event
     */
    @HostListener("window:beforeunload", ["$event"])
    public beforeUnloadHander(event) {
        this.logoutService
            .callLogout()
            .finally(() => {
                document.location.href = this.property.commonURL;
            })
            .subscribe();
    }

    // private loginUser(): string {
    //     return "aaaaa";
    // }

    ngOnInit() {
        //----------------------------------
        // このメソッドで処理するのはダメ！！
        //----------------------------------
    }

    /**
     * 初期処理
     */
    public getEcoInitial(selectFisicalYear: number): void {
        this.sideMenuDisp = false;

        this.sideMenuInf = null;

        // 初期情報を取得
        this.getInitial(selectFisicalYear);

        this.getUserInfo();
    }

    /**
     * ログイン中ユーザの表示ボタン クリック
     * @param event
     */
    public loginUserCheckBTN_click(pop: WjPopup): void {
        pop.show(true);
        this.openloginUserCheckPop();
    }

    //-----------------------
    // serviceの呼び出し
    //-----------------------
    /**
     * 初期処理
     */
    private getInitial(selectFisicalYear: number): void {
        var reqDto: AC000ReqDto = new AC000ReqDto();
        reqDto.fisicalYearCd = selectFisicalYear;
        this.ac000Service.getInitial(reqDto).subscribe(event => {
            this.getInitialOnResult(event);
        });
    }

    private getUserInfo(): void {
        this.ac000Service.getUserInfo().subscribe(userInfo => {
            this.userName = userInfo.userName;
            this.businessName = userInfo.businessName;
            this.businessShortname = userInfo.businessShortname;
            this.businessRepName = userInfo.businessRepName;
        });
    }

    /**
     * ログイン中ユーザのポップアップが開かれたとき
     * or
     * ページ遷移した際にログイン中のユーザ数を取得する
     */
    private openloginUserCheckPop(): void {
        this.ac000Service.getLoginUser().subscribe(event => {
            this.getLoginUserOnResult(event);
        });
    }

    //--------------------------
    // resultEventHandler
    //--------------------------

    /**
     * 初期処理
     * @param dto
     */
    private getInitialOnResult(dto: AC000ResDto): void {
        //---------------------
        // メッセージ一覧
        //---------------------
        this.property.messageDtoList = dto.initialDto.messageDtoList;

        this.property.businessDto = dto.initialDto.businessDto;

        //---------------------
        // 休日カレンダー
        //---------------------
        this.property.nationalHolidayDtoList =
            dto.initialDto.nationalHolidayDtoList;

        //-----------------------
        // 利用者権限を補完
        //-----------------------
        this.property.userAuthorityCls = dto.initialDto.userAuthorityCls;

        //------------------------------
        // ポップアップ用マスタ情報を補完
        //------------------------------
        this.property.acTitlePopupItemList =
            dto.initialDto.acTitlePopupItemList;
        this.property.acSubTitlePopupItemList =
            dto.initialDto.acSubTitlePopupItemList;
        this.property.customerPopupItemList =
            dto.initialDto.customerPopupItemList;
        this.property.segmentPopupItemList =
            dto.initialDto.segmentPopupItemList;
        this.property.consumptionTaxPopupItemList =
            dto.initialDto.consumptionTaxPopupItemList;
        this.property.userPosition = dto.initialDto.userPosition;
        this.property.userSealTop = dto.initialDto.userSealTop;
        this.property.userSealBottom = dto.initialDto.userSealBottom;

        //------------------------------
        // 消費税率一覧を補完
        //------------------------------
        this.property.taxRateList = dto.initialDto.taxRateList;

        //------------------------------------------------
        // クライアント保有情報をプロパティクラスに詰め替え
        //------------------------------------------------
        this.property.ownershipDto = dto.initialDto.ownershipDto;

        let fromDate;
        if (this.property.ownershipDto.fromDate !== undefined) {
            fromDate = this.datepipe.transform(this.property.ownershipDto.fromDate, "yyyy/MM/dd");
        }

        let toDate;
        if (this.property.ownershipDto.toDate !== undefined) {
            toDate = this.datepipe.transform(this.property.ownershipDto.toDate, "yyyy/MM/dd");
        }

        this.fisicalYearTerm = fromDate + "～" + toDate;

        //----------------------
        // メニュー情報
        //----------------------
        this.menuMaster = dto.initialDto.menuDtoList;

        //-------------------------------------------------------------
        // セットアップツアーが完了していない場合はセットアップツアーに遷移
        //-------------------------------------------------------------
        if (dto.initialDto.setupTourStsDto.setupTour11Sts != 9) {
            this.router.navigate(["view/ac002"]);

            return;
        }

        //----------------------------
        // ac001トップメニューに遷移
        //----------------------------
        this.router.navigate(["view/ac001"]);
    }

    /**
     * ログイン中ユーザの一覧の取得 成功
     * @param dto
     */
    private getLoginUserOnResult(dto: AC000ResDto): void {
        this.loginUserBTNLabel = this.BTN_LABEL_1 + dto.loginUserDtoList.length;

        this.loginUserList = dto.loginUserDtoList;
    }

    /**
     * 画面遷移前の共通処理
     * @param path
     */
    NavigationStart_Result(path: string) {
        //---------------------------
        // ログイン中のユーザ数を更新
        //---------------------------
        this.openloginUserCheckPop();

        // サイド・メニューの編集
        if (path === "/view/ac001" || path === "/") {
            this.sideMenuInf = null;
            this.sideMenuDisp = false;
            return;
        }
        // セットアップツアー
        if (path === "/view/ac002") {
            this.sideMenuInf = null;
            this.sideMenuDisp = false;
            return;
        }

        //------------------------------------------
        // セットアップツアー中このパスが呼ばれる
        // このパスから000の初期処理を実行
        //------------------------------------------
        // 環境の作成完了　やり直し　完了時に呼ばれる
        if (path === "/refreshSetupTourOnResult") {
            this.getEcoInitial(0);
            return;
        }

        //-------------------------------------------------
        // AC001の会計年度が変更されたときにこのパスが呼ばれる
        //-------------------------------------------------
        if (path === "/changeFisicalYear") {
            this.getEcoInitial(this.property.ownershipDto.selectFisicalYear);
            return;
        }

        //-------------------------------------------------
        // view間での遷移
        //-------------------------------------------------
        if (path.indexOf(";param=1") === -1) {
            this.property.clearViewChangeBeans();
        }

        /**
         * angular上でパスで異なっているものの
         * サイド・メニューが同じものを選択した状態にしたい場合は
         * ここで記入
         *
         * 例)
         * ac030_勘定科目の登録（一覧）, ac031_勘定科目の登録（ツリー）は
         * サイド・メニューは同じものが選択される。
         */
        if (path === "/view/ac031") {
            path = "/view/ac030";
        }

        /**
         * マスタ・メニュー情報をループさせ
         * パスの値が合致するものについて
         * サイド・メニューに値を設定する。
         */
        if (!this.property.isDuringSetupTour) {
            for (let topMenu of this.menuMaster) {
                // topメニューでループ
                if (path === `/${topMenu.path}`) {
                    this.sideMenuInf = topMenu;
                    this.sideMenuDisp = true;
                    this.sideHeader = topMenu.label;
                    this.selectedSideMenu = topMenu;

                    return;
                }
                for (let middleMenu of topMenu.menuList) {
                    // middleメニューでループ
                    
                    if (path === `/${middleMenu.path}`) {
                        if (middleMenu.rootId == 201){
                            this.sideMenuDisp = false;    
                        }else{
                            this.sideMenuDisp = true;
                        }
                        this.sideMenuInf = topMenu;
                        this.sideHeader = topMenu.label;
                        this.selectedSideMenu = middleMenu;

                        return;
                    }
                    for (let bottoMenu of middleMenu.menuList) {
                        // bottomメニューでループ
                        if (path === `/${bottoMenu.path}`) {
                            this.sideMenuInf = topMenu;
                            this.sideMenuDisp = true;
                            this.sideHeader = topMenu.label;
                            this.selectedSideMenu = bottoMenu;

                            return;
                        }
                    }
                }
            }
        }
    }

    sideMenuSwitchClick() {
        this.sideMenuDisp = !this.sideMenuDisp;

        // 変更イベントをwindowで発火する
        window.dispatchEvent(new Event("sideMenuScaleEvent"));
    }
}
