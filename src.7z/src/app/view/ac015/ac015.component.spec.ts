import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac015Component } from './ac015.component';

describe('Ac015Component', () => {
  let component: Ac015Component;
  let fixture: ComponentFixture<Ac015Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac015Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac015Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
