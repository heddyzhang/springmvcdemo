import { Component, ViewChild } from '@angular/core';
import { AC015Service } from '../../service/AC015Service';
import { AC015ReqDto } from '../../dto/ac015/AC015ReqDto';
import { AC015ResDto } from '../../dto/ac015/AC015ResDto';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { ComponentBase, AppType } from '../component-base';
import { AC015FisicalYearDto } from '../../dto/ac015/AC015FisicalYearDto';
import { AC015FisicalYearItemDto } from '../../dto/ac015/AC015FisicalYearItemDto';
import { EDropDownListComponent } from '../../component/e-drop-down-list/e-drop-down-list.component';
import { AC015FisicalYearUpdateDto } from '../../dto/ac015/AC015FisicalYearUpdateDto';
import { ETextInputComponent } from '../../component/e-text-input/e-text-input.component';

@Component({
    selector: 'app-ac015',
    templateUrl: './ac015.component.html',
    styleUrls: ['./ac015.component.css']
})
export class Ac015Component extends ComponentBase {

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.F_Administrator;

    /** 表示中のデータ */
    public selectItem: AC015FisicalYearDto = new AC015FisicalYearDto();

    /** 保存中のデータ */
    public tmpItem: AC015FisicalYearDto = new AC015FisicalYearDto();

    /** 対象となる事業年度一覧 */
    public dropList: AC015FisicalYearItemDto[] = new Array();

    /** 選択中の事業年度ラベル */
    public selectedFisicalYearFromToDate: string = '';

    /** 選択中の会計年度コード */
    public selectedFisicalYearCd: number = -1;

    /** 編集中（未保存の編集データが存在する） */
    private isDirty: boolean = false;

    /** ショートカットボタン（取消・更新） */
    protected shortcutBtnDefs: any = {
        'update': [
            { tagNo: 3, enabled: false }, { tagNo: 10, enabled: false },
        ],
        'update-dirty': [
            { tagNo: 3, enabled: true }, { tagNo: 10, enabled: true },
        ],
    }

    /** サービス名 */
    constructor(private ac015Service: AC015Service, private property: EcoKaikeiProperty) {
        super(ac015Service, property);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // ショートカットを表示
        super.displayShortCutBtn(3, 10);

        // 初期情報を取得
        this.ac015Service.getInitial(new AC015ReqDto(), this.getInitialOnResult);
    }

    /**
     * 消費税設定情報入力Form変更イベント
     */
    public setDirtyFlag(): void {

        if (!this.isDirty) {

            this.isDirty = true;
            // ショートカットボタンの制御を行う
            this.updateShortcutButtonStatus();
        }
    }

    /**
     * 事業年度の切り替え表示
     */
    public getAgain(index: number): void {

        // 変更がない場合は処理を中断する
        if (this.selectedFisicalYearCd === this.dropList[index].fisicalYearCd) {
            return;
        }

        // 選択中の会計年度コード
        this.selectedFisicalYearCd = this.dropList[index].fisicalYearCd;
        // ラベル部分の設定
        this.selectedFisicalYearFromToDate = this.dropList[index].fisicalYearFromToDate;

        // 選択中の会計年度コードを設定する
        var req: AC015ReqDto = new AC015ReqDto();
        req.selectedFisicalYearCd = this.selectedFisicalYearCd;

        // 情報を再取得
        this.ac015Service.getAgain(req, this.getAgainOnResult);
    }

    /**
     * 検索ボックス
     * @param textInput
     * @param defWord 標準検索ワード
     */
    public seachInputLostFocus(textInput: ETextInputComponent, defWord: string): void {

        // 空欄時は、デフォルト文字を設定
        if (!textInput.value) {
            textInput.value = defWord;
        }
    }

    /**
     * 検索ボタンの押下処理
     * @param word
     */
    public seachWord(textInput: ETextInputComponent): void {

        // 別ウィンドウでgoogle検索を行う
        window.open('https://www.google.co.jp/search?q=' + textInput.value, '_blank');
    }

    /**
     * 取消ボタンの押下処理
     */
    public cancelBtnClick(): void {

        // 変更を取り消す
        this.selectItem = Object.assign({}, this.tmpItem);
        this.isDirty = false;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 更新ボタンの押下処理
     */
    public updateBtnClick(): void {

        // 必須項目のチェック
        // 免税・課税未選択
        if (this.selectItem.businessTaxClsMethod === -1) {
            // "免税業者か課税業者"を選択してください。
            this.eAlert.message('211006', ['免税業者か課税業者'], 'businessTaxClsMethod');
            return;
        }
        // 課税原則 仕入税額控除未選択
        else if (this.selectItem.businessTaxClsMethod === 1
            && this.selectItem.purchaseTaxDeductionCls === -1) {
            // "仕入税額控除"を選択してください。
            this.eAlert.message('211006', ['仕入税額控除'], 'purchaseTaxDeductionCls');
            return;
        }
        // 課税原則 簡易課税事業区分未選択
        else if (this.selectItem.businessTaxClsMethod === 2
            && this.selectItem.businessIndustry === -1) {
            // "簡易課税事業区分"を選択してください。
            this.eAlert.message('211006', ['簡易課税事業区分'], 'businessIndustry');
            return;
        }
        // 課税原則 経理方式未選択
        else if ((this.selectItem.businessTaxClsMethod === 1 || this.selectItem.businessTaxClsMethod === 2)
            && this.selectItem.taxAccountingMethod === -1) {
            // "経理方式"を選択してください。
            this.eAlert.message('211006', ['経理方式'], 'taxAccountingMethod');
            return;
        }
        // 課税原則 端数処理未選択
        else if ((this.selectItem.businessTaxClsMethod === 1 || this.selectItem.businessTaxClsMethod === 2)
            && this.selectItem.taxFractionCls === -1) {
            // "端数処理"を選択してください。
            this.eAlert.message('211006', ['端数処理'], 'taxFractionCls');
            return;
        }

        // 更新します。よろしいですか？
        this.eAlert.message('120024', [], null, () => {

            // リクエストを生成
            var reqDto: AC015ReqDto = new AC015ReqDto();
            reqDto.updateDto = new AC015FisicalYearUpdateDto();

            // 会計年度コード
            reqDto.updateDto.fisicalYearCd = this.selectedFisicalYearCd;
            // 0: 免税 1: 課税（原則） 2: 課税（簡易）
            reqDto.updateDto.businessTaxClsMethod = this.selectItem.businessTaxClsMethod;
            // 仕入税額控除 −１：未設定　０：比例配分　１：個別対応
            reqDto.updateDto.purchaseTaxDeductionCls = this.selectItem.purchaseTaxDeductionCls;
            // 簡易課税業種 -1：未設定 1：第一種事業（卸売業） 2：第二種事業（小売業）・・・
            reqDto.updateDto.businessIndustry = this.selectItem.businessIndustry;
            // 消費税経理処理方法
            reqDto.updateDto.taxAccountingMethod = this.selectItem.taxAccountingMethod;
            // 消費税端数処理方法
            reqDto.updateDto.taxFractionCls = this.selectItem.taxFractionCls;

            // 更新日
            reqDto.updateDto.updatedAt = this.selectItem.updatedAt;

            // 更新処理を実行
            this.ac015Service.update(reqDto, this.updateOnResult);
        });
    }

    /**
     * ショートカットボタンの制御を行う
     */
    private updateShortcutButtonStatus(): void {

        // 通常モード / 変更有無
        var mode: string = this.isDirty ? 'update-dirty' : 'update';

        // ショートカットの制御を行う
        this.setShortcutBtnDefs(mode);
    }

    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     * @param resDto
     */
    private getInitialOnResult(resDto: AC015ResDto): void {

        // 入力内容を表示する
        this.selectItem = resDto.fisicalYearDto;
        this.tmpItem = Object.assign({}, resDto.fisicalYearDto);
        this.dropList = resDto.fisicalYearListDto;

        // ラベル部分の設定
        this.selectedFisicalYearFromToDate = this.dropList[0].fisicalYearFromToDate;
        // 表示中の会計年度を保持
        this.selectedFisicalYearCd = this.dropList[0].fisicalYearCd;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 初期処理 完了
     * @param resDto
     */
    private getAgainOnResult(resDto: AC015ResDto): void {

        // 入力内容を表示する
        this.selectItem = resDto.fisicalYearDto;
        this.tmpItem = Object.assign({}, resDto.fisicalYearDto);

        // 変更の取消
        this.isDirty = false;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 更新処理 完了
     * @param resDto
     */
    private updateOnResult(resDto: AC015ResDto): void {

        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        // クライアント保有情報を更新
        if (resDto.ownershipDto) {
            this.property.ownershipDto = resDto.ownershipDto;
        }

        // 入力内容を表示する
        this.selectItem = resDto.fisicalYearDto;
        this.tmpItem = Object.assign({}, resDto.fisicalYearDto);

        // 変更の取消
        this.isDirty = false;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }
}
