import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac180Component } from './ac180.component';

describe('Ac180Component', () => {
  let component: Ac180Component;
  let fixture: ComponentFixture<Ac180Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac180Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac180Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
