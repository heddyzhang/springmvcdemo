import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac190Component } from './ac190.component';

describe('Ac190Component', () => {
  let component: Ac190Component;
  let fixture: ComponentFixture<Ac190Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac190Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac190Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
