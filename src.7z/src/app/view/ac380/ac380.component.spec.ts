import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac380Component } from './ac380.component';

describe('Ac380Component', () => {
  let component: Ac380Component;
  let fixture: ComponentFixture<Ac380Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac380Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac380Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
