import { Component, ViewChild } from '@angular/core';
import { ComponentBase, AppType } from '../component-base';
import { AC380Service } from '../../service/AC380Service';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { AC380ReqDto } from '../../dto/ac380/AC380ReqDto';
import { EConfigureReportPopComponent } from '../../component/e-configure-report-pop/e-configure-report-pop.component';
import { EMonthSliderSelectRMonth, EMonthSliderComponent } from '../../component/e-month-slider/e-month-slider.component';
import { Router } from '@angular/router';
import { AC380SegmentDto } from '../../dto/ac380/AC380SegmentDto';
import { AC381ViewChangeBean } from '../../bean/AC381ViewChangeBean';
import { AC380ViewChangeBean } from '../../bean/AC380ViewChangeBean';
import { EAcTitleInputModule } from '../../component/e-ac-title-popup-input/supportClass/e-ac-title-input/e-ac-title-input.component';

@Component({
    selector: 'app-ac380',
    templateUrl: './ac380.component.html',
    styleUrls: ['./ac380.component.css']
})
export class Ac380Component extends ComponentBase {

    /** アプリケーションIDを設定 */
    private appID: string = 'ac380';

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.C_Report;

    @ViewChild('reportPop')
    /** 印刷条件ポップアップ */
    private reportPop: EConfigureReportPopComponent;

    @ViewChild(EMonthSliderComponent)
    /** 月度バー */
    private monthSlider: EMonthSliderComponent;

    @ViewChild(EAcTitleInputModule)
    acpop: EAcTitleInputModule;

    /** 0: 当年度 1: 翌年度 (=> 最新年度のみ翌年度表示) */
    public selectedYear: number;

    /** 当年度 */
    public selectFisicalYear: number = 0;

    /** 翌年度 */
    public selectFisicalNextYear: number = 0;

    /** 部門のリスト */
    public segmentList: AC380SegmentDto[] = Array(0);

    /** 翌年度を表示するかどうか */
    public displayNextYear: boolean = true;

    /** 選択開始月 */
    private startMonth: number = -1;

    /** 選択終了月 */
    private endMonth: number = -1;

    /** 借方科目 */
    private drAcTitleId: number = -1;

    /** 貸方科目 */
    private crAcTitleId: number = -1;

    /** 最小金額 */
    private minJournalAmount: number = 0;

    /** 最大金額 */
    private maxJournalAmount: number = 0;

    /** 摘要 */
    private journalSummary: string = "";

    /** 部門の選択フラグ（０：全社対応、１：選択した部門 */
    private selectSegment: number = 0;

    /** 選択された部門コード */
    private selectSegmentId: number = -1;

    // 表示する貸借区分
    private dispAcDrCrCls: number[] = [0, 1, 2, 3];

    // 科目管理区分 -9:ALL
    private acManagementCls: number = -9;

    // マネーツリー口座管理区分 -1:ALL
    private mtAccountCls: number = -1;

    /** ショートカットボタン */
    protected shortcutBtnDefs: any = {
        'summary-none': [
            { tagNo: 6, enabled: false }, { tagNo: 7, enabled: false }, { tagNo: 8, enabled: false },
        ],
        'summary': [
            { tagNo: 6, enabled: true }, { tagNo: 7, enabled: true }, { tagNo: 8, enabled: true },
        ],
    }
    /** コンストラクタ */
    constructor(private ac380Service: AC380Service, private property: EcoKaikeiProperty, private router: Router) {
        super(ac380Service, property);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // ショートカットを表示
        super.displayShortCutBtn(7, 8, 6);

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();

        // 最新年度のみ翌年度表示
        this.displayNextYear = this.property.ownershipDto.newFisicalYear;

        // 年度切り替え時の会計年度コードを設定する
        this.selectFisicalYear = this.property.ownershipDto.selectFisicalYear;
        this.selectFisicalNextYear = this.property.ownershipDto.selectFisicalYear + 1;

        //---------------------------
        // 部門のドロップダウンを設定
        //---------------------------
        var sgList: AC380SegmentDto[] = Array(0);
        var dto: AC380SegmentDto = new AC380SegmentDto("指定なし", -1);
        sgList.push(dto);
        for (var i = 0; i < this.property.segmentPopupItemList.length; i++) {
            dto = new AC380SegmentDto(this.property.segmentPopupItemList[i].label, this.property.segmentPopupItemList[i].id);
            sgList.push(dto);
        }
        this.segmentList = sgList;

        // 画面遷移パラメータを取得
        var bean: AC380ViewChangeBean = this.property.getViewChangeBeans(this.appID) as AC380ViewChangeBean;

        // メニューからの呼び出し
        if (!bean) {
            // 初期値として当年度を指定
            this.selectedYear = this.property.ownershipDto.selectFisicalYear;
        }
        // 画面遷移時
        else {
            // 選択中の会計年度
            this.selectedYear = bean.selectedYear;
            // 集計開始月
            this.startMonth = bean.startMonth;
            // 集計終了月
            this.endMonth = bean.endMonth;
            // 借方科目
            this.drAcTitleId = bean.drAcTitleId;
            // 貸方科目
            this.crAcTitleId = bean.crAcTitleId;
            // 最小金額
            this.minJournalAmount = bean.minJournalAmount;
            // 最大金額
            this.maxJournalAmount = bean.maxJournalAmount;
            // 摘要
            this.journalSummary = bean.journalSummary;
            // 部門の選択フラグ（０：全社対応、１：選択した部
            this.selectSegment = bean.selectSegment;
            // 部門ID
            this.selectSegmentId = bean.selectSegmentId;
        }

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 対象年度の変更処理
     */
    public selectFisicalYearChange(): void {

        // 選択を解除
        this.startMonth = -1;
        this.endMonth = -1;

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }


    /**
     * 月度バーの選択変更処理
     * @param event 選択中の月
     */
    public monthSliderChage(event: EMonthSliderSelectRMonth): void {

        // 開始月を設定
        this.startMonth = event.fromRMonth;

        // 終了月を設定
        this.endMonth = event.toRMonth;

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 月度バーにデータを設定した際の処理
     */
    public itemsSourceChanged(monthSlider: EMonthSliderComponent): void {

        // データの取得に失敗した際は、処理を中断する
        if (!monthSlider.collectionView) {
            return;
        }

        // 選択を行う
        monthSlider.selectNMonth(this.startMonth, this.endMonth);
    }

    /**
     * 表示ボタンの押下処理
     */
    public displayBtnClick(): void {

        // 遷移用パラメータを生成する
        var ac381bean: AC381ViewChangeBean = new AC381ViewChangeBean(this.selectedYear, this.startMonth
            , this.endMonth, this.drAcTitleId, this.crAcTitleId
            , this.minJournalAmount, this.maxJournalAmount, this.journalSummary
            , this.selectSegment, this.selectSegmentId);

        // パラメータの設定を行う
        this.property.setViewChangeBeans(ac381bean, this.appID, 'ac381');

        // 仕訳票
        this.router.navigate(['view/ac381', { param: '1' }]);
    }

    /**
     * 印刷ボタンの押下処理
     */
    public printBtnClick(): void {

        // リクエストを生成
        var reqDto: AC380ReqDto = new AC380ReqDto();
        // 印刷対象の会計年度
        reqDto.selectedYear = this.selectedYear;
        // 選択開始月
        reqDto.startMonth = this.startMonth;
        // 選択終了月
        reqDto.endMonth = this.endMonth;
        // 借方科目
        reqDto.drAcTitleId = this.drAcTitleId;
        // 貸方科目
        reqDto.crAcTitleId = this.crAcTitleId;
        // 最小金額
        reqDto.minJournalAmount = this.minJournalAmount;
        // 最大金額
        reqDto.maxJournalAmount = this.maxJournalAmount;
        // 摘要
        reqDto.journalSummary = this.journalSummary;
        // 部門の選択フラグ（０：全社対応、１：選択した部
        reqDto.selectSegment = this.selectSegment;
        // 部門ID
        reqDto.selectSegmentId = this.selectSegmentId;

        // タイトルを設定
        var title: string = '仕訳票';

        this.reportPop.show(reqDto, () => {
            // 印刷のプレ処理 => 印刷 を行う
            this.ac380Service.onPrint(reqDto, title);
        });
    }

    /**
     * CSV出力ボタンの押下処理
     */
    public csvBtnClick(): void {

        // TODO: CSV押下時の処理
    }

    /**
     * 全指定解除ボタンの押下処理
     */
    public allResetBtnClick(): void {
        // 選択年度
        this.selectedYear = this.selectFisicalYear;
        // 選択開始月
        this.startMonth = -1;
        // 選択終了月
        this.endMonth = -1;
        // 借方科目
        this.drAcTitleId = -1;
        // 貸方科目
        this.crAcTitleId = -1;
        // 最小金額
        this.minJournalAmount = null;
        // 最大金額
        this.maxJournalAmount = null;
        // 摘要
        this.journalSummary = "";
        // 部門の選択フラグ（０：全社対応、１：選択した部門
        this.selectSegment = 0;
        // 部門ID
        this.selectSegmentId = -1;

        // 選択を行う
        this.monthSlider.selectNMonth(this.startMonth, this.endMonth);

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * ショートカットボタンの制御を行う
     */
    private updateShortcutButtonStatus(): void {

        // ショートカット
        var mode: string;

        // 仕訳票 選択の有無
        mode = this.startMonth === -1 ? 'summary-none' : 'summary';

        // ショートカットの制御を行う
        this.setShortcutBtnDefs(mode);
    }

    /**
     * 部門コンボボックスの変更処理
     */
    public segmentIdChange(): void {
        // 部門のラジオボタン制御
        if (this.selectSegmentId > 0) {
            this.selectSegment = 1;
        }

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }
}