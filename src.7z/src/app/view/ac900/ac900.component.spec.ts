import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac900Component } from './ac900.component';

describe('Ac900Component', () => {
  let component: Ac900Component;
  let fixture: ComponentFixture<Ac900Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac900Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac900Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
