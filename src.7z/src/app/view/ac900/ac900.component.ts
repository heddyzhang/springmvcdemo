import { Component, ViewChild } from '@angular/core';
import { ComponentBase, AppType } from '../component-base';
import { AC900Service } from '../../service/AC900Service';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { AC900ResDto } from '../../dto/ac900/AC900ResDto';
import { AC900ReqDto } from '../../dto/ac900/AC900ReqDto';
import { AC900VoucherSortingDto } from '../../dto/ac900/AC900VoucherSortingDto';
import { WjFlexGridEx } from '../../component/wj-flex-grid-ex/wj-flex-grid-ex';
import { AC900VoucherSortingDeleteDto } from '../../dto/ac900/AC900VoucherSortingDeleteDto';
import { AC900VoucherSortingInsertDto } from '../../dto/ac900/AC900VoucherSortingInsertDto';
import { AC900VoucherSortingUpdateDto } from '../../dto/ac900/AC900VoucherSortingUpdateDto';
import { AC900SeqChangeDto } from '../../dto/ac900/AC900SeqChangeDto';
import { CellRange } from 'wijmo/wijmo.grid';

/** 動作モード */
enum EditorMode {
    M_Insert = 'i',             // 追加モード
    M_Update = 'u',             // 更新モード
}

@Component({
    selector: 'app-ac900',
    templateUrl: './ac900.component.html',
    styleUrls: ['./ac900.component.css']
})
export class Ac900Component extends ComponentBase {

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.G_Vouchers;

    /** 動作モード */
    public editorMode: EditorMode = EditorMode.M_Insert;

    /** ﾀｲﾑｽﾀﾝﾌﾟを押す true:変更可能 */
    public timestampUsedFlg: boolean;

    /** 証憑名称が必須項目かどうか true:必須 */
    public sortingNameRequired: boolean;

    /** 編集中（未保存の編集データが存在する） */
    private isDirty: boolean = false;

    /** 上下ボタン押下時の選択Index */
    private selectedRow: number = -1;

    @ViewChild(WjFlexGridEx)
    /** グリッドへの参照 */
    private flexGrid: WjFlexGridEx;

    /** 編集中のデータ */
    public selectItem: AC900VoucherSortingDto = new AC900VoucherSortingDto();

    /** 証憑分類マスタ一覧情報 */
    public voucherSortingList: AC900VoucherSortingDto[];

    /** ショートカットボタン（取消・更新） */
    protected shortcutBtnDefs: any = {
        'reference': [
            { tagNo: 1, enabled: false }, { tagNo: 3, enabled: false }, { tagNo: 4, enabled: false },
            { tagNo: 5, enabled: false }, { tagNo: 10, enabled: false },
        ],
        'insert': [
            { tagNo: 1, enabled: false }, { tagNo: 3, enabled: false }, { tagNo: 4, enabled: false },
            { tagNo: 5, enabled: false }, { tagNo: 10, enabled: false },
        ],
        'insert-dirty': [
            { tagNo: 1, enabled: false }, { tagNo: 3, enabled: true }, { tagNo: 4, enabled: false },
            { tagNo: 5, enabled: false }, { tagNo: 10, enabled: true },
        ],
        'update': [
            { tagNo: 1, enabled: true }, { tagNo: 3, enabled: false }, { tagNo: 10, enabled: false },
        ],
        'update-dirty': [
            { tagNo: 1, enabled: true }, { tagNo: 3, enabled: true }, { tagNo: 4, enabled: false },
            { tagNo: 5, enabled: false }, { tagNo: 10, enabled: true },
        ],
    }

    /** 会計処理区分 */
    public sortingSlipClsList: any[] = [
        { value: -1, title: "破棄" }, { value: 10, title: "入金伝票" }, { value: 20, title: "出金伝票" },
        { value: 30, title: "売掛伝票" }, { value: 40, title: "買掛伝票" }, { value: 50, title: "振替伝票" },
        { value: 59, title: "減価償却自動" }, { value: 60, title: "出納帳添付" }, { value: 70, title: "売掛帳添付" },
        { value: 80, title: "買掛帳添付" }, { value: 90, title: "バインダー" }, { value: 100, title: "楽２" }];

    /** コンストラクタ */
    constructor(private ac900Service: AC900Service, private property: EcoKaikeiProperty) {
        super(ac900Service, property);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // ショートカットボタンの名称を変える
        this.viewBaseButton4.value = '上へ';
        this.viewBaseButton5.value = '下へ';

        // ショートカットを表示
        super.displayShortCutBtn(1, 3, 4, 5, 10);

        // 初期情報を取得
        this.ac900Service.getInitial(new AC900ReqDto(), this.getInitialOnResult);
    }

    /**
     * 編集フォームのデータが変更された
     */
    public setDirtyFlag(): void {

        if (!this.isDirty) {
            // 編集済みフラグを設定して、ショートカットを反映する
            this.isDirty = true;
            this.updateShortcutButtonStatus();
        }
    }

    /**
     * 証憑分類マスタ一覧グリッドで選択が変更された際の処理
     */
    public voucherSortingGridSelectionChanged(): void {

        // 選択の有無でモードを切り替える
        this.editorMode = this.flexGrid.selectedItems.length === 0
            ? EditorMode.M_Insert : EditorMode.M_Update;

        // 初期化を行う
        this.setInitData();
    }

    /**
     * 証憑分類マスタ一覧にデータを設定した際の処理
     */
    public gridItemsSourceChanged(): void {

        // 初期選択行
        if (this.selectedRow > -1) {
            this.flexGrid.selectionRow(this.selectedRow);
            this.selectedRow = -1;
            return;
        }

        // 初期化を行う
        this.setInitData();
    }
    /**
     * 削除ボタンの押下処理
     */
    public deleteRowBtnClick(deleteItem: AC900VoucherSortingDto): void {

        // 削除不可能な証憑分類
        if (deleteItem.evidenceEcokaikeiName) {
            return;
        }

        // 確認ダイアログ 選択された情報を削除しますか？
        this.eAlert.message('120021', [], null, () => {
            // 追加行の削除
            if (deleteItem.voucherSortingId === -1) {
                // 対象の行を削除
                this.voucherSortingList.splice(this.voucherSortingList.findIndex(n => n === deleteItem), 1);
                this.flexGrid.collectionView.refresh();

                return;
            }

            // 登録済みの証憑分類の削除 => 削除用のリクエストを生成
            var reqDto: AC900ReqDto = new AC900ReqDto();
            var reqDeleteItem: AC900VoucherSortingDeleteDto = new AC900VoucherSortingDeleteDto();
            // 削除対象のIDと更新日時をセット
            reqDeleteItem.voucherSortingId = deleteItem.voucherSortingId;
            reqDeleteItem.updatedAt = deleteItem.updatedAt;
            reqDto.voucherSortingDeleteDto = reqDeleteItem;

            // 取消処理を実行
            this.ac900Service.delete(reqDto, this.deletelOnResult);
        });
    }

    /**
     * 追加ボタンの押下処理
     */
    public addBtnClick(): void {

        // 証憑分類一覧グリッドの選択を解除
        this.flexGrid.selectionClear();

        // 管理番号にフォーカスを設定する
        document.getElementById('managementNo').focus();
    }

    /**
     * 取消ボタンの押下処理
     */
    public cancelBtnClick(): void {

        // 初期状態に戻す
        this.setInitData();
    }

    /**
     * 上へボタンの押下処理
     */
    public upBtnClick(): void {

        // 一番上の項目
        if (this.flexGrid.selection.row === 0) {
            return;
        }

        // 変更後のIndexを保存
        this.selectedRow = this.flexGrid.selection.row - 1;

        // 順序を入れ替える
        this.seqChange(this.flexGrid.collectionView.items[this.flexGrid.selection.row]
            , this.flexGrid.collectionView.items[this.flexGrid.selection.row - 1]);
    }

    /**
     * 下へボタンの押下処理
     */
    public downBtnClick(): void {

        // 一番下の項目
        if (this.flexGrid.selection.row === this.flexGrid.itemsSource.length - 1) {
            return;
        }

        // 変更後のIndexを保存
        this.selectedRow = this.flexGrid.selection.row + 1;

        // 順序を入れ替える
        this.seqChange(this.flexGrid.collectionView.items[this.flexGrid.selection.row + 1]
            , this.flexGrid.collectionView.items[this.flexGrid.selection.row]);
    }

    /**
     * 表示順の入れ替えを行う
     */
    private seqChange(upItem: AC900VoucherSortingDto, downItem: AC900VoucherSortingDto) {

        // 登録用リクエストを生成
        var reqDto: AC900ReqDto = new AC900ReqDto();
        reqDto.seqChangeDto = new AC900SeqChangeDto();

        // 証憑分類ID : ↓に移動するもの
        reqDto.seqChangeDto.plusVoucherSortingId = downItem.voucherSortingId;
        // 更新日 : ↓に移動するもの
        reqDto.seqChangeDto.plusUpdatedAt = downItem.updatedAt;

        // 証憑分類ID : ↑に移動するもの
        reqDto.seqChangeDto.minusVoucherSortingId = upItem.voucherSortingId;
        // 更新日 : ↑に移動するもの
        reqDto.seqChangeDto.minusUpdatedAt = upItem.updatedAt;

        this.ac900Service.seqChange(reqDto, this.seqChangeOnResult);
    }

    /**
     * 更新ボタンの押下処理
     */
    public updateBtnClick(): void {

        // 必須項目のチェック
        // 管理番号
        if (!this.selectItem.managementNo) {
            // "管理番号"は入力必須の項目です。
            this.eAlert.message('210001', ['管理番号'], 'managementNo');
            return;
        }
        // 証憑名称
        else if (!this.selectItem.evidenceEcokaikeiName && !this.selectItem.voucherSortingName) {
            // "証憑名称"は入力必須の項目です。
            this.eAlert.message('210001', ['証憑名称'], 'voucherSortingName');
            return;
        }

        // 新規追加
        if (this.editorMode === EditorMode.M_Insert) {

            // 入力したデータを登録しますか？
            this.eAlert.message('120022', [], null, () => {

                // 登録用リクエストを生成
                var reqDto: AC900ReqDto = new AC900ReqDto();
                reqDto.voucherSortingInsertDto = new AC900VoucherSortingInsertDto();

                // 証憑分類管理番号
                reqDto.voucherSortingInsertDto.managementNo = this.selectItem.managementNo;
                // 表示flg
                reqDto.voucherSortingInsertDto.voucherDispFlg = this.selectItem.voucherDispFlg;
                // 証憑分類名称
                reqDto.voucherSortingInsertDto.voucherSortingName = this.selectItem.voucherSortingName;
                // 会計処理区分
                reqDto.voucherSortingInsertDto.sortingSlipCls = this.selectItem.sortingSlipCls;
                // タイムスタンプ要否
                reqDto.voucherSortingInsertDto.timestampRequired = this.selectItem.timestampRequired;

                this.ac900Service.insert(reqDto, this.insertOnResult);
            });
        }
        // 更新処理
        else {

            // 更新します。よろしいですか？
            this.eAlert.message('120023', [], null, () => {

                // 更新用リクエストを生成
                var reqDto: AC900ReqDto = new AC900ReqDto();
                reqDto.voucherSortingUpdateDto = new AC900VoucherSortingUpdateDto();

                // 証憑分類ID
                reqDto.voucherSortingUpdateDto.voucherSortingId = this.selectItem.voucherSortingId;
                // 証憑分類管理番号
                reqDto.voucherSortingUpdateDto.managementNo = this.selectItem.managementNo;
                // 表示flg
                reqDto.voucherSortingUpdateDto.voucherDispFlg = this.selectItem.voucherDispFlg;
                // eco会計証憑名称
                reqDto.voucherSortingUpdateDto.evidenceEcokaikeiName = this.selectItem.evidenceEcokaikeiName;
                // 証憑分類名称
                reqDto.voucherSortingUpdateDto.voucherSortingName = this.selectItem.voucherSortingName;
                // 会計処理区分
                reqDto.voucherSortingUpdateDto.sortingSlipCls = this.selectItem.sortingSlipCls;
                // タイムスタンプ要否
                reqDto.voucherSortingUpdateDto.timestampRequired = this.selectItem.timestampRequired;
                // 更新日
                reqDto.voucherSortingUpdateDto.updatedAt = this.selectItem.updatedAt;

                this.ac900Service.update(reqDto, this.updateOnResult);
            });
        }
    }

    /**
     * モードによって 初期状態にする
     */
    private setInitData(): void {

        // 追加モード => 初期化 / 編集モード => 選択中情報
        this.selectItem = this.editorMode === EditorMode.M_Insert ? this.getNewVoucherSorting()
            : Object.assign({}, this.flexGrid.selectedItems[0]);

        // 証憑名称が必須かどうか
        this.sortingNameRequired = this.selectItem.evidenceEcokaikeiName ? false : true;

        // 編集中フラグをリセット
        this.isDirty = false;

        // ショートカットボタンの活性／非活性を設定
        this.updateShortcutButtonStatus();
    }

    /**
     * 新規明細
     */
    private getNewVoucherSorting(): AC900VoucherSortingDto {

        var item: AC900VoucherSortingDto = new AC900VoucherSortingDto();

        // 証憑分類ID
        item.voucherSortingId = -1;
        // 証憑分類管理番号
        item.managementNo = null;
        // 表示flg
        item.voucherDispFlg = 1;
        // 証憑分類名称
        item.voucherSortingName = '';
        // 会計処理区分
        item.sortingSlipCls = 10;
        // タイムスタンプ要否
        item.timestampRequired = 0;

        return item;
    }

    /**
     * ショートカットボタンの制御を行う
     */
    private updateShortcutButtonStatus(): void {

        // ショートカット
        var mode: string;

        // 参照モード
        if (this.isReferenceMode) {
            mode = 'reference';
        }
        // 通常モード
        else {

            // 追加モード / 編集モード
            mode = this.editorMode === EditorMode.M_Insert ? 'insert' : 'update';

            // 変更有無
            mode += this.isDirty ? '-dirty' : '';
        }

        // ショートカットの制御を行う
        this.setShortcutBtnDefs(mode);

        // 変更モード
        if (mode === 'update') {

            // 一番上の項目は、上ボタン非活性
            this.viewBaseButton4.disabled = this.flexGrid.selection.row === 0;

            // 一番下の項目は、下ボタン非活性
            this.viewBaseButton5.disabled = this.flexGrid.selection.row === this.flexGrid.itemsSource.length - 1;

            // 再表示
            this.shortCutRefresh();
        }
    }
    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     * @param resDto
     */
    private getInitialOnResult(resDto: AC900ResDto): void {

        // ﾀｲﾑｽﾀﾝﾌﾟを押す　変更可能かどうか
        this.timestampUsedFlg = resDto.timestampUsedFlg;

        // 通信完了の共通処理
        this.resultCommon(resDto);
    }

    /**
     * 削除処理 完了
     * @param resDto
     */
    private deletelOnResult(resDto: AC900ResDto): void {

        // 通信完了の共通処理
        this.resultCommon(resDto);
    }

    /**
     * 表示順序の変更処理
     * @param resDto
     */
    private seqChangeOnResult(resDto: AC900ResDto): void {

        // 通信完了の共通処理
        this.resultCommon(resDto);
    }

    /**
     * 新規登録処理 完了
     * @param resDto
     */
    private insertOnResult(resDto: AC900ResDto): void {

        // 通信完了の共通処理
        this.resultCommon(resDto);
    }

    /**
     * 更新処理 完了
     * @param resDto
     */
    private updateOnResult(resDto: AC900ResDto): void {

        // 通信完了の共通処理
        this.resultCommon(resDto);
    }

    /**
     * ResultEventHandlerの共通部分
     * @param resDto
     */
    private resultCommon(resDto: AC900ResDto): void {

        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        // 証憑一覧情報を設定
        this.voucherSortingList = resDto.voucherSortingDtoList;

        // 更新モード
        this.editorMode = EditorMode.M_Update;
    }
}
