import { ViewChild, OnInit, OnDestroy } from "@angular/core";
import { EAlertComponent } from "../component/e-alert/e-alert.component";
import { ViewBaseButton } from "../component/view-base/view-base.button";
import { EServiceBase } from "../service/EServiceBase";
import { ViewBaseComponent } from "../component/view-base/view-base.component";
import { EcoKaikeiProperty } from "../eco.kaikei.property";
import { EProgressBarComponent } from "../component/e-progress-bar/e-progress-bar.component";
import { WjPopup } from "wijmo/wijmo.angular2.input";
import { PopupTrigger } from "wijmo/wijmo.input";

/**
 * ACXXXComponentの基底クラス
 *
 * (必須)
 * appTypeを設定する (各仕様書の権限を設定))
 * constructorで、ACXXXServiceとEcoKaikeiPropertyを設定する
 * ngOnInit ではなく、ecoOnInitを使用する (=> 権限チェック等があるため)
 *
 * eAlertを使用する (=> ServiceBaseでも使用しているのでpublic)
 * ショートカットの変更は以下の方法で制御する
 *   ・displayShortCutBtnメソッド => 表示したいショートカット番号を設定
 *   ・enabledShortCutBtnメソッド => 活性 / 非活性
 *   ・viewBaseButtonXでボタンのプロパティを変更 => shortCutRefreshメソッドで反映
 *
 *  * 制御用の配列 (=> shortcutBtnDefs)
 * shortcutBtnDefs = {'type': [{tagNo: 1, enabled: false}]};
 */
export class ComponentBase implements OnInit, OnDestroy, IComponentBase {

    /** アラート */
    public eAlert: EAlertComponent;

    @ViewChild(ViewBaseComponent)
    protected base: ViewBaseComponent;

    @ViewChild(EProgressBarComponent)
    /** プログレスバー */
    public progressBar: EProgressBarComponent;

    /** アプリケーションのタイプ */
    protected appType: AppType = AppType.Non;

    /** ショートカット制御用の配列 */
    protected shortcutBtnDefs:any;

    /**
     * ショートカット制御用の配列に基づいて、ショートカットを制御する
     * @param typeNames
     */
    protected setShortcutBtnDefs(...typeNames:string[]): void {

        // ショートカットの編集があるかどうか
        var editFlg: boolean = false;

        // 指定の設定文字列分処理を行う
        typeNames.forEach(typeName => {

            // ショートカットボタンの値を取得する
            var button_defs = this.shortcutBtnDefs[typeName];

            // 設定値に基づいてショートカットボタンの制御を行う
            button_defs.forEach(def => {

                // 変更の有無をチェック
                if (this.viewBaseButtonList[def.tagNo - 1].disabled === def.enabled) {

                    // ボタンの活性/非活性の切り替え
                    this.viewBaseButtonList[def.tagNo - 1].disabled = !def.enabled;
                    // ショートカットの編集 : あり
                    editFlg = true;
                }
            })
        });

        // ショートカットの編集がある場合に再描画を行う
        if (editFlg) {
            // 再表示
            this.shortCutRefresh();
        }
    }

    /** 参照フラグ => true:参照モード false:通常モード */
    private _isReferenceMode: Boolean = false;
    public get isReferenceMode(): Boolean {
        return this._isReferenceMode;
    }

    /** ショートカットボタン */
    public viewBaseButton1: ViewBaseButton = new ViewBaseButton({ value: '追加', disabled: true });
    public viewBaseButton2: ViewBaseButton = new ViewBaseButton({ value: '削除', disabled: true });
    public viewBaseButton3: ViewBaseButton = new ViewBaseButton({ value: '取消', disabled: true });
    public viewBaseButton4: ViewBaseButton = new ViewBaseButton({ value: '', disabled: true });
    public viewBaseButton5: ViewBaseButton = new ViewBaseButton({ value: '', disabled: true });
    public viewBaseButton6: ViewBaseButton = new ViewBaseButton({ value: 'CSV表示', disabled: true });
    public viewBaseButton7: ViewBaseButton = new ViewBaseButton({ value: '表示', disabled: true });
    public viewBaseButton8: ViewBaseButton = new ViewBaseButton({ value: '印刷', disabled: true });
    public viewBaseButton9: ViewBaseButton = new ViewBaseButton({ value: 'ﾗﾍﾞﾙ印刷', disabled: true });
    public viewBaseButton0: ViewBaseButton = new ViewBaseButton({ value: '更新', disabled: true });

    /** ショートカットボタンの配列 */
    public viewBaseButtonList: ViewBaseButton[] = [this.viewBaseButton1, this.viewBaseButton2
        , this.viewBaseButton3, this.viewBaseButton4, this.viewBaseButton5, this.viewBaseButton6
        , this.viewBaseButton7, this.viewBaseButton8, this.viewBaseButton9, this.viewBaseButton0];

    /** コンストラクタ */
    constructor(private service: EServiceBase, private propertyBase: EcoKaikeiProperty) {
        service.hostComponent = this;
    }

    /**
     * 初期処理
     */
    public ngOnInit(): void {

        // アラートを設定
        this.eAlert = this.base.eAlert;

        // 会計年度未作成時 アクセス可能権限
        if (this.appType === AppType.H_InitAll) {

            // 処理を開始して終了
            this.ecoOnInit();
            return;
        }

        // エラーを含むかどうか
        var hasError: boolean = false;

        // 権限チェック
        // 最新年度
        if (this.propertyBase.ownershipDto.newFisicalYear) {
            switch (this.appType) {
                case AppType.A_All:
                    break;
                case AppType.B_CreateSlip:
                case AppType.E_Settlement:
                case AppType.G_Vouchers:
                    // 照会はエラー
                    if (this.propertyBase.userAuthorityCls === 3) {
                        hasError = true;
                    }
                    break;
                case AppType.C_Report:
                    // 全て参照モード
                    this._isReferenceMode = true;
                    break;
                case AppType.D_Master:
                    // 照会 / 会計事務所 : 参照モード
                    if (this.propertyBase.userAuthorityCls === 3
                        || this.propertyBase.userAuthorityCls === 4) {
                        this._isReferenceMode = true;
                    }
                    break;
                case AppType.F_Administrator:
                    // 管理者以外はエラー
                    if (this.propertyBase.userAuthorityCls !== 1) {
                        hasError = true;
                    }
                    break;
                default:
                    hasError = true;
            }
        }
        // 過去年度
        else {
            // 全て参照モード
            this._isReferenceMode = true;

            // アプリケーションのタイプによってログイン不可
            switch (this.appType) {
                case AppType.A_All:
                case AppType.E_Settlement:
                case AppType.F_Administrator:
                    // 全てエラー
                    hasError = true;
                    break;
                case AppType.B_CreateSlip:
                case AppType.G_Vouchers:
                    // 照会はエラー
                    if (this.propertyBase.userAuthorityCls === 3) {
                        hasError = true;
                    }
                    break;
                case AppType.C_Report:
                case AppType.D_Master:
                    break;
                default:
                    hasError = true;
            }
        }

        // エラーの有無をチェック
        hasError ? this.service.errorLogout() : this.ecoOnInit();
    }

    /**
     * 終了時
     */
    public ngOnDestroy(): void {

        // サービスクラスへの参照を破棄
        this.service.hostComponent = null;
    }

    /**
     * 子画面で上書きする
     */
    protected ecoOnInit(): void {
    }

    /**
     * ショートカットボタンのリフレッシュ
     */
    protected shortCutRefresh(): void {

        // ショートカットの再生成を行う
        this.viewBaseButtonList = JSON.parse(JSON.stringify(this.viewBaseButtonList));

        // 参照を更新
        this.viewBaseButton1 = this.viewBaseButtonList[0];
        this.viewBaseButton2 = this.viewBaseButtonList[1];
        this.viewBaseButton3 = this.viewBaseButtonList[2];
        this.viewBaseButton4 = this.viewBaseButtonList[3];
        this.viewBaseButton5 = this.viewBaseButtonList[4];
        this.viewBaseButton6 = this.viewBaseButtonList[5];
        this.viewBaseButton7 = this.viewBaseButtonList[6];
        this.viewBaseButton8 = this.viewBaseButtonList[7];
        this.viewBaseButton9 = this.viewBaseButtonList[8];
        this.viewBaseButton0 = this.viewBaseButtonList[9];
    }

    /**
     * 指定されたタグのショートカットの表示を行う
     * @param tagNos
     */
    protected displayShortCutBtn(...tagNos: number[]): void {

        // ショートカットを非表示
        this.viewBaseButtonList.forEach(function (targetBtn) {
            targetBtn.display = undefined;
        });

        // 指定されたものを表示
        tagNos.forEach(tagNo => {
            var targetBtn: ViewBaseButton = this.viewBaseButtonList[tagNo - 1];
            targetBtn.display = true;
        });

        // 再表示
        this.shortCutRefresh();
    }

    /**
     * 指定されたタグのショートカットの活性/非活性の切り替えを行う
     * @param tagNo
     * @param btnDisabled
     */
    protected enabledShortCutBtn(tagNo: number, btnEnabled: boolean): void {

        // 値が変化しないなら処理を中断
        if (this.viewBaseButtonList[tagNo - 1].disabled !== btnEnabled) {
            return;
        }

        // ボタンの活性/非活性の切り替え
        this.viewBaseButtonList[tagNo - 1].disabled = !btnEnabled;

        // 再表示
        this.shortCutRefresh();
    }

    /**
     * 指定のURLを別タブで開き、指定popupを表示する
     * @param pop
     * @param url
     */
    protected openLockWindow(pop: WjPopup, closeFunction: Function, url: string): void {

        // 別タブでウィンドウを表示
        var win: Window = window.open(url);

        // ポップアップブロックされている場合
        if (win === null) {
            // ブラウザによってポップアップがブロックされています。\nポップアップを許可してください。
            this.eAlert.message('100011', [], null, () => {});
            // ポップアップをクローズ
            pop.hide();
            return;
        }

        // ポップアップを表示
        pop.hideTrigger = PopupTrigger.None;
        pop.show(true);

        closeFunction = closeFunction.bind(this);

        // 0.5秒単位でウィンドウが開いているかチェック
        var interval = setInterval(() => {
            if (win !== null && !win.closed) {
                // ウィンドウが存在する間はループ
                return;
            }
            // ポップアップをクローズ
            pop.hide();
            // ループを停止
            clearInterval(interval);
            // ウィンドウが閉じられた際のファンクションを実行
            closeFunction();

        }, 500);
    }


}

/**
 * ComponentBaseのインターフェース
 */
export interface IComponentBase {
    /** アラート */
    eAlert: EAlertComponent;
    /** プログレスバー */
    progressBar: EProgressBarComponent;
}

/**
 * a 誰でも処理
 * b 伝票登録
 * c レポート
 * d マスタ管理
 * e 決算
 * f 管理者
 * g 証憑
 * h 会計年度未作成時 誰でも処理
 */
export enum AppType {
    // 誰でも処理
    A_All = 'a',
    // 伝票登録
    B_CreateSlip = 'b',
    // レポート
    C_Report = 'c',
    // マスタ管理
    D_Master = 'd',
    // 決算
    E_Settlement = 'e',
    // 管理者
    F_Administrator = 'f',
    // 証憑
    G_Vouchers = 'g',
    // 会計年度未作成時誰でも処理
    H_InitAll = 'h',

    // 初期値
    Non = 'non',
}
