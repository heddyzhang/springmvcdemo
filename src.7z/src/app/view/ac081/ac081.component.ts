import { Component, ViewChild, ViewEncapsulation } from '@angular/core';
import { AC081Service } from '../../service/AC081Service';
import { AC081ReqDto } from '../../dto/ac081/AC081ReqDto';
import { AC081ResDto } from '../../dto/ac081/AC081ResDto';
import { AC081CustomerDto } from '../../dto/ac081/AC081CustomerDto';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { ComponentBase, AppType } from '../component-base';
import { WjFlexGridEx } from '../../component/wj-flex-grid-ex/wj-flex-grid-ex';
import { AC081DeleteCustomerDto } from '../../dto/ac081/AC081DeleteCustomerDto';
import { EConfigureReportPopComponent } from '../../component/e-configure-report-pop/e-configure-report-pop.component';
import { AC081InsertCustomerDto } from '../../dto/ac081/AC081InsertCustomerDto';
import { AC081UpdateCustomerDto } from '../../dto/ac081/AC081UpdateCustomerDto';
import { AC081UserCodeDto } from '../../dto/ac081/AC081UserCodeDto';
import { substrByByte } from '../../util/string.util';

/** 動作モード */
enum EditorMode {
    M_Insert = 'i',             // 追加モード
    M_Update = 'u',             // 更新モード
}
@Component({
    selector: 'app-ac081',
    templateUrl: './ac081.component.html',
    styleUrls: ['./ac081.component.css'],
})
export class Ac081Component extends ComponentBase {

    @ViewChild('reportPop')
    /** 印刷条件ポップアップ */
    private reportPop: EConfigureReportPopComponent;

    @ViewChild('customersGrid')
    /** 社員一覧への参照 */
    private customersGrid: WjFlexGridEx;

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.D_Master;

    /** 動作モード */
    public editorMode: EditorMode = EditorMode.M_Insert;

    /** 編集中（未保存の編集データが存在する） */
    private isDirty: boolean = false;

    /** ショートカットボタン（追加・削除・取消・更新） */
    protected shortcutBtnDefs: any = {
        'reference': [
            { tagNo: 1, enabled: false }, { tagNo: 2, enabled: false }, { tagNo: 3, enabled: false }, { tagNo: 10, enabled: false },
        ],
        'insert': [
            { tagNo: 1, enabled: false }, { tagNo: 2, enabled: false }, { tagNo: 3, enabled: false }, { tagNo: 10, enabled: false },
        ],
        'insert-dirty': [
            { tagNo: 1, enabled: false }, { tagNo: 2, enabled: false }, { tagNo: 3, enabled: true }, { tagNo: 10, enabled: true },
        ],
        'update': [
            { tagNo: 1, enabled: true }, { tagNo: 2, enabled: true }, { tagNo: 3, enabled: false }, { tagNo: 10, enabled: false },
        ],
        'update-dirty': [
            { tagNo: 1, enabled: true }, { tagNo: 2, enabled: true }, { tagNo: 3, enabled: true }, { tagNo: 10, enabled: true },
        ],
        'no-print': [
            { tagNo: 8, enabled: false }, { tagNo: 9, enabled: false },
        ],
        'print': [
            { tagNo: 8, enabled: true }, { tagNo: 9, enabled: true },
        ],
    }

    /** 振込先口座種別 */
    public customerBankClsTemplates: any[] = [
        { value: -1, title: "未設定" },
        { value: 1, title: "普通" },
        { value: 2, title: "当座" },
        { value: 4, title: "貯蓄" },
        { value: 9, title: "その他" },
    ];

    /** データベースから取得した社員一覧 */
    public customerDtoList: AC081CustomerDto[];

    /** 一覧内容 */
    public userCodeList: AC081UserCodeDto[];

    // 社員一覧グリッドで選択されている社員レコード
    public selectItem: AC081CustomerDto = new AC081CustomerDto();

    /** コンストラクタ */
    constructor(private ac081Service: AC081Service, private property: EcoKaikeiProperty) {
        super(ac081Service, property);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // ショートカットを表示
        //super.displayShortCutBtn(1, 2, 3, 8, 9, 10);
        // TODO 印刷未実装
        super.displayShortCutBtn(1, 2, 3, 10);

        // 社員一覧にフォーカスを設定する
        document.getElementById('customersGrid').focus();

        // 初期情報を取得
        this.ac081Service.getInitial(new AC081ReqDto(), this.getInitialOnResult);
    }

    /**
     * 一覧へのデータ設定時の処理
     */
    public customersiItemsSourceChanged(): void {

        // 初期化を行う
        this.setInitData();
    }

    /**
     * 社員一覧グリッドで選択が変更された際の処理
     */
    public customersGridSelectionChanged(): void {

        // 選択の有無でモードを切り替える
        this.editorMode = this.customersGrid.selectedItems.length === 0
            ? EditorMode.M_Insert : EditorMode.M_Update;

        // 初期化を行う
        this.setInitData();
    }

    /**
     * 住所検索
     */
    public zipCdBtnClick(): void {

        // リクエストに郵便番号を設定する
        var reqDto: AC081ReqDto = new AC081ReqDto();
        reqDto.zipCd = this.selectItem.customerZipCd;

        // 入力済みの郵便番号から住所を取得する
        this.ac081Service.getAddress(reqDto, this.getAddressOnResult);
    }

    /**
     * 追加ボタンクリックイベント
     */
    public insertBtnClick(): void {

        // 選択を解除 => customersGridSelectionChanged()の呼び出し
        this.customersGrid.selectionClear();

        // 管理番号にフォーカスを設定する
        document.getElementById('customerManagementNo').focus();
    }

    /**
     * 削除ボタンクリックイベント
     */
    public deleteBtnClick(): void {

        // 確認ダイアログ 選択された情報を削除しますか？
        this.eAlert.message('120021', [], null, () => {

            // 削除用リクエストを生成する
            var reqDto: AC081ReqDto = new AC081ReqDto();
            // 削除対象のIDと更新時間を設定する
            reqDto.deleteCustomerDto = new AC081DeleteCustomerDto();
            reqDto.deleteCustomerDto.customerId = this.selectItem.customerId;
            reqDto.deleteCustomerDto.updatedAt = this.selectItem.updatedAt;

            // 削除を行う
            this.ac081Service.delete(reqDto, this.deleteOnResult);
        });
    }

    /**
     * 取消ボタンクリックイベント
     */
    public cancelBtnClick(): void {

        // モードによって 初期状態にする
        this.setInitData();
    }

    /**
     * 印刷ボタンクリックイベント
     */
    public printBtnClick(): void {

        // リクエストを生成
        var reqDto: AC081ReqDto = new AC081ReqDto();

        this.reportPop.show(reqDto, () => {
            // 印刷のプレ処理 => 印刷 を行う
            this.ac081Service.onPrint(reqDto, '社員一覧');
        });
    }

    /**
     * ラベル印刷ボタンクリックイベント
     */
    public labelPrintBtnClick(): void {

    }

    /**
     * 更新ボタンクリックイベント
     */
    public updateBtnClick(): void {

        // 必須項目のチェック
        // 管理番号
        if (!this.selectItem.customerManagementNo) {
            // "管理番号"は入力必須の項目です。
            this.eAlert.message('210001', ['管理番号'], 'customerManagementNo');
            return;
        }
        // 氏名
        else if (!this.selectItem.customerName) {
            // "氏名"は入力必須の項目です。
            this.eAlert.message('210001', ['氏名'], 'customerName');
            return;
        }
        // 検索キー
        else if (!this.selectItem.customerKana) {
            // "検索キー"は入力必須の項目です。
            this.eAlert.message('210001', ['検索キー'], 'customerKana');
            return;
        }
        // 住所1
        else if (!this.selectItem.customerAddress1) {
            // "住所（都道府県 市町村区）"は入力必須の項目です。
            this.eAlert.message('210001', ['住所（都道府県 市町村区）'], 'customerAddress1');
            return;
        }
        // 住所2
        else if (!this.selectItem.customerAddress2) {
            // "住所（番地 マンション）"は入力必須の項目です。
            this.eAlert.message('210001', ['住所（番地 マンション）'], 'customerAddress2');
            return;
        }
        // TEL
        else if (!this.selectItem.customerPhoneNo) {
            // "電話番号"は入力必須の項目です。
            this.eAlert.message('210001', ['電話番号'], 'customerPhoneNo');
            return;
        }

        // 新規追加
        if (this.editorMode === EditorMode.M_Insert) {

            // 入力したデータを登録しますか？
            this.eAlert.message('120022', [], null, () => {

                // 登録用リクエストを生成
                var reqDto: AC081ReqDto = new AC081ReqDto();

                reqDto.insertCustomerDto = new AC081InsertCustomerDto();

                // 取引先管理NO
                reqDto.insertCustomerDto.customerManagementNo = this.selectItem.customerManagementNo;
                // 取引先名称
                reqDto.insertCustomerDto.customerName = this.selectItem.customerName;
                // 取引先略称
                reqDto.insertCustomerDto.customerShortName = substrByByte(this.selectItem.customerName, 14);
                // 取引先カナ
                reqDto.insertCustomerDto.customerKana = this.selectItem.customerKana;
                // 取引先郵便番号
                reqDto.insertCustomerDto.customerZipCd = this.selectItem.customerZipCd;
                // 取引先住所1
                reqDto.insertCustomerDto.customerAddress1 = this.selectItem.customerAddress1;
                // 取引先住所2
                reqDto.insertCustomerDto.customerAddress2 = this.selectItem.customerAddress2;
                // 取引先電話番号
                reqDto.insertCustomerDto.customerPhoneNo = this.selectItem.customerPhoneNo;
                // 銀行コード
                reqDto.insertCustomerDto.customerBank = this.selectItem.customerBank;
                // 支店コード
                reqDto.insertCustomerDto.customerBranch = this.selectItem.customerBranch;
                // 預金種別
                reqDto.insertCustomerDto.customerBankCls = this.selectItem.customerBankCls;
                // 口座番号
                reqDto.insertCustomerDto.customerBankNumber = this.selectItem.customerBankNumber;
                // 名義人名
                reqDto.insertCustomerDto.customerBankHolder = this.selectItem.customerBankHolder;

                this.ac081Service.insert(reqDto, this.insertOnResult);
            });
        }
        // 更新処理
        else {

            // 更新します。よろしいですか？
            this.eAlert.message('120023', [], null, () => {

                // 更新用リクエストを生成
                var reqDto: AC081ReqDto = new AC081ReqDto();
                reqDto.updateCustomerDto = new AC081UpdateCustomerDto();

                // 取引先ID
                reqDto.updateCustomerDto.customerId = this.selectItem.customerId;
                // 取引先管理NO
                reqDto.updateCustomerDto.customerManagementNo = this.selectItem.customerManagementNo;
                // 取引先名称
                reqDto.updateCustomerDto.customerName = this.selectItem.customerName;
                // 取引先略称
                reqDto.updateCustomerDto.customerShortName = substrByByte(this.selectItem.customerName, 14);
                // 取引先カナ
                reqDto.updateCustomerDto.customerKana = this.selectItem.customerKana;
                // 取引先郵便番号
                reqDto.updateCustomerDto.customerZipCd = this.selectItem.customerZipCd;
                // 取引先住所1
                reqDto.updateCustomerDto.customerAddress1 = this.selectItem.customerAddress1;
                // 取引先住所2
                reqDto.updateCustomerDto.customerAddress2 = this.selectItem.customerAddress2;
                // 取引先電話番号
                reqDto.updateCustomerDto.customerPhoneNo = this.selectItem.customerPhoneNo;
                // 銀行コード
                reqDto.updateCustomerDto.customerBank = this.selectItem.customerBank;
                // 支店コード
                reqDto.updateCustomerDto.customerBranch = this.selectItem.customerBranch;
                // 預金種別
                reqDto.updateCustomerDto.customerBankCls = this.selectItem.customerBankCls;
                // 口座番号
                reqDto.updateCustomerDto.customerBankNumber = this.selectItem.customerBankNumber;
                // 名義人名
                reqDto.updateCustomerDto.customerBankHolder = this.selectItem.customerBankHolder;
                /** 更新日 */
                reqDto.updateCustomerDto.updatedAt = this.selectItem.updatedAt;

                this.ac081Service.update(reqDto, this.updateOnResult);
            });
        }
    }

    /**
     * 編集フォームのデータが変更された
     */
    public setDirtyFlag(): void {

        if (!this.isDirty) {
            // 編集済みフラグを設定して、ショートカットを反映する
            this.isDirty = true;
            this.updateShortcutButtonStatus();
        }
    }

    /**
     * 一覧情報の更新
     */
    public itemsSourceChanged(): void {

        // 管理番号にフォーカスを設定する
        document.getElementById('customerManagementNo').focus();
    }

    /**
     * ショートカットボタンの制御を行う
     */
    private updateShortcutButtonStatus(): void {

        // ショートカット
        var mode: string;
        var printMode: string;

        // 参照モード
        if (this.isReferenceMode) {
            mode = 'reference';
        }
        // 通常モード
        else {

            // 追加モード / 編集モード
            mode = this.editorMode === EditorMode.M_Insert ? 'insert' : 'update';

            // 変更有無
            mode += this.isDirty ? '-dirty' : '';
        }

        // 社員一覧の有無によってショートカットを制御する
        if (!this.customerDtoList || this.customerDtoList.length === 0) {
            printMode = 'no-print';
        }
        else {
            printMode = 'print';
        }

        // ショートカットの制御を行う
        this.setShortcutBtnDefs(mode, printMode);
    }

    /**
     * モードによって 初期状態にする
     */
    private setInitData(): void {

        // 追加モード => 初期化 / 編集モード => 選択中情報
        this.selectItem = this.editorMode === EditorMode.M_Insert ? new AC081CustomerDto()
            : Object.assign({}, this.customersGrid.selectedItems[0]);

        // 編集中フラグをリセット
        this.isDirty = false;

        // ショートカットボタンの活性／非活性を設定
        this.updateShortcutButtonStatus();
    }

    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     */
    private getInitialOnResult(resDto: AC081ResDto): void {

        // 社員一覧の設定とモード変更
        this.resultCommon(resDto);
    }

    /**
     * 住所検索 完了
     * @param resDto
     */
    private getAddressOnResult(resDto: AC081ResDto): void {

        // 住所の設定をおこなう
        this.selectItem.customerAddress1 = resDto.address1;
        this.selectItem.customerAddress2 = resDto.address2;

        // 項目の変更
        this.setDirtyFlag();
    }

    /**
     * 削除処理 完了
     * @param resDto
     */
    private deleteOnResult(resDto: AC081ResDto): void {

        // 社員一覧の設定とモード変更
        this.resultCommon(resDto);
    }

    /**
     * 登録処理 完了
     * @param resDto
     */
    private insertOnResult(resDto: AC081ResDto): void {

        // 社員一覧の設定とモード変更
        this.resultCommon(resDto);
    }

    /**
     * 更新処理 完了
     * @param resDto
     */
    private updateOnResult(resDto: AC081ResDto): void {

        // 社員一覧の設定とモード変更
        this.resultCommon(resDto);
    }

    /**
     * ResultEventHandlerの共通部分
     * @param resDto
     */
    private resultCommon(resDto: AC081ResDto): void {

        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        // 登録社員を保存
        this.userCodeList = resDto.userCodeDtoList;

        // 社員一覧を保存
        this.customerDtoList = resDto.customerDtoList;

        //取引先ポップアップを更新
        this.property.customerPopupItemList = resDto.customerPopupItemList;

        // 一覧の件数によってモードを設定する
        if (!this.customerDtoList || this.customerDtoList.length === 0) {
            this.editorMode = EditorMode.M_Insert;
        }
        else {
            this.editorMode = EditorMode.M_Update;
        }
    }
}
