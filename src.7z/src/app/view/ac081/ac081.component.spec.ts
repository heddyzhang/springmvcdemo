import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac081Component } from './ac081.component';

describe('Ac081Component', () => {
  let component: Ac081Component;
  let fixture: ComponentFixture<Ac081Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac081Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac081Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
