import { Component, ViewChild } from '@angular/core';
import { ComponentBase, AppType } from '../component-base';
import { AC020Service } from '../../service/AC020Service';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { AC020ReqDto } from '../../dto/ac020/AC020ReqDto';
import { EConfigureReportPopComponent } from '../../component/e-configure-report-pop/e-configure-report-pop.component';
import { EMonthSliderSelectRMonth, EMonthSliderComponent } from '../../component/e-month-slider/e-month-slider.component';
import { Router } from '@angular/router';
import { AC020CustomerDto } from '../../dto/ac020/AC020CustomerDto';
import { AC020ResDto } from '../../dto/ac020/AC020ResDto';
import { AC020UserAuthorityDto } from '../../dto/ac020/AC020UserAuthorityDto';
import { AC020UserAccountDto } from '../../dto/ac020/AC020UserAccountDto';
import { AC020UserPasswordDto } from '../../dto/ac020/AC020UserPasswordDto';

@Component({
    selector: 'app-ac020',
    templateUrl: './ac020.component.html',
    styleUrls: ['./ac020.component.css']
})
export class Ac020Component extends ComponentBase {

    /** アプリケーションIDを設定 */
    private appID: string = 'ac020';

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.A_All;

    /** 氏名 */
    public userName: string = '';

    /** メールアドレス */
    public userAccount: string = '';

    /** パスワード */
    public userPassword: string = '';

    /** 役職 */
    public userPosition: string = '';

    /** 利用者権限 */
    public userAuthorityCls: number;

    /** 利用者権限(表示用) */
    public userAuthorityClsLabel: string = '';

    /** 経費精算権限 */
    public userSettlementCls: number;

    /** 経費精算権限(表示用) */
    public userSettlementClsLabel: string = '';

    /** 取引先郵便番号 */
    public customerZipCd: string = '';

    /** 取引先住所1 */
    public customerAddress1: string = '';

    /** 取引先住所2 */
    public customerAddress2: string = '';

    /** 取引先電話番号 */
    public customerPhoneNo: string = '';

    /** 銀行コード */
    public customerBank: string = '';

    /** 銀行名称 */
    public customerBankDisp: string = '';

    /** 支店コード */
    public customerBranch: string = '';

    /** 支店名称 */
    public customerBranchDisp: string = '';

    /** 預金種別 */
    public customerBankCls: number;

    /** 預金種別(表示用) */
    public customerBankClsLabel: string = '';

    /** 口座番号 */
    public customerBankNumber: string = '';

    /** 名義人名 */
    public customerBankHolder: string = '';

    /** userAuthorityDto */
    public userAuthorityDto: AC020UserAuthorityDto = new AC020UserAuthorityDto();

    /** customerDto */
    public customerDto: AC020CustomerDto = new AC020CustomerDto();

    /** メールアドレス変更ボタンを非活性化 */
    public userAccountBtnFlg: boolean = true;

    /** パスワード変更ボタンを非活性化 */
    public userPasswordBtnFlg: boolean = true;

    /** コンストラクタ */
    constructor(private ac020Service: AC020Service, private property: EcoKaikeiProperty, private router: Router) {
        super(ac020Service, property);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // 初期情報を取得
        this.ac020Service.getInitial(new AC020ReqDto(), this.getInitialOnResult);

    }

    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     * @param resDto
     */
    private getInitialOnResult(resDto: AC020ResDto): void {

        // DBから取得した情報を表示する
        this.customerDto = resDto.customerDto;
        this.userAuthorityDto = resDto.userAuthorityDto;
        this.userName = resDto.userName;
        this.userAccount = resDto.userAccount;
        this.userPassword = resDto.userPassword;
    }

    /**
     * メールアドレス変更イベント
     */
    public setUserAccountChange(): void {

        // アドレスが変更された場合、変更ボタンが活性化。
        this.userAccountBtnFlg = false;
    }

    /**
     * パスワード変更イベント
     */
    public setUserPasswordChange(): void {

        // パスワードが変更された場合、変更ボタンが活性化。
        this.userPasswordBtnFlg = false;

    }

    /**
     * メールアドレス変更ボタンの押下処理
     */
    public userAccountBtnClick(): void {

            // リクエストを生成
            var reqDto: AC020ReqDto = new AC020ReqDto();

            var userAccountDto: AC020UserAccountDto = new AC020UserAccountDto();

            reqDto.userAccountDto = userAccountDto;

            reqDto.userAccountDto.userAccount = this.userAccount;

            this.ac020Service.updateUserAccount(reqDto, this.updateUserAccountResult);

    }

    /**
     * パスワード変更ボタンの押下処理
     */
    public userPasswordBtnClick(): void {

        // 更新します。よろしいですか？
        this.eAlert.message('120023', [], null, () => {

            // リクエストを生成
            var reqDto: AC020ReqDto = new AC020ReqDto();

            var userPasswordDto: AC020UserPasswordDto = new AC020UserPasswordDto();

            reqDto.userPasswordDto = userPasswordDto;

            reqDto.userPasswordDto.userPassword = this.userPassword;

            this.ac020Service.updateUserPassword(reqDto, this.updateUserPasswordResult);

        });

    }

    /**
     * メールアドレス更新 完了
     * @param resDto
     */
    private updateUserAccountResult(resDto: AC020ResDto): void {

    }

    /**
     * パスワード更新 完了
     * @param resDto
     */
    private updateUserPasswordResult(resDto: AC020ResDto): void {

    }

}
