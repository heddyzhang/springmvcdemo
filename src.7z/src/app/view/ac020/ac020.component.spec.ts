import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac020Component } from './ac020.component';

describe('ac020Component', () => {
  let component: Ac020Component;
  let fixture: ComponentFixture<Ac020Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac020Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac020Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
