import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { ComponentBase, AppType } from '../component-base';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { ETabBarComponent } from "../../component/e-tab-bar/e-tab-bar.component";
import { ETabBarDecoComponent } from "../../component/e-tab-bar-deco/e-tab-bar-deco.component";
import { AC380Service } from '../../service/AC380Service';
import { AC380ReqDto } from '../../dto/ac380/AC380ReqDto';
import { AC380ResDto } from '../../dto/ac380/AC380ResDto';
import { ConditionEviPopupComponent } from '../../component/condition-evi-popup/condition-evi-popup.component';

@Component({
  selector: 'app-npc-test',
  templateUrl: './npc-test.component.html',
  styleUrls: ['./npc-test.component.css']
})
export class NpcTestComponent extends ComponentBase {

    constructor(private ac380Service: AC380Service, public property: EcoKaikeiProperty) {
        super(ac380Service, property);
    }
    ngOnInit() {
    }

    private eTextInput01: string = 'サンプル値';
    private eTextInput02: string;
    private eTextInput03: number = 1234567;
    private eTextInput04: string = '🏠①1１'; // 変な文字をバインド

    private eNumberInput03: number;

    private eZipCpdeInput01: string = '1234567';
    private eZipCpdeInput02: string;

    private searchBankInput01: string = "1000";
    private searchBankInput02: string = "ああああ";
    private searchBankInput03: string = "222";
    private searchBankInput04: string = "いいいいい";

    private taxRateList01: Date = new Date();

    private segmentSelect01: string = "3000";
    private segmentSelect02: string = "ううううう";

    public summaryDateInput01: string = "";
    public summaryDateInput01ForEmmit: string = "";

    public summaryDateInput02: string = "5月分";
    public summaryDateInput02ForEmmit: string = "";

    summaryMasterInput01: string = "摘要10-1-2";
    summaryMasterInput02: string = "";
    summaryMasterSlipCls: number = 10;
    summaryMasterSummaryCls: number = 1;

    conditionEviOccurrenceDateFrom: Date = new Date("2018/01/01");
    conditionEviOccurrenceDateTo: Date = new Date("2018/02/01");
    conditionEviPopUpResult: string = "";
    @Output() conditionEviPopUpResultChanged = new EventEmitter<string>();

    /** Popupの座標 */
    popX: string;
    popY: string;

    // ETabBar用
    private eTab01: any[] = [
        {label: 'たぶラベル１', value: 'たぶ値１', col: 'てすと１'},
        {label: 'たぶラベル２', value: 'たぶ値２', col: 'てすと２'},
        {label: 'たぶラベル３', value: 'たぶ値３', col: 'てすと３'},
    ];
    private etabTest: string = null;
    @ViewChild('ETabBar')
    private eTabBar: ETabBarComponent;
    selectTab(): void {
        // alert(this.eTabBar.tabBar.selectedIndex);
        this.etabTest = '　「' + this.eTabBar.tabBar.selectedTab.header.innerText + '」　が選択されました。';
    }

    // ETabBarDeco用
    private eTabDecoTest: string = null;
    @ViewChild('ETabBarDeco')
    private eTabBarDeco: ETabBarDecoComponent;
    selectTabDeco(): void {
        // alert(this.eTabBarDeco.tabBar.selectedIndex);
        this.eTabDecoTest = '　「' + this.eTabBarDeco.tabBar.selectedTab.header.innerText + '」　が選択されました。';
    }

    changeSummaryDate01(value) {
        this.summaryDateInput01ForEmmit = value;
    }

    changeSummaryDate02(value) {
        this.summaryDateInput02ForEmmit = value;
    }

    // サーバーから取得したレスポンスデータ
    outputPdf(): void {
        var test = new AC380ReqDto();
        this.ac380Service.onPrint(test, "testPdf");
    }

    @ViewChild('conditionEviPopup')
    private conditionEviPopup: ConditionEviPopupComponent;
    openConditionEviPopup() {
        this.conditionEviPopup.show();
    }

    public conditionEviSelectionChanged(e) {
        console.log("conditionEviSelectionChanged", e);
        if (e.occurrenceDateFrom) {
            e.occurrenceDateFrom = e.occurrenceDateFrom.toString();
        }
        if (e.occurrenceDateTo) {
            e.occurrenceDateTo = e.occurrenceDateTo.toString();
        }
        this.conditionEviPopUpResult = JSON.stringify(e, null, 2);
    }
}
