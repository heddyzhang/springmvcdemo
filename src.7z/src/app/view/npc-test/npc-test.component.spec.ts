import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NpcTestComponent } from './npc-test.component';

describe('NpcTestComponent', () => {
  let component: NpcTestComponent;
  let fixture: ComponentFixture<NpcTestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NpcTestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NpcTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
