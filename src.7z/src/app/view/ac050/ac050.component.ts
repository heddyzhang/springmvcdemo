import { Component, OnInit } from '@angular/core';
import { AC050ResDto } from '../../dto/ac050/AC050ResDto';
import { AC050Service } from '../../service/AC050Service';

@Component({
  selector: 'app-ac050',
  templateUrl: './ac050.component.html',
  styleUrls: ['./ac050.component.css']
})
export class Ac050Component implements OnInit {
  resDto: AC050ResDto;
  constructor(private ac050Service: AC050Service) { }

  ngOnInit() {
  }

  onPrint(): void {
    this.ac050Service.onPrint().subscribe(
      event => {
        this.resDto = event;
        this.onPrintResult();
      }
    );
  }

  /**
   * 印刷準備完了
   */
  onPrintResult(): void {
    const serviceUrl: string = 'print/ac050/物件一覧?id=';
    window.open(`${serviceUrl}` + this.resDto.publishId, '_blank');
  }
}
