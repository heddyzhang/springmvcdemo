import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac050Component } from './ac050.component';

describe('Ac050Component', () => {
  let component: Ac050Component;
  let fixture: ComponentFixture<Ac050Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac050Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac050Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
