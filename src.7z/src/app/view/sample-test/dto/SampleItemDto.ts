import { EPopupItem } from "../../../dto/ePopupInput/EPopupItem";

/** 画面表示用 */
export class SampleItemDto {

    /** 文字列 */
    public listS01:string = "";
    public listS02:string = "";
    public listS03:string = "";
    public listS04:string = "";
    public listS05:string = "";

    /** 数値 */
    public listN01:number = -1;
    public listN02:number = -1;
    public listN03:number = -1;
    public listN04:number = -1;
    public listN05:number = -1;

    /** 日付 */
    public listD01:Date = new Date();
    public listD02:Date = new Date();
    public listD03:Date = new Date();

}
