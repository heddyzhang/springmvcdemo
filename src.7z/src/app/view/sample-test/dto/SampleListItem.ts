import { Injectable } from "@angular/core";
import { EPopupItem } from "../../../dto/ePopupInput/EPopupItem";

/** 一覧などの１行分のデータ */
@Injectable()
export class SampleListItemDto {

    /** 文字列 */
    public listS01:string;
    public listS02:string;
    public listS03:string;
    public listS04:string;
    public listS05:string;

    /** 数値 */
    public listN01:number;
    public listN02:number;
    public listN03:number;
    public listN04:number;
    public listN05:number;

    public listB01:boolean = false;
    public listB02:boolean = false;

    public listEPop: EPopupItem;
}
