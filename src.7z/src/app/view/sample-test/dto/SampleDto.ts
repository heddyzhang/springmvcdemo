import { ResDtoBase } from "../../../dto/ResDtoBase";
import { SampleItemDto } from "./SampleItemDto";
import { SampleListItemDto } from "./SampleListItem";
export class SampleDto extends ResDtoBase{

    /** ドロップダウンで使用 */
    public sampleListA: SampleListItemDto[];

    /** ドロップダウンで使用 */
    public sampleListB: SampleListItemDto[];

    /** 一覧で使用 */
    public sampleListC: SampleListItemDto[];

    /** 一覧で使用 */
    public sampleListD: SampleListItemDto[];

    /**  */
    public sampleItemA: SampleItemDto;

    /**  */
    public sampleItemB: SampleItemDto;

    /**  */
    public sampleItemC: SampleItemDto;

    /**  */
    public sampleItemD: SampleItemDto;

    /**  */
    public sampleItemE: SampleItemDto;

    /**  */
    public sampleItemF: SampleItemDto;
}
