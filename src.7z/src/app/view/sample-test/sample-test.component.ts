import { Component, OnInit, Output, EventEmitter, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { SampleItemDto } from './dto/SampleItemDto';
import { SampleListItemDto } from './dto/SampleListItem';
import { EPopupItem } from '../../dto/ePopupInput/EPopupItem';
import { ECustomerPopupInputComponent } from '../../component/e-customer-popup-input/e-customer-popup-input.component';
import { EProgressBarComponent } from '../../component/e-progress-bar/e-progress-bar.component';
import { EAcTitlePopupInputComponent } from '../../component/e-ac-title-popup-input/e-ac-title-popup-input.component';
import { CellRangeEventArgs } from 'wijmo/wijmo.grid';
import { WjFlexGridEx } from '../../component/wj-flex-grid-ex/wj-flex-grid-ex';
import { EConsumptionTaxPopupInputComponent } from '../../component/e-consumption-tax-popup-input/e-consumption-tax-popup-input.component';

@Component({
  selector: 'app-sample-test',
  templateUrl: './sample-test.component.html',
  styleUrls: ['./sample-test.component.css']
})
export class SampleTestComponent implements OnInit {

    constructor(private router: Router, private property: EcoKaikeiProperty, private aRouter: ActivatedRoute) { }

    @ViewChild(ECustomerPopupInputComponent)
    cuspop:ECustomerPopupInputComponent;

    @ViewChild(EAcTitlePopupInputComponent)
    acpop:EAcTitlePopupInputComponent;

    @ViewChild(EConsumptionTaxPopupInputComponent)
    consumptionpop:EConsumptionTaxPopupInputComponent;

    @ViewChild(EProgressBarComponent)
    eprog:EProgressBarComponent;

    @ViewChild(WjFlexGridEx)
    flexGrid:WjFlexGridEx;

    /** 取消ボタンの活性・非活性 null:活性 false：非活性 */
    active: Boolean = false;

    acDrCrCls:number = -1;

    /** 借方 : 貸借区分 */
    acDrCls:number = -1;

    /** 貸方 : 貸借区分 */
    acCrCls:number = -1;

    consumptionTaxId: number = -1;
    customerId:number = -1;
    customerId2:number = -1;

    customerName: string = '';
    popX:string;
    popY:string;

    AAA:string;

    acTitleId:number = 111;
    acSubTitleId:number = 1;

    customer1:EPopupItem = new EPopupItem();
    customer2:EPopupItem = new EPopupItem();
    customer3:EPopupItem = new EPopupItem();
    customer4:EPopupItem = new EPopupItem();
    customer5:EPopupItem = new EPopupItem();
    customer6:EPopupItem = new EPopupItem();
    customerManagementNo:string;
    customerShortName:string;

    /**  */
    listE: EPopupItem[];

    eventNum: number = 0;

    nullNumber: number;
    nullText: string;

    /**  */
    itemA: SampleItemDto = new SampleItemDto;

    /**  */
    itemB: SampleItemDto = new SampleItemDto;

    /**  */
    itemC: SampleItemDto = new SampleItemDto;

    /**  */
    itemD: SampleItemDto = new SampleItemDto;

    /**  */
    itemE: SampleItemDto = new SampleItemDto;

    /**  */
    itemF: SampleItemDto = new SampleItemDto;

    /**  */
    listA: SampleListItemDto[];

    /**  */
    listB: SampleListItemDto[];

    /**  */
    listC: SampleListItemDto[];

    /**  */
    listD: SampleListItemDto[];

    /**  */
    ddlSelectedVal01:number;

    ddlSelectedVal02:any;

    ddlSelectedVal03:number;

    ddlSelectedItem01:any;

    acSubTitleInputIsReadOnly:boolean = false;

    acSummaryCd:number = -1;

    acDrCrCls2:number = -1;

    selectedLabel:string = '';

    isDisabled:boolean= false;

    editX:number = 0;
    editY:number = 0;

    selectedGrid():void {

        document.getElementsByName('acName')[2].focus();
    }


    selectedItemChange(selectedItem:EPopupItem):void {

        this.selectedLabel = selectedItem ? selectedItem.label : '';

        this.flexGrid.refresh();
        this.flexGrid.invalidate();
        if (this.flexGrid.collectionView !== undefined) {
            this.flexGrid.collectionView.refresh();
        }

        if (selectedItem) {
            this.isDisabled = selectedItem.cd === '111';
        } else {
            this.isDisabled = true;
        }

    }

    selectedRowItemChange(item:SampleListItemDto):void {

        if (item && item.listN01 && item.listN01.toString().search('1') > 0) {
            item.listB02 = false;
        }
        else {
            item.listB02 = true;
        }

        if (this.flexGrid.collectionView !== undefined) {
            this.flexGrid.collectionView.refresh();
        }
    }

    selectedRow2ItemChange(item:SampleListItemDto):void {

        if (item && item.listN02 && item.listN02.toString().search('2') > 0) {
            item.listB02 = false;
        }
        else {
            item.listB02 = true;
        }

        if (this.flexGrid.collectionView !== undefined) {
            this.flexGrid.collectionView.refresh();
        }
    }

    selectedRow3ItemChange(item:SampleListItemDto):void {

        if (this.flexGrid.collectionView !== undefined) {
            this.flexGrid.collectionView.refresh();
        }
    }

    listAChange() {
        this.eventNum += 1;
    }

    onclick1() {
        this._val = 0;
        this.eprog.show(true);
    }

    _max:number = 99;
    _val:number = 0;

    onclick2() {
        if ((this._max + 33) === this._val) {
            this.eprog.close();
        }
        else {
            this.eprog.change(this._val, this._max);

            this._val += 33;
        }
    }

    onclick3() {
        this._val = 0;
        this.eprog.show(false);
    }

    onclick4() {
        this.eprog.close();
    }

    gridBeginningEdit(args :CellRangeEventArgs): void {

        if (args.col !== 5) {
            return;
        }

        // 編集データを取得
        var editRow = this.flexGrid.collectionView.items[args.row];

        // 共通部門の場合は、数値変更はできない
        if (editRow === null || editRow.listB01) {
            args.cancel = true;
        }
    }

    onclick() {


        this.customerId = 4;

        this.customerId2 = 7;

        this.active = null;

        this.itemA.listS01 = "AAA";
        this.itemA.listS02 = "BBB";

        this.listA = new Array(15);
        for (var i:number = 0; i < 15; i++) {
            var listItem: SampleListItemDto = new SampleListItemDto;
            listItem.listS01 = "値-A" + i;
            listItem.listN01 = i;

            listItem.listS02 = "値-B" + i;
            listItem.listN02 = 200 + i;

            listItem.listS03 = "値-C" + i;
            listItem.listN03 = 300 + i;

            var cusItem:EPopupItem = this.cuspop.searchCustomerItemByID(listItem.listN01);
            if (cusItem !== undefined && cusItem !== null) {
                listItem.listS05 = cusItem.label;
            } else {
                listItem.listS05 = '';
            }
            this.listA[i] = listItem;

            var listItemE: EPopupItem = new EPopupItem;
            listItemE.cd = "123456";
            listItemE.label = "AAA" + i;

            this.listA[i].listEPop = listItemE;
        }

        this.listB = new Array(20);
        for (var i:number = 0; i < 20; i++) {
            var listItem: SampleListItemDto = new SampleListItemDto;
            this.listB[i] = listItem;
        }

        this.listB[0].listN01 = 111;
        this.listB[0].listN02 = 2;
        this.listB[0].listN03 = 600;
        this.listB[0].listS01 = this.acpop.searchAcTitleItemByID(this.listB[0].listN01).label;
        this.listB[0].listS02 = this.acpop.searchAcSubTitleItemByID(this.listB[0].listN01, this.listB[0].listN02).label;
        this.listB[0].listS03 = this.consumptionpop.searchConsumptionItemByID(this.listB[0].listN03).label;

        this.listB[1].listN01 = 130;
        this.listB[1].listN02 = 1;
        this.listB[1].listN03 = 610;
        this.listB[1].listS01 = this.acpop.searchAcTitleItemByID(this.listB[1].listN01).label;
        this.listB[1].listS02 = this.acpop.searchAcSubTitleItemByID(this.listB[1].listN01, this.listB[1].listN02).label;
        this.listB[1].listS03 = this.consumptionpop.searchConsumptionItemByID(this.listB[1].listN03).label;

        this.listB[2].listN01 = 210;
        this.listB[2].listN02 = -1;
        this.listB[2].listN03 = -1;
        this.listB[2].listS01 = this.acpop.searchAcTitleItemByID(this.listB[2].listN01).label;
        this.listB[2].listS02 = '';
        this.listB[2].listS03 = '';
        this.listB[2].listB01 = true;
        this.listB[2].listB02 = true;

        this.listB[3].listN01 = 186;
        this.listB[3].listN02 = -1;
        this.listB[3].listN03 = -1;
        this.listB[3].listS01 = this.acpop.searchAcTitleItemByID(this.listB[3].listN01).label;
        this.listB[3].listS02 = '';
        this.listB[3].listS03 = '';
        this.listB[3].listB01 = true;
        this.listB[3].listB02 = true;

        this.listB[4].listN01 = 210;
        this.listB[4].listN02 = -1;
        this.listB[4].listN03 = 610;
        this.listB[4].listS01 = this.acpop.searchAcTitleItemByID(this.listB[4].listN01).label;
        this.listB[4].listS02 = '';
        this.listB[4].listS03 = this.consumptionpop.searchConsumptionItemByID(this.listB[4].listN03).label;
        this.listB[4].listB01 = true;

        this.listB[5].listN01 = 120;
        this.listB[5].listN02 = 2;
        this.listB[5].listN03 = -1;
        this.listB[5].listS01 = this.acpop.searchAcTitleItemByID(this.listB[5].listN01).label;
        this.listB[5].listS02 = this.acpop.searchAcSubTitleItemByID(this.listB[5].listN01, this.listB[5].listN02).label;
        this.listB[5].listS03 = '';
        this.listB[5].listB02 = true;

        this.listB[6].listN01 = 130;
        this.listB[6].listN02 = 1;
        this.listB[6].listN03 = 664;
        this.listB[6].listS01 = this.acpop.searchAcTitleItemByID(this.listB[6].listN01).label;
        this.listB[6].listS02 = this.acpop.searchAcSubTitleItemByID(this.listB[6].listN01, this.listB[6].listN02).label;
        this.listB[6].listS03 = this.consumptionpop.searchConsumptionItemByID(this.listB[6].listN03).label;

        this.listB[7].listN01 = 186;
        this.listB[7].listN02 = -1;
        this.listB[7].listN03 = 712;
        this.listB[7].listS01 = this.acpop.searchAcTitleItemByID(this.listB[7].listN01).label;
        this.listB[7].listS02 = '';
        this.listB[7].listS03 = this.consumptionpop.searchConsumptionItemByID(this.listB[7].listN03).label;
        this.listB[7].listB01 = true;

        this.listB[8].listN01 = 172;
        this.listB[8].listN02 = -1;
        this.listB[8].listN03 = -1;
        this.listB[8].listS01 = this.acpop.searchAcTitleItemByID(this.listB[8].listN01).label;
        this.listB[8].listS02 = '';
        this.listB[8].listS03 = '';
        this.listB[8].listB01 = true;
        this.listB[8].listB02 = true;

        this.listB[9].listN01 = 213;
        this.listB[9].listN02 = -1;
        this.listB[9].listN03 = 770;
        this.listB[9].listS01 = this.acpop.searchAcTitleItemByID(this.listB[9].listN01).label;
        this.listB[9].listS02 = '';
        this.listB[9].listS03 = this.consumptionpop.searchConsumptionItemByID(this.listB[9].listN03).label;
        this.listB[9].listB01 = true;

        this.listB[10].listN01 = 172;
        this.listB[10].listN02 = -1;
        this.listB[10].listN03 = 799;
        this.listB[10].listS01 = this.acpop.searchAcTitleItemByID(this.listB[10].listN01).label;
        this.listB[10].listS02 = '';
        this.listB[10].listS03 = this.consumptionpop.searchConsumptionItemByID(this.listB[10].listN03).label;
        this.listB[10].listB01 = true;

        this.listB[11].listN01 = 111;
        this.listB[11].listN02 = 1;
        this.listB[11].listN03 = -1;
        this.listB[11].listS01 = this.acpop.searchAcTitleItemByID(this.listB[11].listN01).label;
        this.listB[11].listS02 = this.acpop.searchAcSubTitleItemByID(this.listB[11].listN01, this.listB[11].listN02).label;
        this.listB[11].listS03 = '';
        this.listB[11].listB02 = true;

        this.listB[12].listN01 = 112;
        this.listB[12].listN02 = 3;
        this.listB[12].listN03 = 634;
        this.listB[12].listS01 = this.acpop.searchAcTitleItemByID(this.listB[12].listN01).label;
        this.listB[12].listS02 = this.acpop.searchAcSubTitleItemByID(this.listB[12].listN01, this.listB[12].listN02).label;
        this.listB[12].listS03 = this.consumptionpop.searchConsumptionItemByID(this.listB[12].listN03).label;

        this.listB[13].listN01 = 173;
        this.listB[13].listN02 = -1;
        this.listB[13].listN03 = -1;
        this.listB[13].listS01 = this.acpop.searchAcTitleItemByID(this.listB[13].listN01).label;
        this.listB[13].listS02 = '';
        this.listB[13].listS03 = '';
        this.listB[13].listB01 = true;
        this.listB[13].listB02 = true;

        this.listB[14].listN01 = 174;
        this.listB[14].listN02 = -1;
        this.listB[14].listN03 = -1;
        this.listB[14].listS01 = this.acpop.searchAcTitleItemByID(this.listB[14].listN01).label;
        this.listB[14].listS02 = '';
        this.listB[14].listS03 = '';
        this.listB[14].listB01 = true;
        this.listB[14].listB02 = true;

        this.listB[15].listN01 = 213;
        this.listB[15].listN02 = -1;
        this.listB[15].listN03 = -1;
        this.listB[15].listS01 = this.acpop.searchAcTitleItemByID(this.listB[15].listN01).label;
        this.listB[15].listS02 = '';
        this.listB[15].listS04 = '';
        this.listB[15].listB01 = true;
        this.listB[15].listB02 = true;

        this.listB[16].listN01 = 342;
        this.listB[16].listN02 = -1;
        this.listB[16].listN03 = 615;
        this.listB[16].listS01 = this.acpop.searchAcTitleItemByID(this.listB[16].listN01).label;
        this.listB[16].listS02 = '';
        this.listB[16].listS03 = this.consumptionpop.searchConsumptionItemByID(this.listB[16].listN03).label;
        this.listB[16].listB01 = true;

        this.listB[17].listN01 = 642;
        this.listB[17].listN02 = -1;
        this.listB[17].listN03 = 714;
        this.listB[17].listS01 = this.acpop.searchAcTitleItemByID(this.listB[17].listN01).label;
        this.listB[17].listS02 = '';
        this.listB[17].listS03 = this.consumptionpop.searchConsumptionItemByID(this.listB[17].listN03).label;
        this.listB[17].listB01 = true;

        this.listB[18].listN01 = 655;
        this.listB[18].listN02 = -1;
        this.listB[18].listN03 = -1;
        this.listB[18].listS01 = this.acpop.searchAcTitleItemByID(this.listB[18].listN01).label;
        this.listB[18].listS02 = '';
        this.listB[18].listS03 = '';
        this.listB[18].listB01 = true;
        this.listB[18].listB02 = true;

        this.listB[19].listN01 = 850;
        this.listB[19].listN02 = -1;
        this.listB[19].listN03 = -1;
        this.listB[19].listS01 = this.acpop.searchAcTitleItemByID(this.listB[19].listN01).label;
        this.listB[19].listS02 = '';
        this.listB[19].listS03 = '';
        //this.listB[19].listB01 = true;


        this.listC = new Array(15);
        for (var i:number = 0; i < 15; i++) {
            var listItem: SampleListItemDto = new SampleListItemDto;
            listItem.listS01 = "値-A" + i;
            listItem.listN01 = 100 + i;

            listItem.listS02 = "値-B" + i;
            listItem.listN02 = 200 + i;

            listItem.listS03 = "値-C" + i;
            listItem.listN03 = 300 + i;

            this.listC[i] = listItem;
        }
        this.ddlSelectedVal03 = 103;
    }


  eTextInputValue1: string;

  // TODO numberでは？？
  //eNumberInputValue1: number = -1;
  eNumberInputValue1: string = "";
  eNumberInputValue2: string = "";

  eMoneyInputValue1: number = 0;
  eMoneyInputValue2: number = 0;

  eZipCodeValue1: string = "";
  eZipCodeValue2: string = "";

  ddList1: any[] = [
        {label: 'ラベルA', value: '1001'},
        {label: 'ラベルB', value: '2001'},
        {label: 'ラベルC', value: '3001'}
    ];

  ddValue1: string = "";


  ddList2: any[] = [
    {label: 'ラベルD', value: '4001'},
    {label: 'ラベルE', value: '5001'},
    {label: 'ラベルF', value: '6001'}
];

ddValue2: string = "";



















  id: number = 0;

  countries = [
    'Afghanistan', 'Albania', 'Algeria', 'American Samoa',
    'Andorra', 'Angola', 'Anguilla', 'Antigua',
    'Argentina', 'Armenia'];

    today: Date;
    minDate: Date;
    maxDate: Date;

    items = [];
    isAnimated = true;
    autoCollapse = true;
    expandOnClick = true;

    onClickPageT() {

      //this.property.sampleValue = 7500;

      this.router.navigate(["userAuth"]);
    }

  ngOnInit() {

        //console.log('test:' + this.property.isNewFisicalYear);
        console.log('開始：' + this.id);
        this.aRouter.params.subscribe(
            params => {
                this.id = params['id']
                console.log('値を受け取った：' + this.id);
            }
        );



        // values for InputDate, InputTime, InputDateTime
        let today = new Date();
        this.today = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 13, 30);
        this.minDate = new Date(today.getFullYear(), 0, 1);
        this.maxDate = new Date(today.getFullYear(), 11, 31);

        this.items = [
          {
               header: 'Electronics', img: 'resources/electronics.png', items: [
                   { header: 'Trimmers/Shavers' },
                  { header: 'Tablets' },
                   {
                       header: 'Phones', img: 'resources/phones.png', items: [
                           { header: 'Apple' },
                           { header: 'Motorola', newItem: true },
                           { header: 'Nokia' },
                           { header: 'Samsung' }
                       ]
                   },
                   { header: 'Speakers', newItem: true },
                   { header: 'Monitors' }
               ]
              }
            ];
  }

}
