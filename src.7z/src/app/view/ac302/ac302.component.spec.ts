import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac302Component } from './ac302.component';

describe('Ac302Component', () => {
  let component: Ac302Component;
  let fixture: ComponentFixture<Ac302Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac302Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac302Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
