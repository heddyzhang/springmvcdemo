import { Component, ViewChild } from '@angular/core';
import { ComponentBase, AppType } from '../component-base';
import { EConfigureReportPopComponent } from '../../component/e-configure-report-pop/e-configure-report-pop.component';
import { AC302Service } from '../../service/AC302Service';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { Router } from '@angular/router';
import { AC302ViewChangeBean } from '../../bean/AC302ViewChangeBean';
import { AC300ViewChangeBean } from '../../bean/AC300ViewChangeBean';
import { AC302ReqDto } from '../../dto/ac302/AC302ReqDto';
import { AC302TransitionDto } from '../../dto/ac302/AC302TransitionDto';
import { AC302ResDto } from '../../dto/ac302/AC302ResDto';
import { FormatItemEventArgs, CellType } from 'wijmo/wijmo.grid';
import { WjFlexGridEx } from '../../component/wj-flex-grid-ex/wj-flex-grid-ex';

@Component({
    selector: 'app-ac302',
    templateUrl: './ac302.component.html',
    styleUrls: ['./ac302.component.css']
})
export class Ac302Component extends ComponentBase {

    /** アプリケーションIDを設定 */
    private appID: string = 'ac302';

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.C_Report;

    @ViewChild('reportPop')
    /** 印刷条件ポップアップ */
    private reportPop: EConfigureReportPopComponent;

    @ViewChild(WjFlexGridEx)
    /** グリッドへの参照 */
    private flexGrid: WjFlexGridEx;

    /** 翌年度かどうか */
    public isNextFisicalYear: boolean;

    /** 選択中の会計年度 */
    public selectedYear: number;

    /** 補助科目を表示する フラグ */
    public showSubTitle: boolean = false;

    /** 選択開始月 */
    public startMonth: number = -1;

    /** 選択終了月 */
    public endMonth: number = -1;

    /** 単位 (0: 円 1: 千円 2: 百万円) */
    public selectUnit: number = 0;

    /** 決算の扱い (true: 決算を最終月に含める false: 決算を最終月に含めない) */
    public selectSettle: boolean = false;

    /** 推移表のデータ */
    public transitionDtoList: AC302TransitionDto[];

    /** ヘッダーラベル */
    public headerLabels: string[] = ['', '', '', '', '', '', '', '', '', '', '', ''];

    /** ショートカットボタン */
    protected shortcutBtnDefs: any = {
        'all': [
            { tagNo: 1, enabled: true }, { tagNo: 8, enabled: true },
        ],
    }

    /** コンストラクタ */
    constructor(private ac302Service: AC302Service, private property: EcoKaikeiProperty, private router: Router) {
        super(ac302Service, property);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // ショートカットを表示
        super.displayShortCutBtn(1, 8);

        // ショートカットボタンの名称を変える
        this.viewBaseButton1.value = '戻る';
        this.shortCutRefresh();

        // ショートカットの制御を行う
        this.setShortcutBtnDefs('all');

        // Ac300からの受け渡しパラメータを設定する
        var bean: AC302ViewChangeBean = this.property.getViewChangeBeans(this.appID) as AC302ViewChangeBean;

        // 選択中の会計年度
        this.selectedYear = bean.selectedYear;

        // 翌年度表示かどうか
        this.isNextFisicalYear = this.property.ownershipDto.newFisicalYear
            && this.property.ownershipDto.selectFisicalYear < this.selectedYear;

        // 補助科目を表示する フラグ
        this.showSubTitle = bean.showSubTitle;

        // 選択開始月
        this.startMonth = bean.startMonth;

        // 選択終了月
        this.endMonth = bean.endMonth;

        // 単位 (0: 円 1: 千円 2: 百万円)
        this.selectUnit = bean.selectUnit;

        // 決算の扱い (true: 決算を最終月に含める false: 決算を最終月に含めない)
        this.selectSettle = bean.selectSettle;

        // ヘッダーの月度を設定
        for (var i: number = 1; i < 13; i++) {

            this.headerLabels[i - 1] = this.property.getMonthLabel(this.selectedYear, i);
        }

        // 初期情報を取得
        var req: AC302ReqDto = new AC302ReqDto();
        req.selectedYear = this.selectedYear;
        req.startMonth = this.startMonth;
        req.endMonth = this.endMonth;
        req.selectUnit = this.selectUnit;
        req.selectSettle = this.selectSettle;
        this.ac302Service.getInitial(req, this.getInitialOnResult);
    }

    /**
     * 背景色の設定
     * @param e
     */
    public formatItem(e: FormatItemEventArgs): void {

        // Cellのみ反映
        if (e.panel.cellType === CellType.Cell) {
            // 背景色を設定する
            e.cell.style.backgroundColor = this.flexGrid.collectionView.items[e.row].backgroundColor;
        }
    }

    /**
     * 一覧の再表示を行う
     */
    public flexGridRefresh(): void {

        // 参照エラー時は処理を中断
        if (!this.flexGrid || !this.flexGrid.collectionView) {
            return;
        }

        // フィルターの設定
        this.flexGrid.collectionView.filter = this.filterFunction.bind(this);
    }

    /**
     * 補助科目を表示するかどうか
     * @param item
     */
    private filterFunction(item: AC302TransitionDto): boolean {

        // 補助科目を表示しない
        if (!this.showSubTitle && item.acSubTitleId !== null && item.acSubTitleId !== -1) {
            return false;
        }

        return true;
    }

    /**
     * 戻るボタンの押下処理
     */
    public removeBtnClick(): void {

        // 遷移用パラメータを生成する
        var ac300bean: AC300ViewChangeBean = new AC300ViewChangeBean(this.selectedYear
            , this.showSubTitle, this.startMonth, this.endMonth, 1, this.selectUnit, this.selectSettle);

        // パラメータの設定を行う
        this.property.setViewChangeBeans(ac300bean, this.appID, 'ac300');

        // 貸借対照表
        this.router.navigate(['view/ac300', { param: '1' }]);
    }

    /**
     * 印刷ボタンの押下処理
     */
    public printBtnClick(): void {

        // リクエストを生成
        var reqDto: AC302ReqDto = new AC302ReqDto();
        reqDto.selectedYear = this.selectedYear;
        reqDto.startMonth = this.startMonth;
        reqDto.endMonth = this.endMonth;
        reqDto.showSubTitle = this.showSubTitle;
        reqDto.selectUnit = this.selectUnit;
        reqDto.selectSettle = this.selectSettle;

        this.reportPop.show(reqDto, () => {
            // 印刷のプレ処理 => 印刷 を行う
            this.ac302Service.onPrint(reqDto, '推移表');
        });
    }

    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     */
    private getInitialOnResult(resDto: AC302ResDto): void {

        // 一覧表を作成
        this.transitionDtoList = resDto.transitionDtoList;
    }
}
