import { Component, OnInit } from '@angular/core';
import { ComponentBase, AppType } from '../component-base';
import { AC110Service } from '../../service/AC110Service';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { AC110ReqDto } from '../../dto/ac110/AC110ReqDto';
import { AC110ResDto } from '../../dto/ac110/AC110ResDto';
// import { AC110SendMailDto } from '../../dto/ac110/AC110SendMailDto';
import { AC110CourseDto } from '../../dto/ac110/AC110CourseDto';

@Component({
    selector: 'app-ac110',
    templateUrl: './ac110.component.html',
    styleUrls: ['./ac110.component.css']
})
export class Ac110Component extends ComponentBase {

    /** 表示中のデータ */
    public selectItem: AC110CourseDto = new AC110CourseDto();

    /** スタンダードコースへの変更 */
    public courseCls: boolean = false;

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.F_Administrator;

    /** コンストラクタ */
    constructor(private ac110Service: AC110Service, private property: EcoKaikeiProperty) {
        super(ac110Service, property);
    }

    /** メールアドレス */
    // public mailAddress1: string = '';

    /** メールアドレス：確認用 */
    // public mailAddress2: string = '';

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {
         // ショートカットを表示
         super.displayShortCutBtn(3, 10);

        // 初期情報を取得
        this.ac110Service.getInitial(new AC110ReqDto(), this.getInitialOnResult);
    }

        /**
     * スタンダードコース、ラベルスイッチ切り替え
     */
    public courseClsClick(): void {

    }

        /**
     * 取消ボタンの押下処理
     */
    public cancelBtnClick(): void {


    }

        /**
     * 更新ボタンの押下処理
     */
    public updateBtnClick(): void {

    }

        /**
     * ショートカットボタンの制御を行う
     */
    private updateShortcutButtonStatus(): void {


    }

    /**
     * メールを送信ボタンの押下処理
     */
    // public sendMail(): void {

        // 必須項目のチェック
        // 招待する方のメールアドレス
        // if (!this.mailAddress1) {
        //     // "招待する方のメールアドレス"は入力必須の項目です。
        //     this.eAlert.message('210001', ['招待する方のメールアドレス'], 'mailAddress1');
        //     return;
        // }
        // // メールアドレスの確認
        // else if (!this.mailAddress2) {
        //     // "メールアドレスの確認"は入力必須の項目です。
        //     this.eAlert.message('210001', ['確認用のメールアドレス'], 'mailAddress2');
        //     return;
        // }
        // // 招待する方のメールアドレスとメールアドレスの確認が異なる場合
        // else if (this.mailAddress1 !== this.mailAddress2) {
        //     // "確認用のメールアドレス"が一致していません。
        //     this.eAlert.message('211035', ['確認用のメールアドレス'], 'mailAddress1');
        //     return;
        // }

        // // メールを送信します。\nよろしいですか？
        // this.eAlert.message('120027', [], null, () => {

        //     // リクエストを生成
        //     var reqDto: AC110ReqDto = new AC110ReqDto();
        //     reqDto.sendMailDto = new AC110SendMailDto();

        //     // メールアドレス
        //     reqDto.sendMailDto.mailAddress = this.mailAddress1;

        //     // メールを送信処理を実行
        //     this.ac110Service.sendMail(reqDto, this.sendMailOnResult);
    //     });
    // }

    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     */
    private getInitialOnResult(resDto: AC110ResDto): void {

        // フォーカスを設定する
        document.getElementById('mailAddress1').focus();

        // TODO 手続きの進捗状況一覧情報
    }

    private sendMailOnResult(resDto: AC110ResDto): void {

        // TODO 手続きの進捗状況一覧情報
    }
}
