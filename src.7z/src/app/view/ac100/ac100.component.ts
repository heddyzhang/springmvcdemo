import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { AC100ReqDto } from '../../dto/ac100/AC100ReqDto';
import { AC100UserAuthorityDto } from '../../dto/ac100/AC100UserAuthorityDto';
import { AC100Service } from '../../service/AC100Servive';
import { ComponentBase, AppType } from '../component-base';
import { AC100ResDto } from '../../dto/ac100/AC100ResDto';
import { AC100EmployeeDto } from '../../dto/ac100/AC100EmployeeDto';
import { AC100UpdateUserAuthorityDto } from '../../dto/ac100/AC100UpdateUserAuthorityDto';
import { WjFlexGridEx } from '../../component/wj-flex-grid-ex/wj-flex-grid-ex';


@Component({
    selector: 'app-ac100',
    templateUrl: './ac100.component.html',
    styleUrls: ['./ac100.component.css']
})
export class Ac100Component extends ComponentBase {

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.F_Administrator;

    /** 一覧情報 */
    public userAuthorityDtoList: AC100UserAuthorityDto[];

    /** 管理番号一覧 */
    public employeeDtoList: AC100EmployeeDto[];

    /** 展開中のデータ */
    public selectItem: AC100UserAuthorityDto = new AC100UserAuthorityDto();

    @ViewChild('userAuth')
    /** 利用者権限一覧への参照 */
    private userAuthGrid: WjFlexGridEx;

    /** 利用者権限 */
    public userAuthorityClsTemplates: any[] = [
        { value: 9, title: "未設定" },
        { value: 1, title: "管理者" },
        { value: 2, title: "一般" },
        { value: 3, title: "照会" },
        { value: 4, title: "会計事務所" },
        { value: 5, title: "経費精算のみ" },
    ];

    /** 編集中（未保存の編集データが存在する） */
    private isDirty: boolean = false;

    /** ショートカットボタン（追加・削除・取消・更新） */
    protected shortcutBtnDefs = {
        'reference': [
            { tagNo: 3, enabled: false }, { tagNo: 10, enabled: false },
        ],
        'update': [
            { tagNo: 3, enabled: false }, { tagNo: 10, enabled: false },
        ],
        'update-dirty': [
            { tagNo: 3, enabled: true }, { tagNo: 10, enabled: true },
        ],
    }

    /** コンストラクタ */
    constructor(private ac100Service: AC100Service, private property: EcoKaikeiProperty) {
        super(ac100Service, property);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // ショートカットを表示
        super.displayShortCutBtn(3, 10);

        // 初期情報を取得
        this.ac100Service.getInitial(new AC100ReqDto(), this.getInitialOnResult);
    }

    /**
     * 利用者権限設定のグリッドの変更イベント
     */
    public selectionChanged(): void {

        // 選択中情報
        this.selectItem = Object.assign({}, this.userAuthGrid.selectedItems[0]);

        // 編集中フラグをリセット
        this.isDirty = false;

        // ショートカットボタンの活性／非活性を設定
        this.updateShortcutButtonStatus();
    }

    /**
     * 編集フォームのデータが変更された
     */
    public setDirtyFlag(): void {

        // 編集中フラグをセット
        if (!this.isDirty) {

            this.isDirty = true;
            this.updateShortcutButtonStatus();
        }
    }

    /**
     * 取消ボタンの押下処理
     */
    public cancelBtnClick(): void {

        // 既存レコードの編集中だった場合、レコードをもとの状態に復元
        this.selectItem = Object.assign({}, this.userAuthorityDtoList.filter(c => c.userId === this.selectItem.userId)[0]);

        // 編集中フラグをリセット
        this.isDirty = false;

        // ショートカットボタンの活性／非活性を設定
        this.updateShortcutButtonStatus();
    }

    /**
     * 更新ボタンの押下処理
     */
    public updateBtnClick(): void {

        // 必須項目のチェック
        // 氏名
        if (!this.selectItem.userName) {
            // "氏名"は入力必須の項目です。
            this.eAlert.message('210001', ['氏名'], 'userName');
            return;
        }
        // 管理番号
        else if (!this.selectItem.userCd) {
            // "管理番号"は入力必須の項目です。
            this.eAlert.message('210001', ['管理番号'], 'userCd');
            return;
        }
        // 役職
        else if (!this.selectItem.userPosition) {
            // "役職"は入力必須の項目です。
            this.eAlert.message('210001', ['役職'], 'userPosition');
            return;
        }
        // 印鑑（上部）
        else if (!this.selectItem.userSealTop) {
            // "印鑑（上部）"は入力必須の項目です。
            this.eAlert.message('210001', ['印鑑（上部）'], 'userSealTop');
            return;
        }
        // 印鑑（下部）
        else if (!this.selectItem.userSealBottom) {
            // "印鑑（下部）"は入力必須の項目です。
            this.eAlert.message('210001', ['印鑑（下部）'], 'userSealBottom');
            return;
        }

        // 更新します。よろしいですか？
        this.eAlert.message('120023', [], null, () => {

            // リクエストを生成
            var reqDto: AC100ReqDto = new AC100ReqDto();
            reqDto.updateDto = new AC100UpdateUserAuthorityDto();

            // 利用者ID
            reqDto.updateDto.userId = this.selectItem.userId;
            // 氏名
            reqDto.updateDto.userName = this.selectItem.userName;
            // 管理番号
            reqDto.updateDto.userCd = this.selectItem.userCd;
            // 利用者役職
            reqDto.updateDto.userPosition = this.selectItem.userPosition;
            // 利用者処理権限区分
            reqDto.updateDto.userAuthorityCls = this.selectItem.userAuthorityCls;
            // 経費精算権限区分
            reqDto.updateDto.userSettlementCls = this.selectItem.userSettlementCls;
            // 利用者状態
            reqDto.updateDto.userSts = this.selectItem.userSts;
            // 印鑑上部
            reqDto.updateDto.userSealTop = this.selectItem.userSealTop;
            // 印鑑下部
            reqDto.updateDto.userSealBottom = this.selectItem.userSealBottom;
            // 更新日時:利用者
            reqDto.updateDto.userUpdatedAt = this.selectItem.userUpdatedAt;
            // 更新日時:利用者権限
            reqDto.updateDto.userAuthorityUpdatedAt = this.selectItem.userAuthorityUpdatedAt;

            // 更新処理を実行
            this.ac100Service.update(reqDto, this.updateOnResult);
        });
    }

    /**
     * ショートカットボタンの制御を行う
     */
    private updateShortcutButtonStatus(): void {

        // 通常モード / 変更有無
        var mode: string = this.isDirty ? 'update-dirty' : 'update';

        // ショートカットの制御を行う
        this.setShortcutBtnDefs(mode);
    }

    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     * @param resDto
     */
    private getInitialOnResult(resDto: AC100ResDto): void {

        // 入力内容を表示する
        this.userAuthorityDtoList = resDto.userAuthorityDtoList;

        // 社員管理を設定
        this.employeeDtoList = resDto.employeeDtoList;

        // 初期は1件目を選択
        this.selectItem = Object.assign({}, resDto.userAuthorityDtoList[0]);

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 初期処理 完了
     * @param resDto
     */
    private updateOnResult(resDto: AC100ResDto): void {

        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        // 入力内容を表示する
        this.userAuthorityDtoList = resDto.userAuthorityDtoList;

        // 社員管理を設定
        this.employeeDtoList = resDto.employeeDtoList;

        // 初期は1件目を選択
        this.selectItem = Object.assign({}, resDto.userAuthorityDtoList[0]);

        // 変更の取消
        this.isDirty = false;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }
}
