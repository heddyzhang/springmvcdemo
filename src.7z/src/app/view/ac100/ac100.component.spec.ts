import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac100Component } from './ac100.component';

describe('Ac100Component', () => {
  let component: Ac100Component;
  let fixture: ComponentFixture<Ac100Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac100Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac100Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
