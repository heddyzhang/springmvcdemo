import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac311Component } from './ac311.component';

describe('Ac311Component', () => {
  let component: Ac311Component;
  let fixture: ComponentFixture<Ac311Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac311Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac311Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
