import { Component, ViewChild } from '@angular/core';
import { AC036Service } from '../../service/AC036Service';
import { AC036ReqDto } from '../../dto/ac036/AC036ReqDto';
import { AC036ResDto } from '../../dto/ac036/AC036ResDto';
import { AC036AmountSumDto } from '../../dto/ac036/AC036AmountSumDto';
import { WjFlexGridEx } from '../../component/wj-flex-grid-ex/wj-flex-grid-ex';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { ComponentBase, AppType } from '../component-base';
import { EConfigureReportPopComponent } from '../../component/e-configure-report-pop/e-configure-report-pop.component';
import { ETabBarDecoComponent } from '../../component/e-tab-bar-deco/e-tab-bar-deco.component';
import { AC036UpdateAmountSumDto } from '../../dto/ac036/AC036UpdateAmountSumDto';

@Component({
    selector: 'app-ac036',
    templateUrl: './ac036.component.html',
    styleUrls: ['./ac036.component.css']
})
export class Ac036Component extends ComponentBase {

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.D_Master;

    @ViewChild('reportPop')
    private reportPop: EConfigureReportPopComponent;

    /** 一覧内容 */
    public amountSumDtoList: AC036AmountSumDto[];

    /** 一覧内容(取消用) */
    private tmpAmountSumDtoList: AC036AmountSumDto[];

    @ViewChild(WjFlexGridEx)
    /** 一覧への参照 */
    private flexGrid: WjFlexGridEx;

    @ViewChild(ETabBarDecoComponent)
    /** 一覧への参照 */
    private tabBar: ETabBarDecoComponent;

    /** タブ内容 */
    public acDrCrClsItems:any[] = [{value:  2, label: "　　資産　　"},
                                   {value:  3, label: "　負債・資本　"},
                                   {value: -1, label: "　　ALL　　"}];

    /** 借方・貸方 / ALL 区分 */
    public acDrCrCls: number = -1;

    /** 使用していない科目を表示 true:全表示 false:使用科目のみ */
    public showNotUse: boolean = false;

    /** 編集中（未保存の編集データが存在する） */
    private isDirty: boolean = false;

    /** ショートカットボタン（取消・更新・印刷） */
    protected shortcutBtnDefs: any = {
        'reference': [
            { tagNo: 3, enabled: false }, { tagNo: 10, enabled: false },
        ],
        'insert': [
            { tagNo: 3, enabled: false }, { tagNo: 10, enabled: false },
        ],
        'insert-dirty': [
            { tagNo: 3, enabled: true }, { tagNo: 10, enabled: true },
        ],
        'no-print': [
            { tagNo: 8, enabled: false },
        ],
        'print': [
            { tagNo: 8, enabled: true },
        ],
    }

    /** サービス名 */
    constructor(private ac036Service: AC036Service, private property: EcoKaikeiProperty) {
        super(ac036Service, property);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // ショートカットを表示
        super.displayShortCutBtn(3, 8, 10);

        // 初期情報を取得
        this.ac036Service.getInitial(new AC036ReqDto(), this.getInitialOnResult);
    }

    /**
     * 編集開始時の処理
     * @param grid
     * @param args
     */
    public gridBeginningEdit(grid: WjFlexGridEx, args :any): void {

        // 編集データを取得
        var editRow = grid.collectionView.items[args.row];

        // 勘定科目の場合は、数値変更はできない
        if (!editRow ||editRow.acSubTitleId === -1) {
            args.cancel = true;
        }
    }

    /**
     * 一覧情報の更新
     */
    public itemsSourceChanged(): void {

        // 1つ目の期首補助科目残高にフォーカスを設定する
        if (this.amountSumDtoList.length > 1) {
            this.flexGrid.refresh();
            this.flexGrid.focusCellInput(1, 5);
        }
    }

    /**
     * 一覧内容の編集
     */
    public gridChange(): void {

        if (!this.isDirty) {
            // 編集済みフラグを設定して、ショートカットを反映する
            this.isDirty = true;
            this.updateShortcutButtonStatus();
        }
    }

    /**
     * 資産　負債・資本　ALL のタブボタンの変更処理
     */
    public selectedTabChange(): void {

        // 選択中のアイテムが取得できなかった際は処理を抜ける
        if (!this.tabBar.selectedItem) {
            return;
        }

        // 値に変更がない場合は処理を中断
        if (this.acDrCrCls === this.tabBar.selectedItem.value) {
            return;
        }

        // 選択中の貸借区分を設定する
        this.acDrCrCls = this.tabBar.selectedItem.value;

        // 一覧の再表示を行う
        this.repossession();
    }

    /**
     * Tabキーの押下処理
     */
    public setNextFocus(e: any, item: AC036AmountSumDto): void {

        // 既存のTab移動を止める
        e.preventDefault();

        // 対象行を取得
        var selectedRow: number = this.flexGrid.collectionView.items.findIndex(
            (element) => { return element === item });

        for (var i:number = selectedRow + 1; i < this.flexGrid.collectionView.items.length; i++) {
            var nextItem: AC036AmountSumDto = this.flexGrid.collectionView.items[i];
            if (nextItem.acSubTitleId !== -1) {
                // 表示されていない場合スクロールを行う
                this.flexGrid.focusCellInput(i, 5);
                return;
            }
        }
    }

    /**
     * Shift + Tabキーの押下処理
     */
    public setBeforeFocus(e: any, item: AC036AmountSumDto): void {

        // 既存のTab移動を止める
        e.preventDefault();

        // 対象行を取得
        var selectedRow: number = this.flexGrid.collectionView.items.findIndex(
            (element) => { return element === item });

        for (var i:number = selectedRow - 1; i >= 0; i--) {
            var befItem: AC036AmountSumDto = this.flexGrid.collectionView.items[i];
            if (befItem.acSubTitleId !== -1) {
                // 表示されていない場合スクロールを行う
                this.flexGrid.focusCellInput(i, 5);
                return;
            }
        }
    }

    /**
     * データの再取得をおこなう
     */
    public repossession(): void {

        // リクエストを生成
        var reqDto: AC036ReqDto = new AC036ReqDto();
        reqDto.acDrcrCls = this.acDrCrCls;
        reqDto.showNotUse = this.showNotUse;

        // 取消処理を実行
        this.ac036Service.cancel(reqDto, this.cancelOnResult);
    }

    /**
     * 取消ボタンの押下処理
     */
    public cancelBtnClick(): void {

        // 変更を取り消す
        this.amountSumDtoList = JSON.parse(JSON.stringify(this.tmpAmountSumDtoList));

        // 変更の取消
        this.isDirty = false;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 更新ボタンの押下処理
     */
    public updateBtnClick(): void {

        // 更新します。よろしいですか？
        this.eAlert.message('120023', [], null, () => {

            // リクエストを生成
            var reqDto: AC036ReqDto = new AC036ReqDto();
            // 表示中のデータを設定する
            reqDto.updateAmountSumDtoList = new Array(0);
            reqDto.acDrcrCls = this.acDrCrCls;
            reqDto.showNotUse = this.showNotUse;

            for (var i:number = 0; i < this.flexGrid.collectionView.items.length; i++) {

                // 入力情報を取得
                var input: AC036AmountSumDto = this.flexGrid.collectionView.items[i];
                // 更新情報を作成
                var updateItem: AC036UpdateAmountSumDto = new AC036UpdateAmountSumDto();

                // 勘定科目ID
                updateItem.acTitleId = input.acTitleId;
                // 補助科目ID
                updateItem.acSubTitleId = input.acSubTitleId;
                // 貸借区分 ２：借方ＢＳ科目　３：貸方ＢＳ科目
                updateItem.acDrcrCls = input.acDrcrCls;
                /** 残高0 : 会計年度の期首残高。 */
                updateItem.amountSumBa0 = input.amountSumBa0;
                // 残高0 : 補助科目の会計年度の期首残高
                updateItem.subAmountSumBa0 = input.subAmountSumBa0;
                // 更新日
                updateItem.updatedAt = input.updatedAt;

                reqDto.updateAmountSumDtoList.push(updateItem);
            }

            // 更新処理を実行
            this.ac036Service.update(reqDto, this.updateOnResult);
        });
    }

    /**
     * 印刷ボタンの押下処理
     */
    public printBtnClick(): void {

        // リクエストを生成
        var reqDto: AC036ReqDto = new AC036ReqDto();
        // 表示中の検索条件を設定する
        reqDto.acDrcrCls = this.acDrCrCls;
        reqDto.showNotUse = this.showNotUse;

        this.reportPop.show(reqDto, () => {
            // 印刷のプレ処理 => 印刷 を行う
            this.ac036Service.onPrint(reqDto, '補助科目の期首残高一覧');
        });
    }

    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     * @param resDto
     */
    private getInitialOnResult(resDto: AC036ResDto): void {

        // 一覧表を作成
        this.amountSumDtoList = resDto.amountSumDtoList;
        this.tmpAmountSumDtoList = JSON.parse(JSON.stringify(this.amountSumDtoList));

        // ALL を初期設定
        this.tabBar.tabBar.selectedIndex = 2;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * データの再取得処理 完了
     * @param resDto
     */
    private cancelOnResult(resDto: AC036ResDto): void {

        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        // 一覧表を作成
        this.amountSumDtoList = resDto.amountSumDtoList;
        this.tmpAmountSumDtoList = JSON.parse(JSON.stringify(this.amountSumDtoList));

        // 変更の取消
        this.isDirty = false;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 更新処理 完了
     * @param resDto
     */
    private updateOnResult(resDto: AC036ResDto): void {

        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        // 一覧表を作成
        this.amountSumDtoList = resDto.amountSumDtoList;
        this.tmpAmountSumDtoList = JSON.parse(JSON.stringify(this.amountSumDtoList));

        // 変更の取消
        this.isDirty = false;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * ショートカットボタンの制御を行う
     */
    private updateShortcutButtonStatus(): void {

        // ショートカット
        var mode: string;
        var printMode: string;

        // 参照モード
        if (this.isReferenceMode) {
            mode = 'reference';
        }
        // 通常モード
        else {

            // 通常モード / 変更有無
            mode = this.isDirty ? 'insert-dirty' : 'insert';
        }

        // 社員一覧の有無によってショートカットを制御する
        if (!this.amountSumDtoList || this.amountSumDtoList.length === 0) {
            printMode = 'no-print';
        }
        else {
            printMode = 'print';
        }

        // ショートカットの制御を行う
        this.setShortcutBtnDefs(mode, printMode);
    }
}
