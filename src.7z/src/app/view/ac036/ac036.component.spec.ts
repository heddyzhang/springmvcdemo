import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac036Component } from './ac036.component';

describe('Ac036Component', () => {
  let component: Ac036Component;
  let fixture: ComponentFixture<Ac036Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac036Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac036Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
