import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac381Component } from './ac381.component';

describe('Ac381Component', () => {
  let component: Ac381Component;
  let fixture: ComponentFixture<Ac381Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac381Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac381Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
