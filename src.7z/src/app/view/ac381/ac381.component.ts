import { Component, ViewChild } from '@angular/core';
import { ComponentBase, AppType } from '../component-base';
import { EConfigureReportPopComponent } from '../../component/e-configure-report-pop/e-configure-report-pop.component';
import { AC381Service } from '../../service/AC381Service';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { Router } from '@angular/router';
import { AC381ViewChangeBean } from '../../bean/AC381ViewChangeBean';
import { AC380ViewChangeBean } from '../../bean/AC380ViewChangeBean';
import { AC381ReqDto } from '../../dto/ac381/AC381ReqDto';
import { AC381journalDto } from '../../dto/ac381/AC381journalDto';
import { CellType, FormatItemEventArgs } from 'wijmo/wijmo.grid';
import { WjFlexGridEx } from '../../component/wj-flex-grid-ex/wj-flex-grid-ex';
import { AC381ResDto } from '../../dto/ac381/AC381ResDto';

@Component({
    selector: 'app-ac381',
    templateUrl: './ac381.component.html',
    styleUrls: ['./ac381.component.css']
})
export class Ac381Component extends ComponentBase {

    /** アプリケーションIDを設定 */
    private appID: string = 'ac381';

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.C_Report;

    @ViewChild('reportPop')
    /** 印刷条件ポップアップ */
    private reportPop: EConfigureReportPopComponent;

    @ViewChild(WjFlexGridEx)
    /** グリッドへの参照 */
    private flexGrid: WjFlexGridEx;

    /** 0: 当年度 1: 翌年度 (=> 最新年度のみ翌年度表示) */
    public selectedYear: number;

    /** 選択開始月 */
    private startMonth: number = -1;

    /** 選択終了月 */
    private endMonth: number = -1;

    /** 借方科目 */
    private drAcTitleId: number = -1;

    /** 貸方科目 */
    private crAcTitleId: number = -1;

    /** 最小金額 */
    private minJournalAmount: number = 0;

    /** 最大金額 */
    private maxJournalAmount: number = 0;

    /** 摘要 */
    private journalSummary: string = "";

    /** 部門の選択フラグ（０：全社対応、１：選択した部門 */
    private selectSegment: number = 0;

    /** 選択された部門コード */
    private selectSegmentId: number = -1;

    /**  */
    public journalDtoList: AC381journalDto[];

    /** ショートカットボタン */
    protected shortcutBtnDefs: any = {
        'all': [
            { tagNo: 1, enabled: true }, { tagNo: 8, enabled: true },
        ],
    }

    /** コンストラクタ */
    constructor(private ac381Service: AC381Service, private property: EcoKaikeiProperty, private router: Router) {
        super(ac381Service, property);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // ショートカットを表示
        super.displayShortCutBtn(1, 8);

        // ショートカットボタンの名称を変える
        this.viewBaseButton1.value = '戻る';
        this.shortCutRefresh();

        // ショートカットの制御を行う
        this.setShortcutBtnDefs('all');

        // Ac380からの受け渡しパラメータを設定する
        var bean: AC381ViewChangeBean = this.property.getViewChangeBeans(this.appID) as AC381ViewChangeBean;

        // 選択中の会計年度
        this.selectedYear = bean.selectedYear;

        // 選択開始月
        this.startMonth = bean.startMonth;

        // 選択終了月
        this.endMonth = bean.endMonth;

        // 借方科目
        this.drAcTitleId = bean.drAcTitleId;

        // 貸方科目
        this.crAcTitleId = bean.crAcTitleId;

        // 最小金額
        this.minJournalAmount = bean.minJournalAmount;

        // 最大金額
        this.maxJournalAmount = bean.maxJournalAmount;

        // 摘要
        this.journalSummary = bean.journalSummary;

        // 部門の選択フラグ（０：全社対応、１：選択した部
        this.selectSegment = bean.selectSegment;

        // 部門ID
        this.selectSegmentId = bean.selectSegmentId;

        // 期間開始
        var startMonth: string = this.property.getYearMonthLabel(this.selectedYear, this.startMonth);

        // 期間終了
        var endMonth: string = this.property.getYearMonthLabel(this.selectedYear, this.endMonth);

        // タイトル部分に期間を表示
        this.base.title = '仕訳票' + startMonth + '～' + endMonth;

        // 初期情報を取得
        var req: AC381ReqDto = new AC381ReqDto();
        req.selectedYear = this.selectedYear;
        req.startMonth = this.startMonth;
        req.endMonth = this.endMonth;
        req.drAcTitleId = this.drAcTitleId;
        req.crAcTitleId = this.crAcTitleId;
        req.minJournalAmount = this.minJournalAmount;
        req.maxJournalAmount = this.maxJournalAmount;
        req.selectSegment = this.selectSegment;
        req.selectSegmentId = this.selectSegmentId;

        this.ac381Service.getInitial(req, this.getInitialOnResult);
    }

    /**
     * 背景色の設定
     * @param e
     */
    public formatItem(e: FormatItemEventArgs): void {

        // Cellのみ反映
        if (e.panel.cellType === CellType.Cell) {
            // 背景色を設定する
            e.cell.style.backgroundColor = this.flexGrid.collectionView.items[e.row].backgroundColor;
        }
    }

    /**
     * 一覧の再表示を行う
     */
    public flexGridRefresh(): void {

        // 参照エラー時は処理を中断
        if (!this.flexGrid || !this.flexGrid.collectionView) {
            return;
        }
    }

    /**
     * 戻るボタンの押下処理
     */
    public removeBtnClick(): void {

        // 遷移用パラメータを生成する
        var ac380bean: AC380ViewChangeBean = new AC380ViewChangeBean(
            this.selectedYear, this.startMonth
            , this.endMonth, this.drAcTitleId, this.crAcTitleId
            , this.minJournalAmount, this.maxJournalAmount, this.journalSummary
            , this.selectSegment, this.selectSegmentId);


        // パラメータの設定を行う
        this.property.setViewChangeBeans(ac380bean, this.appID, 'ac380');

        // 仕訳票
        this.router.navigate(['view/ac380', { param: '1' }]);
    }

    /**
     * 印刷ボタンの押下処理
     */
    public printBtnClick(): void {

        // リクエストを生成
        var reqDto: AC381ReqDto = new AC381ReqDto();
        reqDto.selectedYear = this.selectedYear;
        reqDto.startMonth = this.startMonth;
        reqDto.endMonth = this.endMonth;

        this.reportPop.show(reqDto, () => {
            // 印刷のプレ処理 => 印刷 を行う
            this.ac381Service.onPrint(reqDto, '仕訳票');
        });
    }

    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     */
    private getInitialOnResult(resDto: AC381ResDto): void {

        // 一覧表を作成
        this.journalDtoList = resDto.journalDtoList;
    }
}
