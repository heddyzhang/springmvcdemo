import { Component, ViewChild } from '@angular/core';
import { AC035Service } from '../../service/AC035Service';
import { AC035ReqDto } from '../../dto/ac035/AC035ReqDto';
import { AC035ResDto } from '../../dto/ac035/AC035ResDto';
import { AC035AmountSumDto } from '../../dto/ac035/AC035AmountSumDto';
import { WjFlexGridEx } from '../../component/wj-flex-grid-ex/wj-flex-grid-ex';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { ComponentBase, AppType } from '../component-base';
import { EConfigureReportPopComponent } from '../../component/e-configure-report-pop/e-configure-report-pop.component';
import { ETabBarDecoComponent } from '../../component/e-tab-bar-deco/e-tab-bar-deco.component';
import { AC035UpdateAmountSumDto } from '../../dto/ac035/AC035UpdateAmountSumDto';

@Component({
    selector: 'app-ac035',
    templateUrl: './ac035.component.html',
    styleUrls: ['./ac035.component.css']
})
export class Ac035Component extends ComponentBase {

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.D_Master;

    @ViewChild('reportPop')
    /** 印刷条件ポップアップ */
    private reportPop: EConfigureReportPopComponent;

    /** 一覧内容 */
    public amountSumDtoList: AC035AmountSumDto[];

    /** 一覧内容(取消用) */
    private tmpAmountSumDtoList: AC035AmountSumDto[];

    @ViewChild(WjFlexGridEx)
    /** 一覧への参照 */
    private flexGrid: WjFlexGridEx;

    @ViewChild(ETabBarDecoComponent)
    /** 一覧への参照 */
    private tabBar: ETabBarDecoComponent;

    /** タブ内容 */
    public acDrCrClsItems: any[] = [{ value: 2, label: "　　資産　　" },
    { value: 3, label: "　負債・資本　" },
    { value: -1, label: "　　ALL　　" }];

    /** 借方・貸方 / ALL 区分 */
    public acDrCrCls: number = -1;

    /** 使用していない科目を表示 true:全表示 false:使用科目のみ */
    public showNotUse: boolean = false;

    /** 資産合計金額(a) */
    public acDrSum: number = 0;

    /** 負債・資本合計金額(b) */
    public acCrSum: number = 0;

    /** 編集中（未保存の編集データが存在する） */
    private isDirty: boolean = false;

    /** ショートカットボタン（取消・更新・印刷） */
    protected shortcutBtnDefs: any = {
        'reference': [
            { tagNo: 3, enabled: false }, { tagNo: 10, enabled: false },
        ],
        'insert': [
            { tagNo: 3, enabled: false }, { tagNo: 10, enabled: false },
        ],
        'insert-dirty': [
            { tagNo: 3, enabled: true }, { tagNo: 10, enabled: true },
        ],
        'no-print': [
            { tagNo: 8, enabled: false }, { tagNo: 9, enabled: false },
        ],
        'print': [
            { tagNo: 8, enabled: true }, { tagNo: 9, enabled: false },
        ],
    }

    /** サービス名 */
    constructor(private ac035Service: AC035Service, private property: EcoKaikeiProperty) {
        super(ac035Service, property);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // ショートカットを表示
        super.displayShortCutBtn(3, 8, 10);

        // 初期情報を取得
        this.ac035Service.getInitial(new AC035ReqDto(), this.getInitialOnResult);
    }

    /**
     * 内容の編集終了
     */
    public cellInput(): void {

        if (!this.isDirty) {

            this.isDirty = true;
            // ショートカットボタンの制御を行う
            this.updateShortcutButtonStatus();
        }
    }

    /**
     * タブバーの変更処理
     */
    public selectedTabChange(): void {

        // 選択中のアイテムが取得できなかった際は処理を抜ける
        if (!this.tabBar.selectedItem) {
            return;
        }

        // 選択中の貸借区分を設定する
        this.acDrCrCls = this.tabBar.selectedItem.value;

        // 一覧の再表示を行う
        this.flexGridRefresh();
    }

    /**
     * Tabキーの押下処理
     */
    public setNextFocus(e: any, item: AC035AmountSumDto): void {

        // 既存のTab移動を止める
        e.preventDefault();

        // 合計欄の計算をおこなう => lostFocusが発生しない場合がある
        this.calculationSum();

        // 対象行を取得
        var selectedRow: number = this.flexGrid.collectionView.items.findIndex(
            (element) => { return element === item });

        // 表示されていない場合スクロールを行う
        this.flexGrid.focusCellInput(selectedRow + 1, 2);
    }

    /**
     * Shift + Tabキーの押下処理
     */
    public setBeforeFocus(e: any, item: AC035AmountSumDto): void {

        // 既存のTab移動を止める
        e.preventDefault();

        // 合計欄の計算をおこなう => lostFocusが発生しない場合がある
        this.calculationSum();

        // 対象行を取得
        var selectedRow: number = this.flexGrid.collectionView.items.findIndex(
            (element) => { return element === item });

        // 表示されていない場合スクロールを行う
        this.flexGrid.focusCellInput(selectedRow - 1, 2);
    }

    /**
     * 内容の編集終了
     */
    public lostFocus(): void {

        // 合計欄の計算をおこなう
        this.calculationSum();
    }

    /**
     * 取消ボタンの押下処理
     */
    public cancelBtnClick(): void {

        // 変更を取り消す
        this.amountSumDtoList = JSON.parse(JSON.stringify(this.tmpAmountSumDtoList));
        this.isDirty = false;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 更新ボタンの押下処理
     */
    public updateBtnClick(): void {

        // 更新します。よろしいですか？
        this.eAlert.message('120023', [], null, () => {

            // リクエストを生成
            var reqDto: AC035ReqDto = new AC035ReqDto();
            // 表示中のデータを設定する
            reqDto.updateAmountSumDtoList = new Array(0);

            for (var i: number = 0; i < this.flexGrid.collectionView.items.length; i++) {

                // 入力情報を取得
                var input: AC035AmountSumDto = this.flexGrid.collectionView.items[i];
                // 更新情報を作成
                var updateItem: AC035UpdateAmountSumDto = new AC035UpdateAmountSumDto();

                // 勘定科目ID
                updateItem.acTitleId = input.acTitleId;
                // 貸借区分 ２：借方ＢＳ科目　３：貸方ＢＳ科目
                updateItem.acDrcrCls = input.acDrcrCls;
                // 残高0 : 会計年度の期首残高
                updateItem.amountSumBa0 = input.amountSumBa0;
                // 更新日
                updateItem.updatedAt = input.updatedAt;

                reqDto.updateAmountSumDtoList.push(updateItem);
            }

            // 更新処理を実行
            this.ac035Service.update(reqDto, this.updateOnResult);
        });
    }

    /**
     * 印刷ボタンの押下処理
     */
    public printBtnClick(): void {

        // リクエストを生成
        var reqDto: AC035ReqDto = new AC035ReqDto();
        reqDto.showNotUse = this.showNotUse;
        reqDto.acDrcrCls = this.acDrCrCls;

        this.reportPop.show(reqDto, () => {
            // 印刷のプレ処理 => 印刷 を行う
            this.ac035Service.onPrint(reqDto, '勘定科目の期首残高一覧');
        });
    }

    /**
     * 合計を計算する
     */
    private calculationSum(): void {

        // 資産合計金額(a)
        var sumDr: number = 0;
        // 負債・資本合計金額(b)
        var sumCr: number = 0;

        // 合計金額を足す
        for (var i: number = 0; i < this.amountSumDtoList.length; i++) {
            if (this.amountSumDtoList[i].acDrcrCls === 2) {
                sumDr += this.amountSumDtoList[i].amountSumBa0;
            } else {
                sumCr += this.amountSumDtoList[i].amountSumBa0;
            }
        }

        // 表示を行う
        this.acDrSum = sumDr;
        this.acCrSum = sumCr;
    }

    /**
     * 一覧の再表示を行う
     */
    public flexGridRefresh(): void {

        // 参照エラー時は処理を中断
        if (!this.flexGrid || !this.flexGrid.collectionView) {
            return;
        }

        // フィルターの設定
        this.flexGrid.collectionView.filter = this.filterFunction.bind(this);

        // 1つめの残高にフォーカスを設定する
        if (this.flexGrid.collectionView.items.length > 0) {
            this.flexGrid.focusCellInput(0, 2);
        }

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();

        // 合計欄の計算をおこなう
        this.calculationSum();
    }

    /**
     * 借方・貸方 / 使用していない科目を表示しない によるフィルタ
     * @param item
     */
    private filterFunction(item: AC035AmountSumDto): boolean {

        // 使用していない科目を表示しない
        if (!this.showNotUse && item.acUseCls === 0) {
            return false;
        }

        // 借方・貸方 => 絞り込み
        if (this.acDrCrCls !== -1 && this.acDrCrCls !== item.acDrcrCls) {
            return false;
        }

        return true;
    }

    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     * @param resDto
     */
    private getInitialOnResult(resDto: AC035ResDto): void {

        // 一覧表を作成
        this.amountSumDtoList = resDto.amountSumDtoList;
        this.tmpAmountSumDtoList = JSON.parse(JSON.stringify(this.amountSumDtoList));

        // ALL を初期設定
        this.tabBar.tabBar.selectedIndex = 2;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 更新処理 完了
     * @param resDto
     */
    private updateOnResult(resDto: AC035ResDto): void {

        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        // 一覧表を作成
        this.amountSumDtoList = resDto.amountSumDtoList;
        this.tmpAmountSumDtoList = JSON.parse(JSON.stringify(this.amountSumDtoList));

        // 変更の取消
        this.isDirty = false;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * ショートカットボタンの制御を行う
     */
    private updateShortcutButtonStatus(): void {

        // ショートカット
        var mode: string;
        var printMode: string;

        // 参照モード
        if (this.isReferenceMode) {
            mode = 'reference';
        }
        // 通常モード
        else {

            // 通常モード / 変更有無
            mode = this.isDirty ? 'insert-dirty' : 'insert';
        }

        // 社員一覧の有無によってショートカットを制御する
        if (!this.amountSumDtoList || this.amountSumDtoList.length === 0) {
            printMode = 'no-print';
        }
        else {
            printMode = 'print';
        }

        // ショートカットの制御を行う
        this.setShortcutBtnDefs(mode, printMode);
    }
}
