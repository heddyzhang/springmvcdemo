import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac035Component } from './ac035.component';

describe('Ac035Component', () => {
  let component: Ac035Component;
  let fixture: ComponentFixture<Ac035Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac035Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac035Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
