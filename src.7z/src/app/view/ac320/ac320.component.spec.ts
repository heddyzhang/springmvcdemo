import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac320Component } from './ac320.component';

describe('ac320Component', () => {
  let component: Ac320Component;
  let fixture: ComponentFixture<Ac320Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac320Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac320Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
