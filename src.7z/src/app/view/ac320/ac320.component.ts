import { Component, ViewChild } from '@angular/core';
import { ComponentBase, AppType } from '../component-base';
import { AC320Service } from '../../service/AC320Service';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { AC320ReqDto } from '../../dto/ac320/AC320ReqDto';
import { EConfigureReportPopComponent } from '../../component/e-configure-report-pop/e-configure-report-pop.component';
import { EMonthSliderSelectRMonth, EMonthSliderComponent } from '../../component/e-month-slider/e-month-slider.component';
import { Router } from '@angular/router';
import { EDropDownListModule, EDropDownListComponent } from '../../component/e-drop-down-list/e-drop-down-list.component';
import { AC320SegmentDto } from '../../dto/ac320/AC320SegmentDto';
import { AC320ViewChangeBean } from '../../bean/AC320ViewChangeBean';
import { AC321ViewChangeBean } from '../../bean/AC321ViewChangeBean';
import { AC322ViewChangeBean } from '../../bean/AC322ViewChangeBean';
import { EventArgs } from 'wijmo/wijmo';

@Component({
    selector: 'app-ac320',
    templateUrl: './ac320.component.html',
    styleUrls: ['./ac320.component.css']
})
export class Ac320Component extends ComponentBase {

    /** アプリケーションIDを設定 */
    private appID: string = 'ac320';

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.C_Report;

    @ViewChild('reportPop')
    /** 印刷条件ポップアップ */
    private reportPop: EConfigureReportPopComponent;

    @ViewChild(EMonthSliderComponent)
    /** 月度バー */
    private monthSlider: EMonthSliderComponent;
    private: EDropDownListModule;

    @ViewChild('segList')
    private segList: EDropDownListComponent;

    // 0: 当期 1: 翌期 (=> 最新年度のみ翌期表示)
    public selectedYear: number;

    /** 当期 */
    public selectFisicalYear: number = 0;

    /** 翌期 */
    public selectFisicalNextYear: number = 0;

    /** 部門のリスト */
    public segmentList: AC320SegmentDto[] = Array(0);

    // 翌期を表示するかどうか
    public displayNextYear: boolean = true;

    /** 補助科目を表示する フラグ */
    public showSubTitle: boolean = false;

    // 選択開始月
    private startMonth: number = -1;

    // 選択終了月
    private endMonth: number = -1;

    // 作成対象(0: 損益計算書(pdf) 1: 推移損益計算書(pdf))
    public selectSheet: number = 0;

    /** 単位 (0: 円 1: 千円 2: 百万円) */
    public selectUnit: number = 0;

    /** 事業者の税情報
       税込み処理中: 1: 消費税込（金額 + 消費税） 2: 消費税抜き (金額)
       税抜き処理中: 1: 消費税抜き (金額) 2: なし
       ※会計年度集約.税込税抜集計区分とは異なる
   */
    public acTaxSummary: number = 1;

    /** 決算の扱い (true: 決算を最終月に含める false: 決算を最終月に含めない) */
    public selectSettle: boolean = false;

    /** 部門（全社集計） */
    public selectCompanyTotal: boolean = false;

    /** 部門（全部門別） */
    public selectAllDepartments: boolean = false;

    /** 選択部門 (-1は"指定なし") */
    public segmentId: number = -1;

    /** 事業者の当年度税情報 */
    public currentTaxAccountingMethod: number;

    /** 事業者の翌年度税情報 */
    public nextTaxAccountingMethod: number;

    /** ショートカットボタン */
    protected shortcutBtnDefs: any = {
        'summary-none': [
            { tagNo: 7, enabled: false }, { tagNo: 8, enabled: false },
        ],
        'summary': [
            { tagNo: 7, enabled: true }, { tagNo: 8, enabled: true },
        ],
        'transition-none': [
            { tagNo: 7, enabled: false }, { tagNo: 8, enabled: false },
        ],
        'transition': [
            { tagNo: 7, enabled: true }, { tagNo: 8, enabled: true },
        ],
    }

    /** コンストラクタ */
    constructor(private ac320Service: AC320Service, private property: EcoKaikeiProperty, private router: Router) {
        super(ac320Service, property);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // ショートカットを表示
        super.displayShortCutBtn(7, 8);

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();

        // 最新年度のみ翌年度表示
        this.displayNextYear = this.property.ownershipDto.newFisicalYear;

        // 年度切り替え時の会計年度コードを設定する
        this.selectFisicalYear = this.property.ownershipDto.selectFisicalYear;
        this.selectFisicalNextYear = this.property.ownershipDto.selectFisicalYear + 1;

        // 事業者の税情報
        // 税込み処理中: 1: 消費税込（金額 + 消費税） 2: 消費税抜き (金額)
        // 税抜き処理中: 1: 消費税抜き (金額) 2: なし

        // 当年度
        this.currentTaxAccountingMethod = this.property.ownershipDto.currentTaxInfoDto.taxAccountingMethod;

        // 翌年度
        this.nextTaxAccountingMethod = this.property.ownershipDto.nextTaxInfoDto.taxAccountingMethod;

        //---------------------------
        // 部門のドロップダウンを設定
        //---------------------------
        var sgList: AC320SegmentDto[] = Array(0);
        var dto: AC320SegmentDto = new AC320SegmentDto("指定なし", -1);
        sgList.push(dto);
        for (var i = 0; i < this.property.segmentPopupItemList.length; i++) {

            // AC000のgetSegmentで空白が入っているから-1の時飛ばす
            if (this.property.segmentPopupItemList[i].id === -1) {
                continue;
            }

            dto = new AC320SegmentDto(this.property.segmentPopupItemList[i].label, this.property.segmentPopupItemList[i].id);
            sgList.push(dto);
        }
        this.segmentList = sgList;

        // 画面遷移パラメータを取得
        var bean: AC320ViewChangeBean = this.property.getViewChangeBeans(this.appID) as AC320ViewChangeBean;

        // メニューからの呼び出し
        if (!bean) {
            // 初期値として当年度を指定
            this.selectedYear = this.property.ownershipDto.selectFisicalYear;
        }

        // 画面遷移時(戻るボタンを押したとき残る情報)
        else {
            // 選択中の会計年度
            this.selectedYear = bean.selectedYear;
            // 集計開始月
            this.startMonth = bean.startMonth;
            // 集計終了月
            this.endMonth = bean.endMonth;
            // 貸借対照表、損益計算書、製造原価計集計表
            this.selectSheet = bean.selectSheet;
            // 単位
            this.selectUnit = bean.selectUnit;
            // 事業者の税情報
            // 税込み処理中: 1: 消費税込（金額 + 消費税） 2: 消費税抜き (金額)
            // 税抜き処理中: 1: 消費税抜き (金額) 2: なし
            this.acTaxSummary = bean.acTaxSummary;
            // 決算の扱い
            this.selectSettle = bean.selectSettle;
            //部門（全社集計）
            this.selectCompanyTotal = bean.selectCompanyTotal;
            //部門（全部門別）
            this.selectAllDepartments = bean.selectAllDepartments;
            //選択部門 (-1は"指定なし")
            this.segmentId = bean.segmentId;
        }

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }

    // 表示したときに部門ドロップダウンリストの戻りの設定
    // 部門のリストをwijmoItemに入れる、EDropDownListComponentに入れる
    public formatItem() {
        var temp = this.segmentList.find(x => x.value === this.segmentId);
        this.segList.selectedItem = temp;
    }


    /**
     * 対象年度の変更処理（html画面で使用メソッド）
     */
    public selectFisicalYearChange(): void {

        // 選択を解除
        this.startMonth = -1;
        this.endMonth = -1;

        // 選択月の再設定を行う
        this.monthSlider.selectionClear();

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
 * 選択部門の変更処理
 */
    public selectMenuChange(): void {
        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 部門コンボボックスの変更処理
     */
    public segmentIdChange(): void {
        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 作成帳票の変更処理
     */
    public selectSheetClsChange(): void {

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
 * 月度バーの選択変更処理
 * @param event 選択中の月
 */
    public monthSliderChage(event: EMonthSliderSelectRMonth): void {

        // 開始月を設定
        this.startMonth = event.fromRMonth;

        // 終了月を設定
        this.endMonth = event.toRMonth;

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 月度バーにデータを設定した際の処理
     */
    public itemsSourceChanged(monthSlider: EMonthSliderComponent): void {

        // データの取得に失敗した際は、処理を中断する
        if (!monthSlider.collectionView) {
            return;
        }

        // 選択を行う
        monthSlider.selectNMonth(this.startMonth, this.endMonth);
    }

    /**
     * 表示ボタンの押下処理
     */
    public displayBtnClick(): void {
        // 表示条件をもとに 集計表 に遷移する
        if (this.selectSheet === 0) {
            // 遷移用パラメータを生成する
            var ac321bean: AC321ViewChangeBean = new AC321ViewChangeBean(this.selectedYear
                , this.showSubTitle, this.startMonth, this.endMonth, this.selectSheet, this.selectUnit, this.acTaxSummary, this.selectCompanyTotal, this.selectAllDepartments, this.segmentId);
            // パラメータの設定を行う
            this.property.setViewChangeBeans(ac321bean, this.appID, 'ac321');
            // 貸借対照表 集計表
            this.router.navigate(['view/ac321', { param: '1' }]);
        }
        // 表示条件をもとに 推移表に遷移する
        else if (this.selectSheet === 1) {
            // 遷移用パラメータを生成する
            var ac322bean: AC322ViewChangeBean = new AC322ViewChangeBean(this.selectedYear
                , this.showSubTitle, this.startMonth, this.endMonth, this.selectSheet, this.selectUnit, this.acTaxSummary, this.selectSettle, this.selectCompanyTotal, this.selectAllDepartments, this.segmentId);
            // パラメータの設定を行う
            this.property.setViewChangeBeans(ac322bean, this.appID, 'ac322');
            // 貸借対照表 集計表
            this.router.navigate(['view/ac322', { param: '1' }]);
        }
    }

    /**
* 印刷ボタンの押下処理(印刷ショートカット)
*/
    public printBtnClick(): void {

        // リクエストを生成
        var reqDto: AC320ReqDto = new AC320ReqDto();

        // 印刷対象の会計年度
        reqDto.selectedYear = this.selectedYear;

        // 印刷対象 (0、2、4: 集計表 1、3、5: 推移表)
        reqDto.selectSheet = this.selectSheet;

        // 補助科目を表示する フラグ
        reqDto.showSubTitle = this.showSubTitle;

        // 選択開始月
        reqDto.startMonth = this.startMonth;

        // 選択終了月
        reqDto.endMonth = this.endMonth;

        // 単位 (0: 円 1: 千円 2: 百万円)
        reqDto.selectUnit = this.selectUnit;

        // 事業者が税込みを設定している場合: 1: 消費税込（金額 + 消費税） 2: 消費税
        // 事業者が税抜きを設定している場合: 1: 消費税抜（金額） 2: （仮払・仮受）消費税関連
        if ((this.selectedYear === this.selectFisicalYear && this.currentTaxAccountingMethod === 1) ||
            (this.selectedYear === this.selectFisicalNextYear && this.nextTaxAccountingMethod === 1)) {
            reqDto.acTaxSummary = this.acTaxSummary;
        }
        else {
            reqDto.acTaxSummary = 1;
        }

        // 決算の扱い (0: そのまま表示（決算１に含める） 1: 最終月に含める)
        reqDto.selectSettle = this.selectSettle;


        //部門（全社集計）
        reqDto.selectCompanyTotal = this.selectCompanyTotal;
        //部門（全部門別）
        reqDto.selectAllDepartments = this.selectAllDepartments;
        // 全部門別が選択された場合、segmentIdは-1
        if (this.selectAllDepartments) {
            reqDto.segmentId = -1;
        }
        else {
            reqDto.segmentId = this.segmentId;
        }

        // タイトルを設定
        // var title: string = (this.selectSheet === 0 || this.selectSheet === 2 || this.selectSheet === 4) ? '集計表' : '推移表';

        // タイトルを設定
        var title: string = this.selectSheet === 0 ? '集計表' : '推移表';

        this.reportPop.show(reqDto, () => {
            // 印刷のプレ処理 => 印刷 を行う
            this.ac320Service.onPrint(reqDto, title);
        });
    }

    /**
       * ショートカットボタンの制御を行う(disableの制御)
       */
    private updateShortcutButtonStatus(): void {
        // ショートカット
        var mode: string;

        //----------------------------
        // 部門コンボボックスの選択値
        //----------------------------
        var segmentId: number = -1;

        if (this.segList !== undefined && this.segList.selectedItem !== null) {
            segmentId = (this.segList.selectedItem as AC320SegmentDto).value;
        }

        // 0 製造原価報告書 集計表
        if (this.selectSheet === 0) {
            mode = (this.startMonth >= 0 && (this.selectCompanyTotal === true || this.selectAllDepartments === true || segmentId >= 0)) ? 'summary' : 'summary-none';
        }

        // 推移表
        else if (this.selectSheet === 1) {
            // 推移表 選択の有無
            mode = (this.startMonth >= 0 && (this.selectCompanyTotal === true || this.selectAllDepartments === true || segmentId >= 0)) ? 'transition' : 'transition-none';
        }

        // ショートカットの制御を行う
        this.setShortcutBtnDefs(mode);
    }

    /**
     * チェックボックス(補助科目、決算の扱い(2、3選択時のみ表示)
     */
    public show(): void {
        console.log("チェック:");
        console.log(this.showSubTitle);
        console.log("チェック:");
        console.log(this.selectSettle);
        console.log("チェック");
        console.log(this.selectCompanyTotal);
        console.log("チェック");
        console.log(this.selectAllDepartments);
    }

}
