import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac310Component } from './ac310.component';

describe('Ac310Component', () => {
  let component: Ac310Component;
  let fixture: ComponentFixture<Ac310Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac310Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac310Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
