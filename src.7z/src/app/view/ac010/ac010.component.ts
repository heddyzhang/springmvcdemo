import { Component } from '@angular/core';
import { AC010Service } from '../../service/AC010Service';
import { AC010ReqDto } from '../../dto/ac010/AC010ReqDto';
import { AC010ResDto } from '../../dto/ac010/AC010ResDto';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { ComponentBase, AppType } from '../component-base';
import { AC010BusinessDto } from '../../dto/ac010/AC010BusinessDto';
import { AC010BusinessUpdateDto } from '../../dto/ac010/AC010BusinessUpdateDto';

@Component({
    selector: 'app-ac010',
    templateUrl: './ac010.component.html',
    styleUrls: ['./ac010.component.css']
})
export class Ac010Component extends ComponentBase {

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.F_Administrator;

    /** 表示中のデータ */
    public selectItem: AC010BusinessDto = new AC010BusinessDto();

    /** 保存中のデータ */
    public tmpItem: AC010BusinessDto = new AC010BusinessDto();

    /** 編集中（未保存の編集データが存在する） */
    private isDirty: boolean = false;

    /** 会計期間 */
    public fisicalYearFromToDate: string = '';

    /** 年度表示　表示フラグ */
    public settlementDispyearFlg: boolean = false;
    /** 年度表示 : 0 のラベル */
    public settlementDispyearLabel0: string = '';
    /** 年度表示 : 1 のラベル */
    public settlementDispyearLabel1: string = '';

    /** 月度表示　表示フラグ */
    public settlementDispmonthFlg: boolean = false;
    /** 月度表示 : 0 のラベル */
    public settlementDispmonthLabel0: string = '';
    /** 月度表示 : 1 のラベル */
    public settlementDispmonthLabel1: string = '';

    /** ショートカットボタン（取消・更新） */
    protected shortcutBtnDefs: any = {
        'update': [
            { tagNo: 3, enabled: false }, { tagNo: 10, enabled: false },
        ],
        'update-dirty': [
            { tagNo: 3, enabled: true }, { tagNo: 10, enabled: true },
        ],
    }

    /** コンストラクタ */
    constructor(private ac010Service: AC010Service, private property: EcoKaikeiProperty) {
        super(ac010Service, property);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // ショートカットを表示
        super.displayShortCutBtn(3, 10);

        // 初期情報を取得
        this.ac010Service.getInitial(new AC010ReqDto(), this.getInitialOnResult);
    }

    /**
     * 事業者登録情報入力Form変更イベント
     */
    public setDirtyFlag(): void {

        if (!this.isDirty) {

            this.isDirty = true;
            // ショートカットボタンの制御を行う
            this.updateShortcutButtonStatus();
        }
    }

    /**
     * 住所検索
     */
    public zipCdBtnClick(): void {

        // リクエストに郵便番号を設定する
        var reqDto: AC010ReqDto = new AC010ReqDto();
        reqDto.zipCd = this.selectItem.businessZipCd;

        // 入力済みの郵便番号から住所を取得する
        this.ac010Service.getAddress(reqDto, this.getAddressOnResult);
    }

    /**
     * 取消ボタンの押下処理
     */
    public cancelBtnClick(): void {

        // 変更を取り消す
        this.selectItem = Object.assign({}, this.tmpItem);
        this.isDirty = false;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 更新ボタンの押下処理
     */
    public updateBtnClick(): void {

        // 必須項目のチェック
        // 事業者名称
        if (!this.selectItem.businessName) {
            // "事業者名称"は入力必須の項目です。
            this.eAlert.message('210001', ['事業者名称'], 'businessName');
            return;
        }
        // 事業者略称
        else if (!this.selectItem.businessShortname) {
            // "事業者略称"は入力必須の項目です。
            this.eAlert.message('210001', ['事業者略称'], 'businessShortname');
            return;
        }
        // 代表者名
        else if (!this.selectItem.businessRepName) {
            // "代表者名"は入力必須の項目です。
            this.eAlert.message('210001', ['代表者名'], 'businessRepName');
            return;
        }
        // 住所1
        else if (!this.selectItem.businessAddress1) {
            // "住所（都道府県 市町村区）"は入力必須の項目です。
            this.eAlert.message('210001', ['住所（都道府県 市町村区）'], 'businessAddress1');
            return;
        }
        // 住所2
        else if (!this.selectItem.businessAddress2) {
            // "住所（番地 マンション）"は入力必須の項目です。
            this.eAlert.message('210001', ['住所（番地 マンション）'], 'businessAddress2');
            return;
        }
        // TEL
        else if (!this.selectItem.businessPhoneNo) {
            // "電話番号"は入力必須の項目です。
            this.eAlert.message('210001', ['電話番号'], 'businessPhoneNo');
            return;
        }

        // 更新します。よろしいですか？
        this.eAlert.message('120023', [], null, () => {

            // リクエストを生成
            var reqDto: AC010ReqDto = new AC010ReqDto();
            reqDto.updateDto = new AC010BusinessUpdateDto();

            // 事業者名称
            reqDto.updateDto.businessName = this.selectItem.businessName;
            // 事業者略称
            reqDto.updateDto.businessShortname = this.selectItem.businessShortname;
            // 決算期
            reqDto.updateDto.settlementYear = this.selectItem.settlementYear;
            // 代表者名
            reqDto.updateDto.businessRepName = this.selectItem.businessRepName;
            // 年度表示
            reqDto.updateDto.settlementDispyear = this.selectItem.settlementDispyear;
            // 月度表示
            reqDto.updateDto.settlementDispmonth = this.selectItem.settlementDispmonth;
            // 事業者所在地郵便番号
            reqDto.updateDto.businessZipCd = this.selectItem.businessZipCd;
            // 事業者所在地住所1
            reqDto.updateDto.businessAddress1 = this.selectItem.businessAddress1;
            // 事業者所在地住所2
            reqDto.updateDto.businessAddress2 = this.selectItem.businessAddress2;
            // 事業者連絡先電話番号
            reqDto.updateDto.businessPhoneNo = this.selectItem.businessPhoneNo;
            // 更新日 事業者
            reqDto.updateDto.businessUpdatedAt = this.selectItem.businessUpdatedAt;
            // 更新日 会計年度
            reqDto.updateDto.fisicalYearUpdatedAt = this.selectItem.fisicalYearUpdatedAt;

            // 更新処理を実行
            this.ac010Service.update(reqDto, this.updateOnResult);
        });
    }

    /**
     * ショートカットボタンの制御を行う
     */
    private updateShortcutButtonStatus(): void {

        // 通常モード / 変更有無
        var mode: string = this.isDirty ? 'update-dirty' : 'update';

        // ショートカットの制御を行う
        this.setShortcutBtnDefs(mode);
    }

    /**
     * ラベル項目を設定する
     */
    private setLabelItems(): void {

        // 期首
        var fromDate: Date = new Date(this.selectItem.fisicalYearFromDate);
        // 期首 次月
        var fromNextDate: Date = new Date(fromDate.getFullYear(), fromDate.getMonth() + 1, fromDate.getDate() - 1);
        // 期末
        var toDate: Date = new Date(this.selectItem.fisicalYearToDate);

        // 会計期間
        this.fisicalYearFromToDate = this.dateToString(fromDate, 'yyyy年MM月dd日') + ' ～ '
            + this.dateToString(toDate, 'yyyy年MM月dd日');

        // 1月1日始まりは、年度表示を表示させない
        this.settlementDispyearFlg = fromDate.getMonth() !== 0 || fromDate.getDate() !== 1;

        // 年度表示を表示時 ラベルを設定
        if (this.settlementDispyearFlg) {
            // 年度表示 : 0
            this.settlementDispyearLabel0 = this.dateToString(fromDate, 'yyyy年MM月dd日') + 'から' + this.dateToString(toDate, 'yyyy年MM月dd日')
                + 'の会計期間を「' + this.dateToString(fromDate, 'yyyy') + '年度」と期首の年を表示させる';
            // 年度表示 : 1
            this.settlementDispyearLabel1 = this.dateToString(fromDate, 'yyyy年MM月dd日') + 'から' + this.dateToString(toDate, 'yyyy年MM月dd日')
                + 'の会計期間を「' + this.dateToString(toDate, 'yyyy') + '年度」と期末の年を表示させる';
        }

        // 1日始まりは、月度表示を表示させない
        this.settlementDispmonthFlg = fromDate.getDate() !== 1;

        // 月度表示を表示時 ラベルを設定
        if (this.settlementDispmonthFlg) {
            // 月度表示 : 0
            this.settlementDispmonthLabel0 = this.dateToString(fromDate, 'MM月dd日') + 'から' + this.dateToString(fromNextDate, 'MM月dd日')
                + 'の会計期間を「' + this.dateToString(fromDate, 'MM') + '月度」と月初の月を表示させる';
            // 月度表示 : 1
            this.settlementDispmonthLabel1 = this.dateToString(fromDate, 'MM月dd日') + 'から' + this.dateToString(fromNextDate, 'MM月dd日')
                + 'の会計期間を「' + this.dateToString(fromNextDate, 'MM') + '月度」と月末の月を表示させる';
        }
    }

    /**
     * ラベル用に日付を変更する
     * @param date
     * @param format
     */
    private dateToString(date: Date, format: string): string {
        return format.replace(/yyyy/, date.getFullYear().toString())
            .replace(/MM/, (date.getMonth() + 1).toString())
            .replace(/dd/, date.getDate().toString());
    }

    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     * @param resDto
     */
    private getInitialOnResult(resDto: AC010ResDto): void {

        // 入力内容を表示する
        this.selectItem = resDto.businessDto;
        this.tmpItem = Object.assign({}, resDto.businessDto);

        // ラベル部分の設定
        this.setLabelItems();

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 住所検索 完了
     * @param resDto
     */
    private getAddressOnResult(resDto: AC010ResDto): void {

        // 住所の設定をおこなう
        this.selectItem.businessAddress1 = resDto.address1;
        this.selectItem.businessAddress2 = resDto.address2;

        // 項目の変更
        this.setDirtyFlag();
    }

    /**
     * 更新処理 完了
     * @param resDto
     */
    private updateOnResult(resDto: AC010ResDto): void {

        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        // クライアント保有情報を更新
        if (resDto.ownershipDto) {
            this.property.ownershipDto = resDto.ownershipDto;
        }

        // 入力内容を表示する
        this.selectItem = resDto.businessDto;
        this.tmpItem = Object.assign({}, resDto.businessDto);

        // 変更の取消
        this.isDirty = false;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }
}
