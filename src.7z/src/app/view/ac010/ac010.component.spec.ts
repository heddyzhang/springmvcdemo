import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac010Component } from './ac010.component';

describe('Ac010Component', () => {
  let component: Ac010Component;
  let fixture: ComponentFixture<Ac010Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac010Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac010Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
