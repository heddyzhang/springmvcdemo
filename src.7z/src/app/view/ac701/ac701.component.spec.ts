import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac701Component } from './ac701.component';

describe('Ac701Component', () => {
  let component: Ac701Component;
  let fixture: ComponentFixture<Ac701Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac701Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac701Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
