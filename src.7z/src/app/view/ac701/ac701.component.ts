import { Component, OnInit } from '@angular/core';
import { AC701Service } from '../../service/AC701Service';
import { AC701ResDto } from '../../dto/ac701/AC701ResDto';
import { AC701ReqDto } from '../../dto/ac701/AC701ReqDto';

@Component({
  selector: 'app-ac701',
  templateUrl: './ac701.component.html',
  styleUrls: ['./ac701.component.css']
})
export class Ac701Component implements OnInit {

  resDto: AC701ResDto;
  reqDto: AC701ReqDto;

  constructor(private ac701Service: AC701Service) { }

  ngOnInit() {
    this.reqDto = new AC701ReqDto();
  }

  coverOnChenge(isCheck:boolean) {
    this.reqDto.isCover = isCheck;
  }

  plOnChenge(isCheck:boolean) {
    this.reqDto.isPl = isCheck;
  }

  plSgaOnChenge(isCheck:boolean) {
    this.reqDto.isPlSga = isCheck;
  }

  sgaOnChenge(isCheck:boolean) {
    this.reqDto.isSga = isCheck;
  }

  crOnChenge(isCheck:boolean) {
    this.reqDto.isCr = isCheck;
  }
  
  digitOnChenge(isCheck:boolean) {
    this.reqDto.isDigit = isCheck;
  }

  /**
   * 印刷ボタン clickHandler
   */
  onPrint() {
    // 印刷準備を行う
    this.ac701Service.onPrint(this.reqDto).subscribe(
      event => {
        this.resDto = event;
        this.onPrintResult();
      }
    );
  }

  /**
   * 印刷準備完了イベント
   */
  onPrintResult(): void {
    const serviceUrl: string = 'print/ac701/決算書?id=';
    window.open(`${serviceUrl}` + this.resDto.publishId, '_blank');
  }

}
