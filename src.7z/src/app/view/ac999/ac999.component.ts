import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ac999',
  templateUrl: './ac999.component.html',
  styleUrls: ['./ac999.component.css']
})
export class Ac999Component implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
    
  }

}
