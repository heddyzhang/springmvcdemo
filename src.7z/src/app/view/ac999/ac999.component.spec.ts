import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac999Component } from './ac999.component';

describe('Ac999Component', () => {
  let component: Ac999Component;
  let fixture: ComponentFixture<Ac999Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac999Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac999Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
