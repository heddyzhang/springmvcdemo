import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac312Component } from './ac312.component';

describe('Ac312Component', () => {
  let component: Ac312Component;
  let fixture: ComponentFixture<Ac312Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac312Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac312Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
