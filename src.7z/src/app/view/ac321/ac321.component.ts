import { Component, ViewChild } from '@angular/core';
import { ComponentBase, AppType } from '../component-base';
import { EConfigureReportPopComponent } from '../../component/e-configure-report-pop/e-configure-report-pop.component';
import { AC321Service } from '../../service/AC321Service';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { Router } from '@angular/router';
import { AC321ViewChangeBean } from '../../bean/AC321ViewChangeBean';
import { AC320ViewChangeBean } from '../../bean/AC320ViewChangeBean';
import { AC321ReqDto } from '../../dto/ac321/AC321ReqDto';
import { AC321SummaryDto } from '../../dto/ac321/AC321SummaryDto';
import { CellType, FormatItemEventArgs } from 'wijmo/wijmo.grid';
import { WjFlexGridEx } from '../../component/wj-flex-grid-ex/wj-flex-grid-ex';
import { AC321ResDto } from '../../dto/ac321/AC321ResDto';
import { MonthItemDto } from '../../dto/MonthItemDto';
import { AC321SegmentDto } from '../../dto/ac321/AC321SegmentDto';
import { ETabBarDecoComponent } from '../../component/e-tab-bar-deco/e-tab-bar-deco.component';

@Component({
    selector: 'app-ac321',
    templateUrl: './ac321.component.html',
    styleUrls: ['./ac321.component.css']
})
export class Ac321Component extends ComponentBase {

    /** アプリケーションIDを設定 */
    private appID: string = 'ac321';

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.C_Report;

    /** フィルタタブへの参照 */
    @ViewChild('tabBarDeco') tabBarDeco: ETabBarDecoComponent;

    @ViewChild('reportPop')
    /** 印刷条件ポップアップ */
    private reportPop: EConfigureReportPopComponent;

    @ViewChild(WjFlexGridEx)
    /** グリッドへの参照 */
    private flexGrid: WjFlexGridEx;

    /** 選択中の会計年度 */
    public selectedYear: number;

    /** 補助科目を表示する フラグ */
    public showSubTitle: boolean = false;

    /** 選択開始月 */
    private startMonth: number = -1;

    /** 選択終了月 */
    private endMonth: number = -1;

    /** 単位 (0: 円 1: 千円 2: 百万円) */
    public selectUnit: number = 0;

    /** 事業者の税情報
       税込み処理中: 1: 消費税込（金額 + 消費税） 2: 消費税抜き (金額)
       税抜き処理中: 1: 消費税抜き (金額) 2: なし
       ※会計年度集約.税込税抜集計区分とは異なる
   */
    public acTaxSummary: number = 1;

    /** 部門（全社集計） */
    public selectCompanyTotal: boolean = false;

    /** 部門（全部門別） */
    public selectAllDepartments: boolean = false;

    /** 選択部門 (-1は"指定なし") */
    public segmentId: number = -1;

    /** タブ用の選択部門 */
    public tabSegmentId: number = -1;

    /**  */
    public summaryDtoList: AC321SummaryDto[] = Array(0);

    /** 部門のリスト */
    public segmentList: AC321SegmentDto[] = Array(0);

    /** ショートカットボタン */
    protected shortcutBtnDefs: any = {
        'all': [
            { tagNo: 1, enabled: true }, { tagNo: 8, enabled: true },
        ],
    }

    /** コンストラクタ */
    constructor(private ac321Service: AC321Service, private property: EcoKaikeiProperty, private router: Router) {
        super(ac321Service, property);
    }

    /**
     * 初期処理（画面開いたとき）
     */
    protected ecoOnInit(): void {

        // ショートカットを表示
        super.displayShortCutBtn(1, 8);

        // ショートカットボタンの名称を変える
        this.viewBaseButton1.value = '戻る';
        this.shortCutRefresh();

        // ショートカットの制御を行う
        this.setShortcutBtnDefs('all');

        // Ac320からの受け渡しパラメータを設定する
        var bean: AC321ViewChangeBean = this.property.getViewChangeBeans(this.appID) as AC321ViewChangeBean;

        // 選択中の会計年度
        this.selectedYear = bean.selectedYear;

        // 補助科目を表示する フラグ
        this.showSubTitle = bean.showSubTitle;

        // 選択開始月
        this.startMonth = bean.startMonth;

        // 選択終了月
        this.endMonth = bean.endMonth;

        // 期間開始
        var startMonth: string = this.property.getYearMonthLabel(this.selectedYear, this.startMonth);

        // 期間終了
        var endMonth: string = this.property.getYearMonthLabel(this.selectedYear, this.endMonth);

        // タイトル部分に期間を表示
        this.base.title = '製造原価集計表　' + startMonth + '～' + endMonth;

        // 単位 (0: 円 1: 千円 2: 百万円)
        this.selectUnit = bean.selectUnit;

        // 事業者の税情報
        // 税込み処理中: 1: 消費税込（金額 + 消費税） 2: 消費税抜き (金額)
        // 税抜き処理中: 1: 消費税抜き (金額) 2: なし
        this.acTaxSummary = bean.acTaxSummary;

        //部門（全社集計）
        this.selectCompanyTotal = bean.selectCompanyTotal;
        //部門（全部門別）
        this.selectAllDepartments = bean.selectAllDepartments;
        //選択部門 (-1は"指定なし")
        this.segmentId = bean.segmentId;

        //---------------------------
        // 部門のタブを設定
        //---------------------------

        // 全部門
        if (this.selectAllDepartments === true) {
            var sgList: AC321SegmentDto[] = Array(0);
            // コンストラクタで表示するため（label: string, value: number）
            var dto: AC321SegmentDto = new AC321SegmentDto("全社集計", -1);
            // sgList.push(dto);
            for (var i = 0; i < this.property.segmentPopupItemList.length; i++) {
                // AC000のgetSegmentで空白が入っているから-1の時飛ばす
                if (this.property.segmentPopupItemList[i].id === -1) {
                    continue;
                }

                dto = new AC321SegmentDto(this.property.segmentPopupItemList[i].label, this.property.segmentPopupItemList[i].id);
                sgList.push(dto);
            }
            this.segmentList = sgList;
        }

        // 全社集計＋全部門
        if (this.selectCompanyTotal === true && this.selectAllDepartments === true) {
            var sgList: AC321SegmentDto[] = Array(0);
            var dto: AC321SegmentDto = new AC321SegmentDto("全社集計", -1);
            sgList.push(dto);
            for (var i = 0; i < this.property.segmentPopupItemList.length; i++) {
                // AC000のgetSegmentで空白が入っているから-1の時飛ばす
                if (this.property.segmentPopupItemList[i].id === -1) {
                    continue;
                }

                dto = new AC321SegmentDto(this.property.segmentPopupItemList[i].label, this.property.segmentPopupItemList[i].id);
                sgList.push(dto);
            }
            this.segmentList = sgList;
        }

        // 全社集計＋部門
        if (this.selectCompanyTotal === true && this.segmentId > -1) {
            var sgList: AC321SegmentDto[] = Array(0);
            var dto: AC321SegmentDto = new AC321SegmentDto("全社集計", -1);
            sgList.push(dto);
            for (var i = 0; i < this.property.segmentPopupItemList.length; i++) {
                dto = new AC321SegmentDto(this.property.segmentPopupItemList[i].label, this.property.segmentPopupItemList[i].id);
                if (this.segmentId === this.property.segmentPopupItemList[i].id) {
                    sgList.push(dto);
                }
                if (i >= this.property.segmentPopupItemList.length) {
                    break;
                }
            }
            this.segmentList = sgList;
        }

        // 最初画面が白くなるを解除
        // 初期処理を部門にする
        // 部門リストが0でない場合
        // 部門IDにIDの配列の最初に詰める
        if (this.segmentList.length != 0) {
            this.tabSegmentId = this.segmentList[0].value;
        }

        // 初期情報を取得
        var req: AC321ReqDto = new AC321ReqDto();
        req.selectedYear = this.selectedYear;
        req.startMonth = this.startMonth;
        req.endMonth = this.endMonth;
        req.selectUnit = this.selectUnit;

        // 税込み、全社集計、全部門、部門ID
        req.acTaxSummary = this.acTaxSummary;
        req.selectCompanyTotal = this.selectCompanyTotal;
        req.selectAllDepartments = this.selectAllDepartments;
        req.segmentId = this.segmentId;
        this.ac321Service.getInitial(req, this.getInitialOnResult);
    }

    /**
     * 背景色の設定
     * @param e
     */
    public formatItem(e: FormatItemEventArgs): void {

        // Cellのみ反映
        if (e.panel.cellType === CellType.Cell) {
            // 背景色を設定する
            e.cell.style.backgroundColor = this.flexGrid.collectionView.items[e.row].backgroundColor;
        }
    }

    /**
     * 一覧の再表示を行う
     */
    public flexGridRefresh(): void {

        // 参照エラー時は処理を中断
        if (!this.flexGrid || !this.flexGrid.collectionView) {
            return;
        }

        // フィルターの設定
        this.flexGrid.collectionView.filter = this.filterFunction.bind(this);


    }

    /**
     * 補助科目のフィルタと部門のフィルタを表示するかどうか
     * @param item
     */
    private filterFunction(item: AC321SummaryDto): boolean {

        // 全社集計が選択されている場合
        if (this.selectCompanyTotal !== false || this.selectAllDepartments !== false) {
            // 部門を表示しない
            if (item.segmentId !== this.tabSegmentId) {
                return false;
            }
        }

        // 補助科目を表示しない
        if (!this.showSubTitle && item.acSubTitleId !== null && item.acSubTitleId !== -1) {
            return false;
        }
        return true;
    }

    /**
     * 戻るボタンの押下処理
     */
    public removeBtnClick(): void {

        // 遷移用パラメータを生成する
        var ac320bean: AC320ViewChangeBean = new AC320ViewChangeBean(this.selectedYear
            , this.showSubTitle, this.startMonth, this.endMonth, 0, this.selectUnit, this.acTaxSummary, false, this.selectCompanyTotal, this.selectAllDepartments, this.segmentId);

        // パラメータの設定を行う
        this.property.setViewChangeBeans(ac320bean, this.appID, 'ac320');

        // 貸借対照表
        this.router.navigate(['view/ac320', { param: '1' }]);
    }

    /**
     * 印刷ボタンの押下処理
     */
    public printBtnClick(): void {

        // リクエストを生成
        var reqDto: AC321ReqDto = new AC321ReqDto();
        reqDto.selectedYear = this.selectedYear;
        reqDto.showSubTitle = this.showSubTitle;
        reqDto.startMonth = this.startMonth;
        reqDto.endMonth = this.endMonth;
        reqDto.selectUnit = this.selectUnit;
        // 税込み、全社集計、全部門、部門ID
        reqDto.acTaxSummary = this.acTaxSummary;
        reqDto.selectCompanyTotal = this.selectCompanyTotal;
        reqDto.selectAllDepartments = this.selectAllDepartments;
        reqDto.segmentId = this.segmentId;

        this.reportPop.show(reqDto, () => {
            // 印刷のプレ処理 => 印刷 を行う
            this.ac321Service.onPrint(reqDto, '集計表');
        });
    }

    /**
    * タブクリック
    * タブで選択したものに応じてをフィルタする。
    */
    public filterTabClick(): void {

        // 選択中のアイテムが取得できなかった際は処理を抜ける
        if (!this.tabBarDeco.selectedItem) {
            return;
        }

        // if (this.selectAllDepartments !== true) {
        // 部門でフィルタタブの値を設定
        this.tabSegmentId = this.tabBarDeco.selectedItem.value;


        // 一覧の再表示を行う
        this.flexGridRefresh();

        // フィルタ後に選択行が存在しない場合は先頭を選択
        if (this.flexGrid.selectedItems.length === 0) {
            this.flexGrid.select(0, 0);
        }
        console.log(this.flexGrid);

    }


    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     */
    private getInitialOnResult(resDto: AC321ResDto): void {

        // 一覧表を作成
        this.summaryDtoList = resDto.summaryDtoList;


    }
}
