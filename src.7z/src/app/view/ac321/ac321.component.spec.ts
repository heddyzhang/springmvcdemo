import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac321Component } from './ac321.component';

describe('Ac321Component', () => {
  let component: Ac321Component;
  let fixture: ComponentFixture<Ac321Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac321Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac321Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
