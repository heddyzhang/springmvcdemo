import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac031Component } from './ac031.component';

describe('Ac031Component', () => {
  let component: Ac031Component;
  let fixture: ComponentFixture<Ac031Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac031Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac031Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
