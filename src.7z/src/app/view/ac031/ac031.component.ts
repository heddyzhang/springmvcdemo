import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ac031',
  templateUrl: './ac031.component.html',
  styleUrls: ['./ac031.component.css']
})
export class Ac031Component implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  switch() {
    this.router.navigate(['view/ac030']);
  }
}
