import { Component } from '@angular/core';
import { AC011Service } from '../../service/AC011Service';
import { AC011ReqDto } from '../../dto/ac011/AC011ReqDto';
import { AC011ResDto } from '../../dto/ac011/AC011ResDto';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { ComponentBase, AppType } from '../component-base';
import { AC011BusinessDto } from '../../dto/ac011/AC011BusinessDto';
import { AC011BusinessUpdateDto } from '../../dto/ac011/AC011BusinessUpdateDto';

@Component({
    selector: 'app-ac011',
    templateUrl: './ac011.component.html',
    styleUrls: ['./ac011.component.css']
})
export class Ac011Component extends ComponentBase {

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.F_Administrator;

    /** 表示中のデータ */
    public selectItem: AC011BusinessDto = new AC011BusinessDto();

    /** 保存中のデータ */
    public tmpItem: AC011BusinessDto = new AC011BusinessDto();

    /** 部門管理 */
    public useSegmentCls: boolean = false;
    /** 製造原価管理 */
    public useCostreportCls: boolean = false;
    /** 証憑から会計伝票を起票する 体験期間あり */
    public useEvidenceUsedFlg: boolean = false;
    /** タイムスタンプを押す */
    public useTimestampUsedFlg: boolean = false;
    /** Moneytree連携 体験期間あり */
    public useMoneytreeUsedFlg: boolean = false;
    /** 自動仕訳 体験期間あり */
    public useAutojournalUsedFlg: boolean = false;

    /** 編集中（未保存の編集データが存在する） */
    private isDirty: boolean = false;

    /** ショートカットボタン（取消・更新） */
    protected shortcutBtnDefs: any = {
        'update': [
            { tagNo: 3, enabled: false }, { tagNo: 10, enabled: false },
        ],
        'update-dirty': [
            { tagNo: 3, enabled: true }, { tagNo: 10, enabled: true },
        ],
    }

    /** 対応未定のフラグ */
    public notCompatible: boolean = false;

    /** コンストラクタ */
    constructor(private ac011Service: AC011Service, private property: EcoKaikeiProperty) {
        super(ac011Service, property);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // ショートカットを表示
        super.displayShortCutBtn(3, 10);

        // 初期情報を取得
        this.ac011Service.getInitial(new AC011ReqDto(), this.getInitialOnResult);
    }

    /**
     * ご利用形態情報入力Form変更イベント
     */
    public setDirtyFlag(): void {

        if (!this.isDirty) {

            this.isDirty = true;
            // ショートカットボタンの制御を行う
            this.updateShortcutButtonStatus();
        }
    }

    /**
     * 部門管理
     */
    public segmentClsClick(): void {

        // 部門管理
        if (!this.useSegmentCls) {

            // 本機能は、プレミアムコースのみご利用になれます。
            this.eAlert.message('110016', ['プレミアムコース'], null, undefined);
        }
    }

    /**
     * 製造原価報告書
     */
    public costreportClsClick(): void {

        // 製造原価報告書管理
        if (!this.useCostreportCls) {

            // 本機能は、プレミアムコースのみご利用になれます。
            this.eAlert.message('110016', ['プレミアムコース'], null, undefined);
        }
    }

    /**
     * 証憑から会計伝票を起票する
     * 体験期間あり
     */
    public evidenceUsedFlgClick(): void {

        // 証憑から会計伝票を起票する
        if (!this.useEvidenceUsedFlg) {

            // 本機能は、スタンダード以上のコースのみご利用になれます。
            this.eAlert.message('110016', ['スタンダード以上のコース'], null, undefined);
        }
    }

    /**
     * タイムスタンプを押す
     */
    public timestampUsedFlgClick(): void {

        // タイムスタンプを押す
        if (this.selectItem.evidenceUsedFlg && !this.useTimestampUsedFlg) {

            // 本機能は、プレミアムコースのみご利用になれます。
            this.eAlert.message('110016', ['プレミアムコース'], null, undefined);
        }
    }

    /**
     * Moneytree連携
     * 体験期間あり
     */
    public moneytreeUsedFlgClick(): void {

        // Moneytree連携
        if (!this.useMoneytreeUsedFlg) {

           // 本機能は、スタンダード以上のコースのみご利用になれます。
           this.eAlert.message('110016', ['スタンダード以上のコース'], null, undefined);
        }
    }

    /**
     * 自動仕訳
     * 体験期間あり
     */
    public autojournalUsedFlgClick(): void {

        // Moneytree連携
        if (!this.useAutojournalUsedFlg) {

            // 本機能は、スタンダード以上のコースのみご利用になれます。
            this.eAlert.message('110016', ['スタンダード以上のコース'], null, undefined);
        }
    }

    /**
     * 自動仕訳不合格判定率の変更イベント
     */
    public sortingFailRateChange(): void {

        // 自動仕訳不合格判定率に変更があった場合 （初期設定でイベントが発火するため）
        if (this.selectItem.sortingFailRate !== this.tmpItem.sortingFailRate) {
            // ご利用形態情報入力Form変更イベント
            this.setDirtyFlag();
        }
    }

    /**
     * 自動仕訳自動判定率の変更イベント
     */
    public sortingSuccessRateChange(): void {

        // 自動仕訳自動判定率に変更があった場合 （初期設定でイベントが発火するため）
        if (this.selectItem.sortingSuccessRate !== this.tmpItem.sortingSuccessRate) {
            // ご利用形態情報入力Form変更イベント
            this.setDirtyFlag();
        }
    }

    /**
     * 取消ボタンの押下処理
     */
    public cancelBtnClick(): void {

        // 変更を取り消す
        this.selectItem = Object.assign({}, this.tmpItem);
        this.isDirty = false;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 更新ボタンの押下処理
     */
    public updateBtnClick(): void {

        // 必須項目のチェック
        if (this.selectItem.autojournalUsedFlg) {
            // 自動仕訳不合格判定率
            if (this.selectItem.sortingFailRate === undefined || this.selectItem.sortingFailRate === null) {
                // "自動仕訳不合格判定率"は入力必須の項目です。
                this.eAlert.message('210001', ['自動仕訳不合格判定率'], 'sortingFailRate');
                return;
            }
            // 自動仕訳自動判定率
            else if (this.selectItem.sortingSuccessRate === undefined || this.selectItem.sortingSuccessRate === null) {
                // "自動仕訳自動判定率"は入力必須の項目です。
                this.eAlert.message('210001', ['自動仕訳自動判定率'], 'sortingSuccessRate');
                return;
            }

            // 自動仕訳不合格判定率 => 0 ～ 自動仕訳自動判定率
            if (this.selectItem.sortingFailRate > this.selectItem.sortingSuccessRate) {
                // "自動仕訳不合格判定率"には'0'以上、'自動仕訳自動判定率'以下で入力してください。
                this.eAlert.message('210013', ['自動仕訳不合格判定率', '0', '自動仕訳自動判定率'], 'sortingFailRate');
                return;
            }
        }

        // 更新します。よろしいですか？
        this.eAlert.message('120023', [], null, () => {

            // リクエストを生成
            var reqDto: AC011ReqDto = new AC011ReqDto();
            reqDto.updateDto = new AC011BusinessUpdateDto();

            // 部門ごとに損益を管理する TODO
            reqDto.updateDto.segmentCls = this.selectItem.segmentCls;
            // 帳票タイトル
            reqDto.updateDto.segmentTitle = this.selectItem.segmentTitle;
            // 製造原価報告書を作成する
            reqDto.updateDto.costreportCls = this.selectItem.costreportCls;
            // 証憑から会計伝票を起票する
            reqDto.updateDto.evidenceUsedFlg = this.selectItem.evidenceUsedFlg;
            // タイムスタンプを押す
            reqDto.updateDto.timestampUsedFlg = this.selectItem.timestampUsedFlg;
            // MoneyTree連携
            reqDto.updateDto.moneytreeUsedFlg = this.selectItem.moneytreeUsedFlg;
            // 自動的に仕訳候補を提案する
            reqDto.updateDto.autojournalUsedFlg = this.selectItem.autojournalUsedFlg;
            // 自動仕訳不合格判定率
            reqDto.updateDto.sortingFailRate = this.selectItem.sortingFailRate;
            // 自動仕訳自動判定率
            reqDto.updateDto.sortingSuccessRate = this.selectItem.sortingSuccessRate;
            // 更新日 事業者
            reqDto.updateDto.businessUpdatedAt = this.selectItem.businessUpdatedAt;
            // 更新日 会計年度
            reqDto.updateDto.fisicalYearUpdatedAt = this.selectItem.fisicalYearUpdatedAt;

            // 更新処理を実行
            this.ac011Service.update(reqDto, this.updateOnResult);
        });
    }

    /**
     * ショートカットボタンの制御を行う
     */
    private updateShortcutButtonStatus(): void {

        // 通常モード / 変更有無
        var mode: string = this.isDirty ? 'update-dirty' : 'update';

        // ショートカットの制御を行う
        this.setShortcutBtnDefs(mode);
    }

    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     * @param resDto
     */
    private getInitialOnResult(resDto: AC011ResDto): void {

        // 入力内容を表示する
        this.selectItem = resDto.businessDto;
        this.tmpItem = Object.assign({}, resDto.businessDto);

        // 使用可能フラグを設定する
        // 部門管理　プレミアム / 体験期間無し
        this.useSegmentCls = this.selectItem.usedCourseCls === 2;
        // 製造原価管理　プレミアム / 体験期間無し
        this.useCostreportCls = this.selectItem.usedCourseCls === 2;
        // 証憑から会計伝票を起票する スタンダード / 体験期間あり
        this.useEvidenceUsedFlg = this.selectItem.usedCourseCls > 0 || this.selectItem.isTrialPeriod;
        // タイムスタンプを押す　プレミアム / 体験期間無し
        this.useTimestampUsedFlg = this.selectItem.usedCourseCls === 2;
        // Moneytree連携　スタンダード / 体験期間あり
        this.useMoneytreeUsedFlg = this.selectItem.usedCourseCls > 0 || this.selectItem.isTrialPeriod;
        // 自動仕訳 スタンダード / 体験期間あり
        this.useAutojournalUsedFlg = this.selectItem.usedCourseCls > 0 || this.selectItem.isTrialPeriod;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 更新処理 完了
     * @param resDto
     */
    private updateOnResult(resDto: AC011ResDto): void {

        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        // クライアント保有情報を更新
        if (resDto.ownershipDto) {
            this.property.ownershipDto = resDto.ownershipDto;
        }

        if (resDto.businessDto) {
            this.property.businessDto = resDto.businessDto;
        }

        // 入力内容を表示する
        this.selectItem = resDto.businessDto;
        this.tmpItem = Object.assign({}, resDto.businessDto);

        // 変更の取消
        this.isDirty = false;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }
}
