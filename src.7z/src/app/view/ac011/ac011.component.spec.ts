import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac011Component } from './ac011.component';

describe('Ac011Component', () => {
  let component: Ac011Component;
  let fixture: ComponentFixture<Ac011Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac011Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac011Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
