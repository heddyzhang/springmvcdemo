import { Component, OnInit, ViewChild } from '@angular/core';
import { AC002Service } from '../../service/AC002Service';
import { AC002ResDto } from '../../dto/ac002/AC002ResDto';
import { Router } from '@angular/router';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { ComponentBase, AppType } from '../component-base';
import { AC002ReqDto } from '../../dto/ac002/AC002ReqDto';
import { EDateFieldComponent } from '../../component/e-date-field/e-date-field.component';
import { AC002BusinessDto } from '../../dto/ac002/AC002BusinessDto';
import { AC002ConsumptionTaxDto } from '../../dto/ac002/AC002ConsumptionTaxDto';
import { AC002SetupTourStsDto } from '../../dto/ac002/AC002SetupTourStsDto';
import { ETextInputComponent } from '../../component/e-text-input/e-text-input.component';
import { AC002UpdateBusinessDto } from '../../dto/ac002/AC002UpdateBusinessDto';
import { AC002UpdateConsumptionTaxDto } from '../../dto/ac002/AC002UpdateConsumptionTaxDto';
import { WjPopup, WjComboBox } from 'wijmo/wijmo.angular2.input';
import { AC002UpdateSetupTourStsDto } from '../../dto/ac002/AC002UpdateSetupTourStsDto';
import { EDropDownListModule } from '../../component/e-drop-down-list/e-drop-down-list.component';
import { AC002ViewChangeBean } from '../../bean/AC002ViewChangeBean';

@Component({
    selector: 'app-ac002',
    templateUrl: './ac002.component.html',
    styleUrls: ['./ac002.component.css']
})
/**
 * AC002
 * セットアップツアー
 */
export class Ac002Component extends ComponentBase {

    /** アプリケーションIDを設定 */
    private appID: string = 'ac002';

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.H_InitAll;

    // 画面右部の領域の表示制御 true:表示 false:非表示
    public isViewCard1: boolean = false;
    public isViewCard2: boolean = false;
    public isViewCard3: boolean = false;
    public isViewCard4: boolean = false;
    public isViewCard5: boolean = false;

    /** 表示用 事業者情報の登録Dto */
    public businessDto: AC002BusinessDto = new AC002BusinessDto();

    /** 表示用 消費税の設定DTO */
    public consumptionTaxDto: AC002ConsumptionTaxDto = new AC002ConsumptionTaxDto();

    /** 表示用 セットアップツアー状態DTO */
    public setupTourStsDto: AC002SetupTourStsDto = new AC002SetupTourStsDto();

    /** 期末（表示用） */
    public toDateDisp: string = "";

    /** 会計期間（表示用） */
    public fisicalPeriodDisp: string = "";

    /** 年度表示　活性フラグ true:活性 false:非活性 */
    public settlementDispyearFlg: boolean = false;
    /** 年度表示 : 0 のラベル */
    public settlementDispyearLabel0: string = '';
    /** 年度表示 : 1 のラベル */
    public settlementDispyearLabel1: string = '';

    /** 月度表示　活性フラグ true:活性 false:非活性 */
    public settlementDispmonthFlg: boolean = false;
    /** 月度表示 : 0 のラベル */
    public settlementDispmonthLabel0: string = '';
    /** 月度表示 : 1 のラベル */
    public settlementDispmonthLabel1: string = '';

    /** 今年 */
    public currentYear: number = 　2015;

    /** 勘定科目体系ドロップダウン */
    public businessAccountClsMList: any[] = [
        { value: 1, label: "個人拡大" },
        { value: 3, label: "法人" },
    ];

    /** MT連携Popup  */
    @ViewChild('mtAlert1')
    mtAlert1: WjPopup;

    /** MTロックPopup  */
    @ViewChild('lockPopup')
    lockPopup: WjPopup;

    @ViewChild('fisicalYearFromDate')
    dateInput: EDateFieldComponent;

    @ViewChild('businessAccountCls')
    acTitleInput: WjComboBox;

    /** サービス名 */
    constructor(
        private ac002Service: AC002Service,
        private property: EcoKaikeiProperty,
        private router: Router, ) {

        super(ac002Service, property);
    }

    /**
     * 初期処理
     */
    ecoOnInit() {

        // ショートカットを表示
        super.displayShortCutBtn(10);

        // ショートカットボタンの名称を変える
        this.viewBaseButton0.value = 'tour完了';
        this.shortCutRefresh();

        // セットアップツアー中のフラグをONにする
        this.property.isDuringSetupTour = true;

        // 画面遷移パラメータを取得
        var bean: AC002ViewChangeBean = this.property.getViewChangeBeans(this.appID) as AC002ViewChangeBean;
        if (bean) {
            this.property.clearViewChangeBeans();

            // 3．データ連携 からの戻り
            if (bean.selectedView === 3) {
                // 右部に「3.データ連携」表示
                this.isViewCard3 = true;
            }
            // 4．補助科目及び開始残高の登録 からの戻り
            else if (bean.selectedView === 4) {
                // 右部に「4.開始残高及び補助科目の登録」表示
                this.isViewCard4 = true;
            }
            // 5．取引先を管理する からの戻り
            else if (bean.selectedView === 5) {
                // 右部に「5．取引先を管理する」表示
                this.isViewCard5 = true;
            }
        }
        else {
            // 事業者登録を表示
            this.isViewCard1 = true;
        }

        // 初期情報を取得
        this.ac002Service.getInitial(new AC002ReqDto(), this.getInitialOnResult);
    }

    //=============================
    // 1.画面左部のイベント
    //=============================
    /**
     * １番目のパネルのクリックイベント
     */
    public section1Click(): void {
        // 右リセット
        this.iniViewCard();
        // 右部に「１.事業者情報の登録」表示
        this.isViewCard1 = true;
    }

    /**
     * 2番目のパネルのクリックイベント
     */
    public section2Click(): void {
        if (this.setupTourStsDto.setupTour11Sts !== 0) {
            // セットアップツアーが0以外（環境の作成完了後からしか切り替えを行わない）
            // 右リセット
            this.iniViewCard();
            // 右部に「2.消費税の設定」表示
            this.isViewCard2 = true;
        }
    }

    /**
     * データ連携
     */
    public section3Click(): void {
        if (this.setupTourStsDto.setupTour11Sts !== 0) {

            // 3のフラグを設定
            if (!this.setupTourStsDto.setupTour32StsFlg) {
                this.setupTourStsDto.setupTour32StsFlg = true;
                this.setupStsChange();
            }
            else {
                this.changeSetUpTourEnd();
            }
            // セットアップツアーが0以外（環境の作成完了後からしか切り替えを行わない）
            // 右リセット
            this.iniViewCard();
            // 右部に「3.データ連携」表示
            this.isViewCard3 = true;
        }
    }

    /**
     * 補助科目及び開始残高の登録
     */
    public section4Click(): void {
        if (this.setupTourStsDto.setupTour11Sts !== 0) {
            // 4のフラグを設定
            if (!this.setupTourStsDto.setupTour41StsFlg) {
                this.setupTourStsDto.setupTour41StsFlg = true;
                this.setupStsChange();
            }
            else {
                this.changeSetUpTourEnd();
            }

            // セットアップツアーが0以外（環境の作成完了後からしか切り替えを行わない）
            // 右リセット
            this.iniViewCard();
            // 右部に「4.開始残高及び補助科目の登録」表示
            this.isViewCard4 = true;
        }
    }

    /**
     * 取引先を管理する
     */
    public section5Click(): void {
        if (this.setupTourStsDto.setupTour11Sts !== 0) {
            // 5のフラグを設定
            if (!this.setupTourStsDto.setupTour51StsFlg) {
                this.setupTourStsDto.setupTour51StsFlg = true;
                this.setupStsChange();
            }
            else {
                this.changeSetUpTourEnd();
            }

            // セットアップツアーが0以外（環境の作成完了後からしか切り替えを行わない）
            // 右リセット
            this.iniViewCard();
            // 右部に「5.取引先を管理する」表示
            this.isViewCard5 = true;
        }
    }

    /**
     * セットアップツアーの状態チェックボックスクリックイベント
     */
    public setupStsChange(): void {

        // 表示用 項目を更新用DTOに詰め込み
        var reqDto: AC002ReqDto = new AC002ReqDto();
        var updateSetupTourStsDto: AC002UpdateSetupTourStsDto = new AC002UpdateSetupTourStsDto();

        updateSetupTourStsDto.setupTour21StsFlg = this.setupTourStsDto.setupTour21StsFlg;
        updateSetupTourStsDto.setupTour31StsFlg = this.setupTourStsDto.setupTour31StsFlg;
        updateSetupTourStsDto.setupTour32StsFlg = this.setupTourStsDto.setupTour32StsFlg;
        updateSetupTourStsDto.setupTour41StsFlg = this.setupTourStsDto.setupTour41StsFlg;
        updateSetupTourStsDto.setupTour51StsFlg = this.setupTourStsDto.setupTour51StsFlg;

        reqDto.updateSetupTourStsDto = updateSetupTourStsDto;

        // サーバに対し「セットアップツアー状態の更新」処理呼び出し
        this.ac002Service.updateSetupTourSts(reqDto, this.updateSetupTourStsOnResult);

    }

    /**
     * 環境全部削除ボタンクリックイベント
     */
    public resetEnvBtnClick(): void {

        // セットアップツアーを最初からやり直します。よろしいですか？
        this.eAlert.message('120025', [], null, () => {

            // サーバに対し「環境全部削除（セットアップツアーのやり直し）」処理呼び出し
            this.ac002Service.resetEnv(new AC002ReqDto(), this.resetEnvOnResult);
        })
    }

    //=============================
    // 1.事業者情報の登録で使うイベント
    //=============================
    /**
     * 勘定科目体系の変更イベント
     */
    public businessAccountClsChange(item: any): void {

        // TODO 変更前にイベントが起こるため対応
        this.businessDto.businessAccountCls = item.value;

        // ラベルを再表示
        this.setLabelItems();
    }

    /**
    * 会計年度（期首）の変更イベント
    */
    public yearFromDateChange(): void {
        this.setLabelItems();
    }

    /**
     * 環境の生成ボタンクリックイベント
     */
    public createEnvBtnClick(): void {

        // 必須項目のチェック
        // 事業者名称
        if (!this.businessDto.businessName) {
            // "事業者名称"は入力必須の項目です。
            this.eAlert.message('210001', ['事業者名称'], 'businessName');
            return;
        }
        // 事業者略称
        else if (!this.businessDto.businessShortname) {
            // "事業者略称"は入力必須の項目です。
            this.eAlert.message('210001', ['事業者略称'], 'businessShortname');
            return;
        }
        // 代表者名
        else if (!this.businessDto.businessRepName) {
            // "代表者名"は入力必須の項目です。
            this.eAlert.message('210001', ['代表者名'], 'businessRepName');
            return;
        }

        // 入力された情報で環境の作成を行います。\nよろしいですか？
        this.eAlert.message('120026', [], null, () => {

            // 表示用 項目を更新用DTOに詰め込み
            var reqDto: AC002ReqDto = new AC002ReqDto();
            var updateBusinessDto: AC002UpdateBusinessDto = new AC002UpdateBusinessDto();

            // 事業者名称
            updateBusinessDto.businessName = this.businessDto.businessName;
            // 事業者略称
            updateBusinessDto.businessShortname = this.businessDto.businessShortname;
            // 決算期
            updateBusinessDto.settlementYear = this.businessDto.settlementYear;
            // 事業者代表者名称
            updateBusinessDto.businessRepName = this.businessDto.businessRepName;
            // 期初日
            if (this.businessDto.businessAccountCls == 3) {
                updateBusinessDto.fisicalYearFromDate = new Date(this.businessDto.fisicalYearFromDate);
            } else {
                updateBusinessDto.fisicalYearFromDate = new Date(this.currentYear, 0, 1);
            }

            // 年度表示方法
            updateBusinessDto.settlementDispyear = this.businessDto.settlementDispyear;
            // 月度表示方法
            updateBusinessDto.settlementDispmonth = this.businessDto.settlementDispmonth;
            // 採用科目体系区分
            updateBusinessDto.businessAccountCls = this.businessDto.businessAccountCls;

            reqDto.updateBusinessDto = updateBusinessDto;

            // サーバに対し「環境の作成」処理呼び出し
            this.ac002Service.createEnv(reqDto, this.createEnvOnResult)

        });
    }

    //=============================
    // 2.消費税の設定で使うイベント
    //=============================
    /**
     * 検索ボタンの押下処理
     * @param word
     */
    public seachWord(textInput: ETextInputComponent, defWord: string): void {

        // 空欄時は、デフォルト文字を設定
        if (!textInput.value) {
            textInput.value = defWord;
        }
        // 別ウィンドウでgoogle検索を行う
        window.open('https://www.google.co.jp/search?q=' + textInput.value, '_blank');
    }

    /**
     * 検索ボックス
     * @param textInput
     * @param defWord 標準検索ワード
     */
    public seachInputLostFocus(textInput: ETextInputComponent, defWord: string): void {

        // 空欄時は、デフォルト文字を設定
        if (!textInput.value) {
            textInput.value = defWord;
        }
    }

    /**
     * 更新（消費税の設定）ボタンのクリックイベント
     */
    public updateTaxBtnClick(): void {

        // 必須項目のチェック
        // 免税・課税未選択
        if (this.consumptionTaxDto.businessTaxClsMethod === -1) {
            // "消費税区分"を選択してください。
            this.eAlert.message('211006', ['消費税区分'], 'businessTaxClsMethod');
            return;
        }
        // 課税原則 仕入税額控除未選択
        else if (this.consumptionTaxDto.businessTaxClsMethod === 1
            && this.consumptionTaxDto.purchaseTaxDeductionCls === -1) {
            // "仕入税額控除"を選択してください。
            this.eAlert.message('211006', ['仕入税額控除'], 'purchaseTaxDeductionCls');
            return;
        }
        // 課税原則 簡易課税事業区分未選択
        else if (this.consumptionTaxDto.businessTaxClsMethod === 2
            && this.consumptionTaxDto.businessIndustry === -1) {
            // "簡易課税事業区分"を選択してください。
            this.eAlert.message('211006', ['簡易課税事業区分'], 'businessIndustry');
            return;
        }
        // 課税原則 経理方式未選択
        else if ((this.consumptionTaxDto.businessTaxClsMethod === 1 || this.consumptionTaxDto.businessTaxClsMethod === 2)
            && this.consumptionTaxDto.taxAccountingMethod === -1) {
            // "経理方式"を選択してください。
            this.eAlert.message('211006', ['経理方式'], 'taxAccountingMethod');
            return;
        }
        // 課税原則 端数処理未選択
        else if ((this.consumptionTaxDto.businessTaxClsMethod === 1 || this.consumptionTaxDto.businessTaxClsMethod === 2)
            && this.consumptionTaxDto.taxFractionCls === -1) {
            // "端数処理"を選択してください。
            this.eAlert.message('211006', ['端数処理'], 'taxFractionCls');
            return;
        }

        // 更新します。よろしいですか？
        this.eAlert.message('120023', [], null, () => {

            // リクエストを生成
            var reqDto: AC002ReqDto = new AC002ReqDto();
            reqDto.updateConsumptionTaxDto = new AC002UpdateConsumptionTaxDto();

            // 会計年度コード
            //reqDto.updateDto.fisicalYearCd = this.selectedFisicalYearCd;
            // 0: 免税 1: 課税（原則） 2: 課税（簡易）
            reqDto.updateConsumptionTaxDto.businessTaxClsMethod = this.consumptionTaxDto.businessTaxClsMethod;
            // 仕入税額控除 −１：未設定　０：比例配分　１：個別対応
            reqDto.updateConsumptionTaxDto.purchaseTaxDeductionCls = this.consumptionTaxDto.purchaseTaxDeductionCls;
            // 簡易課税業種 -1：未設定 1：第一種事業（卸売業） 2：第二種事業（小売業）・・・
            reqDto.updateConsumptionTaxDto.businessIndustry = this.consumptionTaxDto.businessIndustry;
            // 消費税経理処理方法
            reqDto.updateConsumptionTaxDto.taxAccountingMethod = this.consumptionTaxDto.taxAccountingMethod;
            // 消費税端数処理方法
            reqDto.updateConsumptionTaxDto.taxFractionCls = this.consumptionTaxDto.taxFractionCls;

            // サーバに対し「消費税の設定更新」処理呼び出し
            this.ac002Service.updateTax(reqDto, this.updateTaxOnResult);
        });

    }

    //=============================
    // 3.データ連携で使うイベント
    //=============================
    /**
     * 「Money Treeのページに遷移」ボタンクリック
     */
    public mtCallBtnClick(): void {
        // MT認証ポップアップを呼び出し
        this.mtAlert1.show(true);
    }

    /**
     * MT認証ポップアップのOKボタンクリック
     */
    public mtAlert1OkBtnCkick(): void {
        // サーバに対し「MT コールバックURLの取得」処理呼び出し
        this.ac002Service.getMTLinkAuthData(new AC002ReqDto(), this.getMTLinkAuthDataOnResult);
    }

    //=============================
    // 別画面遷移イベント
    //=============================
    public mtManagerTranBTnClick(): void {

        // 遷移用パラメータを生成する
        var ac002bean: AC002ViewChangeBean = new AC002ViewChangeBean(3);

        // パラメータの設定を行う
        this.property.setViewChangeBeans(ac002bean, this.appID, this.appID);

        // MT管理画面に遷移
        this.router.navigate(['/view/ac090', { param: '1' }]);
    }

    public actitleTranBtnClick(selectedView: number): void {

        // 遷移用パラメータを生成する
        var ac002bean: AC002ViewChangeBean = new AC002ViewChangeBean(selectedView);

        // パラメータの設定を行う
        this.property.setViewChangeBeans(ac002bean, this.appID, this.appID);

        // 勘定科目画面に遷移
        this.router.navigate(['/view/ac030', { param: '1' }]);
    }

    public acBalanceTranBtnClick(): void {

        // 遷移用パラメータを生成する
        var ac002bean: AC002ViewChangeBean = new AC002ViewChangeBean(4);

        // パラメータの設定を行う
        this.property.setViewChangeBeans(ac002bean, this.appID, this.appID);

        // 勘定科目の残高登録に遷移
        this.router.navigate(['/view/ac035', { param: '1' }]);
    }

    public acSubBalanceTranBtnClick(): void {

        // 遷移用パラメータを生成する
        var ac002bean: AC002ViewChangeBean = new AC002ViewChangeBean(4);

        // パラメータの設定を行う
        this.property.setViewChangeBeans(ac002bean, this.appID, this.appID);

        // 補助科目の残高登録に遷移
        this.router.navigate(['/view/ac036', { param: '1' }]);
    }

    public customerTranBtnClick(): void {

        // 遷移用パラメータを生成する
        var ac002bean: AC002ViewChangeBean = new AC002ViewChangeBean(5);

        // パラメータの設定を行う
        this.property.setViewChangeBeans(ac002bean, this.appID, this.appID);

        // 取引先の登録画面に遷移
        this.router.navigate(['/view/ac080', { param: '1' }]);
    }

    public customerBalanceTranBtnClick(): void {

        // 遷移用パラメータを生成する
        var ac002bean: AC002ViewChangeBean = new AC002ViewChangeBean(5);

        // パラメータの設定を行う
        this.property.setViewChangeBeans(ac002bean, this.appID, this.appID);

        // 取引先の残高登録画面に遷移
        this.router.navigate(['/view/ac085', { param: '1' }]);

    }

    //=============================
    // ショートカットイベント
    //=============================
    /**
     * セットアップツアーの終了ボタン クリックイベント
     */
    private setupTourCommit(): void {

        this.ac002Service.endProcessSetupTour(new AC002ReqDto(), this.endProcessSetupTourOnResult);
    }

    //=========================
    // ResultHandler
    //=========================
    /**
     * 初期処理　完了
     * @param resDto
     */
    private getInitialOnResult(resDto: AC002ResDto): void {

        // 今年を取得
        var current: Date = new Date();
        this.currentYear = current.getFullYear();

        // 表示用 事業者情報の登録Dto
        this.businessDto = resDto.businessDto;
        // 表示用 消費税の設定DTO
        this.consumptionTaxDto = resDto.consumptionTaxDto;
        // 表示用 セットアップツアー状態DTO
        this.setupTourStsDto = resDto.setupTourStsDto;
        // 1.事業者情報の登録 ラベル項目を設定する
        this.setLabelItems()
        // セットアップツアー完了ボタンの制御
        this.changeSetUpTourEnd();
    }

    /**
     * 環境の生成 完了
     * @param resDto
     */
    private createEnvOnResult(resDto: AC002ResDto): void {
        // 再度ログインした時と同じ動きをする
        if (resDto.responseCd === -1) {
            // エラー発生
            return;
        }

        this.router.navigate(['refreshSetupTourOnResult']);
    }

    /**
     * 消費税の設定更新 完了
     * @param resDto
     */
    private updateTaxOnResult(resDto: AC002ResDto): void {

        if (resDto.responseCd === -1) {
            // エラー発生
            return;
        }

        // 表示用 消費税の設定DTO
        this.consumptionTaxDto = resDto.consumptionTaxDto;

        //------------------------------------------
        // クライアント保有情報をプロパティに設定
        //------------------------------------------
        this.property.ownershipDto = resDto.ownershipDto;

        // 2のフラグを設定
        if (!this.setupTourStsDto.setupTour21StsFlg) {
            this.setupTourStsDto.setupTour21StsFlg = true;
            this.setupStsChange();
        }
        else {
            this.changeSetUpTourEnd();
        }
    }

    /**
     * 「環境全部削除（セットアップツアーのやり直し）」　完了
     */
    private resetEnvOnResult(): void {
        // 再度ログインした時と同じ動きをする
        this.router.navigate(['refreshSetupTourOnResult']);
    }

    /**
     * セットアップツアーの終了 成功
     * @param resDto
     */
    private endProcessSetupTourOnResult(resDto: AC002ResDto): void {

        //------------------------------------------
        // クライアント保有情報をプロパティに設定
        //------------------------------------------
        this.property.ownershipDto = resDto.ownershipDto;

        // セットアップツアー中のフラグをOFFとする
        this.property.isDuringSetupTour = false;

        // TOPメニューに遷移
        this.router.navigate(['refreshSetupTourOnResult']);
    }

    /**
     * MT コールバックURLの取得 完了
     * @param resDto
     */
    private getMTLinkAuthDataOnResult(resDto: AC002ResDto): void {

        //--------------------------
        // MTLINK連携認証画面を開く
        //--------------------------
        this.openLockWindow(this.lockPopup, this.mtWindowClose, resDto.mtLinkCallbackUrl);
    }

    /**
     * セットアップツアー状態の更新 完了
     * @param resDto
     */
    updateSetupTourStsOnResult(resDto: AC002ResDto): void {
        // セットアップツアー完了ボタンの制御
        this.changeSetUpTourEnd();
    }

    /**
     * MTロックPopupを閉じたときのイベント
     */
    private mtWindowClose(): void {

        // MT遷移済みフラグを設定
        if (!this.setupTourStsDto.setupTour31StsFlg) {
            this.setupTourStsDto.setupTour31StsFlg = true;
            this.setupStsChange();
        }
    }

    /**
     * 画面右の表示リセット 全て非表示
     */
    private iniViewCard(): void {
        this.isViewCard1 = false;
        this.isViewCard2 = false;
        this.isViewCard3 = false;
        this.isViewCard4 = false;
        this.isViewCard5 = false;
    }

    /**
     * 1.事業者情報の登録 ラベル項目を設定する
     */
    private setLabelItems(): void {

        // ラベルを設定
        if (this.businessDto.fisicalYearFromDate && this.businessDto.businessAccountCls === 3) {
            // 勘定科目体系が法人でかつ 期首が設定済の場合
            // 会計期間 期首
            var fromDate: Date = new Date(this.businessDto.fisicalYearFromDate);

            // 1月1日始まりは、年度表示を非活性にし編集不可
            // true → 活性(編集可) false → 非活性(編集不可)
            this.settlementDispyearFlg = fromDate.getMonth() !== 0 || fromDate.getDate() !== 1;

            // 1日始まりは、月度表示を非活性にし編集不可
            // true → 活性(編集可) false → 非活性(編集不可)
            this.settlementDispmonthFlg = fromDate.getDate() !== 1;

            // 期首 次月
            var fromNextDate: Date = new Date(fromDate.getFullYear(), fromDate.getMonth() + 1, fromDate.getDate() - 1);
            // 期末
            var toDate: Date = new Date(fromDate.getFullYear() + 1, fromDate.getMonth(), fromDate.getDate() - 1);
            // 期末を画面表示に編集
            this.toDateDisp = this.dateToString(toDate, 'yyyy年MM月dd日');
            // 会計期間
            this.fisicalPeriodDisp = this.dateToString(fromDate, 'yyyy年MM月dd日') + '～' + this.dateToString(fromNextDate, 'yyyy年MM月dd日');

            // 年度表示ラベル
            if (this.settlementDispyearFlg) {
                // 年度表示が編集可の場合
                // 年度表示ラベル
                // 年度表示 : 0
                this.settlementDispyearLabel0 = this.dateToString(fromDate, 'yyyy年MM月dd日') + 'から' + this.dateToString(toDate, 'yyyy年MM月dd日')
                    + 'の会計期間を「' + this.dateToString(fromDate, 'yyyy') + '年度」と期首の年を表示させる';
                // 年度表示 : 1
                this.settlementDispyearLabel1 = this.dateToString(fromDate, 'yyyy年MM月dd日') + 'から' + this.dateToString(toDate, 'yyyy年MM月dd日')
                    + 'の会計期間を「' + this.dateToString(toDate, 'yyyy') + '年度」と期末の年を表示させる';
            } else {
                // 上記以外
                // 年度表示ラベル
                // 年度表示 : 0
                this.settlementDispyearLabel0 = '-';
                // 年度表示 : 1
                this.settlementDispyearLabel1 = '-';

                // 年度表示を削除する
                this.businessDto.settlementDispyear = null;
            }

            if (this.settlementDispmonthFlg) {
                // 月度表示が編集可の場合
                // 月度表示ラベル
                // 月度表示 : 0
                this.settlementDispmonthLabel0 = this.dateToString(fromDate, 'MM月dd日') + 'から' + this.dateToString(fromNextDate, 'MM月dd日')
                    + 'の会計期間を「' + this.dateToString(fromDate, 'MM') + '月度」と月初の月を表示させる';
                // 月度表示 : 1
                this.settlementDispmonthLabel1 = this.dateToString(fromDate, 'MM月dd日') + 'から' + this.dateToString(fromNextDate, 'MM月dd日')
                    + 'の会計期間を「' + this.dateToString(fromNextDate, 'MM') + '月度」と月末の月を表示させる';

            } else {
                // 月度表示ラベル
                // 月度表示 : 0
                this.settlementDispmonthLabel0 = '-';
                // 月度表示 : 1
                this.settlementDispmonthLabel1 = '-';

                // 月度表示を削除する
                this.businessDto.settlementDispmonth = null;
            }
        } else {
            // 期首が未設定の場合
            // 年度表示を非活性にする
            this.settlementDispyearFlg = false;

            // 月度表示を非活性にする
            this.settlementDispmonthFlg = false;

            // 期末を画面表示に編集
            this.toDateDisp = '-';

            // 年度表示と月度表示を削除する
            this.businessDto.settlementDispyear = null;
            this.businessDto.settlementDispmonth = null;

            // 年度表示ラベル
            // 年度表示 : 0
            this.settlementDispyearLabel0 = '-';
            // 年度表示 : 1
            this.settlementDispyearLabel1 = '-';

            // 月度表示ラベル
            // 月度表示 : 0
            this.settlementDispmonthLabel0 = '-';
            // 月度表示 : 1
            this.settlementDispmonthLabel1 = '-';

            // 会計期間
            this.fisicalPeriodDisp = this.currentYear + '年01月01日' + '～' + this.currentYear + '年12月31日';
        }

    }

    /**
     * セットアップツアー完了ボタンの制御
     */
    private changeSetUpTourEnd(): void {

        if (this.setupTourStsDto.setupTour11Sts === 1
            && this.setupTourStsDto.setupTour21StsFlg
            && this.setupTourStsDto.setupTour32StsFlg
            && this.setupTourStsDto.setupTour41StsFlg
            && this.setupTourStsDto.setupTour51StsFlg) {
            // セットアップツアー1_1状態が1:事業者関係テーブル作成済でかつ
            // セットアップツアー2_1状態, セットアップツアー4_1状態, セットアップツアー5_1状態がtrue(済)
            // かつ (セットアップツアー3_1がtrue（利用する） セットアップツアー3_2が済
            // または セットアップツアー3_1がtrue（利用しない））
            super.enabledShortCutBtn(10, true);

        } else {
            // 上記以外
            super.enabledShortCutBtn(10, false);

        }
    }

    /**
     * ラベル用に日付を変更する
     * @param date
     * @param format
     */
    private dateToString(date: Date, format: string): string {
        return format.replace(/yyyy/, date.getFullYear().toString())
            .replace(/MM/, (date.getMonth() + 1).toString())
            .replace(/dd/, date.getDate().toString());
    }
}



