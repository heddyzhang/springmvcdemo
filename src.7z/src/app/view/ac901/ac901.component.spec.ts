import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac901Component } from './ac901.component';

describe('Ac901Component', () => {
  let component: Ac901Component;
  let fixture: ComponentFixture<Ac901Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac901Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac901Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
