import { Component, OnInit, ViewChild } from '@angular/core';
import { ControlBase } from 'wijmo/wijmo';
import { AC901Service } from '../../service/AC901Service';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { ComponentBase, AppType } from '../component-base';
import { EConfigureReportPopComponent } from '../../component/e-configure-report-pop/e-configure-report-pop.component';
import { AC901ReqDto } from '../../dto/ac901/AC901ReqDto';
import { AC901ResDto } from '../../dto/ac901/AC901ResDto';

/**
 * TODO 消す
 * 
 * eco会計プロジェクトにて試算表の印刷を勉強するためのプログラム
 * よってAC901系のプログラムを全部消す。
 */
@Component({
  selector: 'app-ac901',
  templateUrl: './ac901.component.html',
  styleUrls: ['./ac901.component.css']
})
export class Ac901Component extends ComponentBase {

  /** アプリケーションタイプを設定 */
  protected appType: AppType = AppType.A_All;

  @ViewChild('reportPop')
  private reportPop: EConfigureReportPopComponent;

  public value1: String;

  public value2: String;

  public addValue: String;

  /** サービス名 */
  constructor(private ac901Service: AC901Service, private property: EcoKaikeiProperty) {
    super(ac901Service, property);
  }

  /**
   * 初期処理
   */
  protected ecoOnInit(): void {

    // ショートカットを表示
    super.displayShortCutBtn(8);

    // ショートカット有効
    super.enabledShortCutBtn(8, true);
  }

  /**
   * addボタン click
   */
  public add_click():void {

    var num1:number = Number(this.value1);
    var num2:number = Number(this.value2);

    var reqDto:AC901ReqDto = new AC901ReqDto();
    reqDto.num1 = num1;
    reqDto.num2 = num2;

    this.ac901Service.add(reqDto, this.addOnResult);
  }

  public addOnResult(res:AC901ResDto): void {

    this.addValue = String(res.addNum);
  }

  /**
   * 印刷ショートカット
   */
  public printBtnClick(): void {

    var reqDto: AC901ReqDto = new AC901ReqDto();

    this.reportPop.show(reqDto, () => {
      // 印刷のプレ処理 => 印刷 を行う
      this.ac901Service.onPrint(reqDto, '試算表サンプル');
  });
  }

}
