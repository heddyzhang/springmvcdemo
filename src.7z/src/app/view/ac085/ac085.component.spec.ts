import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac085Component } from './ac085.component';

describe('Ac085Component', () => {
  let component: Ac085Component;
  let fixture: ComponentFixture<Ac085Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac085Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac085Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
