import { Component, ViewChild } from '@angular/core';
import { AC085Service } from '../../service/AC085Service';
import { AC085ReqDto } from '../../dto/ac085/AC085ReqDto';
import { AC085ResDto } from '../../dto/ac085/AC085ResDto';
import { AC085AmountSumDto } from '../../dto/ac085/AC085AmountSumDto';
import { EDropDownListComponent } from '../../component/e-drop-down-list/e-drop-down-list.component';
import { AC085AcTitleDto } from '../../dto/ac085/AC085AcTitleDto';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { GroupRow } from 'wijmo/wijmo.grid';
import { ComponentBase, AppType } from '../component-base';
import { WjFlexGridEx } from '../../component/wj-flex-grid-ex/wj-flex-grid-ex';
import { AC085UpdateAmountSumDto } from '../../dto/ac085/AC085UpdateAmountSumDto';

@Component({
    selector: 'app-ac085',
    templateUrl: './ac085.component.html',
    styleUrls: ['./ac085.component.css']
})
export class Ac085Component extends ComponentBase {

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.D_Master;

    @ViewChild(WjFlexGridEx)
    private flexGrid: WjFlexGridEx;

    @ViewChild(EDropDownListComponent)
    private acTitleDropDown: EDropDownListComponent;

    /** 現在表示中の勘定科目ID */
    private selectedAcTitleId: number;

    /** 一覧内容 */
    public amountSumDtoList: AC085AmountSumDto[];

    /** 一覧内容(取消用) */
    private tmpAmountSumDtoList: AC085AmountSumDto[];

    /** 勘定科目 */
    public acTitleList: AC085AcTitleDto[];

    /** 編集中（未保存の編集データが存在する） */
    private isDirty: boolean = false;

    /** ショートカットボタン（取消・更新・印刷） */
    protected shortcutBtnDefs: any = {
        'reference': [
            { tagNo: 3, enabled: false }, { tagNo: 10, enabled: false },
        ],
        'insert': [
            { tagNo: 3, enabled: false }, { tagNo: 10, enabled: false },
        ],
        'insert-dirty': [
            { tagNo: 3, enabled: true }, { tagNo: 10, enabled: true },
        ],
        'no-print': [
            { tagNo: 8, enabled: false },
        ],
        'print': [
            { tagNo: 8, enabled: true },
        ],
    }

    /** サービス名 */
    constructor(private ac085Service: AC085Service, private property: EcoKaikeiProperty) {
        super(ac085Service, property);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // ショートカットを表示
        super.displayShortCutBtn(3, 10);

        // FlexGridのフッターに合計値を表示
        this.flexGrid.columnFooters.rows.push(new GroupRow());

        // 初期情報を取得
        this.ac085Service.getInitial(new AC085ReqDto(), this.getInitialOnResult);
    }

    /**
     * 一覧へのデータの読み込み時
     */
    public flexGridRefresh(): void {

        // 1件以上データが存在する時
        if (this.amountSumDtoList && this.amountSumDtoList.length > 0) {
            // 部門コードの先頭行にフォーカスをあてる
            this.flexGrid.refresh();
            this.flexGrid.focusCellInput(0, 4);
        }
    }

    /**
     * 勘定科目の変更
     * @param acTitleList
     */
    public acTitleChange(): void {

        // 勘定科目IDの変更がない場合は処理を中断
        if (this.acTitleDropDown.selectedItem
            && this.selectedAcTitleId === this.acTitleDropDown.selectedItem.acTitleId) {
            return;
        }

        // リストを初期化
        this.amountSumDtoList = null;
        this.tmpAmountSumDtoList = null;

        // 選択中の勘定科目IDを保存
        this.selectedAcTitleId = this.acTitleDropDown.selectedItem.acTitleId;
    }

    /**
     * 勘定科目の変更を実行
     * @param acTitleList
     */
    public onClickAcTitleChangeBtn(): void {

        // リクエストを生成
        var reqDto: AC085ReqDto = new AC085ReqDto();

        // 選択中の勘定科目ID
        reqDto.selectedAcTitleId = Number(this.acTitleDropDown.selectedValue);

        // 取消処理を実行
        this.ac085Service.cancel(reqDto, this.cancelOnResult);
    }

    /**
     * 部門内容の編集
     */
    public gridChange(): void {

        if (!this.isDirty) {
            this.isDirty = true;
            // ショートカットボタンの制御を行う
            this.updateShortcutButtonStatus();
        }
    }

    /**
     * Tabキーの押下処理
     */
    public setNextFocus(e: any, item: AC085AmountSumDto): void {

        // 既存のTab移動を止める
        e.preventDefault();

        // 対象行を取得
        var selectedRow: number = this.flexGrid.collectionView.items.findIndex(
            (element) => { return element === item });

        // 表示されていない場合スクロールを行う
        this.flexGrid.focusCellInput(selectedRow + 1, 4);
    }

    /**
     * Shift + Tabキーの押下処理
     */
    public setBeforeFocus(e: any, item: AC085AmountSumDto): void {

        // 既存のTab移動を止める
        e.preventDefault();

        // 対象行を取得
        var selectedRow: number = this.flexGrid.collectionView.items.findIndex(
            (element) => { return element === item });

        // 表示されていない場合スクロールを行う
        this.flexGrid.focusCellInput(selectedRow - 1, 4);
    }

    /**
     * 期首残高のフォーカスアウト
     */
    public lostFocus(): void {

        // 合計金額の再計算を行う
        this.flexGrid.collectionView ? this.flexGrid.collectionView.refresh() : null;
    }

    /**
     * 取消ボタンの押下処理
     */
    public cancelBtnClick(): void {

        // 変更を取り消す
        this.amountSumDtoList = JSON.parse(JSON.stringify(this.tmpAmountSumDtoList));
        this.isDirty = false;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 更新ボタンの押下処理
     * @param grid
     */
    public updateBtnClick(): void {

        // 更新します。よろしいですか？
        this.eAlert.message('120023', [], null, () => {
            // リクエストを生成
            var reqDto: AC085ReqDto = new AC085ReqDto();
            // 表示中のデータを設定する
            reqDto.selectedAcTitleId = this.selectedAcTitleId;
            reqDto.updateAmountSumDtoList = new Array(0);

            for (var i:number = 0; i < this.flexGrid.collectionView.items.length; i++) {

                // 入力情報を取得
                var input: AC085AmountSumDto = this.flexGrid.collectionView.items[i];
                // 更新情報を作成
                var updateItem: AC085UpdateAmountSumDto = new AC085UpdateAmountSumDto();

                // 科目集計コード
                updateItem.acSummaryCd = input.acSummaryCd;
                // 取引先コード
                updateItem.customerId = input.customerId;
                // 勘定科目ID
                updateItem.acTitleId = input.acTitleId;
                // 残高0 : 会計年度の期首残高。
                updateItem.amountSumBa0 = input.amountSumBa0;
                // 更新日
                updateItem.updatedAt = input.updatedAt;

                reqDto.updateAmountSumDtoList.push(updateItem);
            }

            // 更新処理を実行
            this.ac085Service.update(reqDto, this.updateOnResult);
        });
    }

    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     * @param resDto
     */
    private getInitialOnResult(resDto: AC085ResDto): void {

        // 勘定科目の設定
        this.acTitleList = resDto.acTitleDtoList;

        // 選択中の勘定科目IDを保存
        this.selectedAcTitleId = resDto.acTitleDtoList && resDto.acTitleDtoList[0] ?
            resDto.acTitleDtoList[0].acTitleId : -1;

        // 一覧表を作成
        this.amountSumDtoList = resDto.amountSumDtoList;
        this.tmpAmountSumDtoList = JSON.parse(JSON.stringify(this.amountSumDtoList));

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 取消処理 完了
     * @param resDto
     */
    private cancelOnResult(resDto: AC085ResDto): void {

        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        // 一覧表を作成
        this.amountSumDtoList = resDto.amountSumDtoList;
        this.tmpAmountSumDtoList = JSON.parse(JSON.stringify(this.amountSumDtoList));

        // 変更の取消
        this.isDirty = false;

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 更新処理 完了
     * @param resDto
     */
    private updateOnResult(resDto: AC085ResDto): void {

        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        // 一覧表を作成
        this.amountSumDtoList = resDto.amountSumDtoList;
        this.tmpAmountSumDtoList = JSON.parse(JSON.stringify(this.amountSumDtoList));

        // ショートカットボタンの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * ショートカットボタンの制御を行う
     */
    private updateShortcutButtonStatus(): void {

        // ショートカット
        var mode: string;
        var printMode: string;

        // 参照モード
        if (this.isReferenceMode) {
            mode = 'reference';
        }
        // 通常モード
        else {

            // 通常モード / 変更有無
            mode = this.isDirty ? 'insert-dirty' : 'insert';
        }

        // 社員一覧の有無によってショートカットを制御する
        if (!this.amountSumDtoList || this.amountSumDtoList.length === 0) {
            printMode = 'no-print';
        }
        else {
            printMode = 'print';
        }

        // ショートカットの制御を行う
        this.setShortcutBtnDefs(mode, printMode);
    }
}
