import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac910Component } from './ac910.component';

describe('Ac910Component', () => {
  let component: Ac910Component;
  let fixture: ComponentFixture<Ac910Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac910Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac910Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
