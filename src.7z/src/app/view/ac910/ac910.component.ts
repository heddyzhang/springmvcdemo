import { Component, ViewChild } from '@angular/core';
import { ComponentBase, AppType } from '../component-base';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { AC910Service } from '../../service/AC910Service';
import { AC910ReqDto } from '../../dto/ac910/AC910ReqDto';
import { EConfigureReportPopComponent } from '../../component/e-configure-report-pop/e-configure-report-pop.component';
import { EMonthSliderSelectRMonth, EMonthSliderComponent } from '../../component/e-month-slider/e-month-slider.component';
import { Router } from '@angular/router';
import { AC910ViewChangeBean } from '../../bean/AC910ViewChangeBean';
import { AC911ViewChangeBean } from '../../bean/AC911ViewChangeBean';
import { AC912ViewChangeBean } from '../../bean/AC912ViewChangeBean';
import { EPopupItem } from '../../dto/ePopupInput/EPopupItem';
import { AC910SegmentDto } from '../../dto/ac910/AC910SegmentDto';
import { EDropDownListModule, EDropDownListComponent } from '../../component/e-drop-down-list/e-drop-down-list.component';
import { TaxInfoDto } from '../../dto/TaxInfoDto';

@Component({
    selector: 'app-ac910',
    templateUrl: './ac910.component.html',
    styleUrls: ['./ac910.component.css']
})
export class Ac910Component extends ComponentBase {


    /** アプリケーションIDを設定 */
    private appID: string = 'ac910';

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.D_Master;

    @ViewChild('reportPop')
    /** 印刷条件ポップアップ */
    private reportPop: EConfigureReportPopComponent;

    @ViewChild(EMonthSliderComponent)
    /** 月度バー */
    private monthSlider: EMonthSliderComponent;

    private : EDropDownListModule;

    @ViewChild('segList')
    private segList: EDropDownListComponent;

    // 0: 当期 1: 翌期 (=> 最新年度のみ翌期表示)
    public selectedYear: number;

    /** 当期 */
    public selectFisicalYear: number = 0;
    /** 翌期 */
    public selectFisicalNextYear: number = 0;

    /** 部門のリスト */
    public segmentList: AC910SegmentDto[] = Array(0);

    // 翌期を表示するかどうか
    public displayNextYear: boolean = true;

    /** 補助科目を表示する フラグ */
    public showSubTitle: boolean = false;

    // 選択開始月
    private startMonth: number = -1;

    // 選択終了月
    private endMonth: number = -1;

    // 作成対象(0: 損益計算書(pdf) 1: 推移損益計算書(pdf))
    public selectSheet: number = 0;

    /** 単位 (0: 円 1: 千円 2: 百万円) */
    public selectUnit: number = 0;

    /** 事業者の税情報
        税込み処理中: 1: 消費税込（金額 + 消費税） 2: 消費税抜き (金額)
        税抜き処理中: 1: 消費税抜き (金額) 2: なし
        ※会計年度集約.税込税抜集計区分とは異なる
    */
    public acTaxSummary: number = 1;

    /** 決算の扱い (true: 決算を最終月に含める false: 決算を最終月に含めない) */
    public selectSettle: boolean = false;

    /** 部門（全社集計） */
    public selectCompanyTotal: boolean = false;

    /** 部門（全部門別） */
    public selectAllDepartments: boolean = false;

    /** 選択部門 (-1は"指定なし") */
    public segmentId: number = -1;

    /** 事業者の当年度税情報 */
    public currentTaxAccountingMethod: number;

    /** 事業者の翌年度税情報 */
    public nextTaxAccountingMethod: number;

    /** ショートカットボタン */
    protected shortcutBtnDefs:any = {
        'summary-none': [
             {tagNo: 8, enabled: false },
        ],
        'summary': [
             {tagNo: 8, enabled: true },
        ],
    }


    /** コンストラクタ(サービス名) */
    constructor(private ac910Service: AC910Service, private property: EcoKaikeiProperty) {
        super(ac910Service, property);
    }


    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // ショートカットを表示
        super.displayShortCutBtn(8);

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();

        // 最新年度のみ翌年度表示
        this.displayNextYear = this.property.ownershipDto.newFisicalYear;

        // 年度切り替え時の会計年度コードを設定する
        this.selectFisicalYear = this.property.ownershipDto.selectFisicalYear;
        this.selectFisicalNextYear = this.property.ownershipDto.selectFisicalYear + 1;

        // 事業者の税情報
        // 税込み処理中: 1: 消費税込（金額 + 消費税） 2: 消費税抜き (金額)
        // 税抜き処理中: 1: 消費税抜き (金額) 2: なし

        // 当年度
        this.currentTaxAccountingMethod = this.property.ownershipDto.currentTaxInfoDto.taxAccountingMethod;

        // 翌年度
        this.nextTaxAccountingMethod = this.property.ownershipDto.nextTaxInfoDto.taxAccountingMethod;

        //---------------------------
        // 部門のドロップダウンを設定
        //---------------------------
        var sgList: AC910SegmentDto[] = Array(0);
        var dto: AC910SegmentDto = new AC910SegmentDto("指定なし", -1);
        sgList.push(dto);
        for(var i=0; i<this.property.segmentPopupItemList.length; i++) {
            dto = new AC910SegmentDto(this.property.segmentPopupItemList[i].label, this.property.segmentPopupItemList[i].id);
            sgList.push(dto);
        }
        this.segmentList = sgList;

        // 画面遷移パラメータを取得
        var bean:AC910ViewChangeBean = this.property.getViewChangeBeans(this.appID) as AC910ViewChangeBean;

        // メニューからの呼び出し
        if (!bean) {
            // 初期値として当年度を指定
            this.selectedYear = this.property.ownershipDto.selectFisicalYear;
        }
        // 画面遷移時
        else {
            // 選択中の会計年度
            this.selectedYear = bean.selectedYear;
            // 集計開始月
            this.startMonth = bean.startMonth;
            // 集計終了月
            this.endMonth = bean.endMonth;
            // 貸借対照表、損益計算書、製造原価計集計表
            this.selectSheet = bean.selectSheet;
            // 単位
            this.selectUnit = bean.selectUnit;
            // 事業者の税情報
            // 税込み処理中: 1: 消費税込（金額 + 消費税） 2: 消費税抜き (金額)
            // 税抜き処理中: 1: 消費税抜き (金額) 2: なし
            this.acTaxSummary = bean.acTaxSummary;
            // 決算の扱い
            this.selectSettle = bean.selectSettle;
            //部門（全社集計）
            this.selectCompanyTotal = bean.selectCompanyTotal;
            //部門（全部門別）
            this.selectAllDepartments = bean.selectAllDepartments;
            //選択部門 (-1は"指定なし")
            this.segmentId = bean.segmentId;
        }

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 対象年度の変更処理
     */
    public selectFisicalYearChange(): void {

        // 選択を解除
        this.startMonth = -1;
        this.endMonth = -1;

        // 選択月の再設定を行う
        this.monthSlider.selectionClear();

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 選択部門の変更処理
     */
    public selectMenuChange(): void {

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 部門コンボボックスの変更処理
     */
    public segmentIdChange(): void {

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 作成帳票の変更処理
     */
    public selectSheetClsChange(): void {

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 月度バーの選択変更処理
     * @param event 選択中の月
     */
    public monthSliderChange(event: EMonthSliderSelectRMonth): void {

        // 開始月を設定
        this.startMonth = event.fromRMonth;

        // 終了月を設定
        this.endMonth = event.toRMonth;

        // ショートカットの制御を行う
        this.updateShortcutButtonStatus();
    }

    /**
     * 月度バーにデータを設定した際の処理
     */
    public itemsSourceChanged(monthSlider: EMonthSliderComponent): void {

        // データの取得に失敗した際は、処理を中断する
        if (!monthSlider.collectionView) {
            return;
        }

        // 選択を行う
        monthSlider.selectNMonth(this.startMonth, this.endMonth);
    }


   /**
   * 印刷ボタンの押下処理(印刷ショートカット)
   */
  public printBtnClick(): void {

    // リクエストを生成
    var reqDto: AC910ReqDto = new AC910ReqDto();
    // 印刷対象の会計年度
    reqDto.selectedYear = this.selectedYear;
    // 印刷対象 (0、2、4: 集計表 1、3、5: 推移表)
    reqDto.selectSheet = this.selectSheet;
    // 補助科目を表示する フラグ
    reqDto.showSubTitle = this.showSubTitle;
    // 選択開始月
    reqDto.startMonth = this.startMonth;
    // 選択終了月
    reqDto.endMonth = this.endMonth;
    // 単位 (0: 円 1: 千円 2: 百万円)
    reqDto.selectUnit = this.selectUnit;

    // 事業者が税込みを設定している場合: 1: 消費税込（金額 + 消費税） 2: 消費税
    // 事業者が税抜きを設定している場合: 1: 消費税抜（金額） 2: （仮払・仮受）消費税関連
    if ((this.selectedYear === this.selectFisicalYear && this.currentTaxAccountingMethod === 1) ||
        (this.selectedYear === this.selectFisicalNextYear && this.nextTaxAccountingMethod === 1)) {
            reqDto.acTaxSummary = this.acTaxSummary;
        }
        else {
            reqDto.acTaxSummary = 1;
        }

    // 決算の扱い (0: そのまま表示（決算１に含める） 1: 最終月に含める)
    reqDto.selectSettle = this.selectSettle;
    //部門（全社集計）
    reqDto.selectCompanyTotal = this.selectCompanyTotal;
    //部門（全部門別）
    reqDto.selectAllDepartments = this.selectAllDepartments;

    // 全部門別が選択された場合、segmentIdは-1
    if (this.selectAllDepartments) {
        reqDto.segmentId = -1;
    }
    else {
        reqDto.segmentId = this.segmentId;
    }

    // タイトルを設定
    var title: string = (this.selectSheet === 0 || this.selectSheet === 2 || this.selectSheet === 4) ? '集計表' : '推移表';

    this.reportPop.show(reqDto, () => {
        // 印刷のプレ処理 => 印刷 を行う
        this.ac910Service.onPrint(reqDto, title);
    });

}

  /**
     * ショートカットボタンの制御を行う
     */
    private updateShortcutButtonStatus(): void {

        // ショートカット
        var mode:string;

        //----------------------------
        // 部門コンボボックスの選択値
        //----------------------------
        var segmentId: number = -1;
        if(this.segList !== undefined && this.segList.selectedItem !== null) {
            segmentId = (this.segList.selectedItem as AC910SegmentDto).value;
        }

        // 貸借対照表
        if (this.selectSheet === 0 || this.selectSheet === 1) {
            mode = this.startMonth === -1 ? 'summary-none' : 'summary';
        }
        // 損益計算書、製造原価報告書
        else if (this.selectSheet > 1 && this.selectSheet < 6) {
            mode = (this.startMonth >= 0 && (this.selectCompanyTotal === true || this.selectAllDepartments === true || segmentId >= 0)) ? 'summary' : 'summary-none';
        }

        // ショートカットの制御を行う
        this.setShortcutBtnDefs(mode);
    }


    /**
     * チェックボックス(補助科目、決算の扱い(2、3選択時のみ表示)
     */

    public show(): void {
        console.log("チェック:");
        console.log(this.showSubTitle);
        console.log("チェック:");
        console.log(this.selectSettle);
        console.log("チェック");
        console.log(this.selectCompanyTotal);
        console.log("チェック");
        console.log(this.selectAllDepartments);
    }

}



    /**
     * チェックボックスの場合(削除)
     */
    // pl: boolean = false;
    // plPdf: boolean = false;
    // transPl: boolean = false;
    // transPlPdf: boolean = false;

    // public show(): void {
    //     console.log("チェック:");
    //     console.log(this.pl);
    //     console.log("チェック:");
    //     console.log(this.plPdf);
    //     console.log("チェック:");
    //     console.log(this.transPl);
    //     console.log("チェック:");
    //     console.log(this.transPlPdf);
    // }
