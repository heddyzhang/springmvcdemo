import { Component, OnInit, ViewChild, ChangeDetectorRef, ElementRef } from '@angular/core';
import { extend } from 'webdriver-js-extender';
import { ComponentBase, AppType } from '../component-base';
import { AC090Service } from '../../service/AC090Service';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { AC090ReqDto } from '../../dto/ac090/AC090ReqDto';
import { AC090ResDto } from '../../dto/ac090/AC090ResDto';
import { AC090MtAccountsDto } from '../../dto/ac090/AC090MtAccountsDto';
import { AC090SelectMtAccountsDto } from '../../dto/ac090/AC090SelectMtAccountsDto';
import { WjFlexGridEx } from '../../component/wj-flex-grid-ex/wj-flex-grid-ex';
import { WjPopup } from 'wijmo/wijmo.angular2.input';
import { AC090AcTitleDto } from '../../dto/ac090/AC090AcTitleDto';
import { DatePipe } from '@angular/common';
import { AC001ReqDto } from '../../dto/ac001/AC001ReqDto';
import { AC001ResDto } from '../../dto/ac001/AC001ResDto';
import { AC001Service } from '../../service/AC001Service';
import { EAcTitleInputComponent } from '../../component/e-ac-title-popup-input/supportClass/e-ac-title-input/e-ac-title-input.component';
import { CellRangeEventArgs } from 'wijmo/wijmo.grid';
import { GetAcSubTitleListService } from '../../service/GetAcSubTitleListService';
import { ReqDtoBase } from '../../dto/ReqDtoBase';
import { AcSubTitleListDto } from '../../dto/AcSubTitleListDto';

@Component({
    selector: "app-ac090",
    templateUrl: "./ac090.component.html",
    styleUrls: ["./ac090.component.css"]
})
export class Ac090Component extends ComponentBase {
    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.D_Master;

    public mtAccountsList: AC090MtAccountsDto[];

    public subTitleItem: AC090AcTitleDto = new AC090AcTitleDto();

    /** 補助科目設定Popup  */
    @ViewChild("subTitlePopup")
    subTitlePopup: WjPopup;

    @ViewChild("lockPopup")
    lockPopup: WjPopup;

    @ViewChild("aci")
    aci: EAcTitleInputComponent;

    /** MT口座Grid */
    @ViewChild("mtAccountsGrid")
    public mtAccountsGrid: WjFlexGridEx;

    public get isAcTitleDisable(): Boolean {
        if (this.selectMtAccountsDto.institutionAccountNumber != null) {
            return false;
        } else {
            return true;
        }
    }

    public selectMtAccountsDto: AC090SelectMtAccountsDto = new AC090SelectMtAccountsDto();

    /** サービス名 */
    constructor(
        private ac090Service: AC090Service,
        private ac001Service: AC001Service, //後で001との共通化を考える。今は001をそのまま使う
        private getAcSubTitleService: GetAcSubTitleListService,
        private property: EcoKaikeiProperty,
        public datepipe: DatePipe
    ) {
        super(ac090Service, property);
        getAcSubTitleService.hostComponent = this;
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {
        // ショートカットを表示
        super.displayShortCutBtn(1, 2, 3, 10);

        // ショートカットボタンの名称を変える
        this.viewBaseButton1.value = "連携認証";
        this.viewBaseButton1.disabled = false;
        this.viewBaseButton2.value = "連携解除";
        this.viewBaseButton2.disabled = false;
        this.viewBaseButton3.value = "情報更新";
        this.viewBaseButton3.disabled = false;
        this.viewBaseButton0.value = "更新";
        this.viewBaseButton0.disabled = false;
        this.shortCutRefresh();

        this.getGridInfo();
    }

    private getGridInfo(): void {
        // 初期情報を取得する
        var reqDto = new AC090ReqDto();
        reqDto.fisicalYearCd = this.property.ownershipDto.selectFisicalYear;
        this.ac090Service.getInitial(reqDto, this.getInitialOnResult);
    }

    /**
     * 新規補助登録ボタン　クリック
     */
    public inserAcSubTitleBtnClick(): void {
        // 勘定科目が選択されていないときはは何もしない

        this.subTitleItem = new AC090AcTitleDto();
        this.subTitlePopup.show(true);
    }

    /**
     * 補助科目登録ポップアップのOKボタンクリック
     */
    public subTitlePopupOkBtnCkick(): void {
        var reqDto = new AC090ReqDto();
        this.subTitleItem.acTitleId = this.selectMtAccountsDto.acTitleId;
        reqDto.acSubTitleItem = this.subTitleItem;
        this.ac090Service.acSubTitleCommit(reqDto, () => {
            this.aci.selectedId = this.selectMtAccountsDto.acTitleId;
            var reqDtoBase = new ReqDtoBase();
            reqDtoBase.fisicalYearCd = this.property.ownershipDto.selectFisicalYear;
            this.getAcSubTitleService.GetAcSubTitleListService(
                reqDtoBase,
                (rsp: AcSubTitleListDto) => {
                    this.property.acSubTitlePopupItemList = rsp.acSubTileList;
                }
            );
        });
    }

    public linkAuthBtnClick(): void {
        this.ac090Service.getMTLinkAuthData(
            new AC090ReqDto(),
            (resDto: AC001ResDto) => {
                //--------------------------
                // MTLINK連携認証画面を開く
                //--------------------------
                this.openLockWindow(
                    this.lockPopup,
                    this.mtWindowClose,
                    resDto.mtLinkCallbackUrl
                );
            }
        );
    }

    public linkRevokeBtnClick(): void {
        this.eAlert.message("120017", [], null, () => {
            this.ac090Service.revokeMTLink(new AC090ReqDto(), () => {
                this.eAlert.message("100005");
                this.mtAccountsList = null;
                //nullにするとエラーになるので空のオブジェクト入れておく
                this.selectMtAccountsDto = new AC090SelectMtAccountsDto();
            });
        });
    }

    public updateAccountBtnClick(): void {
        //グリッド情報再取得
        this.getGridInfo();
    }

    public updateBtnClick(): void {
        //-------------------------------
        // 連携する場合は必須チェック
        //-------------------------------
        if (this.selectMtAccountsDto.mtCtl === 2) {
            if (this.selectMtAccountsDto.acTitleId === 0) {
                // "勘定科目"は入力必須の項目です。
                this.eAlert.message("210001", ["勘定科目"]);
                return;
            }
            if (this.selectMtAccountsDto.acSubTitleId == 0) {
                // "補助科目"は入力必須の項目です。
                this.eAlert.message("210001", ["補助科目"]);
                return;
            }
        }

        var reqDto: AC090ReqDto = new AC090ReqDto();
        reqDto.ac090MtAccountsItem = this.selectMtAccountsDto;

        this.ac090Service.updateAccount(reqDto, () => {
            //グリッド情報再取得
            this.getGridInfo();
        });
    }

    /**
     * MT口座一覧　選択
     */
    public mtAccountsGridSelectionChanged(): void {
        this.selectMtAccountsDto = Object.assign(
            {},
            this.mtAccountsGrid.selectedItems[0]
        );
        if (this.selectMtAccountsDto.mtExists === 0) {
            this.selectMtAccountsDto = new AC090SelectMtAccountsDto();
        }
    }

    public mtAccountsGridSelectionChanging(arg: CellRangeEventArgs): void {
        if (arg.row != -1) {
            if (this.mtAccountsList[arg.row].mtExists === 0) {
                arg.cancel = true;
            }
        }
    }

    /**
     * 初期処理　完了
     */
    private getInitialOnResult(resDto: AC090ResDto): void {
        resDto.mtAccountsDtoList.forEach((x, index) => {
            resDto.mtAccountsDtoList[
                index
            ].displayMtCtl = this.convertMtLinkState(x);
            resDto.mtAccountsDtoList[
                index
            ].displayLastUpdate = this.convertDisplayLastUpdate(x);
        });

        if (resDto.mtLinkResult != "success") {
            this.mtAccountsList = null;
        } else {
            this.mtAccountsList = resDto.mtAccountsDtoList;
            this.mtAccountsGrid.selectionClear();
        }
        //未選択状態にする
        //nullにするとエラーになるので空のオブジェクト入れておく
        this.selectMtAccountsDto = new AC090SelectMtAccountsDto();
    }

    /**
     * MTのウィンドウが閉じられたとき
     */
    public mtWindowClose(): void {
        // MTのお客様情報をecoDBに登録
        this.ac001Service.permissionState(
            new AC001ReqDto(),
            (resDto: AC001ResDto) => {
                if (!resDto.mtAuth) {
                    //----------------------------------
                    // MTとの連携に失敗した際のメッセージ
                    // →終了
                    //----------------------------------
                    this.eAlert.message("110014");
                    this.mtAccountsList = null;
                    //nullにするとエラーになるので空のオブジェクト入れておく
                    this.selectMtAccountsDto = new AC090SelectMtAccountsDto();
                } else {
                    //グリッド情報再取得
                    this.getGridInfo();
                }
            }
        );
    }

    private convertMtLinkState(item: AC090MtAccountsDto): string {
        //MTから削除されていたら削除
        if (item.mtExists === 0) {
            return "削除済";
        }

        //------------------------------------------------
        // JPYで銀行orクレジットカードの場合以外は連携不可
        //------------------------------------------------
        if (
            item.currency == "JPY" &&
            (item.accountType == "bank" || item.accountType == "credit_card")
        ) {
            if (item.mtCtl == 2) {
                return "する";
            } else {
                return "しない";
            }
        } else {
            return "不可";
        }
    }

    private convertDisplayLastUpdate(item: AC090MtAccountsDto): string {
        let mtLastUpdatedAt = this.datepipe.transform(
            item.mtLastUpdatedAt,
            "yyyy/MM/dd"
        );
        let mtRetrydateAt = this.datepipe.transform(
            item.mtRetrydateAt,
            "yyyy/MM/dd"
        );
        var ret = mtLastUpdatedAt;
        if (mtLastUpdatedAt !== null) {
            ret + " / " + mtRetrydateAt;
        }

        return ret;
    }
}
