import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac090Component } from './ac090.component';

describe('Ac090Component', () => {
  let component: Ac090Component;
  let fixture: ComponentFixture<Ac090Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac090Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac090Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
