import { Component, OnInit, ViewChild } from '@angular/core';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { OwnershipDto } from '../../dto/OwnershipDto';
import { getAppInitializer } from '@angular/router/src/router_module';
import { AC001Service } from '../../service/AC001Service';
import { AC001ReqDto } from '../../dto/ac001/AC001ReqDto';
import { AC001ResDto } from '../../dto/ac001/AC001ResDto';
import { AC001YearInfoDto } from '../../dto/ac001/AC001YearInfoDto';
import { EDropDownListComponent } from '../../component/e-drop-down-list/e-drop-down-list.component';
import { Router } from '@angular/router';
import { EMonthSliderSelectRMonth } from '../../component/e-month-slider/e-month-slider.component';
import { ViewBaseComponent } from '../../component/view-base/view-base.component';
import { ComponentBase, AppType } from '../component-base';
import { CommonComponentResDto } from '../../dto/commonComponent/CommonComponentResDto';
import { ProgressDto } from '../../dto/commonComponent/ProgressDto';
import { WjPopup } from 'wijmo/wijmo.angular2.input';
import { PopupTrigger } from 'wijmo/wijmo.input';
import { AC901ResDto } from '../../dto/ac901/AC901ResDto';

@Component({
    selector: 'app-ac001',
    templateUrl: './ac001.component.html',
    styleUrls: ['./ac001.component.css']
})
export class Ac001Component extends ComponentBase {

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.H_InitAll;

    _ownershipDto: OwnershipDto = new OwnershipDto();

    _yearInfoDtoList: AC001YearInfoDto[];

    _selectFisicalYearCd: number;

    _monthSliderFYCd: number;

    customerId: number = -1;

    progressCount: string = "";

    @ViewChild('mtAlert1')
    mtAlert1: WjPopup;

    @ViewChild('mtAlert2')
    mtAlert2: WjPopup;

    @ViewChild('lockPopup')
    lockPopup: WjPopup;

    constructor(
        private property: EcoKaikeiProperty,
        private router: Router,
        private ac001Service: AC001Service
    ) {

        super(ac001Service, property);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {
        // TODO 画面にクライアント保有情報を表示
        this._ownershipDto = this.property.ownershipDto;

        // 初期情報を取得
        this.ac001Service.getInitial(new AC001ReqDto(), this.getInitialOnResult);
    }

    /**
     * 会計年度変更ボタンクリック
     * @param eDropDownList
     */
    public chageFisicalYearBtn_click(eDropDownList: EDropDownListComponent) {

        this.property.ownershipDto.selectFisicalYear = eDropDownList.selectedValue;

        //--------------------------
        // 一時移動
        //--------------------------
        this.router.navigate(['changeFisicalYear']);
    }

    /**
     * MT認証ポップアップのOKボタンクリック
     */
    public mtAlert1OkBtnCkick(): void {
        this.ac001Service.getMTLinkAuthData(new AC001ReqDto(), this.getMTLinkAuthDataOnResult);
    }

    /**
     * MT認証失敗ポップアップのOKボタンクリック
     */
    public mtAlert2OkBtnCkick(): void {
        return;
    }

    //------------------
    // テスト
    //------------------

    /**
     * 証憑分類ボタン
     */
    public voucherBTN_click(): void {

        this.ac001Service.getNextUrl(new AC001ReqDto(), this.getNextUrlOnResult);
    }

    public monthSliderChage(rMonth: EMonthSliderSelectRMonth) {

        return;
    }

    /**
     * MTのウィンドウが閉じられたとき
     */
    public mtWindowClose(): void {

        // MTのお客様情報をecoDBに登録
        this.ac001Service.permissionState(new AC001ReqDto(), this.permissionStateOnResult);
    }

    //--------------------------
    // resultHandler
    //--------------------------

    /**
     * 初期情報を取得 成功
     * @param resDto
     */
    private getInitialOnResult(resDto: AC001ResDto) {

        this._yearInfoDtoList = resDto.initialDto.yearInfoDtoList;

        this._selectFisicalYearCd = this.property.ownershipDto.selectFisicalYear;

        this._monthSliderFYCd = this._selectFisicalYearCd;

        // TODO MTの処理を一旦回避
        // //-----------------------------------------------
        // // トップ画面の表示が初回の場合はMT関連の処理に移行
        // //-----------------------------------------------
        if (this.property.topPageViewCount == 0) {

            this.ac001Service.getMtLinkPermissionState(new AC001ReqDto(), this.getMtLinkPermissionStateOnResult);

            this.property.topPageViewCount++;
        }
    }

    /**
     * MTの連携確認 完了
     */
    private getMtLinkPermissionStateOnResult(resDto: AC001ResDto): void {

        // MTを利用し、認証済み
        if (resDto.mtUse && resDto.mtAuth) {
            //----------------------
            // MTから明細を取得・登録
            //----------------------
            this.getMTJournal();
        }
        // MTを利用し、未認証
        else if (resDto.mtUse && !resDto.mtAuth) {
            //----------------------------
            // MT画面を開くためのメッセージ
            //----------------------------
            this.mtAlert1.show(true);
        }
    }

    /**
     *
     * @param resDto
     */
    private getMTLinkAuthDataOnResult(resDto: AC001ResDto): void {

        //--------------------------
        // MTLINK連携認証画面を開く
        //--------------------------
        this.openLockWindow(this.lockPopup, this.mtWindowClose, resDto.mtLinkCallbackUrl);
    }

    /**
     * MTのお客様情報をecoDBに登録　完了
     * @param resDto
     */
    private permissionStateOnResult(resDto: AC001ResDto): void {

        if (!resDto.mtAuth) {
            //----------------------------------
            // MTとの連携に失敗した際のメッセージ
            // →終了
            //----------------------------------
            this.mtAlert2.show(true);
            return;
        }

        //------------------------------------
        // MTとの連携可の場合は明細を取得する
        //------------------------------------
        this.getMTJournal();
    }

    /**
     * MTから明細を取得する　完了
     * @param resDto
     */
    private getMTJournalOnResult(resDto: AC901ResDto): void {

    }

    /**
     * eco会計からeco不動産への遷移URLの取得　完了
     * @param resDto
     */
    private getNextUrlOnResult(resDto: AC001ResDto): void {

        // 別タブでeco不動産の証憑分類を表示
        this.openLockWindow(this.lockPopup, this.mtWindowClose, resDto.nextUrlDto.url);
    }

    /**
     * MTから明細を取得・登録する
     */
    private getMTJournal(): void {

        this.ac001Service.getMTJournal(new AC001ReqDto(), this.getMTJournalOnResult);
    }
}
