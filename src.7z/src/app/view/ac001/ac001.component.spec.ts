import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac001Component } from './ac001.component';

describe('TopComponent', () => {
  let component: Ac001Component;
  let fixture: ComponentFixture<Ac001Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac001Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac001Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
