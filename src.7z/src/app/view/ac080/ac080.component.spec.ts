import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac080Component } from './ac080.component';

describe('Ac080Component', () => {
  let component: Ac080Component;
  let fixture: ComponentFixture<Ac080Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac080Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac080Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
