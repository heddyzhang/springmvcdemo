import { Component, ViewChild, ViewEncapsulation } from "@angular/core";
import { DataMap } from "wijmo/wijmo.grid";
import { WjInputMask } from "wijmo/wijmo.angular2.input";
import { AC080Service } from "../../service/AC080Service";
import { AC080ReqDto } from "../../dto/ac080/AC080ReqDto";
import { AC080ResDto } from "../../dto/ac080/AC080ResDto";
import { AC080CustomerDto } from "../../dto/ac080/AC080CustomerDto";
import { EcoKaikeiProperty } from "../../eco.kaikei.property";
import { ComponentBase, AppType } from "../component-base";
import { WjFlexGridEx } from "../../component/wj-flex-grid-ex/wj-flex-grid-ex";
import { ETabBarDecoComponent } from "../../component/e-tab-bar-deco/e-tab-bar-deco.component";
import { ResDtoBase } from "../../dto/ResDtoBase";

/** 動作モード */
enum EditorMode {
    M_Insert = "i", // 追加モード
    M_Update = "u" // 更新モード
}

@Component({
    selector: "app-ac080",
    templateUrl: "./ac080.component.html",
    styleUrls: ["./ac080.component.css"]
})
export class Ac080Component extends ComponentBase {
    @ViewChild("customersGrid") customersGrid: WjFlexGridEx;
    @ViewChild("tabBarDeco") tabBarDeco: ETabBarDecoComponent;

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.D_Master;

    /** 動作モード */
    private get editorMode(): EditorMode {
        return this.filteredCustomerDtoList.length > 0
            ? EditorMode.M_Update
            : EditorMode.M_Insert;
    }

    /** 編集中（未保存の編集データが存在する） */
    private isDirty: boolean = false;

    /** ショートカットボタン（追加・削除・取消・更新） */
    protected shortcutBtnDefs = {
        reference: [
            { tagNo: 1, enabled: false },
            { tagNo: 2, enabled: false },
            { tagNo: 3, enabled: false },
            { tagNo: 10, enabled: false }
        ],
        insert: [
            { tagNo: 1, enabled: false },
            { tagNo: 2, enabled: false },
            { tagNo: 3, enabled: false },
            { tagNo: 10, enabled: false }
        ],
        "insert-dirty": [
            { tagNo: 1, enabled: false },
            { tagNo: 2, enabled: false },
            { tagNo: 3, enabled: true },
            { tagNo: 10, enabled: true }
        ],
        update: [
            { tagNo: 1, enabled: true },
            { tagNo: 2, enabled: true },
            { tagNo: 3, enabled: false },
            { tagNo: 10, enabled: false }
        ],
        "update-dirty": [
            { tagNo: 1, enabled: true },
            { tagNo: 2, enabled: true },
            { tagNo: 3, enabled: true },
            { tagNo: 10, enabled: true }
        ]
    };

    /** ショートカットボタン（ラベル印刷・印刷） */
    private shortcutBtnDefsForPrint: any = {
        print: [{ tagNo: 8, enabled: true }, { tagNo: 9, enabled: true }],
        "no-print": [{ tagNo: 8, enabled: false }, { tagNo: 9, enabled: false }]
    };

    /** 取引先一覧に表示するレコードのフィルタリング */
    public customerClsFilterTemplates: any[] = [
        { value: 0, label: "ALL" },
        { value: 1, label: "得意先" },
        { value: 2, label: "仕入先" },
        { value: 3, label: "両方" }
    ];
    private customerClsFilter: number = 0;

    /** 取引先/区分 */
    public customerClsTemplates: any[] = [
        { value: 1, title: "得意先" },
        { value: 2, title: "仕入先" },
        { value: 3, title: "両方" }
    ];
    public customerClsDataMap = new DataMap(
        this.customerClsTemplates,
        "value",
        "title"
    );

    /** 入金/サイト */
    public paymentSightTemplates: any[] = [
        { value: -1, title: "未設定" },
        { value: 1, title: "当月" },
        { value: 2, title: "翌月" },
        { value: 3, title: "翌々月" }
    ];

    /** 入金/営業日調整 */
    public paymentAdjustmentTemplates: any[] = [
        { value: -1, title: "未設定" },
        { value: 1, title: "翌営業日" },
        { value: 2, title: "前営業日" }
    ];

    /** 振込先口座種別 */
    public customerBankClsTemplates: any[] = [
        { value: -1, title: "未設定" },
        { value: 1, title: "普通" },
        { value: 2, title: "当座" },
        { value: 4, title: "貯蓄" },
        { value: 5, title: "その他" }
    ];

    // データベースから取得した取引先一覧
    public customerDtoList: AC080CustomerDto[];

    // 取引先一覧グリッドに表示されている（表示フィルター適用済みの）取引先一覧
    public filteredCustomerDtoList: AC080CustomerDto[] = [];

    // 取引先一覧グリッドで選択されている取引先レコード
    public selectItem: AC080CustomerDto = new AC080CustomerDto();

    constructor(
        private ac080Service: AC080Service,
        private property: EcoKaikeiProperty
    ) {
        super(ac080Service, property);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {
        // ショートカットを表示
        super.displayShortCutBtn(1, 2, 3, 8, 9, 10);

        // 初期情報を取得
        this.ac080Service.getInitial(
            new AC080ReqDto(),
            this.getInitialOnResult
        );

        // 社員一覧にフォーカスを設定する
        document.getElementById("customersGrid").focus();
    }

    /**
     * 取引先一覧グリッドの表示（フィルタリング）と選択状態、編集モードを設定する。
     */
    private updateGrid(): void {
        // e-tab-bar-deco が初期化時に一度 eOnTabClick イベントを発火するのを無視する
        if (!this.customerDtoList) {
            return;
        }

        // e-tab-bar-deco で選択されているフィルターを取得
        this.customerClsFilter = this.tabBarDeco.selectedItem.value;

        console.log("updateGrid: newFilter = " + this.customerClsFilter);

        // フィルターにマッチするレコードのみを抽出する。ALL の場合はすべて抽出。
        this.filteredCustomerDtoList = this.customerDtoList.filter(
            value =>
                this.customerClsFilter === 0 ||
                value.customerCls === this.customerClsFilter
        );

        // カレントレコードの設定
        if (this.editorMode === EditorMode.M_Update) {
            // 取引一覧グリッドに1件以上のいレコードが表示されている場合は先頭レコードを選択
            this.customersGrid.select(0, 0);
        } else {
            // 新しいレコードをカレントに設定
            this.selectItem = new AC080CustomerDto();
        }

        // グリッド初期化時には選択変更イベントが発火しないのでカレントレコードを手動でセットする
        if (this.editorMode === EditorMode.M_Update) {
            // グリッドの先頭レコードのクローンをカレントに設定
            this.selectItem = Object.assign(
                {},
                this.filteredCustomerDtoList[0]
            );
        }

        // 編集中フラグをリセット
        this.isDirty = false;

        // ショートカットボタンの活性／非活性を設定
        this.updateShortcutButtonStatus();
    }

    /**
     * ショートカットボタンの活性／非活性を設定
     */
    private updateShortcutButtonStatus(): void {
        console.log("updateShortcutButtonStatus: ");

        var def_name: string;

        if (this.isReferenceMode) {
            def_name = "reference";
        } else {
            if (this.editorMode === EditorMode.M_Update) {
                def_name = this.isDirty ? "update-dirty" : "update";
            } else {
                def_name = this.isDirty ? "insert-dirty" : "insert";
            }
        }

        // ショートカットボタンの活性化／非活性化
        var button_defs = this.shortcutBtnDefs[def_name];
        button_defs.forEach(def => {
            this.enabledShortCutBtn(def.tagNo, def.enabled);
        });

        // ショートカットボタン（印刷系）の活性化／非活性化
        def_name =
            this.editorMode === EditorMode.M_Update ? "print" : "no-print";
        button_defs = this.shortcutBtnDefsForPrint[def_name];
        button_defs.forEach(def => {
            this.enabledShortCutBtn(def.tagNo, def.enabled);
        });
    }

    /**
     * 編集フォームのデータが変更された
     */
    private setDirtyFlag(n: number): void {
        console.log("setDirtyFlag: n = " + n);

        // 編集中フラグをセット
        if (!this.isDirty) {
            console.log("setDirtyFlag: isDirty = true");
            this.isDirty = true;
            this.updateShortcutButtonStatus();
        }
    }

    /**
     * 取引先一覧グリッドで選択が変更された
     */
    private customersGridSelectionChanged(grid: WjFlexGridEx): void {
        // グリッドで選択されたレコードのクローンを編集フォームに表示
        this.selectItem = Object.assign({}, grid.selectedItems[0]);

        // 編集中フラグをリセット
        this.isDirty = false;

        // ショートカットボタンの活性／非活性を設定
        this.updateShortcutButtonStatus();
    }

    /**
     * 住所検索
     */
    private zipCdBtnClick(): void {
        var req_dto: AC080ReqDto = new AC080ReqDto();
        req_dto.zipCd = this.selectItem.customerZipCd;
        this.ac080Service.getAddress(req_dto, this.getAddressOnResult);
    }

    /**
     * 追加ボタン クリックイベントハンドラー
     */
    private insertBtnClick(): void {
        // 変更モードの場合、取引一覧グリッドの選択状態をクリアー
        if (this.editorMode === EditorMode.M_Update) {
            this.customersGrid.select(-1, -1);
        }

        // 新しいレコードをカレントに設定
        // 編集中フラグをリセット
        // ショートカットボタンの活性／非活性を設定
        this.cancelBtnClick();

        // 管理番号にフォーカスを設定する
        document.getElementById("customerManagementNo").focus();
    }

    /**
     * 削除ボタン クリックイベントハンドラー
     */
    private deleteBtnClick(): void {
        // 確認ダイアログ 選択された情報を削除しますか？
        this.eAlert.message("120021", [], null, () => {
            var req_dto: AC080ReqDto = new AC080ReqDto();
            req_dto.fisicalYearCd = this.property.ownershipDto.selectFisicalYear;
            req_dto.deleteDto = this.selectItem;
            this.ac080Service.delete(req_dto, this.deleteOnResult);
        });
    }

    /**
     * 取消ボタン クリックイベントハンドラー
     */
    private cancelBtnClick(): void {
        if (this.selectItem.customerId) {
            // 既存レコードの編集中だった場合、レコードをもとの状態に復元
            this.selectItem = Object.assign(
                {},
                this.filteredCustomerDtoList.filter(
                    c => c.customerId === this.selectItem.customerId
                )[0]
            );
        } else {
            // 新しいレコードをカレントに設定
            this.selectItem = new AC080CustomerDto();
        }

        // 編集中フラグをリセット
        this.isDirty = false;

        // ショートカットボタンの活性／非活性を設定
        this.updateShortcutButtonStatus();
    }

    /**
     * 印刷ボタン クリックイベントハンドラー
     */
    private printBtnClick(): void {
        //------------------------------------
        // TODO: KAG様にて実装予定
        //------------------------------------
    }

    /**
     * ラベル印刷ボタン クリックイベントハンドラー
     */
    private labelPrintBtnClick(): void {
        //------------------------------------
        // TODO: KAG様にて実装予定
        //------------------------------------
    }

    /**
     * 更新ボタン クリックイベントハンドラー
     */
    private updateBtnClick(): void {
        //--------------------------
        // 必須入力項目チェック
        //--------------------------

        // 管理番号
        if (!this.selectItem.customerManagementNo) {
            // "管理番号"は入力必須の項目です。
            this.eAlert.message("210001", ["管理番号"], "customerManagementNo");
            return;
        }

        // 取引先名称
        if (!this.selectItem.customerName) {
            // "取引先名称"は入力必須の項目です。
            this.eAlert.message("210001", ["取引先名称"], "customerName");
            return;
        }

        // 取引先略称
        if (!this.selectItem.customerShortName) {
            // "取引先略称"は入力必須の項目です。
            this.eAlert.message("210001", ["取引先略称"], "customerShortName");
            return;
        }

        // 取引先検索キー
        if (!this.selectItem.customerKana) {
            // "取引先検索キー"は入力必須の項目です。
            this.eAlert.message("210001", ["取引先検索キー"], "customerKana");
            return;
        }

        // 住所（都道府県 市町村区）
        if (!this.selectItem.customerAddress1) {
            // "住所（都道府県 市町村区）"は入力必須の項目です。
            this.eAlert.message(
                "210001",
                ["住所（都道府県 市町村区）"],
                "customerAddress1"
            );
            return;
        }

        // 住所（番地 マンション）
        if (!this.selectItem.customerAddress2) {
            // "住所（番地 マンション）"は入力必須の項目です。
            this.eAlert.message(
                "210001",
                ["住所（番地 マンション）"],
                "customerAddress2"
            );
            return;
        }

        // 電話番号
        if (!this.selectItem.customerPhoneNo) {
            // "電話番号"は入力必須の項目です。
            this.eAlert.message("210001", ["電話番号"], "customerPhoneNo");
            return;
        }

        //--------------------------
        // API 呼び出し
        //--------------------------

        var req_dto: AC080ReqDto = new AC080ReqDto();
        req_dto.fisicalYearCd = this.property.ownershipDto.selectFisicalYear;

        // パラメーター補正
        // 取引先区分=1:仕入先の場合、支払_締め日、支払_サイト、支払_支払予定日、支払_営業日調整をすべてリセット
        if (this.selectItem.customerCls === 1) {
            this.selectItem.withdrawalCloseDate = 0;
            this.selectItem.withdrawalPayday = 0;
            this.selectItem.withdrawalSight = -1;
            this.selectItem.withdrawalAdjustment = -1;
        }
        // 取引先区分=2:得意先の場合、入金_締め日、入金_サイト、入金_入金予定日、入金_営業日調整をすべてリセット
        else if (this.selectItem.customerCls === 2) {
            this.selectItem.paymentCloseDate = 0;
            this.selectItem.paymentPayday = 0;
            this.selectItem.paymentSight = -1;
            this.selectItem.paymentAdjustment = -1;
        }

        //チェックのみの処理を行う
        // 内部IDが存在すれば更新処理、無ければ新規処理
        if (this.selectItem.customerId == null) {
            // 新規処理
            req_dto.insertDto = this.selectItem;
            this.ac080Service.insert(
                req_dto,
                (resDto: AC080ResDto) => {
                    if (resDto.messageId === null) {
                        // 確認ダイアログ 入力したデータを登録しますか？
                        this.eAlert.message("120022", [], null, () => {
                            // 新規処理
                            req_dto.insertDto = this.selectItem;
                            this.ac080Service.insert(
                                req_dto,
                                this.insertOnResult
                            );
                        });
                    }
                },
                true
            );
        } else {
            // 更新処理
            req_dto.updateDto = this.selectItem;
            this.ac080Service.update(
                req_dto,
                (resDto: AC080ResDto) => {
                    if (resDto.messageId === null) {
                        // 確認ダイアログ 入力したデータを登録しますか？
                        this.eAlert.message("120022", [], null, () => {
                            // 更新処理
                            req_dto.updateDto = this.selectItem;
                            this.ac080Service.update(
                                req_dto,
                                this.updateOnResult
                            );
                        });
                    }
                },
                true
            );
        }
    }

    /**
     * tabKeyDown - コンポーネントでTABキーが押下された
     * @param focusTo 次にフォーカスするコンポーネント
     */
    tabKeyDown(focusTo: WjInputMask): boolean {
        // ターゲットコンポーネントにフォーカスをあてる
        focusTo.focus();

        // false を返すことでTABキーのデフォルト動作をキャンセルする
        return false;
    }

    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     */
    private getInitialOnResult(resDto: AC080ResDto): void {
        // 得意先一覧を保存
        this.customerDtoList = resDto.customerDtoList || [];

        // 取引先一覧グリッドの表示（フィルタリング）と選択状態、編集モードを設定する。
        this.updateGrid();
    }

    /**
     * 住所検索 完了
     * @param resDto
     */
    private getAddressOnResult(resDto: AC080ResDto): void {
        if (this.selectItem != null) {
            this.selectItem.customerAddress1 = resDto.address1;
            this.selectItem.customerAddress2 = resDto.address2;
        }
    }

    /**
     * 登録処理 完了
     * @param resDto
     */
    private insertOnResult(resDto: AC080ResDto): void {
        if (resDto.messageId === "100002") {
            this.getInitialOnResult(resDto);
            this.property.customerPopupItemList = resDto.customerPopupItemList;
        }
    }

    /**
     * 削除処理 完了
     * @param resDto
     */
    private deleteOnResult(resDto: AC080ResDto): void {
        if (resDto.messageId === "100007") {
            this.getInitialOnResult(resDto);
            this.property.customerPopupItemList = resDto.customerPopupItemList;
        }
    }

    /**
     * 更新処理 完了
     * @param resDto
     */
    private updateOnResult(resDto: AC080ResDto): void {
        if (resDto.messageId === "100002") {
            this.getInitialOnResult(resDto);
            this.property.customerPopupItemList = resDto.customerPopupItemList;
        }
    }
}
