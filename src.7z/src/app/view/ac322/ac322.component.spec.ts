import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac322Component } from './ac322.component';

describe('Ac322Component', () => {
  let component: Ac322Component;
  let fixture: ComponentFixture<Ac322Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac322Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac322Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
