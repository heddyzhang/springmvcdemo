import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac360Component } from './ac360.component';

describe('Ac360Component', () => {
  let component: Ac360Component;
  let fixture: ComponentFixture<Ac360Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac360Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac360Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
