import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ac360',
  templateUrl: './ac360.component.html',
  styleUrls: ['./ac360.component.css']
})
export class Ac360Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
