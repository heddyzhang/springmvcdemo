import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac510Component } from './ac510.component';

describe('Ac510Component', () => {
  let component: Ac510Component;
  let fixture: ComponentFixture<Ac510Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac510Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac510Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
