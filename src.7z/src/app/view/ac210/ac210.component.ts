import { Component, ViewChild, ElementRef } from '@angular/core';
import { ComponentBase, AppType } from '../component-base';
import { AC210Service } from '../../service/AC210Service';
import { EcoKaikeiProperty } from '../../eco.kaikei.property';
import { AC210ReqDto } from '../../dto/ac210/AC210ReqDto';
import { AC210ResDto } from '../../dto/ac210/AC210ResDto';
import { AC210VoucherFileDto } from '../../dto/ac210/AC210VoucherFileDto';
import { AC210VoucherSortingDto } from '../../dto/ac210/AC210VoucherSortingDto';
import { WjFlexGridEx } from '../../component/wj-flex-grid-ex/wj-flex-grid-ex';
import { AC210VoucherFileThumbnailDto } from '../../dto/ac210/AC210VoucherFileThumbnailDto';
import { Point } from 'wijmo/wijmo';
import { AC210VoucherFileDeleteDto } from '../../dto/ac210/AC210VoucherFileDeleteDto';
import { AC210VoucherFileInsertDto } from '../../dto/ac210/AC210VoucherFileInsertDto';

@Component({
    selector: 'app-ac210',
    templateUrl: './ac210.component.html',
    styleUrls: ['./ac210.component.css']
})
export class Ac210Component extends ComponentBase {

    /** アプリケーションタイプを設定 */
    protected appType: AppType = AppType.G_Vouchers;

    @ViewChild('fileInput')
    /** 選択用入力欄 */
    private fileInput: ElementRef;

    @ViewChild('voucherFileGrid')
    /** 未分類証憑一覧への参照 */
    private voucherFileGrid: WjFlexGridEx;

    @ViewChild('voucherSortingGrid')
    /** 証憑推論一覧への参照 */
    private voucherSortingGrid: WjFlexGridEx;

    /** 表示用未分類証憑一覧情報 */
    public voucherFileThumbnailList: AC210VoucherFileThumbnailDto[];

    /** 証憑分類マスタ一覧情報 */
    public voucherSortingList: AC210VoucherSortingDto[];

    /** 作業エリアに配置済みのID 証憑ファイルID / 更新日 のみ */
    public setVoucherSortingIds: AC210VoucherFileDto[] = new Array();

    /** 拡大画面に表示中のデータ */
    public voucherFileDto: AC210VoucherFileDto = new AC210VoucherFileDto();

    /** 読み込みエリア ページ数 */
    public pages: number[] = new Array();

    /** 読み込みエリアのスクロール位置 */
    private voucherFileGridScrollPosition: Point;

    /** 読み込みエリアに表示中のページ：再読込用 */
    public loadPage: number = 0;

    /** 取消用未分類証憑一覧情報 */
    private voucherFileList: AC210VoucherFileDto[];

    /** サムネイルからマウスドラッグ中のファイルID */
    private moveId: number;

    /** ショートカットボタン（取消・更新） */
    protected shortcutBtnDefs: any = {
        'reference': [
            { tagNo: 1, enabled: false }, { tagNo: 2, enabled: false }, { tagNo: 3, enabled: false }, { tagNo: 10, enabled: false },
        ],
        'update-none': [
            { tagNo: 1, enabled: true }, { tagNo: 3, enabled: false }, { tagNo: 10, enabled: false },
        ],
        'update': [
            { tagNo: 1, enabled: true }, { tagNo: 3, enabled: true }, { tagNo: 10, enabled: true },
        ],
        'selected': [
            { tagNo: 1, enabled: true }, { tagNo: 2, enabled: true },
        ],
        'selected-none': [
            { tagNo: 1, enabled: true }, { tagNo: 2, enabled: false },
        ],
    }

    /** コンストラクタ */
    constructor(private ac210Service: AC210Service, private property: EcoKaikeiProperty) {
        super(ac210Service, property);

        // UserAgetn を小文字に正規化
        var ua: string = window.navigator.userAgent.toLowerCase();
        // IE かどうか判定
        this.isIE = (ua.indexOf('msie') >= 0 || ua.indexOf('trident') >= 0);
    }

    /**
     * 初期処理
     */
    protected ecoOnInit(): void {

        // ショートカットボタンの名称を変える
        this.viewBaseButton4.value = '再読込';
        this.viewBaseButton4.disabled = false;

        // ショートカットを表示
        super.displayShortCutBtn(1, 2, 3, 4, 10);

        // 初期情報を取得
        this.ac210Service.getInitial(new AC210ReqDto(), this.getInitialOnResult);
    }

    /**
     * 作業エリアにサムネイルをドラッグした際の処理
     * @param event
     */
    public onUploadDragOver(event: DragEvent): void {

        // 参照モード時は処理を中断する
        if (this.isReferenceMode) {
            return;
        }

        // ドラッグ操作を受け入れる
        event.preventDefault();
    }

    /**
     * ファイルドロップ時のイベント
     * @param event イベント
     */
    public onUploadDrop(event: DragEvent): void {

        // 参照モード時は処理を中断する
        if (this.isReferenceMode) {
            return;
        }

        // ドラッグ操作を受け入れる
        event.preventDefault();

        // jpeg画像のみ受け入れる
        if (event.dataTransfer.files.length === 1
            && event.dataTransfer.files[0].type === 'image/jpeg') {

            // 画像の読み込みを行う
            this.loadImage(event.dataTransfer.files[0]);
        }
    }

    /**
     * ファイル選択完了時
     */
    public onChangeFileInput(): void {

        // 選択したファイル
        var files: { [key: string]: File } = this.fileInput.nativeElement.files;

        // 未選択時は処理を中断
        if (!files[0]) {
            return;
        }

        // 画像の読み込みを行う
        this.loadImage(files[0]);
    }

    /**
     * 画像の読み込みを行う
     * @param imgFile
     */
    private loadImage(imgFile: File): void {

        // リクエスト情報を作成
        var req: AC210ReqDto = new AC210ReqDto();
        req.page = this.loadPage;

        // 画像のアップロードをおこなう
        this.ac210Service.uploadFile(req, imgFile, this.uploadFileOnResult);
    }

    /**
     * ページ変更
     */
    public pageChangeClick(page: number): void {

        // ページ情報を保持
        this.loadPage = page;

        // リクエスト情報を作成
        var req: AC210ReqDto = new AC210ReqDto();
        req.page = page;

        // 原本情報を取得
        this.ac210Service.getPage(req, this.getPageOnResult);
    }

    /**
     * 作業エリア 重複画像の選択変更
     */
    public renewClick(id: number): void {

        // リクエスト情報を作成
        var req: AC210ReqDto = new AC210ReqDto();
        req.voucherFileId = id;

        // 原本情報を取得
        this.ac210Service.getVoucherFile(req, this.getVoucherFileOnResult);
    }

    /**
     * 右ボタンの押下処理
     */
    public rightBtnClick(): void {

        // 未選択時は処理を中断する
        if (!this.voucherFileGrid.selectedItems) {
            return;
        }

        // 選択中のデータを取得する
        var selectedItem: AC210VoucherFileDto = this.getSelectedItem();

        // データを取得に失敗した際は処理を中断する
        if (!selectedItem.voucherFileId) {
            return;
        }

        // 作業エリアに登録したIDに追加
        this.setVoucherSortingIds.push(selectedItem);
        this.makeThumbnailList();

        // リクエスト情報を作成
        var req: AC210ReqDto = new AC210ReqDto();
        req.voucherFileId = selectedItem.voucherFileId;

        // 原本情報を取得
        this.ac210Service.getVoucherFile(req, this.getVoucherFileOnResult);
    }

    /**
     * 左ボタンの押下処理
     */
    public leftBtnClick(): void {

        // 作業エリアに配置済みのIDから表示中のIDを削除
        var setVoucherSortingIds: AC210VoucherFileDto[] = new Array();
        this.setVoucherSortingIds.forEach(element => {
            // 表示中以外のものを抜き出す
            if (this.voucherFileDto.voucherFileId !== element.voucherFileId) {
                setVoucherSortingIds.push(element);
            }
        });
        this.setVoucherSortingIds = setVoucherSortingIds;
        this.makeThumbnailList();

        // 作業エリアに配置済みのIDが存在する場合は抜き出す
        if (this.setVoucherSortingIds.length > 0) {
            // リクエスト情報を作成
            var req: AC210ReqDto = new AC210ReqDto();
            req.voucherFileId = this.setVoucherSortingIds[this.setVoucherSortingIds.length - 1].voucherFileId;

            // 原本情報を取得
            this.ac210Service.getVoucherFile(req, this.getVoucherFileOnResult);
        }
        // IDが存在しなくなった際は、作業エリアを初期化
        else {
            this.voucherFileDto = new AC210VoucherFileDto();
        }
    }

    /**
     * サムネイル画像のドラッグ開始
     * @param moveId ドラッグ中のファイルID
     */
    public onDragstart(moveId: number): void {

        // ドラッグ中のファイルIDを保存する
        this.moveId = moveId;
    }

    /**
     * サムネイル画像のドラッグ終了
     */
    public onDragend(): void {

        // ドラッグ中のファイルIDを破棄
        this.moveId = undefined;
    }

    /**
     * 作業エリアにサムネイルをドラッグした際の処理
     * @param event
     */
    public onDragOver(event: DragEvent): void {

        // ドラッグ中のアイテムが、サムネイル情報の場合　受け入れ可能
        if (this.moveId === this.getSelectedItem().voucherFileId) {
            // ドラッグ操作を受け入れる
            event.preventDefault();
        }
    }

    /**
     * ファイルドロップ時のイベント
     * @param event イベント
     */
    public onDrop(event: DragEvent): void {

        // ドロップしたアイテムが、サムネイル情報の場合　受け入れ可能
        if (this.moveId !== this.getSelectedItem().voucherFileId) {
            return;
        }

        // 参照モード時は処理を中断する
        if (this.isReferenceMode) {
            return;
        }

        // ブラウザ標準のドロップ処理を中断
        event.preventDefault();

        // 右ボタンの押下と同じ
        this.rightBtnClick();
    }

    /**
     * 選択中のサムネイル情報を取得する
     */
    private getSelectedItem(): AC210VoucherFileDto {

        // 返却用DTO
        var item: AC210VoucherFileDto = new AC210VoucherFileDto();

        // 選択中のデータを取得する
        var rowItem: AC210VoucherFileThumbnailDto = this.voucherFileGrid.selectedItems[0];

        // 選択中のアイテムがない場合は処理を中断
        if (!rowItem) {
            return item;
        }

        // 選択した列によって情報を取得する
        if (this.voucherFileGrid.selection.col === 0) {
            item.voucherFileId = rowItem.voucherFileId1;
            item.updatedAt = new Date(rowItem.updatedAt1);
        }
        else if (this.voucherFileGrid.selection.col === 1) {
            item.voucherFileId = rowItem.voucherFileId2;
            item.updatedAt = new Date(rowItem.updatedAt2);
        }
        else {
            item.voucherFileId = rowItem.voucherFileId3;
            item.updatedAt = new Date(rowItem.updatedAt3);
        }

        return item;
    }

    /**
     * 読み込みエリアにデータを設定した際の処理
     */
    public gridItemsSourceChanged(): void {

        // スクロール位置が保存されている場合は、再設定する
        if (this.voucherFileGridScrollPosition) {
            this.voucherFileGrid.scrollPosition = this.voucherFileGridScrollPosition;
        }

        // ショートカット制御
        this.updateShortcutButtonStatus();
    }

    /**
     * サムネイル選択の変更イベント
     */
    public gridSelectionChanged(): void {

        // ショートカット制御
        this.updateShortcutButtonStatus();
    }


    /**
     * サムネイル一覧を作成する
     */
    private makeThumbnailList(): void {

        // 一覧情報
        var voucherFileThumbnailList: AC210VoucherFileThumbnailDto[] = new Array();
        var voucherFileThumbnailItem: AC210VoucherFileThumbnailDto = new AC210VoucherFileThumbnailDto();

        this.voucherFileList.filter(this.filterFunction.bind(this)).forEach(element => {

            // item1 / item2 / item3 の設定していない項目に設定
            if (!voucherFileThumbnailItem.voucherFileId1) {
                voucherFileThumbnailItem.fileData1 = element.fileData;
                voucherFileThumbnailItem.voucherFileId1 = element.voucherFileId;
                voucherFileThumbnailItem.updatedAt1 = element.updatedAt;
            } else if (!voucherFileThumbnailItem.voucherFileId2) {
                voucherFileThumbnailItem.fileData2 = element.fileData;
                voucherFileThumbnailItem.voucherFileId2 = element.voucherFileId;
                voucherFileThumbnailItem.updatedAt2 = element.updatedAt;
            } else if (!voucherFileThumbnailItem.voucherFileId3) {
                voucherFileThumbnailItem.fileData3 = element.fileData;
                voucherFileThumbnailItem.voucherFileId3 = element.voucherFileId;
                voucherFileThumbnailItem.updatedAt3 = element.updatedAt;
            }
            // item1 / item2 / item3 全てが設定済みの場合は、次の行に遷移
            else {
                voucherFileThumbnailList.push(voucherFileThumbnailItem);
                voucherFileThumbnailItem = new AC210VoucherFileThumbnailDto();
                voucherFileThumbnailItem.fileData1 = element.fileData;
                voucherFileThumbnailItem.voucherFileId1 = element.voucherFileId;
                voucherFileThumbnailItem.updatedAt1 = element.updatedAt;
            }
        });

        // 1件目が設定済の場合に設定
        if (voucherFileThumbnailItem.voucherFileId1) {
            voucherFileThumbnailList.push(voucherFileThumbnailItem);
        }

        // サムネイルのスクロール位置を保存
        this.voucherFileGridScrollPosition = this.voucherFileGrid.scrollPosition;

        // 一覧を設定
        this.voucherFileThumbnailList = voucherFileThumbnailList;
    }

    /**
     * 勘定・補助科目情報のフィルター
     * @param item
     */
    private filterFunction(item: AC210VoucherFileDto): boolean {

        // 作業エリアに設定したファイルは非表示
        if (!this.setVoucherSortingIds || this.setVoucherSortingIds.length === 0) {
            return true;
        }

        // 作業エリアに設定したファイルは非表示
        return this.setVoucherSortingIds.find(function (id) { return item.voucherFileId === id.voucherFileId }) === undefined;
    }

    //======================
    // ショートカット関連
    //======================
    /**
     *
     */
    public fileUploadBtnClick(): void {

        // ファイル選択画面を表示
        this.fileInput.nativeElement.click();
    }

    /**
     * 削除ボタンの押下処理
     */
    public deleteBtnClick(): void {

        // 確認ダイアログ 選択された情報を削除しますか？
        this.eAlert.message('120021', [], null, () => {
            // リクエスト情報を作成
            var req: AC210ReqDto = new AC210ReqDto();
            req.voucherFileDeleteDto = new AC210VoucherFileDeleteDto();

            // 未選択時は処理を中断する
            if (!this.voucherFileGrid.selectedItems) {
                return;
            }

            // 選択中のデータを取得する
            var selectedItem: AC210VoucherFileDto = this.getSelectedItem();

            // データを取得に失敗した際は処理を中断する
            if (!selectedItem.voucherFileId) {
                return;
            }

            // 証憑ファイルID 更新日時を設定
            req.voucherFileDeleteDto.voucherFileId = selectedItem.voucherFileId;
            req.voucherFileDeleteDto.updatedAt = selectedItem.updatedAt;

            // 最終項目を削除する際は、前ページに遷移
            if (this.voucherFileList.length === 1 && this.loadPage !== 0) {
                this.loadPage -= 1;
            }
            // ページを設定する
            req.page = this.loadPage;

            // 削除を行う
            this.ac210Service.delete(req, this.deleteOnResult);
        });
    }

    /**
     * 取消ボタンの押下処理
     */
    public cancelBtnClick(): void {

        // 作業エリアに配置済みのIDを全削除
        this.setVoucherSortingIds = new Array();
        this.makeThumbnailList();

        // 作業エリアを初期化
        this.voucherFileDto = new AC210VoucherFileDto();

        // ショートカット制御
        this.updateShortcutButtonStatus();
    }

    /**
     * 再読込ボタンの押下処理
     */
    public renewBtnClick(): void {

        // リクエスト情報を作成
        var req: AC210ReqDto = new AC210ReqDto();
        req.page = this.loadPage;

        // 原本情報を取得
        this.ac210Service.getPage(req, this.renewOnResult);
    }

    /**
     * 更新ボタンの押下処理
     */
    public insertBtnClick(): void {

        // 必須項目のチェック
        if (this.setVoucherSortingIds.length === 0) {
            // "証憑"を選択してください。
            this.eAlert.message('211006', ['証憑'], 'voucherFileGrid');
            return;
        }
        // 証憑分類未選択
        else if (this.voucherSortingGrid.selectedItems.length === 0) {
            // "証憑推論"を選択してください。
            this.eAlert.message('211006', ['証憑推論'], 'voucherSortingGrid');
            return;
        }
        // 日付未入力
        else if (!this.voucherFileDto.jsonDate) {
            // "発生日付"は入力必須の項目です。
            this.eAlert.message('210001', ['発生日付'], 'jsonDate');
            return;
        }

        // 入力したデータを登録しますか？
        this.eAlert.message('120022', [], null, () => {

            // リクエスト情報を作成
            var req: AC210ReqDto = new AC210ReqDto();
            req.voucherFileInsertDto = new AC210VoucherFileInsertDto();
            req.voucherFileInsertDto.voucherFileIds = new Array();

            var selectedItem: AC210VoucherSortingDto = this.voucherSortingGrid.selectedItems[0];

            // 証憑分類ID
            req.voucherFileInsertDto.voucherSortingId = selectedItem.voucherSortingId;
            // 発生日付
            req.voucherFileInsertDto.jsonDate = this.voucherFileDto.jsonDate;

            // 証憑ファイルID
            this.setVoucherSortingIds.forEach(element => {
                req.voucherFileInsertDto.voucherFileIds.push(element.voucherFileId);
            });

            // 登録を行う
            this.ac210Service.insert(req, this.insertOnResult);
        });
    }

    /**
     * ショートカットボタンの制御を行う
     */
    private updateShortcutButtonStatus(): void {

        // ショートカット
        var mode: string[] = new Array();

        // 参照モード
        if (this.isReferenceMode) {
            mode.push('reference');
        }
        // 通常モード
        else {
            mode.push(this.setVoucherSortingIds.length === 0 ? 'update-none' : 'update');
            mode.push(this.getSelectedItem().voucherFileId ? 'selected' : 'selected-none');
        }

        // ショートカットの制御を行う
        this.setShortcutBtnDefs(...mode);
    }
    //======================
    // ResultEventHandler
    //======================
    /**
     * 初期処理 完了
     * @param resDto
     */
    private getInitialOnResult(resDto: AC210ResDto): void {

        // 未分類証憑一覧
        this.voucherFileList = resDto.voucherFileDtoList;

        // サムネイル一覧を作成する
        this.makeThumbnailList();

        // サムネイルのページを設定する
        for (var i: number = 0; i < resDto.maxPages; i++) {
            this.pages.push(i);
        }

        // 証憑推論一覧
        this.voucherSortingList = resDto.voucherSortingDtoList;
    }

    /**
     * 画像のアップロードご処理
     * @param resDto
     */
    private uploadFileOnResult(resDto: AC210ResDto): void {

        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        // 未分類証憑一覧
        this.voucherFileList = resDto.voucherFileDtoList;

        // サムネイル一覧を作成する
        this.makeThumbnailList();

        // サムネイルのページを初期化
        this.pages = new Array();
        for (var i: number = 0; i < resDto.maxPages; i++) {
            this.pages.push(i);
        }
    }

    /**
     * 証憑画像取得処理
     * @param resDto
     */
    private getVoucherFileOnResult(resDto: AC210ResDto): void {

        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        // 証憑画像の表示
        this.voucherFileDto = resDto.voucherFileDto;

        // 証憑分類の選択変更を行う
        if (this.voucherFileDto.jsonVoucherSortingId) {
            this.selectGridSortingId(this.voucherFileDto.jsonVoucherSortingId);
        }

        // 証憑画像の拡大・縮小・移動を初期化
        this.clearImg();

        // ショートカットの制御
        this.updateShortcutButtonStatus();
    }

    /**
     * 証憑分類の設定を行う
     */
    private selectGridSortingId(jsonVoucherSortingId: number): void {

        if (!this.voucherSortingGrid.collectionView || !this.voucherSortingGrid.collectionView.items) {
            return;
        }

        for (var i: number = 0; i < this.voucherSortingGrid.collectionView.items.length; i++) {
            if (this.voucherSortingGrid.collectionView.items[i].voucherSortingId === jsonVoucherSortingId) {

                this.voucherSortingGrid.selectionRow(i);
                return;
            }
        }
    }

    /**
     * 作業エリアのページ変更処理
     * @param resDto
     */
    private renewOnResult(resDto: AC210ResDto): void {

        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        // 再読込で指定ページが存在しない場合は、１ページ目を再取得
        if (resDto.voucherFileDtoList.length === 0 && this.loadPage !== 0) {

            // 1ページ目を設定
            this.loadPage = 0;
            this.renewBtnClick();
            return;
        }

        // スクロール位置を初期化
        this.voucherFileGridScrollPosition = undefined;

        // 未分類証憑一覧
        this.voucherFileList = resDto.voucherFileDtoList;

        // サムネイル一覧を作成する
        this.makeThumbnailList();

        // サムネイルのページを初期化
        this.pages = new Array();
        for (var i: number = 0; i < resDto.maxPages; i++) {
            this.pages.push(i);
        }
    }

    /**
     * サムネイルのページ変更処理
     * @param resDto
     */
    private getPageOnResult(resDto: AC210ResDto): void {

        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        // 再読込で指定ページが存在しない場合は、１ページ目を再取得
        if (resDto.voucherFileDtoList.length === 0 && this.loadPage !== 0) {

            // 1ページ目を設定
            this.loadPage = 0;
            this.renewBtnClick();
            return;
        }

        // スクロール位置を初期化
        this.voucherFileGridScrollPosition = undefined;

        // 未分類証憑一覧
        this.voucherFileList = resDto.voucherFileDtoList;

        // サムネイル一覧を作成する
        this.makeThumbnailList();
    }

    /**
     * 削除処理
     * @param resDto
     */
    private deleteOnResult(resDto: AC210ResDto): void {

        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        // 再読込で指定ページが存在しない場合は、１ページ目を再取得
        if (resDto.voucherFileDtoList.length === 0 && this.loadPage !== 0) {

            // 1ページ目を設定
            this.loadPage = 0;
            this.renewBtnClick();
            return;
        }

        // 未分類証憑一覧
        this.voucherFileList = resDto.voucherFileDtoList;

        // サムネイル一覧を作成する
        this.makeThumbnailList();

        // サムネイルのページを初期化
        this.pages = new Array();
        for (var i: number = 0; i < resDto.maxPages; i++) {
            this.pages.push(i);
        }
    }

    /**
     * 登録処理
     * @param resDto
     */
    private insertOnResult(resDto: AC210ResDto): void {

        // エラー発生時は処理を中断
        if (resDto.responseCd === -1) {
            return;
        }

        // 未分類証憑一覧
        this.voucherFileList = resDto.voucherFileDtoList;

        // 読込中のサムネイルページを1ページ目に変更
        this.loadPage = 0;

        // サムネイル一覧を作成する
        this.makeThumbnailList();

        // 作業エリアを初期化
        this.setVoucherSortingIds = new Array();
        this.voucherFileDto = new AC210VoucherFileDto();

        // サムネイルのページを初期化
        this.pages = new Array();
        for (var i: number = 0; i < resDto.maxPages; i++) {
            this.pages.push(i);
        }
    }

    /**
     * 以下TODO
     */
    @ViewChild('img')
    private img: ElementRef;

    @ViewChild('canvas')
    private canvas: ElementRef;

    /** IEかどうか */
    private isIE: boolean;

    /** 画像の拡大率 */
    public zoom: number = 1.0;
    /** 画像の位置 : 左 */
    public left: number = 0;
    /** 画像の位置 : 右 */
    public top: number = 0;

    /** マウス移動開始位置 */
    private mouseDownPoint: Point = new Point();
    /** マウス移動終了位置 */
    private mouseEndPoint: Point = new Point(0, 0);

    /**
     * キャンバスへのマウスホイールの操作時
     * マウスホイールの方向によって、拡大・縮小を行う
     * @param event
     */
    public mousewheel(event: WheelEvent): void {

        // デフォルトのマウスホイールイベントを削除する
        event.preventDefault();

        // 最大 2倍　最小 1/4 倍
        if ((event.wheelDelta > 0 && this.zoom >= 2)
            || (event.wheelDelta < 0 && this.zoom <= 0.25)) {

            return;
        }

        // マウスホイールの方向で、拡大・縮小を行う
        if (event.wheelDelta > 0) {
            this.zoom += 0.05;
        }
        else {
            this.zoom -= 0.05;
        }

        // 画像が範囲外に出ないようにする
        this.moveInRange();
    }

    /**
     * キャンバスへのマウスダウン処理
     * 画像の移動開始処理
     * @param event
     */
    public mousedown(event: MouseEvent): void {

        // デフォルトのイベントを削除
        event.preventDefault();

        // マウス移動開始位置を保存
        this.mouseDownPoint = new Point(event.clientX, event.clientY);
    }

    /**
     * キャンバス内でのマウス移動
     * @param event
     */
    public mousemove(event: MouseEvent): void {

        // 画像移動中ではない場合は、処理を中断する
        if (!this.mouseDownPoint.x || !this.mouseDownPoint.y || !this.img) {
            return;
        }

        // 移動を行う
        this.setPosition(new Point(event.clientX - this.mouseDownPoint.x, event.clientY - this.mouseDownPoint.y));

        // 画像が範囲外に出ないようにする
        this.moveInRange();
    }

    /**
     * キャンバスへのマウスアップ処理
     * @param event
     */
    public mouseup(event: MouseEvent): void {

        // マウス移動開始位置を破棄
        this.mouseDownPoint = new Point();
        // マウス移動終了位置を保存
        this.mouseEndPoint = new Point(this.left, this.top);
    }

    /**
     * キャンバスへのマウスアップ処理
     * @param event
     */
    public mouseleave(event: MouseEvent): void {

        // マウス移動開始位置を破棄
        this.mouseDownPoint = new Point();
        // マウス移動終了位置を保存
        this.mouseEndPoint = new Point(this.left, this.top);
    }

    /**
     * キャンバス内で画像を移動する
     * @param delta
     */
    private setPosition(delta: Point): void {

        // 画像の位置を設定
        if (this.isIE) {
            this.left = delta.x + this.mouseEndPoint.x;
            this.top = delta.y + this.mouseEndPoint.y;
        } else {
            this.left = (delta.x / this.zoom) + this.mouseEndPoint.x;
            this.top = (delta.y / this.zoom) + this.mouseEndPoint.y;
        }
    }

    /**
     * キャンバス外に画像がはみ出ないようにする
     */
    private moveInRange(): void {

        var canvasCenter: Point;
        // キャンバスの中央位置を取得する
        if (this.isIE) {
            canvasCenter = new Point((this.canvas.nativeElement.clientWidth / 2)
                , (this.canvas.nativeElement.clientHeight / 2));
        }
        else {
            canvasCenter = new Point((this.canvas.nativeElement.clientWidth / 2) / this.zoom
                , (this.canvas.nativeElement.clientHeight / 2) / this.zoom);
        }

        // 画像サイズ
        var imgWidth: number = this.img.nativeElement.clientWidth;
        var imgHeight: number = this.img.nativeElement.clientHeight;

        if (this.isIE) {
            imgWidth *= this.zoom;
            imgHeight *= this.zoom;
        }

        // 横方向　中央より右に移動させない
        if (this.left > canvasCenter.x) {
            this.left = canvasCenter.x;
        }
        // 横方向　中央より左に移動させない
        else if (imgWidth + this.left < canvasCenter.x) {
            this.left = canvasCenter.x - imgWidth;
        }

        // 縦方向　中央より下に移動させない
        if (this.top > canvasCenter.y) {
            this.top = canvasCenter.y;
        }
        // 縦方向　中央より上に移動させない
        else if (imgHeight + this.top < canvasCenter.y) {
            this.top = canvasCenter.y - imgHeight;
        }
    }

    /**
     * 画像関連の初期化
     */
    private clearImg(): void {

        // 画像の拡大率
        this.zoom = 1.0;
        // 画像の位置 : 左
        this.left = 0;
        // 画像の位置 : 右
        this.top = 0;

        // マウス移動開始位置
        this.mouseDownPoint = new Point();
        // マウス移動終了位置
        this.mouseEndPoint = new Point(0, 0);
    }
}
