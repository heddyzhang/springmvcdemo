import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ac210Component } from './ac210.component';

describe('Ac210Component', () => {
  let component: Ac210Component;
  let fixture: ComponentFixture<Ac210Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ac210Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ac210Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
