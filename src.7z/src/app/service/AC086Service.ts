import { AC086ReqDto } from '../dto/ac086/AC086ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC086 部門の登録 サービスクラス
 */
export class AC086Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac086';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC086ReqDto, resultFunction: Function): void {

        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
 * 部門取得処理
 * @param reqDto リクエストパラメータ
 * @param resultFunction 正常応答処理
 */
    public getSegment(reqDto: AC086ReqDto, resultFunction: Function): void {

        super.postRequest('/getSegment', reqDto, resultFunction);
    }

    /**
     * 削除処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public delete(reqDto: AC086ReqDto, resultFunction: Function): void {

        super.postRequest('/delete', reqDto, resultFunction);
    }

    /**
     * 更新処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public update(reqDto: AC086ReqDto, resultFunction: Function): void {

        super.postRequest('/update', reqDto, resultFunction);
    }
}
