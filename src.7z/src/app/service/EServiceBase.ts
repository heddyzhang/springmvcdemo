import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

import { ReqDtoBase } from '../dto/ReqDtoBase';
import { ResDtoBase } from '../dto/ResDtoBase';
import { EcoKaikeiProperty } from '../eco.kaikei.property';
import { IComponentBase } from '../view/component-base';
import { ProgressDto } from '../dto/commonComponent/ProgressDto';
import { CommonComponentReqDto } from '../dto/commonComponent/CommonComponentReqDto';
import { CommonComponentResDto } from '../dto/commonComponent/CommonComponentResDto';
import { Router } from '@angular/router';
import { LogoutService } from './logoutServive';
import { IndexService } from './IndexService';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
/**
 * ACXXXServiceの基底クラス
 * 継承先で （必須）serviceUrl と （印刷を使用する場合）printServiceUrl を記載
 *
 * 継承先で、postRequestの呼び出し
 * 　　　　　postPrintRequestの呼び出し
 * 　　　　　longPostRequestの呼び出し
 * 　　　　　　(画面にe-progress-bar 進捗管理テーブルのステータスが終了するまで画面ロック)
 * componentで、printの呼び出しを行う
 */
export class EServiceBase {

    /** AcXXXComponent */
    public hostComponent: IComponentBase;

    /**
     * 継承先で記載
     * サーバー側のクラスの@RequestMapping "/api/acXXX"
     */
    protected serviceUrl: string;

    /**
     * 印刷用 継承先で記載
     * サーバー側のクラスの@RequestMapping "/print/acXXX"
     */
    protected printServiceUrl: string;

    /**
     * 継承先で記載
     * 共通など、セッションタイムアウト管理を行わない場合は、falseにする
     * 例）ac000 CommonComponentService など
     */
    protected sessionCheck: boolean = true;

    /** 印刷のタイトル */
    private printTitle: string;

    /**
     * ポーリング通信用パラメータ
     */
    /** ポーリング通信用サーバー側クラス */
    private commonServiceUrl: string = 'api/commonComponent';
    /** 進捗管理用ID */
    private progressId:number;
    /** 通信時のリクエスト */
    private pollingReqDto:ReqDtoBase;
    /** サーバー側のメソッドに記載した @RequestMappingのvalue */
    private pollingMappingValue:string;
    /** 通信正常応答時のイベント ダイアログ無し / OK / YES */
    private resultFunction: Function;
    /** 通信正常応答時のイベント NO / CANCEL */
    private cancelFunction?: Function;

    /** セッションタイムアウト時間 30min */
    private readonly SESSION_TIME: number = 1800000;

    /** セッション確認時間 25min */
    private readonly REQ_SESSION_TIME: number = 1500000;

    /** セッションチェック時間 */
    private readonly INTERVAL_TIME: number = 30000;

    /** 最終リクエストからの経過時間 生成時に、一定時間経過していることにする　1分 */
    private postSessionTime: number = 60000;

    // コンストラクタで利用するモジュールをインスタンス化
    constructor(private http: HttpClient, private property: EcoKaikeiProperty
        , private logoutService: LogoutService, private indexService:IndexService) {

        this.onResult = this.onResult.bind(this);
        this.onPrintResult = this.onPrintResult.bind(this);
        this.pollingRequest = this.pollingRequest.bind(this);
        this.pollingCheck = this.pollingCheck.bind(this);
        this.onError = this.onError.bind(this);

        // セッション管理を行わない場合
        if (!this.sessionCheck) {
            return;
        }

        // セッションチェック時間毎に設定
        var interval = setInterval(() => {

            // 画面が破棄された場合の処理
            if (!this.hostComponent) {
                // ループを停止
                clearInterval(interval);
                return;
            }

            // 経過時間を更新
            this.postSessionTime += this.INTERVAL_TIME;

            // セッションタイムアウト時間経過した場合は、セッションタイムアウトを表示
            if (this.postSessionTime >= this.SESSION_TIME) {

                // ダイアログを閉じる
                this.hostComponent.eAlert.close();
                // セッションタイムアウト
                this.sessionTimeOutLogout();

                // ループを停止
                clearInterval(interval);
                return;
            }

            // セッション確認時間経過した場合は、セッション確認を行う
            if (this.postSessionTime >= this.REQ_SESSION_TIME && !this.hostComponent.eAlert.isPopShow()) {

                // 一定時間以上、通信がありません。\n入力操作中でしょうか？
                this.hostComponent.eAlert.message('120028', [], null, () => {
                    this.http.post<ResDtoBase>(this.commonServiceUrl + '/sessionCheck', new CommonComponentReqDto(), httpOptions)
                        .subscribe(() => {this.postSessionTime = 0;}, this.onError);
                });
            }
        }, this.INTERVAL_TIME);
    }

    /**
     * 通常のリクエスト
     * @param mappingValue サーバー側のメソッドに記載した @RequestMappingのvalueを設定
     * @param param リクエストパラメーター
     * @param resultFunction 通信完了時のイベント (ダイアログがない場合の通常処理 / OK / YES)
     * @param cancelFunction 通信完了時のイベント (ダイアログがない場合は呼び出されない / CANCEL / NO)
     * @param errorFunction 共通エラーではない場合に記述 基本的には不要
     */
    protected postRequest(mappingValue:string, param:ReqDtoBase, resultFunction:Function, cancelFunction?:Function, errorFunction?:Function): void {

        // ReqDtoBaseの値を設定
        this.reqDtoBaseSetting(param);

        // 完了イベントを設定 (ダイアログがない場合の通常処理 / OK / YES)
        var resultFunction: Function = resultFunction.bind(this.hostComponent);
        // 完了イベントを設定 (ダイアログがない場合は呼び出されない / CANCEL / NO)
        var cancelFunction: Function = cancelFunction !== undefined ? cancelFunction.bind(this.hostComponent) : undefined;
        // エラーイベントを設定
        var errorFunction: Function = errorFunction !== undefined ? errorFunction.bind(this.hostComponent) : undefined;

        // 通信をおこなう 正常応答 => onResult 異常応答 => onError
        this.http.post<ResDtoBase>(this.serviceUrl + mappingValue, param, httpOptions)
            .subscribe((res) => {this.onResult(res, resultFunction, cancelFunction)}
                     , (res) => {this.onError(res, errorFunction)});
    }

    /**
     * ファイルアップ用リクエスト
     * Controller側のRequestParamをreqとfileで取得し、jsonToObjectでDTOにコンバートする。
     *
     * @RequestMapping(value = "/uploadFile", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
     * public ACXXXResDto uploadFile(@RequestParam("req") String reqJson, @RequestParam("file") MultipartFile file) {
     * req = acXXXService.jsonToObject(ACXXXReqDto.class, reqJson);
     * @param mappingValue サーバー側のメソッドに記載した @RequestMappingのvalueを設定
     * @param param リクエストパラメーター
     * @param file 送信ファイル
     * @param resultFunction 通信完了時のイベント (ダイアログがない場合の通常処理 / OK / YES)
     * @param cancelFunction 通信完了時のイベント (ダイアログがない場合は呼び出されない / CANCEL / NO)
     * @param errorFunction 共通エラーではない場合に記述 基本的には不要
     */
    protected postFileRequest(mappingValue:string, param:ReqDtoBase, file: File, resultFunction:Function, cancelFunction?:Function, errorFunction?:Function): void {

        // ReqDtoBaseの値を設定
        this.reqDtoBaseSetting(param);

        // 完了イベントを設定 (ダイアログがない場合の通常処理 / OK / YES)
        var resultFunction: Function = resultFunction.bind(this.hostComponent);
        // 完了イベントを設定 (ダイアログがない場合は呼び出されない / CANCEL / NO)
        var cancelFunction: Function = cancelFunction !== undefined ? cancelFunction.bind(this.hostComponent) : undefined;
        // エラーイベントを設定
        var errorFunction: Function = errorFunction !== undefined ? errorFunction.bind(this.hostComponent) : undefined;

        var formData: FormData = new FormData();
        formData.append("file", file);
        formData.append("req", JSON.stringify(param));

        // 通信をおこなう 正常応答 => onResult 異常応答 => onError
        this.http.post<ResDtoBase>(this.serviceUrl + mappingValue, formData)
            .subscribe((res) => {this.onResult(res, resultFunction, cancelFunction)}
                     , (res) => {this.onError(res, errorFunction)});
    }

    /**
     * 印刷リクエスト
     * @param mappingValue サーバー側のメソッドに記載した @RequestMappingのvalueを設定
     * @param param リクエストパラメーター
     * @param title 印刷のタイトル
     */
    protected postPrintRequest(mappingValue:string, param:ReqDtoBase, title:string): void {

        // ReqDtoBaseの値を設定
        this.reqDtoBaseSetting(param);

        // タイトルを保存
        this.printTitle = title;

        // 通信をおこなう 正常応答 => onPrintResult 異常応答 => onError
        this.http.post<ResDtoBase>(this.serviceUrl + mappingValue, param, httpOptions)
            .subscribe(this.onPrintResult, this.onError);
    }

    /**
     * 長時間かかるリクエスト。
     *
     * @param mappingValue サーバー側のメソッドに記載した @RequestMappingのvalueを設定
     * @param param リクエストパラメーター
     * @param completeCnt DBに保存するための完了値
     * @param resultFunction 通信完了時のイベント (ダイアログがない場合の通常処理 / OK / YES)
     * @param cancelFunction 通信完了時のイベント (ダイアログがない場合は呼び出されない / CANCEL / NO)
     */
    protected longPostRequest(mappingValue:string, param:ReqDtoBase, completeCnt: number
                                , resultFunction:Function, cancelFunction?:Function): void {

        // プログレスバーを表示
        if (this.hostComponent.progressBar !== undefined) {
            this.hostComponent.progressBar.show(true, completeCnt);
        }

        // パラメータを保持
        this.pollingMappingValue = mappingValue;
        this.pollingReqDto = param;

        // ポーリング用のリクエストを生成する
        var reqDto:CommonComponentReqDto = new CommonComponentReqDto();
        reqDto.progressDto = new ProgressDto();
        reqDto.progressDto.completeCnt = completeCnt;

        // 完了イベントを設定 (ダイアログがない場合の通常処理 / OK / YES)
        this.resultFunction = resultFunction.bind(this.hostComponent);
        // 完了イベントを設定 (ダイアログがない場合は呼び出されない / CANCEL / NO)
        this.cancelFunction = cancelFunction !== undefined ? cancelFunction.bind(this.hostComponent) : undefined;

        // ReqDtoBaseの値を設定
        this.reqDtoBaseSetting(reqDto);

        // 進捗管理テーブルへ登録をおこなう 正常応答 => pollingRequest 異常応答 => onError
        this.http.post<ResDtoBase>(this.commonServiceUrl + '/progressInitialize', reqDto, httpOptions)
            .subscribe(this.pollingRequest, this.onError);
    }

    /**
     * 長時間かかるリクエストの事前登録完了時の処理
     * 本通信と確認用のポーリング通信を行う
     *
     * @param res 登録完了時のパラメータ
     */
    private pollingRequest(res:CommonComponentResDto): void {

        // プログレスバー情報を設定
        this.pollingReqDto.progressId = res.progressDto.progressId;
        this.progressId = res.progressDto.progressId;

        // 本通信
        this.http.post(this.serviceUrl + this.pollingMappingValue, this.pollingReqDto, httpOptions).subscribe();

        // ポーリング通信
        this.pollingCheck(res);
    }

    /**
     * プログレスIDをキーに進捗状態を確認する
     * @param value
     * @param resultFunction
     * @param cancelFunction
     * @param errorFunction
     */
    private pollingCheck(res:CommonComponentResDto) {

        // リクエストの経過時間をリセット
        this.postSessionTime = 0;

        // 終了
        if (res.progressDto.progressSts !== null && res.progressDto.progressSts !== 1) {
            // プログレスバーを終了
            if (this.hostComponent.progressBar !== undefined) {
                this.hostComponent.progressBar.close();
            }
            this.onResult(res, this.resultFunction, this.cancelFunction);
            return;
        }

        // プログレスバーを更新
        if (this.hostComponent.progressBar !== undefined && res.progressDto.progressCnt !== undefined) {
            this.hostComponent.progressBar.change(res.progressDto.progressCnt);
        }

        // reqDtoにセット
        var reqDto:CommonComponentReqDto = new CommonComponentReqDto();
        reqDto.progressDto = res.progressDto;

        // ReqDtoBaseの値を設定
        this.reqDtoBaseSetting(reqDto);

        // 15s後にチェックリクエストを投げる　エラー時には、再度ポーリング通信を行う
        setTimeout(() => {
            this.http.post<ResDtoBase>(this.commonServiceUrl + '/progressCheck', reqDto, httpOptions)
                .subscribe(this.pollingCheck, () => {
                    // リクエストを生成する
                    var res:CommonComponentResDto = new CommonComponentResDto();
                    res.progressDto = new ProgressDto();
                    // 進捗管理用IDを再設定する
                    res.progressDto.progressId = this.progressId;
                    // プログレスIDをキーに進捗状態を確認する
                    this.pollingCheck(res);
            });
        }, 15000);
    }

    /**
     * 印刷の実行処理
     * @param title 印刷のタイトル
     * @param publishId 発行ID
     */
    public print(title:string, publishId:string): void {

        // 印刷の必須項目チェック
        if (this.printServiceUrl === undefined || publishId == null) {
            return;
        }

        // 別ウィンドウ（別タブ）で印刷画面を開く
        var win: Window = window.open(this.printServiceUrl + '/' + title + '?id=' + publishId, '_blank');

        // ポップアップブロックされている場合
        if (win === null) {
            // ブラウザによってポップアップがブロックされています。\nポップアップを許可してください。
            this.hostComponent.eAlert.message('100011', [], null, () => {});
        }
    }

    /**
     * リクエストの共通情報を設定する
     * @param param
     */
    private reqDtoBaseSetting(param: ReqDtoBase): void {

        // ReqDtoBaseの値を設定 (会計年度ID / 最終環境更新日時)
        param.fisicalYearCd = this.property.ownershipDto.selectFisicalYear;
        param.updatedEnvironment = this.property.ownershipDto.updatedEnvironment;
    }

    /**
     * 通信完了時のイベント
     * @param dto
     */
    private onResult(dto:ResDtoBase, resultFunction:Function, cancelFunction?:Function): void {

        // リクエストの経過時間をリセット
        this.postSessionTime = 0;

        // 最終環境更新日時が設定されている場合は、置き換える
        if (dto.updatedEnvironment !== undefined && dto.updatedEnvironment !== null) {
            this.property.ownershipDto.updatedEnvironment = dto.updatedEnvironment;
        }

        // 環境更新日時エラー
        if (dto.isEnvironmentError) {

            // 環境更新日時エラー時のログアウト
            this.environmentErrorLogout();
            return;
        }

        // ダイアログ非表示
        if (dto.messageId === null) {
            // 完了イベント
            resultFunction(dto);
            return;
        }

        // 通信で取得したメッセージIDから、アラートを表示する
        this.hostComponent.eAlert.message(dto.messageId, dto.umekomiList, dto.clientTarget, () => {
            // 完了イベント
            resultFunction(dto);
        }, () => {
            // 完了イベント
            if (cancelFunction !== undefined) {
                cancelFunction(dto);
            }
        });
    }

    /**
     * プレ印刷の通信完了時のイベント
     * @param dto
     */
    private onPrintResult(dto:ResDtoBase): void {

        // リクエストの経過時間をリセット
        this.postSessionTime = 0;

        // 印刷を実行
        this.print(this.printTitle, dto.publishId);

        // ダイアログ表示
        if (dto.messageId !== null) {
            this.hostComponent.eAlert.message(dto.messageId);
        }
    }

    /**
     * 通信エラー時のイベント
     * @param error
     */
    private onError(error: any, errorFunction?:Function): void {

        // エラーイベント
        if (errorFunction !== undefined) {
            errorFunction(error);
        }
        else {
            // システムエラーでログアウト
            this.errorLogout();
        }
    }

    /**
     * セッションタイムアウト時のログアウト
     */
    private sessionTimeOutLogout(): void {

        // セッションタイムアウトした際のエラーを表示
        this.hostComponent.eAlert.message('120029', [], null, () => {

            // ログアウト
            this.logout();
        });
    }

    /**
     * 環境更新日時エラー時のログアウト
     */
    private environmentErrorLogout(): void {

        // システムエラーを表示
        this.hostComponent.eAlert.message('211025', [], null, () => {

            // ログアウト
            this.logout();
        });
    }

    /**
     * エラー時のログアウト
     */
    public errorLogout(): void {

        // システムエラーを表示
        this.hostComponent.eAlert.message('220001', [], null, () => {

            // ログアウト
            this.logout();
        });
    }

    /**
     * ログアウト
     */
    private logout(): void {

        // ログアウト
        this.logoutService.callLogout().finally(() => {
            this.indexService.authenticated = false;
            document.location.href = this.property.commonURL;
        }).subscribe();
    }
}
