import { AC190ReqDto } from '../dto/ac190/AC190ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * TODO: このファイルは AC180Service.ts をコピーしただけの内容なので、仕様が決まったら正式な内容に書き換えること。
 */

export class AC190Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac190';

    /**
     * 振替伝票リスト取得
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getSlipList(reqDto: AC190ReqDto, resultFunction: Function): void {

        super.postRequest('/getSlipList', reqDto, resultFunction);
    }

    /**
     * 振替伝票追加
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public insert(reqDto: AC190ReqDto, resultFunction: Function): void {

        super.postRequest('/insert', reqDto, resultFunction);
    }

    /**
     * 振替伝票更新
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public update(reqDto: AC190ReqDto, resultFunction: Function): void {

        super.postRequest('/update', reqDto, resultFunction);
    }

    /**
     * 振替伝票削除
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public delete(reqDto: AC190ReqDto, resultFunction: Function): void {

        super.postRequest('/delete', reqDto, resultFunction);
    }
}
