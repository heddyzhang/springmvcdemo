import { AC322ReqDto } from '../dto/ac322/AC322ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC322 推移表
 */
export class AC322Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac322';

    /** 印刷 */
    protected printServiceUrl = 'print/ac322';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC322ReqDto, resultFunction: Function): void {
        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 印刷処理
     * @param reqDto リクエストパラメータ
     * @param title 印刷のタイトル
     */
    public onPrint(reqDto: AC322ReqDto, title:string): void {
        super.postPrintRequest('/onPrint', reqDto, title);
    }
}

