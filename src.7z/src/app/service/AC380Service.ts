import { AC380ReqDto } from '../dto/ac380/AC380ReqDto';
import { EServiceBase } from './EServiceBase';

export class AC380Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac380';

    /** 印刷 */
    protected printServiceUrl = 'print/ac380';

    /**
     * 印刷処理
     * @param reqDto リクエストパラメータ
     * @param title 印刷のタイトル
     */
    public onPrint(reqDto: AC380ReqDto, title:string): void {
        super.postPrintRequest('/onPrint', reqDto, title);
    }

       /**
     * 買掛伝票リスト取得
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public outputPdf(reqDto: AC380ReqDto, resultFunction: Function): void {

        super.postRequest('', reqDto, resultFunction);
    }

}
