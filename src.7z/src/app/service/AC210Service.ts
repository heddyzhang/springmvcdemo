import { AC210ReqDto } from '../dto/ac210/AC210ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC210 証憑分類
 */
export class AC210Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac210';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC210ReqDto, resultFunction: Function): void {

        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * ファイルのアップロード処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public uploadFile(reqDto: AC210ReqDto, file: File, resultFunction: Function): void {

        super.postFileRequest('/uploadFile', reqDto, file, resultFunction);
    }

    /**
     * 作業エリアに表示するファイルを取得する処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getVoucherFile(reqDto: AC210ReqDto, resultFunction: Function): void {

        super.postRequest('/getVoucherFile', reqDto, resultFunction);
    }

    /**
     * 作業エリアに表示するファイルを取得する処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getPage(reqDto: AC210ReqDto, resultFunction: Function): void {

        super.postRequest('/getPage', reqDto, resultFunction);
    }

    /**
     * 削除処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public delete(reqDto: AC210ReqDto, resultFunction: Function): void {

        super.postRequest('/delete', reqDto, resultFunction);
    }

    /**
     * 登録処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public insert(reqDto: AC210ReqDto, resultFunction: Function): void {

        super.postRequest('/insert', reqDto, resultFunction);
    }
}
