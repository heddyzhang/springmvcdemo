import { AC321ReqDto } from '../dto/ac321/AC321ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC321 集計表
 */
export class AC321Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac321';

    /** 印刷 */
    protected printServiceUrl = 'print/ac321';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC321ReqDto, resultFunction: Function): void {
        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 印刷処理
     * @param reqDto リクエストパラメータ
     * @param title 印刷のタイトル
     */
    public onPrint(reqDto: AC321ReqDto, title:string): void {
        super.postPrintRequest('/onPrint', reqDto, title);
    }
}

