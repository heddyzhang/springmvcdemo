import { EServiceBase } from './EServiceBase';
import { ConditionEviPopupResDto } from '../dto/conditionEviPopup/ConditionEviPopupResDto';
import { ConditionEviPopupReqDto } from '../dto/conditionEviPopup/ConditionEviPopupReqDto';
import { UserDto } from '../dto/conditionEviPopup/UserDto';
import { ConditionEviPopupDto } from '../dto/conditionEviPopup/ConditionEviPopupDto';

/**
 * 証憑表示条件ポップアップ
 */
export class ConditionEviPopupService extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/conditionEviPopup';

    /**
     * 初期表示する未処理証憑の情報を取得
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: ConditionEviPopupReqDto, resultFunction: Function, isUnitTest?: boolean): void {
        if (!isUnitTest) {
            super.postRequest('/getInitial', reqDto, resultFunction);
        } else {
            // storybookでのUnitテスト
            const json = this.jsonData();
            this.callBackUnitTest(json, resultFunction);
        }
    }

    private callBackUnitTest(json: any, resultFunction: Function): void {
        const dto: ConditionEviPopupResDto = json;
        window.setTimeout(() => {
            resultFunction(dto);
        }, 500);
    }

    private jsonData(): any {
        const userDtoList: UserDto[] = [
            { userId: -1, userName: null },
            { userId: 1, userName: "一郎" },
            { userId: 2, userName: "二郎" },
            { userId: 3, userName: "三郎" },
            { userId: 4, userName: "四郎" },
        ];

        const conditionEviPopupDtoList: ConditionEviPopupDto[] = [
            { voucherSortingId: 3, voucherSortingName: "領収書", occurrenceDate: null, createdUser: null },
            { voucherSortingId: 17, voucherSortingName: "領収書（クレジット）", occurrenceDate: null, createdUser: null },
            { voucherSortingId: 5, voucherSortingName: "請求書（控え）", occurrenceDate: new Date("2018/12/01"), createdUser: 4 },
            { voucherSortingId: 5, voucherSortingName: "請求書（控え）", occurrenceDate: new Date("2018/12/01"), createdUser: 4 },
            { voucherSortingId: 6, voucherSortingName: "請求書", occurrenceDate: null, createdUser: null },
            { voucherSortingId: 7, voucherSortingName: "給与集計表", occurrenceDate: null, createdUser: null },
            { voucherSortingId: 13, voucherSortingName: "クレジットご利用明細書", occurrenceDate: null, createdUser: null },
            { voucherSortingId: 12, voucherSortingName: "振込依頼書", occurrenceDate: null, createdUser: null },
            { voucherSortingId: 14, voucherSortingName: "自動引落のお知らせ", occurrenceDate: null, createdUser: null },
            { voucherSortingId: 9, voucherSortingName: "住民税納付書", occurrenceDate: null, createdUser: null },
            { voucherSortingId: 15, voucherSortingName: "社会保険料納入告知額", occurrenceDate: null, createdUser: null },
            { voucherSortingId: 19, voucherSortingName: "返済予定表", occurrenceDate: null, createdUser: null },
            { voucherSortingId: 1, voucherSortingName: "領収書(控え)", occurrenceDate: null, createdUser: null },
            { voucherSortingId: 2, voucherSortingName: "レシートタイプ　領収書(控え)", occurrenceDate: null, createdUser: null },
            { voucherSortingId: 4, voucherSortingName: "レシートタイプ　領収書", occurrenceDate: null, createdUser: null },
            { voucherSortingId: 8, voucherSortingName: "労働保険納付書", occurrenceDate: null, createdUser: null },
            { voucherSortingId: 10, voucherSortingName: "源泉税納付書", occurrenceDate: new Date("2018/10/12"), createdUser: 4 },
            { voucherSortingId: 11, voucherSortingName: "配当金支払通知書", occurrenceDate: new Date("2018/10/12"), createdUser: 4 },
            { voucherSortingId: 11, voucherSortingName: "配当金支払通知書", occurrenceDate: new Date("2018/10/12"), createdUser: 4 },
            { voucherSortingId: 16, voucherSortingName: "見積書", occurrenceDate: null, createdUser: null },
            { voucherSortingId: 18, voucherSortingName: "クレジットカード売上票", occurrenceDate: null, createdUser: null },
            { voucherSortingId: 20, voucherSortingName: "給与明細", occurrenceDate: new Date("2018/10/12"), createdUser: 4 },
            { voucherSortingId: 21, voucherSortingName: "通帳", occurrenceDate: new Date("2018/10/12"), createdUser: 4 },
            { voucherSortingId: 21, voucherSortingName: "通帳", occurrenceDate: new Date("2018/10/12"), createdUser: 4 },
            { voucherSortingId: 21, voucherSortingName: "通帳", occurrenceDate: new Date("2018/10/12"), createdUser: 4 },
            { voucherSortingId: 22, voucherSortingName: "決算書・申告書", occurrenceDate: null, createdUser: null },
        ]

        return {
            "responseCd": 0,
            "publishId": null,
            "messageId": null,
            "umekomiList": null,
            "updatedEnvironment": null,
            "isEnvironmentError": false,
            "clientTarget": null,
            userDtoList: userDtoList,
            conditionEviPopupDtoList: conditionEviPopupDtoList,
        }
    }
}
