import { Injectable } from '@angular/core';
import { EServiceBase } from './EServiceBase';
import { AC510ReqDto } from '../dto/ac510/AC510ReqDto';

export class AC510Service extends EServiceBase {
    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac510';

    /**
     * 売掛伝票リスト取得
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getSlipList(reqDto: AC510ReqDto, resultFunction: Function): void {

        super.postRequest('/getSlipList', reqDto, resultFunction);
    }

    /**
 * 売掛伝票追加
 * @param reqDto リクエストパラメータ
 * @param resultFunction 正常応答処理
 */
    public insert(reqDto: AC510ReqDto, resultFunction: Function): void {

        super.postRequest('/insert', reqDto, resultFunction);
    }

    /**
     * 売掛伝票更新
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public update(reqDto: AC510ReqDto, resultFunction: Function): void {

        super.postRequest('/update', reqDto, resultFunction);
    }

    /**
     * 売掛伝票削除
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public delete(reqDto: AC510ReqDto, resultFunction: Function): void {

        super.postRequest('/delete', reqDto, resultFunction);
    }
}
