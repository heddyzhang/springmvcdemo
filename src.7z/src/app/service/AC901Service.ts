import { EServiceBase } from "./EServiceBase";
import { AC901ReqDto } from "../dto/ac901/AC901ReqDto";

export class AC901Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac901';

    /** 印刷 */
    protected printServiceUrl = 'print/ac901';

    
    public onPrint(reqDto: AC901ReqDto, title: string): void {

        super.postPrintRequest('/onPrint', reqDto, title);
    }

    public add(reqDto: AC901ReqDto, resultFunction: Function): void {

        super.postRequest('/add', reqDto, resultFunction);
    }
}