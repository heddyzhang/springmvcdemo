import { AC320ReqDto } from '../dto/ac320/AC320ReqDto';
import { EServiceBase } from './EServiceBase';

// /**
//  * AC320 ~~~~~
//  */
export class AC320Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac320';

    /** 印刷 */
    protected printServiceUrl = 'print/ac320';


    public onPrint(reqDto: AC320ReqDto, title: string): void {

        super.postPrintRequest('/onPrint', reqDto, title);
    }

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC320ReqDto, resultFunction: Function): void {

        super.postRequest('/getInitial', reqDto, resultFunction);
    }
}
