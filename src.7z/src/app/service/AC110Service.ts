import { AC110ReqDto } from '../dto/ac110/AC110ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC110 利用者招待 サービスクラス
 */
export class AC110Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac110';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC110ReqDto, resultFunction: Function): void {

        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * メールを送信処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public sendMail(reqDto: AC110ReqDto, resultFunction: Function): void {

        super.postRequest('/sendMail', reqDto, resultFunction);
    }
}
