import { AC911ReqDto } from '../dto/ac911/AC911ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC911 集計表
 */
export class AC911Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac911';

    /** 印刷 */
    protected printServiceUrl = 'print/ac911';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC911ReqDto, resultFunction: Function): void {
        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 印刷処理
     * @param reqDto リクエストパラメータ
     * @param title 印刷のタイトル
     */
    public onPrint(reqDto: AC911ReqDto, title:string): void {
        super.postPrintRequest('/onPrint', reqDto, title);
    }
}

