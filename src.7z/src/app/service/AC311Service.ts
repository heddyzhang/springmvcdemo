import { AC311ReqDto } from '../dto/ac311/AC311ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC311 集計表
 */
export class AC311Service extends EServiceBase {

    /** 必須：リクエスト先 */
    // protected serviceUrl = 'api/ac311';
    protected serviceUrl = 'api/ac301'; // TODO: サービス実装されたら311に戻す

    /** 印刷 */
    protected printServiceUrl = 'print/ac311';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC311ReqDto, resultFunction: Function): void {
        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 印刷処理
     * @param reqDto リクエストパラメータ
     * @param title 印刷のタイトル
     */
    public onPrint(reqDto: AC311ReqDto, title:string): void {
        super.postPrintRequest('/onPrint', reqDto, title);
    }
}

