import { AC015ReqDto } from '../dto/ac015/AC015ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC015 消費税設定 サービスクラス
 */
export class AC015Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac015';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC015ReqDto, resultFunction: Function): void {

        super.postRequest('/getInitial', reqDto, resultFunction);
    }

     /**
     * 事業年度の切り替え表示処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getAgain(reqDto: AC015ReqDto, resultFunction: Function): void {

        super.postRequest('/getAgain', reqDto, resultFunction);
    }

    /**
     * 更新処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public update(reqDto: AC015ReqDto, resultFunction: Function): void {

        super.postRequest('/update', reqDto, resultFunction);
    }
}
