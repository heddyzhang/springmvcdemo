import { EServiceBase } from "./EServiceBase";
import { CommonComponentReqDto } from "../dto/commonComponent/CommonComponentReqDto";

/**
 * 共通コンポーネント用Serviceクラス
 */
export class CommonComponentService extends EServiceBase {

    //-------------------------
    // 以下　金融機関検索用API
    //-------------------------

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/commonComponent';

    /**
     * セッションタイムアウト管理を行わない
     */
    protected sessionCheck: boolean = false;

    /**
     * 銀行を全件取得
     * @param reqDto
     * @param resultFunction
     */
    public getBankAll(reqDto: CommonComponentReqDto, resultFunction: Function): void {

        super.postRequest('/getBankAll', reqDto, resultFunction);
    }

    /**
     * 銀行コードをキーに支店情報を全件取得
     * @param reqDto
     * @param resultFunction
     */
    public getBankBranchAll(reqDto: CommonComponentReqDto, resultFunction: Function): void {

        super.postRequest('/getBankBranchAll', reqDto, resultFunction);
    }

    /**
     * 銀行コードをキーに対象の銀行情報を取得
     * @param reqDto
     * @param resultFunction
     */
    public getBank(reqDto: CommonComponentReqDto, resultFunction: Function): void {

        super.postRequest('/getBank', reqDto, resultFunction);
    }

    /**
     * 銀行コード／支店コードをキーに対象の支店情報を取得
     */
    public getBankBranch(reqDto: CommonComponentReqDto, resultFunction: Function): void {

        super.postRequest('/getBankBranch', reqDto, resultFunction);
    }


    //-------------------------
    // 以下　摘要マスターポップアップ用
    //-------------------------
    /**
     * 摘要のテーブルから全件対象に情報を取得
     */
    public getSummary(reqDto: CommonComponentReqDto, resultFunction: Function): void {

        super.postRequest('/getSummary', reqDto, resultFunction);
    }

    /**
     * 摘要のテーブルへ情報を登録
     *  @param reqDto リクエストパラメータ
     */
    public insert(reqDto: CommonComponentReqDto, resultFunction: Function): void {
        super.postRequest('/insert', reqDto, resultFunction);
    }

    /**
     * 更新処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public update(reqDto: CommonComponentReqDto, resultFunction: Function): void {

        super.postRequest('/update', reqDto, resultFunction);
    }

    /**
     * 更新処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public updateCount(reqDto: CommonComponentReqDto, resultFunction: Function): void {

        super.postRequest('/updateCount', reqDto, resultFunction);
    }

    /**
     * 削除処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public delete(reqDto: CommonComponentReqDto, resultFunction: Function): void {

        super.postRequest('/delete', reqDto, resultFunction);
    }

}
