import { AC010ReqDto } from '../dto/ac010/AC010ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC010 事業者登録情報 サービスクラス
 */
export class AC010Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac010';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC010ReqDto, resultFunction: Function): void {

        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 住所検索
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getAddress(reqDto: AC010ReqDto, resultFunction: Function): void {
        super.postRequest('/getAddress', reqDto, resultFunction);
    }

    /**
     * 更新処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public update(reqDto: AC010ReqDto, resultFunction: Function): void {

        super.postRequest('/update', reqDto, resultFunction);
    }
}
