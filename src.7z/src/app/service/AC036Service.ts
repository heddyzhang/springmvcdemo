import { AC036ReqDto } from '../dto/ac036/AC036ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC036 補助科目の残高登録 サービスクラス
 */
export class AC036Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac036';

    /** 印刷 */
    protected printServiceUrl = 'print/ac036';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC036ReqDto, resultFunction: Function): void {

        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 取消処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public cancel(reqDto: AC036ReqDto, resultFunction: Function): void {

        super.postRequest('/cancel', reqDto, resultFunction);
    }

    /**
     * 更新処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public update(reqDto: AC036ReqDto, resultFunction: Function): void {

        super.postRequest('/update', reqDto, resultFunction);
    }

    /**
     * 印刷処理
     * @param reqDto リクエストパラメータ
     * @param title 印刷のタイトル
     */
    public onPrint(reqDto: AC036ReqDto, title:string): void {

        super.postPrintRequest('/onPrint', reqDto, title);
    }
}
