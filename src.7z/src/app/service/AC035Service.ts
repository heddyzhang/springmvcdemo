import { AC035ReqDto } from '../dto/ac035/AC035ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC035 勘定科目の残高登録 サービスクラス
 */
export class AC035Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac035';

    /** 印刷 */
    protected printServiceUrl = 'print/ac035';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC035ReqDto, resultFunction: Function): void {

        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 更新処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public update(reqDto: AC035ReqDto, resultFunction: Function): void {

        super.postRequest('/update', reqDto, resultFunction);
    }

    /**
     * 印刷処理
     * @param reqDto リクエストパラメータ
     * @param title 印刷のタイトル
     */
    public onPrint(reqDto: AC035ReqDto, title: string): void {

        super.postPrintRequest('/onPrint', reqDto, title);
    }
}
