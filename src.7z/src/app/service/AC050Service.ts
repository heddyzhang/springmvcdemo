import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';

import {Observable} from 'rxjs/Observable';
import {catchError, map, tap} from 'rxjs/operators';
import {AC050ResDto} from '../dto/ac050/AC050ResDto';
import {AC050ReqDto} from '../dto/ac050/AC050ReqDto';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};
@Injectable()
export class AC050Service {

  private serviceUrl = 'api/ac050';

  // コンストラクタで利用するモジュールをインスタンス化
  constructor(private http: HttpClient) {}

  onPrint(): Observable<AC050ResDto> {

    const reqDto: AC050ReqDto = new AC050ReqDto();

    //---------------------------
    // TODO リスエスト情報固定
    //---------------------------
    reqDto.dispBusinessFlg = true;
    reqDto.dispPrintTimeFormat = `yyyy/MM/dd`;

    const url = `${this.serviceUrl}/outputReserve`;

    return this.http.post<AC050ResDto>(url, reqDto, httpOptions);
  }
}
