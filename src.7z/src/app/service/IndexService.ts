import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { catchError, map, tap } from 'rxjs/operators';
import { IndexResDto } from '../dto/index/IndexResDto'

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable()
export class IndexService {

    private serviceUrl = 'api';

    indexResDto:IndexResDto;
    authenticated = false;

    // コンストラクタで利用するモジュールをインスタンス化
    constructor(private http: HttpClient) { }

    authCheck() {

         const url = `${this.serviceUrl}/authCheck`;

        this.http.get<IndexResDto>(url, httpOptions).subscribe(
            data => {
                this.indexResDto = data;
                if (this.indexResDto.authCd == 0) {
                    this.authenticated = true;
                }
            }
          );
    }
}
