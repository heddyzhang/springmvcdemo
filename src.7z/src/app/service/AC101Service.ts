import { AC101ReqDto } from '../dto/ac101/AC101ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC101 利用者招待 サービスクラス
 */
export class AC101Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac101';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC101ReqDto, resultFunction: Function): void {

        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * メールを送信処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public sendMail(reqDto: AC101ReqDto, resultFunction: Function): void {

        super.postRequest('/sendMail', reqDto, resultFunction);
    }
}
