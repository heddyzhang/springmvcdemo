import { AC312ReqDto } from '../dto/ac312/AC312ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC312 推移表
 */
export class AC312Service extends EServiceBase {

    /** 必須：リクエスト先 */
    // protected serviceUrl = 'api/ac312';
    protected serviceUrl = 'api/ac302'; // TODO: サービス実装されたら312に戻す

    /** 印刷 */
    protected printServiceUrl = 'print/ac312';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC312ReqDto, resultFunction: Function): void {
        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 印刷処理
     * @param reqDto リクエストパラメータ
     * @param title 印刷のタイトル
     */
    public onPrint(reqDto: AC312ReqDto, title:string): void {
        super.postPrintRequest('/onPrint', reqDto, title);
    }
}

