import { Injectable }    from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { AC000ResDto } from '../dto/ac000/AC000ResDto';
import { AC000ReqDto } from '../dto/ac000/AC000ReqDto';
import { AC000UserInfoDto } from '../dto/ac000/AC000UserInfoDto';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };
@Injectable()
export class AC000Service {
    private serviceUrl = "api/ac000";

    //コンストラクタで利用するモジュールをインスタンス化
    constructor(private http: HttpClient) {}

    /**
     * 初期処理
     */
    public getInitial(reqDto: AC000ReqDto): Observable<AC000ResDto> {
        const url = `${this.serviceUrl}/getInitial`;
        return this.http.post<AC000ResDto>(url, reqDto, httpOptions);
    }

    /**
     * ログイン中ユーザの一覧を取得
     */
    public getLoginUser(): Observable<AC000ResDto> {
        const url = `${this.serviceUrl}/getLoginUser`;
        return this.http.post<AC000ResDto>(url, httpOptions);
    }

    public getUserInfo(): Observable<AC000UserInfoDto>{
        const url = `${this.serviceUrl}/getUserInfo`;
        return this.http.post<AC000UserInfoDto>(url, httpOptions);
    }
}
