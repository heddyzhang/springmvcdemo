import { EServiceBase } from "./EServiceBase";
import { UnlinkEviReqDto } from '../dto/unlinkEvi/UnlinkEviReqDto';
import { UnlinkEviResDto } from '../dto/unlinkEvi/UnlinkEviResDto';
import { CommonEviDetailDto } from '../dto/commonEvi/CommonEviDetailDto';

/**
 * リンク証憑コンポーネント
 */
export class UnlinkEviService extends EServiceBase {
    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/unlinkEvi';
    //protected serviceUrl = 'http://localhost:8084/kaikei/api/unlinkEvi';

    /**
     * 初期表示するリンク証憑の情報を取得
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: UnlinkEviReqDto, resultFunction: Function, isUnitTest? :boolean): void {
        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 対象の画像情報を取得
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getFileData(reqDto: UnlinkEviReqDto, resultFunction: Function, isUnitTest? :boolean): void {
        super.postRequest('/getFileData', reqDto, resultFunction);
    }

    /**
     * 未証憑の画像表示順序の並べ替え
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public voucherImageOrderChange(reqDto: UnlinkEviReqDto, resultFunction: Function, isUnitTest? :boolean): void {
        super.postRequest('/voucherImageOrderChange', reqDto, resultFunction);
    }

    /**
     * リンク解除
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public unlink(reqDto: UnlinkEviReqDto, resultFunction: Function, isUnitTest? :boolean): void {
        super.postRequest('/unlink', reqDto, resultFunction);
    }
}
