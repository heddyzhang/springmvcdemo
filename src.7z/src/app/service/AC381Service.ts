import { AC381ReqDto } from '../dto/ac381/AC381ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC381 仕訳票
 */
export class AC381Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac381';

    /** 印刷 */
    protected printServiceUrl = 'print/ac381';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC381ReqDto, resultFunction: Function): void {
        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 印刷処理
     * @param reqDto リクエストパラメータ
     * @param title 印刷のタイトル
     */
    public onPrint(reqDto: AC381ReqDto, title:string): void {
        super.postPrintRequest('/onPrint', reqDto, title);
    }
}

