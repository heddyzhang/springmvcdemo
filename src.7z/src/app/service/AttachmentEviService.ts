import { EServiceBase } from "./EServiceBase";
import { AttachmentEviReqDto } from "../dto/attachmentEvi/AttachmentEviReqDto";
import { AttachmentEviResDto } from "../dto/attachmentEvi/AttachmentEviResDto";
import { ResDtoBase } from "../dto/ResDtoBase";

/**
 * 添付証憑コンポーネント
 */
export class AttachmentEviService extends EServiceBase {
    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/attachmentEvi';
    //protected serviceUrl = 'http://localhost:8084/kaikei/api/attachmentEvi';

    /**
     * 初期表示する添付証憑情報一覧を取得
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AttachmentEviReqDto, resultFunction: Function, isUnitTest? :boolean): void {
        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 指定ページする添付証憑情報一覧を取得
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getList(reqDto: AttachmentEviReqDto, resultFunction: Function, isUnitTest? :boolean): void {
        super.postRequest('/getList', reqDto, resultFunction);
    }

    /**
     * 指定ページする添付証憑情報一覧を取得
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public delete(reqDto: AttachmentEviReqDto, resultFunction: Function, isUnitTest? :boolean): void {
        super.postRequest('/delete', reqDto, resultFunction);
    }

    /**
     * 指定の添付証憑データの詳細一覧を取得
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getDetail(reqDto: AttachmentEviReqDto, resultFunction: Function, isUnitTest? :boolean): void {
        super.postRequest('/getDetail', reqDto, resultFunction);
    }

    /**
     * 指定の証憑詳細の画像データを取得
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getFileData(reqDto: AttachmentEviReqDto, resultFunction: Function, isUnitTest? :boolean): void {
        super.postRequest('/getFileData', reqDto, resultFunction);
    }

    /**
     * 証憑詳細の並び替え
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public voucherImageOrderChange(reqDto: AttachmentEviReqDto, resultFunction: Function, isUnitTest? :boolean): void {
        super.postRequest('/voucherImageOrderChange', reqDto, resultFunction);
    }

}
