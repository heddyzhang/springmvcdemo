import { AC081ReqDto } from '../dto/ac081/AC081ReqDto';
import { EServiceBase } from './EServiceBase';
/**
 * AC081 社員登録 サービスクラス
 */
export class AC081Service extends EServiceBase {
    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac081';
    /** 印刷 */
    protected printServiceUrl = 'print/ac081';
    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC081ReqDto, resultFunction: Function): void {
        super.postRequest('/getInitial', reqDto, resultFunction);
    }
    /**
     * 住所検索
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getAddress(reqDto: AC081ReqDto, resultFunction: Function): void {
        super.postRequest('/getAddress', reqDto, resultFunction);
    }
    /**
     * 新規処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public insert(reqDto: AC081ReqDto, resultFunction: Function): void {
        super.postRequest('/insert', reqDto, resultFunction);
    }
    /**
     * 更新処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public update(reqDto: AC081ReqDto, resultFunction: Function): void {
        super.postRequest('/update', reqDto, resultFunction);
    }
    /**
     * 削除処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public delete(reqDto: AC081ReqDto, resultFunction: Function): void {
        super.postRequest('/delete', reqDto, resultFunction);
    }
    /**
     * 印刷処理
     * @param reqDto リクエストパラメータ
     * @param title 印刷のタイトル
     */
    public onPrint(reqDto: AC081ReqDto, title:string): void {
        super.postPrintRequest('/outputReserve', reqDto, title);
    }
}

