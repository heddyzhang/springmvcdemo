import {AC309ReqDto} from '../dto/ac309/AC309ReqDto';
import {AC309ResDto} from '../dto/ac309/AC309ResDto';
import {HttpClient} from '@angular/common/http';
import {HttpHeaders} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import { EPopupInputResDto } from '../dto/ePopupInput/EPopupInputResDto';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};

@Injectable()
export class AC309Service {
  private serviceUrl = 'api/ac309';

  // コンストラクタで利用するモジュールをインスタンス化
  constructor(private http: HttpClient) {}

  onInit(): Observable<EPopupInputResDto> {
    const url: string = `api/ePopupInput/getAcSubTitleList`;
    return this.http.post<EPopupInputResDto>(url, httpOptions);
  }

  onSearch(reqDto: AC309ReqDto): Observable<AC309ResDto> {
    const url: string = `${this.serviceUrl}/getSearchResult`;
    return this.http.post<AC309ResDto>(url, reqDto, httpOptions);
  }

  /**
   * 印刷準備を行うAPIを実行
   */
  outputReserve(reqDto: AC309ReqDto): Observable<AC309ResDto> {
    const url: string = `${this.serviceUrl}/outputReserve`;
    return this.http.post<AC309ResDto>(url, reqDto, httpOptions);
  }
}