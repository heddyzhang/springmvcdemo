import { EServiceBase } from './EServiceBase';
import { ReqDtoBase } from '../dto/ReqDtoBase';

export class GetAcSubTitleListService extends EServiceBase{

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac000';
    /**
    * 補助科目ポップアップ更新処理
    * @param reqDto
    * @param resultFunction
    */
    public GetAcSubTitleListService(reqDto: ReqDtoBase, resultFunction: Function ): void {
        super.postRequest('/getAcSubTitle', reqDto, resultFunction);
    }

}
