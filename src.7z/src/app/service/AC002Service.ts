import { EServiceBase } from "./EServiceBase";
import { AC002ReqDto } from "../dto/ac002/AC002ReqDto";

export class AC002Service extends EServiceBase {

    protected serviceUrl = 'api/ac002';

    /**
     * 初期処理
     * @param reqDto
     * @param resultFunction
     */
    public getInitial(reqDto:AC002ReqDto, resultFunction: Function): void {

        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 環境の作成
     * @param reqDto
     * @param resultFunction
     */
    public createEnv(reqDto:AC002ReqDto, resultFunction: Function): void {

        super.postRequest('/createEnv', reqDto, resultFunction);
    }

     /**
     * 環境全部削除（セットアップツアーのやり直し）
     * @param reqDto リクエストDTOは空でよい
     * @param resultFunction
     */
    public resetEnv(reqDto:AC002ReqDto, resultFunction: Function): void {

        super.postRequest('/resetEnv', reqDto, resultFunction);
    }

    /**
     * 消費税の設定更新
     * @param reqDto
     * @param resultFunction
     */
    public updateTax(reqDto:AC002ReqDto, resultFunction: Function): void {

        super.postRequest('/updateTax', reqDto, resultFunction);
    }

    /**
     * セットアップツアー状態の更新
     * @param reqDto
     * @param resultFunction
     */
    public updateSetupTourSts(reqDto: AC002ReqDto, resultFunction: Function): void {

        super.postRequest('/updateSetupTourSts', reqDto, resultFunction);
    }

    /**
     * MT コールバックURLの取得
     * @param reqDto
     * @param resultFunction
     */
    public getMTLinkAuthData(reqDto: AC002ReqDto, resultFunction: Function): void {

        super.postRequest('/getMTLinkAuthData', reqDto, resultFunction);
    }

    /**
     * セットアップツアーの状態を完了とする
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public endProcessSetupTour(reqDto: AC002ReqDto, resultFunction: Function): void {

        super.postRequest('/endProcessSetupTour', reqDto, resultFunction);
    }
}
