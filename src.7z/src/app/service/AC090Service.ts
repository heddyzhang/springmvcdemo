import { EServiceBase } from "./EServiceBase";
import { AC090ReqDto } from "../dto/ac090/AC090ReqDto";
import { AC001ReqDto } from "../dto/ac001/AC001ReqDto";

export class AC090Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac090';

    /** 印刷 */
    protected printServiceUrl = 'print/ac090';

    /**
     * 初期処理
     * @param reqDto
     * @param resultFunction
     */
    public getInitial(reqDto: AC090ReqDto, resultFunction: Function): void {

        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 補助科目登録処理
     * @param reqDto
     * @param resultFunction
     */
    public acSubTitleCommit(reqDto: AC090ReqDto, resultFunction: Function): void {

        super.postRequest('/acSubTitleCommit', reqDto, resultFunction);
    }

    /**
     * MT認証処理
     * @param reqDto
     * @param resultFunction
     */
    public getMTLinkAuthData(reqDto: AC090ReqDto, resultFunction: Function): void {

        super.postRequest('/getMTLinkAuthData', reqDto, resultFunction);
    }

    /**
     * MT解除処理
     * @param reqDto
     * @param resultFunction
     */
    public revokeMTLink(reqDto: AC090ReqDto, resultFunction: Function): void {

        super.postRequest('/revokeMTLink', reqDto, resultFunction);
    }

    /**
     * 情報更新処理
     * @param reqDto
     * @param resultFunction
     */
    public getReplacement(reqDto: AC090ReqDto, resultFunction: Function): void {

        super.postRequest('/getReplacement', reqDto, resultFunction);
    }

    /**
     * 更新処理
     * @param reqDto
     * @param resultFunction
     */
    public updateAccount(reqDto: AC090ReqDto, resultFunction: Function): void {

        super.postRequest('/updateAccount', reqDto, resultFunction);
    }

        /**
     * MTのお客様情報をecoDBに登録
     * @param reqDto
     * @param resultFunction
     */
    public permissionState(reqDto: AC001ReqDto, resultFunction: Function): void {

        super.postRequest('/permissionState', reqDto, resultFunction);
    }


}
