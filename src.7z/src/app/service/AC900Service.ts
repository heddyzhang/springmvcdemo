import { AC900ReqDto } from '../dto/ac900/AC900ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC900 証憑分類マスタ登録情報 サービスクラス
 */
export class AC900Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac900';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC900ReqDto, resultFunction: Function): void {

        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 削除処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public delete(reqDto: AC900ReqDto, resultFunction: Function): void {

        super.postRequest('/delete', reqDto, resultFunction);
    }

    /**
     * 表示順序の変更
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public seqChange(reqDto: AC900ReqDto, resultFunction: Function): void {

        super.postRequest('/seqChange', reqDto, resultFunction);
    }

    /**
     * 新規登録処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public insert(reqDto: AC900ReqDto, resultFunction: Function): void {
        super.postRequest('/insert', reqDto, resultFunction);
    }

    /**
     * 更新処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public update(reqDto: AC900ReqDto, resultFunction: Function): void {

        super.postRequest('/update', reqDto, resultFunction);
    }
}
