import { AC020ReqDto } from '../dto/ac020/AC020ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC300 貸借対照表
 */
export class AC020Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac020';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC020ReqDto, resultFunction: Function): void {
        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * メールアドレス更新処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public updateUserAccount(reqDto: AC020ReqDto, resultFunction: Function): void {
        super.postRequest('/updateUserAccount', reqDto, resultFunction);
    }

    /**
     * パスワード更新処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public updateUserPassword(reqDto: AC020ReqDto, resultFunction: Function): void {
        super.postRequest('/updateUserPassword', reqDto, resultFunction);
    }

}

