import { AC300ReqDto } from '../dto/ac300/AC300ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC300 貸借対照表
 */
export class AC300Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac300';

    /** 印刷 */
    protected printServiceUrl = 'print/ac300';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC300ReqDto, resultFunction: Function): void {
        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 印刷処理
     * @param reqDto リクエストパラメータ
     * @param title 印刷のタイトル
     */
    public onPrint(reqDto: AC300ReqDto, title:string): void {
        super.postPrintRequest('/onPrint', reqDto, title);
    }
}

