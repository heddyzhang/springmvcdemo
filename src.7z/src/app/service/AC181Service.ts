import { AC181ResDto } from '../dto/ac181/AC181ResDto';
import { AC181ReqDto } from '../dto/ac181/AC181ReqDto';
import { EServiceBase } from './EServiceBase';

export class AC181Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac181';

    /**
     * 買掛伝票リスト取得
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getSlipList(reqDto: AC181ReqDto, resultFunction: Function): void {

        super.postRequest('/getSlipList', reqDto, resultFunction);
    }

    /**
     * 買掛伝票追加
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public insert(reqDto: AC181ReqDto, resultFunction: Function): void {

        super.postRequest('/insert', reqDto, resultFunction);
    }

    /**
     * 買掛伝票更新
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public update(reqDto: AC181ReqDto, resultFunction: Function): void {

        super.postRequest('/update', reqDto, resultFunction);
    }

    /**
     * 買掛伝票削除
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public delete(reqDto: AC181ReqDto, resultFunction: Function): void {

        super.postRequest('/delete', reqDto, resultFunction);
    }
}
