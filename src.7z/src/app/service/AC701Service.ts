import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { catchError, map, tap } from 'rxjs/operators';
import { AC701ReqDto } from '../dto/ac701/AC701ReqDto';
import { AC701ResDto } from '../dto/ac701/AC701ResDto';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable()
export class AC701Service {

    private serviceUrl = 'api/ac701';

    // コンストラクタで利用するモジュールをインスタンス化
    constructor(private http: HttpClient) { }

    /**
     * 印刷準備を行う
     */
    onPrint(reqDto:AC701ReqDto): Observable<AC701ResDto> {

        // ---------------
        // TODO モック
        // ---------------
        reqDto.dispBusinessFlg = true;
        reqDto.dispPrintTimeFormat = `yyyy/MM/dd`;

        const url = `${this.serviceUrl}/outputReserve`;

        return this.http.post<AC701ResDto>(url, reqDto, httpOptions);
    }
}
