import { AC085ReqDto } from '../dto/ac085/AC085ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC085 取引先・社員残高登録 サービスクラス
 */
export class AC085Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac085';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC085ReqDto, resultFunction: Function): void {

        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 取消処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public cancel(reqDto: AC085ReqDto, resultFunction: Function): void {

        super.postRequest('/cancel', reqDto, resultFunction);
    }

    /**
     * 更新処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public update(reqDto: AC085ReqDto, resultFunction: Function): void {

        super.postRequest('/update', reqDto, resultFunction);
    }
}
