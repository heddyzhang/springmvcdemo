import { AC180ResDto } from '../dto/ac180/AC180ResDto';
import { AC180ReqDto } from '../dto/ac180/AC180ReqDto';
import { EServiceBase } from './EServiceBase';

export class AC180Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac180';

    /**
     * 売掛伝票リスト取得
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getSlipList(reqDto: AC180ReqDto, resultFunction: Function): void {

        super.postRequest('/getSlipList', reqDto, resultFunction);
    }

    /**
     * 売掛伝票追加
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public insert(reqDto: AC180ReqDto, resultFunction: Function): void {

        super.postRequest('/insert', reqDto, resultFunction);
    }

    /**
     * 売掛伝票更新
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public update(reqDto: AC180ReqDto, resultFunction: Function): void {

        super.postRequest('/update', reqDto, resultFunction);
    }

    /**
     * 売掛伝票削除
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public delete(reqDto: AC180ReqDto, resultFunction: Function): void {

        super.postRequest('/delete', reqDto, resultFunction);
    }
}
