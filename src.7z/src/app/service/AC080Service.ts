import { AC080ResDto } from '../dto/ac080/AC080ResDto';
import { AC080ReqDto } from '../dto/ac080/AC080ReqDto';
import { EServiceBase } from './EServiceBase';

export class AC080Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac080';

    /** 印刷 */
    protected printServiceUrl = 'print/ac080';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC080ReqDto, resultFunction: Function): void {

        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 住所検索
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getAddress(reqDto: AC080ReqDto, resultFunction: Function): void {

        super.postRequest('/getAddress', reqDto, resultFunction);
    }

    /**
     * 新規処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public insert(reqDto: AC080ReqDto, resultFunction: Function,isCheckOnly = false): void {
        reqDto.checkOnly = isCheckOnly;
        super.postRequest('/insert', reqDto, resultFunction);
    }

    /**
     * 更新処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public update(reqDto: AC080ReqDto, resultFunction: Function, isCheckOnly = false): void {
        reqDto.checkOnly = isCheckOnly;
        super.postRequest('/update', reqDto, resultFunction);
    }

    /**
     * 削除処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public delete(reqDto: AC080ReqDto, resultFunction: Function): void {

        super.postRequest('/delete', reqDto, resultFunction);
    }

    /**
     * 印刷処理
     * @param reqDto リクエストパラメータ
     * @param title 印刷のタイトル
     */
    public onPrint(reqDto: AC080ReqDto, title:string): void {
        super.postPrintRequest('/outputReserve', reqDto, title);
    }
}
