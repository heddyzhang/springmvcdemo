import { AC302ReqDto } from '../dto/ac302/AC302ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC302 推移表
 */
export class AC302Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac302';

    /** 印刷 */
    protected printServiceUrl = 'print/ac302';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC302ReqDto, resultFunction: Function): void {
        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 印刷処理
     * @param reqDto リクエストパラメータ
     * @param title 印刷のタイトル
     */
    public onPrint(reqDto: AC302ReqDto, title:string): void {
        super.postPrintRequest('/onPrint', reqDto, title);
    }
}

