import { HttpHeaders, HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { EServiceBase } from "./EServiceBase";
import { AC030ReqDto } from "../dto/ac030/AC030ReqDto";

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };
@Injectable()
export class AC030Service extends EServiceBase{

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac030';

     /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC030ReqDto, resultFunction: Function): void {

        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 更新処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public update(reqDto: AC030ReqDto, resultFunction: Function): void {

        super.postRequest('/update', reqDto, resultFunction);
    }

    /**
     * 補助科目削除処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public deleteAcSubTitle(reqDto: AC030ReqDto, resultFunction: Function): void {

        super.postRequest('/deleteAcSubTitle', reqDto, resultFunction);
    }
}
