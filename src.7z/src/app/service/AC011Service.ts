import { AC011ReqDto } from '../dto/ac011/AC011ReqDto';
import { EServiceBase } from './EServiceBase';

/**
 * AC011 ご利用形態 サービスクラス
 */
export class AC011Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac011';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC011ReqDto, resultFunction: Function): void {

        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 更新処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public update(reqDto: AC011ReqDto, resultFunction: Function): void {

        super.postRequest('/update', reqDto, resultFunction);
    }
}
