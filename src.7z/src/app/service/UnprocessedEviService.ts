import { UnprocessedEviReqDto } from '../dto/unprocessedEvi/UnprocessedEviReqDto';
//import { UnprocessedEviResDto } from '../dto/unprocessedEvi/UnprocessedEviResDto';
import { EServiceBase } from './EServiceBase';
import { UnprocessedEviResDto } from '../dto/unprocessedEvi/UnprocessedEviResDto';
import { CommonEviDetailDto } from '../dto/commonEvi/CommonEviDetailDto';
//CommonEviDetailDto

/**
 * 未証憑コンポーネント
 */
export class UnprocessedEviService extends EServiceBase {
    /** 必須：リクエスト先 */
    //protected serviceUrl = 'http://localhost:8084/kaikei/api/unprocessedEvi';
    protected serviceUrl = 'api/unprocessedEvi';

    /**
     * 初期表示する未処理証憑の情報を取得
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: UnprocessedEviReqDto, resultFunction: Function, isUnitTest? :boolean): void {
        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * 指定した未処理証憑の詳細情報を取得
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getDetail(reqDto: UnprocessedEviReqDto, resultFunction: Function, isUnitTest? :boolean): void {
        super.postRequest('/getDetail', reqDto, resultFunction);
    }

    /**
     * 未証憑の画像表示順序の並べ替え
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public voucherImageOrderChange(reqDto: UnprocessedEviReqDto, resultFunction: Function, isUnitTest? :boolean): void {
        super.postRequest('/voucherImageOrderChange', reqDto, resultFunction);
    }

    /**
     * 未証憑の対象の画像情報を取得
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getFileData(reqDto: UnprocessedEviReqDto, resultFunction: Function, isUnitTest? :boolean): void {
        super.postRequest('/getFileData', reqDto, resultFunction);
    }

    /**
     * 対象の未証憑データを削除
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public delete(reqDto: UnprocessedEviReqDto, resultFunction: Function, isUnitTest? :boolean): void {
        super.postRequest('/delete', reqDto, resultFunction);
    }

}
