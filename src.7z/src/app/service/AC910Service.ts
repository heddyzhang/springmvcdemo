import { AC910ReqDto } from '../dto/ac910/AC910ReqDto';
import { EServiceBase } from './EServiceBase';

// /**
//  * AC910 ~~~~~
//  */
export class AC910Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac910';

    /** 印刷 */
    protected printServiceUrl = 'print/ac910';


    public onPrint(reqDto: AC910ReqDto, title: string): void {

        super.postPrintRequest('/onPrint', reqDto, title);
    }

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC910ReqDto, resultFunction: Function): void {

        super.postRequest('/getInitial', reqDto, resultFunction);
    }
}
