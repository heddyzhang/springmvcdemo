import { Injectable } from "@angular/core";
import { HttpHeaders, HttpClient } from "@angular/common/http";
import { AC001ResDto } from "../dto/ac001/AC001ResDto";
import { AC001ReqDto } from "../dto/ac001/AC001ReqDto";
import { Observable } from "rxjs/Observable";
import { EServiceBase } from "./EServiceBase";
import { ProgressDto } from "../dto/commonComponent/ProgressDto";

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable()
export class AC001Service extends EServiceBase {

    /** 必須：リクエスト先 */
    protected serviceUrl = 'api/ac001';

    /**
     * 初期処理
     * @param reqDto リクエストパラメータ
     * @param resultFunction 正常応答処理
     */
    public getInitial(reqDto: AC001ReqDto, resultFunction: Function): void {

        super.postRequest('/getInitial', reqDto, resultFunction);
    }

    /**
     * MT 連携状態の確認
     * @param resDto
     * @param resultFunction
     */
    public getMtLinkPermissionState(reqDto: AC001ReqDto, resultFunction: Function): void {

        super.postRequest('/getMtLinkPermissionState', reqDto, resultFunction);
    }

    /**
     *
     * @param reqDto
     * @param resultFunction
     */
    public getMTLinkAuthData(reqDto: AC001ReqDto, resultFunction: Function): void {

        super.postRequest('/getMTLinkAuthData', reqDto, resultFunction);
    }

    /**
     * MTのお客様情報をecoDBに登録
     * @param reqDto
     * @param resultFunction
     */
    public permissionState(reqDto: AC001ReqDto, resultFunction: Function): void {

        super.postRequest('/permissionState', reqDto, resultFunction);
    }

    /**
     * MTの明細を取得する
     * @param reqDto
     * @param resultFunction
     */
    public getMTJournal(reqDto: AC001ReqDto, resultFunction: Function): void {

        super.postRequest('/getMTJournal', reqDto, resultFunction);
    }

    /**
     * TODO 消す
     * テスト
     * 長い処理
     * プログレスIDを取得する
     * @param resultFunction
     */
    public test_longProgress(reqDto: AC001ReqDto, completeCnt: number, resultFunction: Function): void {
        super.longPostRequest('/test_execution', reqDto, completeCnt, resultFunction);
    }

    /**
     * eco会計からeco不動産への遷移URLを取得
     * @param reqDto
     * @param resultFunction
     */
    public getNextUrl(reqDto: AC001ReqDto, resultFunction: Function): void {

        super.postRequest('/getNextUrl', reqDto, resultFunction);
    }



    // /**
    //  * 初期処理
    //  * @param reqDto リクエストパラメータ
    //  * @param resultFunction 正常応答処理
    //  */
    // public getOwnership(reqDto: AC001ReqDto, resultFunction: Function): void {

    //     super.postRequest('/getOwnership', reqDto, resultFunction);
    // }
}
