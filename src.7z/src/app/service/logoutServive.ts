import { Injectable }    from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };
@Injectable()
export class LogoutService {

    //コンストラクタで利用するモジュールをインスタンス化
    constructor(private http: HttpClient) { }

    callLogout():Observable<{}> {
        return this.http.post<{}>('logout', httpOptions);
    }
}
