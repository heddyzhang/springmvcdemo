import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {
  HttpInterceptor, HttpHandler, HttpRequest, HTTP_INTERCEPTORS
} from '@angular/common/http';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';

import { EcoKaikeiProperty } from './eco.kaikei.property';
import { IndexService } from './service/IndexService';

import { Ac000Component } from './view/ac000/ac000.component';
import { AC000Service } from './service/AC000Servive';
import { topMenu } from './view/ac000/supportClass/top.menu';
import { sideMenu } from './view/ac000/supportClass/side.menu';
import { Ac001Component } from './view/ac001/ac001.component';
import { AC001Service } from './service/AC001Service';
import { Ac002Component } from './view/ac002/ac002.component';
import { AC002Service } from './service/AC002Service';
import { Ac010Component } from './view/ac010/ac010.component';
import { AC010Service } from './service/AC010Service';
import { Ac011Component } from './view/ac011/ac011.component';
import { AC011Service } from './service/AC011Service';
import { Ac015Component } from './view/ac015/ac015.component';
import { AC015Service } from './service/AC015Service';
import { Ac020Component } from './view/ac020/ac020.component';
import { AC020Service } from './service/AC020Service';
import { Ac030Component } from './view/ac030/ac030.component';
import { AC030Service } from './service/AC030Service';
import { Ac031Component } from './view/ac031/ac031.component';
import { Ac035Component } from './view/ac035/ac035.component';
import { AC035Service } from './service/AC035Service';
import { Ac036Component } from './view/ac036/ac036.component';
import { AC036Service } from './service/AC036Service';
import { Ac050Component } from './view/ac050/ac050.component';
import { AC050Service } from './service/AC050Service';
import { Ac080Component } from './view/ac080/ac080.component';
import { AC080Service } from './service/AC080Service';
import { Ac081Component } from './view/ac081/ac081.component';
import { AC081Service } from './service/AC081Service';
import { Ac085Component } from './view/ac085/ac085.component';
import { AC085Service } from './service/AC085Service';
import { Ac086Component } from './view/ac086/ac086.component';
import { AC086Service } from './service/AC086Service';
import { Ac090Component } from './view/ac090/ac090.component';
import { AC090Service } from './service/AC090Service';
import { Ac100Component } from './view/ac100/ac100.component';
import { AC100Service } from './service/AC100Servive';
import { Ac101Component } from './view/ac101/ac101.component';
import { AC101Service } from './service/AC101Service';
import { Ac110Component } from './view/ac110/ac110.component';
import { AC110Service } from './service/AC110Service';
import { Ac180Component } from './view/ac180/ac180.component';
import { AC180Service } from './service/AC180Service';
import { Ac181Component } from './view/ac181/ac181.component';
import { AC181Service } from './service/AC181Service';
import { Ac190Component } from './view/ac190/ac190.component';
import { AC190Service } from './service/AC190Service';
import { Ac210Component } from './view/ac210/ac210.component';
import { AC210Service } from './service/AC210Service';
import { Ac300Component } from './view/ac300/ac300.component';
import { AC300Service } from './service/AC300Service';
import { Ac301Component } from './view/ac301/ac301.component';
import { AC301Service } from './service/AC301Service';
import { Ac302Component } from './view/ac302/ac302.component';
import { AC302Service } from './service/AC302Service';
import { Ac309Component } from './view/ac309/ac309.component';
import { AC309Service } from './service/AC309Service';
import { Ac310Component } from './view/ac310/ac310.component';
import { AC310Service } from './service/AC310Service';
import { Ac311Component } from './view/ac311/ac311.component';
import { AC311Service } from './service/AC311Service';
import { Ac312Component } from './view/ac312/ac312.component';
import { AC312Service } from './service/AC312Service';
import { Ac320Component } from './view/ac320/ac320.component';
import { AC320Service } from './service/AC320Service';
import { Ac321Component } from './view/ac321/ac321.component';
import { AC321Service } from './service/AC321Service';
import { Ac322Component } from './view/ac322/ac322.component';
import { AC322Service } from './service/AC322Service';
import { Ac360Component } from './view/ac360/ac360.component';
import { Ac361Component } from './view/ac361/ac361.component';
import { Ac380Component } from './view/ac380/ac380.component';
import { AC380Service } from './service/AC380Service';
import { Ac381Component } from './view/ac381/ac381.component';
import { AC381Service } from './service/AC381Service';
import { Ac701Component } from './view/ac701/ac701.component';
import { AC701Service } from './service/AC701Service';
import { Ac900Component } from './view/ac900/ac900.component';
import { AC900Service } from './service/AC900Service';
import { Ac901Component } from './view/ac901/ac901.component';
import { AC901Service } from './service/AC901Service';
import { Ac910Component } from './view/ac910/ac910.component';
import { AC910Service } from './service/AC910Service';
import { LogoutComponent } from './component/logout/logout.component';
import { LogoutService } from './service/logoutServive';
import { CommonComponentService } from './service/CommonComponentService';

import { SampleTestComponent } from './view/sample-test/sample-test.component';
import { NpcTestComponent } from './view/npc-test/npc-test.component';

import { WjGridModule } from 'wijmo/wijmo.angular2.grid';
import { WjInputModule, WjPopup } from 'wijmo/wijmo.angular2.input';
import { WjNavModule } from 'wijmo/wijmo.angular2.nav';
import { WjFlexGridModuleEx } from './component/wj-flex-grid-ex/wj-flex-grid-ex';

import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { SideMenuScaleEvent } from './event/side.menu.scale.event';
import { ETextInputModule } from "./component/e-text-input/e-text-input.component";
import { EZipCodeInputModule } from "./component/e-zip-code-input/e-zip-code-input.component";
import { EDropDownListModule } from "./component/e-drop-down-list/e-drop-down-list.component";
import { EMoneyInputModule } from "./component/e-money-input/e-money-input.component";
import { ENumberInputModule } from "./component/e-number-input/e-number-input.component";
import { ENumberStepperModule } from './component/e-number-stepper/e-number-stepper.component';
import { Ac999Component } from './view/ac999/ac999.component';
import { ECodeInputModule } from './component/e-code-input/e-code-input.component';
import { EAlertModule } from './component/e-alert/e-alert.component';
import { ViewBaseModule } from './component/view-base/view-base.component';
import { EPopupInputModule } from './component/e-popup-input/e-popup-input.component';
import { EConfigureReportPopModule } from './component/e-configure-report-pop/e-configure-report-pop.component';
import { EDateFieldModule } from './component/e-date-field/e-date-field.component';
import { EDateFieldExModule } from './component/e-date-field-ex/e-date-field-ex.component';
import { EAlphaNumInputModule } from "./component/e-alpha-num-input/e-alpha-num-input.component";
import { EHalfWidthCharInputModule } from "./component/e-half-width-char-input/e-half-width-char-input.component";
import { ETelNoInputModule } from "./component/e-tel-no-input/e-tel-no-input.component";
import { ETabBarModule } from './component/e-tab-bar/e-tab-bar.component';
import { ETabBarDecoModule } from './component/e-tab-bar-deco/e-tab-bar-deco.component';
import { EMonthSliderModule } from "./component/e-month-slider/e-month-slider.component";
import { ECustomerInputModule } from './component/e-customer-popup-input/supportClass/e-customer-input/e-customer-input.component';
import { ECustomerPopupInputModule } from './component/e-customer-popup-input/e-customer-popup-input.component';
import { EProgressBarModule } from './component/e-progress-bar/e-progress-bar.component';
import { EAcTitlePopupInputModule } from './component/e-ac-title-popup-input/e-ac-title-popup-input.component';
import { EAcTitleInputModule } from './component/e-ac-title-popup-input/supportClass/e-ac-title-input/e-ac-title-input.component';
import { EAcSubTitleInputModule } from './component/e-ac-title-popup-input/supportClass/e-ac-sub-title-input/e-ac-sub-title-input.component';
import { EConsumptionTaxPopupInputModule } from './component/e-consumption-tax-popup-input/e-consumption-tax-popup-input.component';
import { EConsumptionTaxInputModule } from './component/e-consumption-tax-popup-input/supportClass/e-consumption-tax-input/e-consumption-tax-input';
import { SearchBankInputModule } from './component/search-bank-input/search-bank-input.component';
import { ETextAreaModule } from './component/e-text-area/e-text-area.component';
import { AcReceivableSlipModule } from './component/ac-receivable-slip/ac-receivable-slip.component';
import { AcPayableSlipModule } from './component/ac-payable-slip/ac-payable-slip.component';
import { TransferSlipModule } from './component/transfer-slip/transfer-slip.component';
import { WjGaugeModule } from 'wijmo/wijmo.angular2.gauge';
import { NoCommaModule } from './pipe/no-comma.pipe';
import { ETaxRateSelectModule } from './component/e-tax-rate-select/e-tax-rate-select.component';
import { ESegmentSelectModule } from './component/e-segment-select/e-segment-select.component';
import { UnprocessedEviModule } from './component/unprocessed-evi/unprocessed-evi.component';
import { EMoneyLabelModule } from './component/e-money-label/e-money-label.component';
import { ESummaryDatePopupModule } from './component/e-summary-date-popup/e-summary-date-popup';
import { SummaryMasterPopupModule } from './component/e-summary-master-popup/e-summary-master-popup';
import { ESummaryMasterPopupModule } from './component/e-summary-master-popup/supportClass/e-summary-master-popup/e-summary-master-popup-input';
import { EApprovalStampModule } from './component/e-approval-stamp/e-approval-stamp.component';
import { ESummaryDateInputModule } from './component/e-summary-date-popup/supportClass/e-summary-date-input/e-summary-date-input';
import { DatePipe } from '@angular/common';
import { UnlinkEviModule } from './component/unlink-evi/unlink-evi.component';
import { GetAcSubTitleListService } from './service/GetAcSubTitleListService';
import { AttachmentEviModule } from './component/attachment-evi/attachment-evi.component';
import { Ac510Component } from './view/ac510/ac510.component';
import { AC510Service } from './service/AC510Service';
import { FileUploadModule } from 'ng2-file-upload';
import { CookieService } from "ngx-cookie-service";
import { Ac000Util } from './view/ac000/supportClass/ac000util';
import { ConditionEviPopupModule } from './component/condition-evi-popup/condition-evi-popup.component';
import { ConditionEviPopupService } from './service/ConditionEviPopupService';
import { CandidateJournalListComponent } from './component/candidate-journal-list/candidate-journal-list.component';
@Injectable()
export class XhrInterceptor implements HttpInterceptor {
    intercept(req: HttpRequest<any>, next: HttpHandler) {
        const xhr = req.clone({
        headers: req.headers.set('X-Requested-With', 'XMLHttpRequest')
        });
        return next.handle(xhr);
    }
}

@NgModule({
    declarations: [
        AppComponent,
        Ac000Component,
        // AC000 support
        topMenu,
        sideMenu,
        Ac001Component,
        Ac002Component,
        Ac010Component,
        Ac011Component,
        Ac015Component,
        Ac020Component,
        Ac030Component,
        Ac031Component,
        Ac035Component,
        Ac036Component,
        Ac050Component,
        Ac080Component,
        Ac081Component,
        Ac085Component,
        Ac086Component,
        Ac090Component,
        Ac100Component,
        Ac101Component,
        Ac110Component,
        Ac180Component,
        Ac181Component,
        Ac190Component,
        Ac210Component,
        Ac300Component,
        Ac301Component,
        Ac302Component,
        Ac309Component,
        Ac310Component,
        Ac320Component,
        Ac321Component,
        Ac322Component,
        Ac380Component,
        Ac381Component,
        Ac510Component,
        Ac701Component,
        Ac900Component,
        Ac901Component,
        Ac910Component,
        Ac999Component,
        LogoutComponent,
        SampleTestComponent,
        NpcTestComponent,
        Ac311Component,
        Ac312Component,
        Ac360Component,
        Ac361Component,
        CandidateJournalListComponent,
        // カスタム コンポーネント系
    ],
    imports: [
        BrowserModule,
        FormsModule,
        HttpClientModule,
        AppRoutingModule,
        // ngx-bootstrap
        TooltipModule.forRoot(),
        // wijmo
        ViewBaseModule,
        WjGridModule,
        WjInputModule,
        WjNavModule,
        WjFlexGridModuleEx,
        WjGaugeModule,
        ETextInputModule,
        ETextAreaModule,
        ENumberInputModule,
        ENumberStepperModule,
        ECodeInputModule,
        EZipCodeInputModule,
        EDropDownListModule,
        EMoneyInputModule,
        EAlertModule,
        EPopupInputModule,
        EConfigureReportPopModule,
        EDateFieldModule,
        EDateFieldExModule,
        EAlphaNumInputModule,
        EHalfWidthCharInputModule,
        ETelNoInputModule,
        ETabBarModule,
        ETabBarDecoModule,
        EMonthSliderModule,
        ECustomerInputModule,
        ECustomerPopupInputModule,
        EProgressBarModule,
        EAcTitlePopupInputModule,
        EAcTitleInputModule,
        EAcSubTitleInputModule,
        EConsumptionTaxPopupInputModule,
        EConsumptionTaxInputModule,
        SearchBankInputModule,
        AcReceivableSlipModule,
        AcPayableSlipModule,
        TransferSlipModule,
        NoCommaModule,
        ETaxRateSelectModule,
        ESegmentSelectModule,
        UnprocessedEviModule,
        UnlinkEviModule,
        AttachmentEviModule,
        EMoneyLabelModule,
        ESummaryDatePopupModule,
        SummaryMasterPopupModule,
        ESummaryMasterPopupModule,
        EApprovalStampModule,
        ESummaryDateInputModule,
        FileUploadModule,
        ConditionEviPopupModule
    ],
    providers: [
        EcoKaikeiProperty,
        AC000Service,
        AC001Service,
        AC002Service,
        AC010Service,
        AC011Service,
        AC015Service,
        AC020Service,
        AC030Service,
        AC035Service,
        AC036Service,
        AC050Service,
        AC080Service,
        AC081Service,
        AC085Service,
        AC086Service,
        AC090Service,
        AC100Service,
        AC101Service,
        AC110Service,
        AC180Service,
        AC181Service,
        AC190Service,
        AC210Service,
        AC300Service,
        AC301Service,
        AC302Service,
        AC309Service,
        AC310Service,
        AC311Service,
        AC312Service,
        AC320Service,
        AC321Service,
        AC322Service,
        AC380Service,
        AC381Service,
        AC510Service,
        AC701Service,
        AC900Service,
        AC901Service,
        AC910Service,
        IndexService,
        LogoutService,
        { provide: HTTP_INTERCEPTORS, useClass: XhrInterceptor, multi: true },
        SideMenuScaleEvent,
        CommonComponentService,
        DatePipe,
        GetAcSubTitleListService,
        CookieService,
        Ac000Util,
        ConditionEviPopupService
    ],
    bootstrap: [AppComponent]
})
export class AppModule {}
